// Regression suite runner. Loads the core modules (no browser, no DOM) and plays complete AI-vs-AI battles.
//   node tests/run.mjs           full suite: all 64 rule combinations x 2 victory conditions, plus extra scenarios
//   node tests/run.mjs --quick   about a dozen battles
// Exits with code 1 if anything fails. Turn-limit endings are reported as warnings (likely stalemates).
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const code = manifest.core.map(f => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
const ctx = vm.createContext({ console, Date, Math, JSON, Promise, Object, Array, Map, Set, Number, String, Error });
vm.runInContext(`'use strict';\n${code}`, ctx, { filename: 'core.js' });

const suite = process.argv.includes('--quick') ? 'quick' : 'full';
const icon = { pass: 'PASS', warn: 'WARN', fail: 'FAIL' };
const t0 = Date.now();
ctx.__progress = (frac, row) =>
  console.log(`${icon[row.status]}  ${row.label.padEnd(58)} ${row.detail}${row.ms ? `  (${row.ms} ms)` : ''}`);
console.log(`Iron Hex regression suite: ${suite}\n`);
const rows = await vm.runInContext(`runSuite(${JSON.stringify(suite)}, (f, r) => __progress(f, r))`, ctx);
const count = s => rows.filter(r => r.status === s).length;
console.log(`\n${count('pass')} passed, ${count('warn')} warnings, ${count('fail')} failed in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
process.exit(count('fail') ? 1 : 0);
