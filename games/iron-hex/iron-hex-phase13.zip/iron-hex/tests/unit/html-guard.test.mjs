// Guard: player-controlled text must never reach HTML unescaped. Every HTML template interpolation of a name-like
// field (.name, .title, .label, ...) must go through escapeHtml() or sit inside an html`` template (which escapes
// everything), unless it is on the reviewed allowlist of developer-defined constants (rule labels, strategy names,
// structure names...). Parsed with acorn, so it knows exactly which template each ${...} belongs to.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import * as acorn from 'acorn';
import * as walk from 'acorn-walk';
import { root } from '../core.mjs';

const ALLOWED = JSON.parse(fs.readFileSync(new URL('./html-allowlist.json', import.meta.url), 'utf8'));
const FIELD = /\.(name|short|role|title|mapName|label|blurb|text|desc|detail|mission|source|caveats|note)\b/;

export function unescapedInterpolations() {
  const out = [],
    manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
  // Every interface file that ships; allowlist entries are keyed by base name, so moving a file between folders keeps them valid.
  for (const rel of [...manifest.ui].sort((x, y) => path.basename(x).localeCompare(path.basename(y)))) {
    const f = path.basename(rel);
    const src = fs.readFileSync(path.join(root, rel), 'utf8');
    const ast = acorn.parse(src, { ecmaVersion: 2022, sourceType: 'script' });
    walk.ancestor(ast, {
      TemplateLiteral(node, _state, anc) {
        const parents = anc.slice(0, -1);
        const htmlTagged = n => n.type === 'TaggedTemplateExpression' && n.tag.type === 'Identifier' && n.tag.name === 'html';
        if (parents.some(htmlTagged)) return; // inside html``: escaped automatically
        if (!node.quasis.some(q => q.value.raw.includes('<'))) return; // not HTML
        if (
          parents.some(
            p => p.type === 'AssignmentExpression' && p.left.type === 'MemberExpression' && p.left.property.name === 'textContent'
          )
        )
          return;
        for (const e of node.expressions) {
          const text = src.slice(e.start, e.end);
          if (!FIELD.test(text) || /escapeHtml/.test(text)) continue;
          out.push(`${f}: ${text.split(/\s+/).join(' ')}`);
        }
      },
    });
  }
  return out;
}

test('no unescaped player text in HTML templates', () => {
  const unexpected = unescapedInterpolations().filter(x => !ALLOWED.includes(x));
  assert.deepEqual(
    unexpected,
    [],
    'Escape these with escapeHtml() or html``, or (if they are developer constants) add them to html-allowlist.json after review'
  );
});
