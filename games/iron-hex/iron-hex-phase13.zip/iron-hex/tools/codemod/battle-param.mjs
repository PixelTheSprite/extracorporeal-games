// Codemod: pass the battle explicitly through game logic (engine/).
// Every top-level function that reads appState.battle or R.map, directly or through functions it calls, gets a
// parameter B (defaulting to appState.battle, so interface callers keep working); its reads become B / B.map;
// and every call to such a function from a place where B exists passes B. Battle owners (functions that create
// or swap appState.battle) and the test harness are left alone.   node tools/codemod/battle-param.mjs [--write]
import fs from 'node:fs';
import path from 'node:path';
import * as acorn from 'acorn';
import * as walk from 'acorn-walk';
const root = path.join(path.dirname(new URL(import.meta.url).pathname), '../..');
const WRITE = process.argv.includes('--write');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const SKIP_FILES = new Set(['engine/harness/harness-setup.js', 'engine/harness/harness-suite.js', 'engine/harness/harness-checks.js']);
const files = manifest.core.filter(f => !SKIP_FILES.has(f));
const src = Object.fromEntries(files.map(f => [f, fs.readFileSync(path.join(root, f), 'utf8')]));
const ast = Object.fromEntries(files.map(f => [f, acorn.parse(src[f], { ecmaVersion: 2022, locations: true })]));
const isBattleRead = n =>
  n.type === 'MemberExpression' &&
  !n.computed &&
  n.object.type === 'Identifier' &&
  n.object.name === 'appState' &&
  n.property.name === 'battle';
const isMapRead = n =>
  n.type === 'MemberExpression' && !n.computed && n.object.type === 'Identifier' && n.object.name === 'R' && n.property.name === 'map';
// 1. top-level functions
const fns = new Map();
for (const f of files)
  for (const st of ast[f].body) {
    if (st.type === 'FunctionDeclaration') fns.set(st.id.name, { file: f, node: st, name: st.id.name });
    if (st.type === 'VariableDeclaration')
      for (const d of st.declarations)
        if (d.id.type === 'Identifier' && d.init && /^(ArrowFunctionExpression|FunctionExpression)$/.test(d.init.type))
          fns.set(d.id.name, { file: f, node: d.init, name: d.id.name });
  }
// owners: functions that assign appState.battle or R.map
const owners = new Set();
for (const fn of fns.values())
  walk.simple(fn.node.body, {
    AssignmentExpression(a) {
      if (isBattleRead(a.left) || isMapRead(a.left)) owners.add(fn.name);
    },
  });
// a function that calls a battle owner (e.g. creates a new battle, then works on it) is an owner too
{
  const callsOf = new Map();
  for (const fn of fns.values()) {
    const cs = new Set();
    walk.simple(fn.node.body, {
      CallExpression(c) {
        if (c.callee.type === 'Identifier' && fns.has(c.callee.name)) cs.add(c.callee.name);
      },
    });
    callsOf.set(fn.name, cs);
  }
  for (let changed = true; changed;) {
    changed = false;
    for (const [f, cs] of callsOf)
      if (!owners.has(f) && [...cs].some(c => owners.has(c))) {
        owners.add(f);
        changed = true;
      }
  }
}
// 2. direct readers and the call graph
const direct = new Set(),
  calls = new Map();
for (const fn of fns.values()) {
  const cs = new Set();
  walk.full(fn.node.body, n => {
    if ((isBattleRead(n) || isMapRead(n)) && !owners.has(fn.name)) direct.add(fn.name);
    if (n.type === 'CallExpression' && n.callee.type === 'Identifier' && fns.has(n.callee.name)) cs.add(n.callee.name);
  });
  // default parameters reading appState.battle count as "already takes B" rather than a body read
  calls.set(fn.name, cs);
}
const S = new Set(direct);
for (let changed = true; changed;) {
  changed = false;
  for (const [f, cs] of calls)
    if (!S.has(f) && !owners.has(f) && [...cs].some(c => S.has(c))) {
      S.add(f);
      changed = true;
    }
}
const boundNames = id => {
  const out = [];
  walk.full(id, n => {
    if (n.type === 'Identifier') out.push(n.name);
  });
  return out;
};
// functions that already have their own B (destructured from a context object, e.g. the AI's planning steps)
const ownsB = fnNode =>
  fnNode.body.type === 'BlockStatement' &&
  fnNode.body.body.some(
    st => st.type === 'VariableDeclaration' && st.declarations.some(d => d.id.type !== 'Identifier' && boundNames(d.id).includes('B'))
  );
for (const name of [...S]) if (ownsB(fns.get(name).node)) S.delete(name); // they pass their B on, but need no parameter
// 3. where B goes for each function in S; conflicts
const plan = new Map(),
  conflicts = [];
const paramName = p =>
  p.type === 'Identifier' ? p.name : p.type === 'AssignmentPattern' && p.left.type === 'Identifier' ? p.left.name : null;
for (const name of S) {
  const fn = fns.get(name),
    ps = fn.node.params;
  if (ps.some(p => p.type === 'RestElement')) {
    conflicts.push(name + ': rest parameter');
    S.delete(name);
    continue;
  }
  let idx = ps.findIndex(p => paramName(p) === 'B'),
    add = idx < 0;
  if (add) idx = ps.length;
  // does the body declare B itself? (const B = appState.battle is fine: it gets removed)
  let localB = null,
    otherB = false;
  if (fn.node.body.type === 'BlockStatement')
    for (const st of fn.node.body.body)
      if (st.type === 'VariableDeclaration')
        for (const d of st.declarations)
          if (d.id.type === 'Identifier' && d.id.name === 'B') {
            if (d.init && isBattleRead(d.init)) localB = { st, d };
            else otherB = true;
          }
  if (otherB) {
    conflicts.push(name + ': declares its own B');
    S.delete(name);
    continue;
  }
  plan.set(name, { idx, add, localB });
}
// 4. edits
const edits = Object.fromEntries(files.map(f => [f, []]));
const ed = (f, s, e, t) => edits[f].push({ s, e, t });
const declaresB = fnNode => {
  if (fnNode.params.some(p => paramName(p) === 'B')) return true;
  let found = false;
  if (fnNode.body.type === 'BlockStatement')
    for (const st of fnNode.body.body)
      if (st.type === 'VariableDeclaration') for (const d of st.declarations) if (boundNames(d.id).includes('B')) found = true;
  return found;
};
let addedParams = 0,
  rewrittenReads = 0,
  passedCalls = 0;
for (const fn of fns.values()) {
  const f = fn.file,
    s = src[f],
    inS = S.has(fn.name),
    p = plan.get(fn.name);
  const hasB = inS || (!owners.has(fn.name) && declaresB(fn.node));
  if (inS && p.add) {
    const ps = fn.node.params;
    const text = 'B = appState.battle';
    const bare = fn.node.type === 'ArrowFunctionExpression' && ps.length === 1 && s[fn.node.start] !== '(';
    if (bare)
      ed(f, ps[0].start, ps[0].end, '(' + s.slice(ps[0].start, ps[0].end) + ', ' + text + ')'); // u => ...  becomes  (u, B = ...) => ...
    else if (ps.length) ed(f, ps[ps.length - 1].end, ps[ps.length - 1].end, ', ' + text);
    else {
      // empty parameter list: find "()" before the body / arrow
      const head = s.slice(fn.node.start, fn.node.body.start),
        i = head.indexOf('(');
      ed(f, fn.node.start + i + 1, fn.node.start + i + 1, text);
    }
    addedParams++;
  }
  if (inS && p.localB) {
    const { st, d } = p.localB;
    if (st.declarations.length === 1) ed(f, st.start, st.end, '');
    else {
      const i = st.declarations.indexOf(d),
        next = st.declarations[i + 1],
        prev = st.declarations[i - 1];
      if (next) ed(f, d.start, next.start, '');
      else ed(f, prev.end, d.end, '');
    }
  }
  if (inS)
    walk.full(fn.node.body, n => {
      if (isBattleRead(n) && !(p.localB && n.start >= p.localB.d.start && n.end <= p.localB.d.end)) {
        ed(f, n.start, n.end, 'B');
        rewrittenReads++;
      } else if (isMapRead(n)) {
        ed(f, n.start, n.end, 'B.map');
        rewrittenReads++;
      }
    });
  if (hasB)
    walk.simple(fn.node.body, {
      CallExpression(c) {
        if (c.callee.type !== 'Identifier' || !S.has(c.callee.name) || c.arguments.some(a => a.type === 'SpreadElement')) return;
        const { idx } = plan.get(c.callee.name),
          n = c.arguments.length;
        if (n > idx) return; // already passes something in B's place
        const pad = Array(idx - n)
          .fill('undefined')
          .concat(['B'])
          .join(', ');
        const at = n ? c.arguments[n - 1].end : c.callee.end + src[f].slice(c.callee.end, c.end).indexOf('(') + 1;
        ed(f, at, at, (n ? ', ' : '') + pad);
        passedCalls++;
      },
    });
}
// apply (later edits first; skip edits nested inside a removed declaration)
let changedFiles = 0;
for (const f of files) {
  const es = edits[f].sort((a, b) => b.s - a.s || b.e - a.e);
  let out = src[f],
    lastStart = Infinity;
  for (const e of es) {
    if (e.e > lastStart && e.s < lastStart) continue;
    out = out.slice(0, e.s) + e.t + out.slice(e.e);
    lastStart = e.s;
  }
  if (out !== src[f]) {
    changedFiles++;
    if (WRITE) fs.writeFileSync(path.join(root, f), out);
  }
}
console.log(
  `functions taking B: ${S.size} (${direct.size} read it directly) · parameters added: ${addedParams} · reads rewritten: ${rewrittenReads} · calls now passing B: ${passedCalls} · files: ${changedFiles}`
);
console.log('owners left alone:', [...owners].join(', '));
if (conflicts.length) console.log('skipped:', conflicts.join('; '));
if (!WRITE) console.log('(dry run: add --write to apply)');
// Safety check: S functions used as values (callbacks) anywhere in core or ui would receive stray arguments in B's place.
const valueRefs = [];
for (const f of manifest.core.concat(manifest.ui)) {
  const s = fs.readFileSync(path.join(root, f), 'utf8'),
    a = acorn.parse(s, { ecmaVersion: 2022, locations: true });
  walk.ancestor(a, {
    Identifier(n, anc) {
      if (!S.has(n.name)) return;
      const parent = anc[anc.length - 2];
      if (!parent) return;
      if (parent.type === 'CallExpression' && parent.callee === n) return;
      if ((parent.type === 'FunctionDeclaration' && parent.id === n) || (parent.type === 'VariableDeclarator' && parent.id === n)) return;
      if (parent.type === 'MemberExpression' && parent.property === n && !parent.computed) return;
      if (parent.type === 'Property' && parent.key === n && !parent.shorthand) return;
      valueRefs.push(`${f}:${n.loc.start.line} ${n.name}`);
    },
  });
}
console.log('used as values (need wrapping):', valueRefs.length ? valueRefs.join(', ') : 'none');
