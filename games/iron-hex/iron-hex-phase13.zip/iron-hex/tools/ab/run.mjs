// A/B experiment: plays seeded AI-vs-AI battles under different Battle settings and measures, per battle:
// turns, playback seconds per turn (from a timing view that adds up every pause and tween the browser would play),
// orders per turn (your units needing orders), and an estimated wall-clock turn and game time.
import fs from 'node:fs'; import vm from 'node:vm';
const root = new URL('../..', import.meta.url).pathname.replace(/\/$/, '');
const m = JSON.parse(fs.readFileSync(root + '/manifest.json', 'utf8'));
const code = m.core.map(f => fs.readFileSync(root + '/' + f, 'utf8')).join('\n');
const ctx = vm.createContext({ console, Date, Math, JSON, Promise, Object, Array, Map, Set, Number, String, Error });
vm.runInContext(`'use strict';\n${code}`, ctx);
const [,, which, out] = process.argv;
const VARIANTS = JSON.parse(fs.readFileSync(new URL('variants.json', import.meta.url), 'utf8')).filter((v, i) => String(i % 3) === which || which === 'all');
const SEEDS = JSON.parse(fs.readFileSync(new URL('seeds.json', import.meta.url), 'utf8'));
const results = await vm.runInContext(`(async () => {
  const SHOT_MS = { land:340, air:260, sea:750 };
  const res = [];
  for (const v of ${JSON.stringify(VARIANTS)}){
    for (const sd of ${JSON.stringify(SEEDS)}){
      let clock = 0, shotEnd = 0;
      const TV = Object.assign({}, NullView, {
        sleep: ms => { clock += ms; return Promise.resolve(); },
        tween: (d, fn) => { clock += d; fn(1); return Promise.resolve(); },
        shot: sh => { shotEnd = Math.max(shotEnd, clock + 90 + SHOT_MS[UNIT_TYPES[sh.u.type].domain] + 250); return Promise.resolve(); },
        sshot: sh => { shotEnd = Math.max(shotEnd, clock + 90 + SHOT_MS[UNIT_TYPES[sh.u.type].domain] + 250); return Promise.resolve(); },
      });
      VIEW = TV;
      const base = defaultSettings(), defRules = Object.assign({}, base.rules), vs = JSON.parse(JSON.stringify(v.settings || {}));
      appState.settings = Object.assign(base, { mapId:sd.map, randomSeed:sd.mapSeed }, vs);
      appState.settings.rules = Object.assign(defRules, vs.rules || {});   // flip only the listed rules
      newBattle(sd.seed);
      let o = { end:false }, turns = 0, play = 0, orders = 0;
      const t0 = Date.now();
      while (!o.end){
        const B = appState.battle;
        orders += aliveUnits().filter(u => u.pid === 0 && !u.in).length;
        clock = 900;            // the "Engage!" banner pause before every turn
        shotEnd = 0;
        o = await simulateTurn(planAllAI('balanced'));
        play += Math.max(clock, shotEnd); turns++;
      }
      const B = appState.battle, win = o.winner !== undefined ? o.winner : pickWinner(o.remaining);
      res.push({ variant:v.name, map:sd.map, seed:sd.seed, turns, reason:o.reason, youWon:!!win && win.id === 0,
        playPerTurn:play / turns / 1000, ordersPerTurn:orders / turns, cpuMs:Date.now() - t0 });
    }
  }
  return res;
})()`, ctx);
fs.writeFileSync(out, JSON.stringify(results));
console.log('done', which, results.length);
