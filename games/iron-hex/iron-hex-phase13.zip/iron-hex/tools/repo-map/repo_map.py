#!/usr/bin/env python3
"""Build a compact map of a project: files, sizes, imports, and top-level names with line numbers.

Usage:
    python repo_map.py SRC_DIR [--out docs/PROJECT_MAP.md] [--exclude dist,build] [--max-names 60]

Why: reading a whole codebase to find where a change goes costs tens of thousands of tokens.
The map costs a few hundred to a couple of thousand, and the line numbers let you open just the
function you need (view with view_range, or sed -n 'START,ENDp').

Recognises JS/TS (functions, classes, top-level const/let/var, exports, imports), Python
(def/class/imports), CSS (file size only), HTML (size, flags inline <script> monoliths), and
lists JSON/MD files by size. Dependency-free; regex based, so treat it as a guide, not a parser.
"""
import argparse
import datetime
import re
from pathlib import Path

SKIP_DIRS = {".git", "node_modules", "dist", "build", "coverage", ".next", "__pycache__", ".venv", "venv"}
JS_EXT = {".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx"}

JS_DECL = re.compile(
    r"^(?:export\s+(?:default\s+)?)?(?:async\s+)?"
    r"(?:function\*?\s+(?P<fn>[A-Za-z_$][\w$]*)"
    r"|class\s+(?P<cls>[A-Za-z_$][\w$]*)"
    r"|(?:const|let|var)\s+(?P<var>[A-Za-z_$][\w$]*)\s*=)"
)
JS_IMPORT = re.compile(r"""^\s*import\s+(?:.+?\s+from\s+)?['"]([^'"]+)['"]""")
JS_REQUIRE = re.compile(r"""require\(\s*['"]([^'"]+)['"]\s*\)""")
PY_DECL = re.compile(r"^(?:async\s+)?(def|class)\s+([A-Za-z_]\w*)")
PY_IMPORT = re.compile(r"^(?:from\s+(\S+)\s+import|import\s+(\S+))")


def tokens(n_chars):
    return max(1, n_chars // 4)


def scan_js(lines):
    names, imports = [], []
    for i, line in enumerate(lines, 1):
        m = JS_IMPORT.match(line) or None
        if m:
            imports.append(m.group(1))
            continue
        if "require(" in line and not line.startswith(" "):
            imports.extend(JS_REQUIRE.findall(line))
        d = JS_DECL.match(line)  # column 0 only: top-level declarations
        if d:
            if d.group("fn"):
                names.append((d.group("fn") + "()", i))
            elif d.group("cls"):
                names.append(("class " + d.group("cls"), i))
            else:
                v = d.group("var")
                # ALL_CAPS or table-like names are usually data; mark them
                names.append((v + ("*" if v.isupper() else ""), i))
    return names, imports


def scan_py(lines):
    names, imports = [], []
    for i, line in enumerate(lines, 1):
        d = PY_DECL.match(line)
        if d:
            names.append((d.group(2) + "()" if d.group(1) == "def" else "class " + d.group(2), i))
            continue
        m = PY_IMPORT.match(line)
        if m:
            imports.append(m.group(1) or m.group(2))
    return names, imports


def describe(path, root, max_names):
    rel = path.relative_to(root).as_posix()
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    ext = path.suffix.lower()
    head = f"- `{rel}` ({len(lines)} lines, ~{tokens(len(text)):,} tok)"
    notes = []
    if ext in JS_EXT:
        names, imports = scan_js(lines)
    elif ext == ".py":
        names, imports = scan_py(lines)
    elif ext in {".html", ".htm"}:
        if len(lines) > 800 and "<script" in text:
            notes.append("MONOLITH: inline script in a large HTML file, read by line range only")
        return head, notes, [], []
    else:
        return head, notes, [], []
    shown = names[:max_names]
    rest = len(names) - len(shown)
    return head, notes, [f"{n}:{ln}" for n, ln in shown] + ([f"+{rest} more"] if rest > 0 else []), imports


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src", help="project source directory")
    ap.add_argument("--out", help="write the map to this file instead of stdout")
    ap.add_argument("--exclude", default="", help="comma-separated extra names/paths to skip (for example the built single-file output)")
    ap.add_argument("--max-names", type=int, default=60, help="max names listed per file")
    ap.add_argument("--exts", default=".js,.mjs,.cjs,.jsx,.ts,.tsx,.py,.html,.css,.json,.md",
                    help="comma-separated extensions to include")
    args = ap.parse_args()

    root = Path(args.src).resolve()
    extra = {e.strip() for e in args.exclude.split(",") if e.strip()}
    exts = {e.strip().lower() for e in args.exts.split(",")}

    files = []
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in exts:
            continue
        parts = set(p.relative_to(root).parts)
        if parts & SKIP_DIRS or p.name in extra or p.relative_to(root).as_posix() in extra:
            continue
        files.append(p)

    out = []
    total_chars = 0
    body = []
    for p in files:
        total_chars += p.stat().st_size
        head, notes, names, imports = describe(p, root, args.max_names)
        body.append(head)
        for n in notes:
            body.append(f"  - {n}")
        if imports:
            uniq = list(dict.fromkeys(imports))
            body.append("  - imports: " + ", ".join(uniq[:12]) + (f", +{len(uniq) - 12} more" if len(uniq) > 12 else ""))
        if names:
            body.append("  - " + " ".join(names))

    stamp = datetime.date.today().isoformat()
    out.append("# Project map")
    out.append("")
    out.append(f"Generated {stamp} by repo_map.py from `{root.name}/`. {len(files)} files, ~{tokens(total_chars):,} tokens of source in total.")
    out.append("Names are `name:line`. `()` = function, `*` = ALL_CAPS constant (usually a data table). "
               "Read only the line ranges you need. Regenerate after structural changes.")
    out.append("")
    out.extend(body)
    result = "\n".join(out) + "\n"

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(result, encoding="utf-8")
        print(f"Wrote {args.out}: ~{tokens(len(result)):,} tokens describing ~{tokens(total_chars):,} tokens of source")
    else:
        print(result)


if __name__ == "__main__":
    main()
