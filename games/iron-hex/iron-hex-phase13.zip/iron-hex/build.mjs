// Builds dist/iron-hex.html: inlines ui/styles.css and every script in manifest.json (core, then ui)
// into ui/index.html. No dependencies; run with `node build.mjs`.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const manifest = JSON.parse(read('manifest.json'));
const files = [...manifest.core, ...manifest.ui];
const js = files.map(f => `// ===== ${f} =====\n${read(f)}`).join('\n');
const html = read('ui/index.html')
  .replace('/*@@STYLES@@*/', () => read('ui/styles.css'))
  .replace('//@@SCRIPTS@@', () => js);
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist', 'iron-hex.html'), html);
console.log(`Built dist/iron-hex.html: ${files.length} modules, ${html.split('\n').length} lines, ${Math.round(html.length / 1024)} KB`);
