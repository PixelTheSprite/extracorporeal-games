# Handoff: after Phase 13 (Restructure and export)

Date: 2026-10-17
Next: Phase 14 (Validation and release candidate), first step: `npm ci`, then run `npm test`, `npm run test:unit` and `npm run test:browser` in Claude Code (set `CHROMIUM_PATH`) to confirm the baseline there before changing anything.

## What changed
- Repository reorganized, no behavior change: `engine/` (battle, combat, ai, vision, economy, missions, replay, net, rules, harness), `content/` (skins, realmaps), `ui/` (screens, battle, editors, community, a11y, audio); `src/` is gone. Layout and the Phase 15 content list: `docs/notes/architecture.md`.
- Split along section comments: ai (3 files), harness (3), render (3), realism (4). Manifest order unchanged; 64 files became 73.
- New: `CLAUDE.md`, `docs/ROADMAP.md` (index), `docs/phases/01-20`, `docs/notes/` (architecture, balance, decisions, code-health), `docs/PROJECT_MAP.md`, `tools/repo-map/repo_map.py`.
- Version still 1.0.0-rc.3; published artifact: https://claude.ai/artifact/E3Eefgm6tCLUJdn62D1YXZ. The old roadmap Claude Doc is superseded by `docs/`.

## Decisions made (and why)
- `manifest.json` at the repo root and `index.html`/`styles.css` in `ui/`: `src/` would hold only three files after the move.
- `engine/harness/` (not `tests/`): the harness ships in the game's Diagnostics screen.
- Realism stays four batch files; one file per rule waits for ES modules (Phase 15).

## Gotchas
- Scripts are globals concatenated in `manifest.json` order; moving or adding a file means editing the manifest and respecting that order.
- The suite row "Version 1 save upgrades and plays to the end" varies run to run (migration seeds with `Math.random()`); compare everything else.
- html-guard allowlist entries are keyed by file base name; keep `ui/` base names unique.
- Browser tests need `CHROMIUM_PATH`. The full suite takes about 2.5 minutes.

## Verification
- Before and after the move: `npm test` 189 passed, 14 warnings, 0 failed, output identical except the row above; unit 40/40; browser 22/22. Built HTML identical apart from 9 added header comments. `tools/codemod/battle-param.mjs` dry run: nothing to change.
- Not verified: a live Claude Code session reading only `CLAUDE.md`, `ROADMAP.md`, `HANDOFF.md`; online match between two people, gallery share, phone performance, tutorial cold start (all Phase 14).

## Open items
- Choose missile values (`tools/ab/phase12-report.md`). Phase 14 work item.
- AI never blows bridges; economy and all-realism battles tend to stall. Phase 14 playtesting.
- Make the v1-migration suite row deterministic (found here, not fixed: no behavior change in Phase 13).

## Read first next time
- `docs/phases/14-validation-rc.md`, then `engine/combat/missiles.js` (values in `REAL`) and `tools/ab/phase12-report.md`
