# Iron Hex roadmap

Iron Hex is a single-file hex wargame (simultaneous orders, real-time resolution) with editors, campaigns, online play and replays. Part 1 (Phases 1-12) was built in chat; Phase 13 reorganized the repository for Claude Code; Part 2 (Phases 14-20) hardens the game, moves content to data, and ships it as a web app, desktop app and phone/tablet apps. The hosted Claude artifact stays a supported target.

Each phase ends at a gate. Phases are one file each in `docs/phases/`; shipped ones are condensed to outcomes and known issues. Only the next phase is detailed; later ones are filled in when they become current. Principles and open decisions: `docs/notes/decisions.md`. Architecture and the content-to-move list: `docs/notes/architecture.md`. Balance findings: `docs/notes/balance.md`.

Marks: ▶ next, done = shipped, planned = stub.

| # | Phase | Shape | Status | Gate |
|---|---|---|---|---|
| 1 | [Stabilize and balance](phases/01-stabilize.md) | Debug | done | every rule combination finishes without errors |
| 2 | [Unit Editor](phases/02-unit-editor.md) | Feature | done | a unit made from a vehicle name fights and survives save/load |
| 3 | [Map Editor](phases/03-map-editor.md) | Feature | done | a hand-made map builds, validates, saves, plays |
| 4 | [Infrastructure Editor](phases/04-infrastructure.md) | Feature | done | each structure works; the AI uses airfields and ports |
| 5 | [Campaign, Leaderboard, skins](phases/05-campaign-leaderboard.md) | Feature | done | a 3-mission campaign plays through with veterans |
| 6 | [Endgame and fixes](phases/06-endgame-fixes.md) | Debug | done | under 1 in 20 suite battles hit the turn limit |
| 7 | [Depth](phases/07-depth.md) | Feature | done | each system behind a toggle with AI support |
| 8 | [Play with people](phases/08-play-with-people.md) | Feature | done (simulated) | two devices finish a match; any battle replays |
| 9 | [Content and polish](phases/09-content-polish.md) | Feature | done | a newcomer learns from the tutorial alone |
| 10 | [Toward release](phases/10-toward-release.md) | Optimize | done | smooth on a mid-range phone; sharing works |
| 11 | [Realism toggles](phases/11-realism.md) | Feature | done | 22 rules each pass the suite alone and together |
| 12 | [Missiles and cities](phases/12-missiles-cities.md) | Feature | done; values open | both rules within targets; suite and replays pass |
| 13 | [Restructure and export](phases/13-restructure.md) | Data/engine split | done | same game, identical suite; fresh session oriented |
| 14 | [Validation and release candidate](phases/14-validation-rc.md) | Debug | ▶ next | Part 1 gates confirmed on real devices; missile values applied |
| 15 | [ES modules and content as data](phases/15-modules-content-data.md) | Data/engine split | planned | identical battles; new content touches only data files |
| 16 | [Platform layer](phases/16-platform-layer.md) | Feature | planned | game runs on each adapter set; online play outside Claude |
| 17 | [Installable web app](phases/17-installable-web-app.md) | Feature | planned | installs on computer and phone; plays a battle offline |
| 18 | [Desktop app](phases/18-desktop-app.md) | Feature | planned | signed builds on three systems open a saved map |
| 19 | [Phone and tablet apps](phases/19-phone-tablet-apps.md) | Feature | planned | real devices: battle, suspend/resume, online match |
| 20 | [Cross-platform release](phases/20-cross-platform-release.md) | Debug | planned | one tag builds everything; saves load on every platform |

## Notes
- [Code health](notes/code-health.md): the scan between Phases 7 and 8 (security, performance, explicit battle `B`).

## Open decisions
Backend for matches and the gallery (by Phase 16), desktop shell Tauri or Electron (Phase 18), distribution (Phase 20), 3D renderer and 3D import (after Phase 14), era scope, cosmetic-only skins, missile values (Phase 14). Details in `docs/notes/decisions.md`.

## Carried in to Phase 14
Missile values to choose; the AI never blows bridges; economy and all-realism battles tend to stall; unconfirmed on real devices: online match, gallery share, phone performance, tutorial cold start.
