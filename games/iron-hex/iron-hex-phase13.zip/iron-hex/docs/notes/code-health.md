# Code health (between Phases 7 and 8)

**Shape:** Optimize and harden
**Status:** Done. Every performance and refactor change was checked by running the full suite before and after and comparing battle by battle: identical.

## Outcomes
- Security: custom unit ids restricted; every HTML attribute value escaped; escape-by-default `html` tagged template plus a parser-based guard test (`tests/unit/html-guard.test.mjs`, allowlist `tests/unit/html-allowlist.json`, keyed by file base name); imports over 5 MB refused.
- Performance (40 x 30, 4 armies, all rules): AI planning 324 to 184 ms a turn (one army per frame); vision cached; priority heap in all pathfinders; units indexed by id; suite 43% faster.
- Readability: `planAI`, `simulateTurn`, `logistics`, `runSuite` split into named steps; `B.rules.x` is the one way to read rules; `AI_WEIGHTS` in one table; Prettier at 140 columns.
- Explicit battle: 174 functions take the battle as `B` (default `appState.battle`), 495 calls pass it on; the battle carries its own map. Made by `tools/codemod/battle-param.mjs`; `tests/unit/explicit-battle.test.mjs` plays a battle handed in explicitly with a decoy global.
- Testing: Playwright browser tests, unit tests for pure functions, suite seeds derived from case names.

## Known issues
- Shared-board results can't be verified (kept, labeled unverified, by choice).
