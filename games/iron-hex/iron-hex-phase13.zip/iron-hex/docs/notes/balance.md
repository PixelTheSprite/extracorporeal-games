# Balance notes

Where the numbers live: every tunable rule value is in `REAL` (see `architecture.md`); AI scoring is `AI_WEIGHTS` in `engine/ai/ai-plan.js`; A/B tooling is `tools/ab` (`run.mjs`, `strategic.mjs`, `agg.py`, `variants.json`, `seeds.json`).

## Findings so far
- Territory: target 60% with Spread limited to 3 hexes from a supply point made territory wins rare (1 of 14); a 4-hex radius with a 50% target split wins evenly. The shipped defaults are the 60% / 3-hex pair; revisit if territory games feel too slow.
- Stalls: turn-limit endings were 3 of 133 (Phase 1), 16 of 139 after structures (Phase 4), 7 of 148 (4.7%) after endgame AI and Supply exhaustion (Phase 6). Gate for Part 1 is under 1 in 20.
- Sandstorm Strait: the southeast army wins about two-thirds of AI games; a map-layout effect.
- Economy and Mid-battle production, Timed reinforcements, and all-realism battles: AI-versus-AI battles tend to run long or stall because both sides replace losses as fast as they take them.
- Missiles at defaults deal 2% of damage with 67% intercepted; the report's suggested mix (3-turn charge, 14-hex range, 20% interception, targets don't guard themselves) reaches 17% with 94% high-value hits. Not yet applied: see `tools/ab/phase12-report.md`.
- City development earns about 2.9x the investment over a battle (designed payback 10-17.5 turns per level): within target.
- Performance on the largest setup (40 x 30, 4 armies, all rules): AI planning about 46 ms per army, planned across frames.

## Open
- AI never blows bridges.
- Missile values to choose (Phase 14).
- Balance-data telemetry is opt-in; no playtest loop has run yet.
