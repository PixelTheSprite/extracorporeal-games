# Decisions

## Settled
- Unit Editor lookups run in the hosted game through Claude, with copy-and-paste as the fallback.
- Economy, production and capital loss are separate optional rules (Income, Mid-battle production, Capital loss); every unit has a price, and the roster picker has an optional point budget.
- Online play is asynchronous matches plus hot-seat; no real-time play.
- Shipped art periods beyond the base units: Medieval Europe, Ancient Mediterranean, Ancient China, Maori and Inca (Maori and Inca show warriors, tools, canoes and rafts only).
- Leaderboard: local records plus an optional shared board (results labeled unverified).
- Campaign came after the three editors because its missions are built from their maps, units and structures.
- Export to Claude Code after Phase 13: later phases need native toolchains, git, CI and real devices.
- Phase 13 moves and splits files only; ES modules and JSON content wait for Phase 15.
- Target layout: `engine/`, `content/`, `ui/`, `platform/`, `apps/`, `tests/`, `tools/`, `docs/`. Deviations recorded in Phase 13: `engine/harness/` added; `manifest.json` lives at the repo root and `index.html`/`styles.css` live in `ui/` (the `src/` folder is gone).
- Rules are always toggles, off by default unless a phase says otherwise, with AI support and a suite case.
- Unverified shared-board results are kept and labeled unverified, by choice.

## Open (decide by the phase named)
- 3D: full 3D, or keep the pixel 2.5D look and render 3D models to sprites? The WebGL renderer and 3D import are deferred (revisit after Phase 14).
- Era scope: WWII only, or mixed eras and sci-fi (Warhammer 40k and Empire at War were inspirations)?
- Period skins: purely cosmetic, or small stat differences?
- Backend for matches, gallery and balance data outside Claude: Supabase, Firebase or your own server (by Phase 16).
- Desktop shell: Tauri (recommended: small downloads, system webview) or Electron (by Phase 18).
- Distribution: free on the web, paid in app stores, or both (by Phase 20).
- Keep the hosted Claude artifact as a supported target after export (recommended: yes, at least until Phase 16 gives the game its own backend).
- Missile values (Phase 14).

## Principles (carry through every phase)
- Every new system is a toggle; compare it on and off.
- Real-world data in, 0-10 out: the unit schema is the contract between the Unit Editor and the game.
- Every feature gets AI support and an AI-versus-AI suite case; it is not done without them.
- Single-file output, vanilla JS, local-first saves, until Phase 15 changes the source layout (the single-file artifact stays one build output).
- Prove changes with the suite: same seed, same battles before and after.
