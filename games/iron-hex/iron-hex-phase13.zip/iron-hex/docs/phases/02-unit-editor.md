# Phase 2: Unit Editor

**Shape:** Feature
**Status:** Shipped. A unit made from a vehicle name shows up in the library, fights, and survives save and load.

## Outcomes
- Lookup through Claude in the hosted game, copy-and-paste fallback; one shared prompt and parser (`engine/battle/customunits.js`: `lookupPrompt`, `parseLookup`). Sources and caveats are shown.
- One shared scale table for all three domains (`STAT_SCALES`), matching the built-in units; per-stat overrides in the editor (`ui/editors/uniteditor.js`).
- Game values, damage multipliers, abilities as checkboxes; pixel-art editor with four-army preview and image import (background removal, army-paint mapping, outline).
- Saved units appear in the library and roster picker; export/import as .json; battles carry the custom units they use. Ids restricted to a safe pattern (`SAFE_UNIT_ID`); schema checks in `engine/battle/validate.js`.

## Known issues
- Importing 3D models not built (deferred with the 3D renderer).
