# Phase 9: Content and polish

**Shape:** Feature
**Status:** Shipped. A browser test plays the tutorial from first selection to completion; building it fixed three first-time-player problems.

## Outcomes
- Four more looks (Ancient Mediterranean, Ancient China, Maori, Inca; 48 sprites composed by `tools/art/looks.py` into `content/skins.js`) and a redrawn knight. Maori and Inca show warriors, tools, canoes and rafts only.
- Operation Archipelago (second campaign) and the Campaign Editor (`ui/editors/campaign-editor.js`): missions, maps with live preview, objectives, enemies, reinforcements, rules, branches, test play, export/import.
- Chiptune music generated live (`ui/audio/music.js`); accessibility (`ui/a11y/access.js`): colorblind-safe palette and shape markers, full keyboard play, screen-reader announcements, reduced motion; interactive Tutorial (`ui/screens/tutorial.js`).

## Known issues
- Not confirmed: a real newcomer playing the tutorial cold (Phase 14). 3D renderer and 3D import deferred again.
