# Phase 17: Installable web app

**Shape:** Feature
**Status:** Not started. Detail this file when the phase becomes current.

## Goal
A progressive web app: install prompt, offline play, tablet-sized layouts, and polished mouse, touch and keyboard input.

## Gate
It installs from the browser on a computer and a phone and plays a full battle offline.
