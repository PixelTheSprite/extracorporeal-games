# Phase 14: Validation and release candidate

**Shape:** Debug and harden
**Depends on:** Phase 13 (first phase done in Claude Code)

## Goal
Confirm what has only been simulated, choose the missile values, and clear the open balance items, so Part 1 is a release candidate.

## Files touched
- `engine/combat/missiles.js` (missile values in `REAL`), `tools/ab/phase12-report.md` (the suggestion to apply)
- `engine/ai/ai-support.js` (bridge demolition), `engine/ai/ai-plan.js`, `engine/rules/realism-world.js` (stall fixes)
- `engine/harness/harness-suite.js` (make the v1-migration case deterministic, see Open items)
- `content/skins.js` (only after the cultural review of the Maori and Inca looks)

## Work items
- [ ] Choose and apply the missile values (A/B report suggests 3-turn charge, 14-hex range, 20% interception, targets don't guard themselves); re-run `tools/ab/strategic.mjs` and the full suite
- [ ] Teach the AI to blow bridges (`planDemolish`-style step beside `planMines` in `engine/ai/ai-support.js`)
- [ ] Playtest economy, timed-reinforcement and all-realism battles for stalls; add an endgame rule or AI change; target under 1 in 20 turn-limit endings
- [ ] Make the "Version 1 save upgrades" suite row deterministic (the v1 -> v2 migration seeds with `Math.random()`; give the harness a fixed seed)
- [ ] Real-device checks: online match between two people, gallery share between accounts, `Run performance test` on real phones, a newcomer playing the tutorial cold
- [ ] Cultural review of the Maori and Inca looks; accessibility audit with a screen reader user; start a balance-data playtest loop

## Data vs engine
No new split. Missile values stay in `REAL` until Phase 15 moves them to `content/rules.json`.

## Checks
- `npm test` (full suite, no failures, turn-limit rate under 1 in 20), `npm run test:unit`, `npm run test:browser`
- The A/B harness shows missiles and city development within their targets

## Gate
Every Part 1 gate confirmed by real people on real devices, and the missile values chosen and applied.

## Status
Not started.

## Open items
- None yet. Carried in: missile values, AI bridges, stalls (see `docs/HANDOFF.md`).
