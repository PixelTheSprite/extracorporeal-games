# Phase 15: ES modules and content as data

**Shape:** Data/engine split
**Status:** Not started. Detail this file when the phase becomes current.

## Goal
Replace the concatenated global scripts with ES modules and a Vite build (keeping the single-file artifact as one output); move units, structures, terrain, maps, campaigns, looks and rule values into schema-validated JSON loaded through `engine/registry.js`; run AI planning in a Web Worker. Content files to move are listed in `docs/notes/architecture.md`.

## Gate
Every build produces identical battles, and adding a unit, map or rule value touches only data files.
