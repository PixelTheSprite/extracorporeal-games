# Phase 10: Toward release

**Shape:** Optimize + Feature
**Status:** Shipped. Built-in performance test reports 60 fps idle, panning and resolving on an emulated mid-range phone (CPU slowed 4x); a two-player browser test shares and installs a map, unit pack and campaign (a tampered post is refused).

## Outcomes
- Phone performance: redraw at full speed only while something changes (else 8 fps); terrain cached offscreen and shifted while panning; specks skipped on tiny hexes (`ui/battle/render-*.js`). Run performance test button in Diagnostics (`ui/screens/diagnostics.js`).
- Community gallery for maps, unit packs, campaigns (`ui/community/community.js`): installs are validated, get fresh ids, never replace your own work.
- Opt-in "Share balance data" telemetry (off by default; no names or typed text).

## Known issues
- Not confirmed: the performance test on a physical phone (Phase 14).
