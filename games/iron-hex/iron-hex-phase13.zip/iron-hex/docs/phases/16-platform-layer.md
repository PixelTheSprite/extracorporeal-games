# Phase 16: Platform layer

**Shape:** Feature
**Status:** Not started. Detail this file when the phase becomes current.

## Goal
One interface for storage, files, sharing, accounts, networking and audio, implemented per platform: the hosted Claude artifact (today's runtime), the standalone web app (IndexedDB and a backend for matches, the gallery and balance data), desktop (real files) and mobile (device storage). Backend choice is decided by this phase.

## Gate
The game runs on each adapter set, chosen at startup, and online matches work outside Claude.
