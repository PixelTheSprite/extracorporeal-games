# Phase 12: Missiles and city development

**Shape:** Feature with an A/B tuning harness
**Status:** Shipped with one open decision (missile values). City development is within target; missiles at the defaults are not.

## Outcomes
- Missile silos (`engine/combat/missiles.js`, `ui/battle/strategic.js`): engineers build (4 turns); charge 5 turns (faster with cities held and near a level-3 city); strike order 60 damage on the hex, 20 splash, 60 to structures, range 10; interception by AA units and warships (40% each, up to 80%); launches are orders, so replays, saves and online matches carry them. AI builds up to two silos and fires at the most valuable visible target.
- City development: levels 1-3 by investing funds (20 / 35, 3 turns each; a captured city drops a level); +2 income, 10% less damage and 5% healing per level above 1; level 3 adds a purchase a turn and speeds nearby silos. AI invests in threatened cities, otherwise a rear city.
- A/B harness (`tools/ab/strategic.mjs`, variants in `tools/ab/variants.json`); report `tools/ab/phase12-report.md` suggests values and never applies them. City development earns about 2.9x its investment per battle.

## Known issues
- Decision pending (Phase 14): at defaults missiles deal 2% of damage (67% intercepted); the suggested mix (3-turn charge, 14-hex range, 20% interception, targets don't guard themselves) reaches 17% with 94% high-value hits.
