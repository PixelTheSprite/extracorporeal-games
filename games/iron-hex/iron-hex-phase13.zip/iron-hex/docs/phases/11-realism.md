# Phase 11: Realism toggles

**Shape:** Feature (four batches)
**Status:** Shipped. All 22 realism rules have AI support, suite cases and unit tests; with every rule on, battles replay and reload exactly.

## Outcomes
Rules live in `engine/rules/realism-*.js`; every value is in the `REAL` table (`realism-core.js`), all off by default, group Realism.
- Batch 1 (`realism-core.js`): supply lines, entrenchment, suppression, armor facing, urban combat, surrender.
- Batch 2 (`realism-command.js`): command radius, order friction, electronic warfare, air superiority zones, AA umbrellas.
- Batch 3 (`realism-ops.js`): artillery and indirect fire (M7 Priest), submarines and ASW (Gato), carriers (Essex), mines, railways, demolition.
- Batch 4 (`realism-world.js`): seasons, elevation, timed reinforcements, victory points and war weariness, information operations, ammunition types.
- Fixed: Supply exhaustion could end a battle before armies met; it now counts quiet turns after first contact.

## Known issues
- AI never blows bridges; timed reinforcements and all-realism battles tend to stall (Phase 14).
