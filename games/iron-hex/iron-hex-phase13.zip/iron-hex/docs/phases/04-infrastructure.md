# Phase 4: Infrastructure Editor

**Shape:** Feature
**Status:** Shipped. AI built 1,181 structures, landed on airfields 235 times and made 308 port calls across the 135-battle suite; the suite fails if the AI stops using them.

## Outcomes
- Five structures (`engine/economy/structures.js`): airfield, port, bridge, depot, fortification; build times 1-3 turns; airfields, ports and depots are capturable supply points; the Bombard order destroys any structure.
- Infrastructure Editor (`ui/editors/infra.js`) on any map; per-army or neutral placement, auto-place a base per army, saved layouts.
- AI builds what the army lacks, lands aircraft at bingo fuel, puts damaged ships into ports. Saves moved to version 3 with a migration.

## Known issues
- Turn-limit endings rose from 3 to 16 of 139 suite checks at the time (depleted endgames); addressed by Phase 6.
