# Phase 20: Cross-platform release

**Shape:** Debug and harden
**Status:** Not started. Detail this file when the phase becomes current.

## Goal
Continuous integration builds every target and runs the tests on each; store listings, a privacy policy covering balance data, crash reporting, and save compatibility across platforms.

## Gate
One tagged release produces every build from CI, and a save made on any platform loads on every other.
