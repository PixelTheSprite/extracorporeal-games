# Phase 19: Phone and tablet apps

**Shape:** Feature
**Status:** Not started. Detail this file when the phase becomes current.

## Goal
Capacitor apps for iOS and Android: safe areas, orientation, haptics, pausing and resuming mid-battle, storage limits and real-device performance.

## Gate
On a real iPhone, Android phone and tablet: a full battle, suspend and resume, and an online match.
