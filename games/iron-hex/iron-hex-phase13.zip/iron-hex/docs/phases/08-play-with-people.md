# Phase 8: Play with people

**Shape:** Feature
**Status:** Shipped in simulation. Two simulated devices finish full matches in Node (one resolution per turn, identical final states); two browser tabs play a match through the real interface; a 60-turn all-rules battle replays to the identical final state.

## Outcomes
- Asynchronous online matches (`engine/net/match.js`, `ui/community/multiplayer.js`): 2-4 seats (person or AI), teams, optional 24/72-hour deadlines. The first device to take the turn's lease resolves it and stores the result; other devices animate and adopt it. Trust model: orders hidden in the game, readable by a determined player.
- Hot-seat for up to 4 with an opaque handoff screen (`ui/battle/modes.js`).
- Replays (`engine/replay/replay.js`, `ui/community/replays.js`): opening state plus each turn's orders, RNG state, purchases and diplomacy; last 5 local, file export/import, shared in the hosted game.

## Known issues
- Not confirmed: a match between two people on real devices in the hosted game (Phase 14).
