# Phase 7: Depth

**Shape:** Feature
**Status:** Shipped. Full suite passed 164 checks; with everything on, the same seed replays identically and a mid-battle save reloads identically.

## Outcomes (each behind its own toggle, with AI support)
- Fog of war and line of sight (`engine/vision/vision.js`); unreliable intel: fading intel, decoys, AI deception.
- Economy and production (`engine/economy/economy.js`): prices, optional point budget, Income, Mid-battle production, Capital loss; the AI buys counters to what it sees.
- Weather and time of day, morale (`engine/battle/conditions.js`).

## Known issues
- AI-versus-AI economy battles usually run to the turn limit (both sides replace losses as fast as they take them). Carried to Phase 14 playtesting.
- 3D renderer moved out of this phase; still deferred (see `notes/decisions.md`).
