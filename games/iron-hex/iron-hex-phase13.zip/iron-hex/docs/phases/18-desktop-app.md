# Phase 18: Desktop app

**Shape:** Feature
**Status:** Not started. Detail this file when the phase becomes current.

## Goal
A Tauri app around the web build (small downloads, the system webview) with saves and maps as real files, menus, fullscreen and automatic updates, for Windows, macOS and Linux.

## Gate
Signed builds for all three play a full battle and open a saved map file.
