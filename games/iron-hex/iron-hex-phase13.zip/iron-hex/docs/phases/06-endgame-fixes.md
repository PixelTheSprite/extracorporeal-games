# Phase 6: Endgame and fixes

**Shape:** Debug and harden
**Status:** Shipped. 7 of 148 full-suite battles (4.7%) reached the turn limit, down from 14; three 2-versus-2 battles finish with no friendly fire.

## Outcomes
- Endgame AI presses harder in the second half; rules Supply exhaustion (on by default: 6 quiet turns end the battle on team score) and Attrition (off by default).
- Save, Load, New as in-page dialogs (`ui/screens/saves.js`): 12 named slots, export/import, restart keeping setup; slots sit behind a `SaveStore` interface (a cross-device store exists but is switched off).
- Teams and diplomacy (`engine/battle/diplomacy.js`, `ui/screens/diplomacy.js`): free-for-all, 2v2, map alliances; allies never fight and win together; grants (territory, resupply, passage) switchable one-sidedly.

## Known issues
- None open from this phase.
