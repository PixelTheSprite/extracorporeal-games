# Phase 1: Stabilize and balance

**Shape:** Debug and harden
**Status:** Shipped. Full suite passed all 133 battles with no errors; 3 ended at the turn limit.

## Outcomes
- Territory pacing: default target 60%, Spread claims only hexes within 3 of a supply point (a 4-hex radius with a 50% target split territory and destruction wins evenly in AI tests).
- AI engineers stay at least a hex behind the closest fighter and within 2 hexes of a friend; after 4 quiet turns every AI pushes forward; out-of-ammo units head home; ships resupply at their army's flags and cities. Turn-limit endings fell from 6 to 3 of 133.
- LST can move and load in one turn; How to play overlay (`ui/screens/help.js`); phone HUD shrank (about 210 px to 110 px); cached hex geometry cut slow frames from 41-54 ms to 13-17 ms.
- Regression suite: Node runner (`tests/run.mjs`) and the in-game Diagnostics screen run the same suites (`engine/harness/`).

## Known issues
- Sandstorm Strait's southeast army wins about two-thirds of AI suite games; traced to map layout, not the engine.
