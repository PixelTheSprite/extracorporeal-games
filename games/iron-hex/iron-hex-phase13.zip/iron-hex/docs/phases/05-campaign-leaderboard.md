# Phase 5: Campaign, Leaderboard, period skins

**Shape:** Feature
**Status:** Shipped. The suite plays every mission and the whole campaign (with veterans and retries); browser tests cover records, mission wins/losses, retries and the shared board.

## Outcomes
- Campaign (`engine/missions/campaign.js`, `ui/screens/campaign-screen.js`): missions as data (map, rosters, rules, objective, structures, reinforcements, turn limit); objectives beyond destruction (capture and hold, structure, survive N turns, escort); veterans (+5% damage, +3 evasion per rank); briefings and a branch. First campaign: The Iron Coast.
- Leaderboard (`ui/community/leaderboard.js`, `engine/missions/records.js`): local records, per-unit-type profile, optional shared board (unverified results, names looked up not stored).
- Period skins (`content/skins.js`, `ui/screens/looks.js`): medieval sprites for all 12 units; a look per army; unlock ladder per unit type; Unit library shows looks and progress.

## Known issues
- Remaining period art was finished in Phase 9. Unit Editor tie-in (tagging imported art with a period) not built.
- Non-medieval sets should get cultural review (see Phase 14).
