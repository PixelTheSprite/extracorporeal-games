// AI order planning, part 3: distance fields, APC/engineer/transport AI, mines, broadcasts, ammo, missiles, city investment.
// Multi-source travel cost from every enemy position, over terrain this domain can cross.
function distField(dom, sources, B = appState.battle) {
  const def = B.mapDef,
    dist = new Map(),
    open = heapOf(n => n.d);
  const passCost = (c, r) => {
    const v = MOVE_COST[dom][tileAt(c, r, B).t];
    return v != null ? v : dom === 'land' && bridgeAt(c, r, B) ? 1 : null;
  };
  for (const e of sources) {
    if (passCost(e.c, e.r) == null) continue;
    const k = key(e.c, e.r);
    if (!dist.has(k)) {
      dist.set(k, 0);
      open.push({ c: e.c, r: e.r, d: 0 });
    }
  }
  while (open.length) {
    const cur = open.shift();
    if (cur.d > dist.get(key(cur.c, cur.r))) continue;
    for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
      const cost = passCost(n.c, n.r);
      if (cost == null) continue;
      const k = key(n.c, n.r),
        nd = cur.d + cost;
      if (!dist.has(k) || dist.get(k) > nd) {
        dist.set(k, nd);
        open.push({ c: n.c, r: n.r, d: nd });
      }
    }
  }
  return dist;
}

// APC AI: drive the infantry toward the front (or an enemy-held city) and drop it off within a few hexes.
function planAPC(u, reach, nearest, pid, B = appState.battle) {
  const cityGoal = h => {
    let best = Infinity;
    for (const k of Object.keys(B.cities || {})) {
      if (B.cities[k].owner != null && !isEnemy(B.cities[k].owner, pid, B)) continue;
      const [c, r] = unkey(k);
      best = Math.min(best, hexDist({ c, r }, h));
    }
    return best;
  };
  const goal = h => Math.min(nearest(h), cityGoal(h));
  const ends = [...reach.values()].filter(n => n.end);
  // Close enough already: unload toward the goal
  if (goal(u) <= 4) {
    const spot = landingSpots(u, B).sort((a, b) => goal(a) - goal(b))[0];
    return spot ? { type: 'unload', unload: { c: spot.c, r: spot.r } } : null;
  }
  const n = ends.filter(n => nearest(n) >= 2).sort((a, b) => goal(a) - goal(b) || a.cost - b.cost)[0];
  if (!n || n.cost === 0) return null;
  const spot = goal(n) <= 4 ? landingSpots(n, B).sort((a, b) => goal(a) - goal(b))[0] : null;
  const o = { type: 'move', path: pathTo(n), target: null };
  if (spot) o.unload = { c: spot.c, r: spot.r };
  return o;
}

// Engineer AI: fix the most damaged friend in reach (below 80% health), adjacent first.
function planEngineer(u, reach, mine, B = appState.battle) {
  const hurt = mine.filter(x => x !== u && !x.in && x.hp <= x.maxHp * 0.8).sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp);
  if (!hurt.length) return planBuild(u, reach, mine, B);
  const adj = hurt.find(x => hexDist(x, u) === 1);
  if (adj) return { type: 'repair', mend: adj.id };
  const ends = [...reach.values()].filter(n => n.end && n.cost > 0);
  for (const x of hurt) {
    const n = ends.filter(n => hexDist(n, x) === 1).sort((a, b) => a.cost - b.cost)[0];
    if (n) return { type: 'move', path: pathTo(n), target: null, repair: x.id };
  }
  return planBuild(u, reach, mine, B);
}
// Engineer AI, when nobody needs repairs: finish our own scaffold if one is in reach, otherwise start the
// structure the army lacks most (airfield if it has aircraft, port if it has ships, then a depot, then
// fortifications near the front) on our own ground, away from the enemy.
function planBuild(u, reach, mine, B = appState.battle) {
  const pid = u.pid,
    def = B.mapDef;
  // No building during a stalemate, or when the engineer is all that's left to fight with: go fight instead.
  if ((B.quiet || 0) >= STALL_TURNS || !mine.some(x => x !== u && !UNIT_TYPES[x.type].repairs && fighting(x))) return null;
  const enemies = aliveUnits(B).filter(e => isEnemy(e.pid, pid, B));
  const near = h => enemies.reduce((m, e) => Math.min(m, hexDist(e, h)), Infinity);
  const ends = [...reach.values()].filter(n => n.end);
  const order = (n, kind) =>
    n.cost === 0
      ? { type: 'build', kind, at: { c: n.c, r: n.r } }
      : { type: 'move', path: pathTo(n), target: null, build: { kind, at: { c: n.c, r: n.r } } };
  for (const n of ends.sort((a, b) => a.cost - b.cost)) {
    const s = structAt(n.c, n.r, B);
    if (s && s.build && s.build.pid === pid && s.kind !== 'bridge') return order(n, s.kind);
  }
  const has = kind => Object.values(B.structs).some(s => s.kind === kind && (s.build ? s.build.pid : s.owner) === pid);
  const forts = Object.values(B.structs).filter(s => s.kind === 'fort' && (s.build ? s.build.pid : s.owner) === pid).length;
  const front = near(u);
  let kind = null;
  if (mine.some(x => UNIT_TYPES[x.type].domain === 'air') && !has('airfield')) kind = 'airfield';
  else if (mine.some(x => UNIT_TYPES[x.type].domain === 'sea') && !has('port')) kind = 'port';
  else if (!has('depot')) kind = 'depot';
  else if (
    B.rules.missiles &&
    Object.values(B.structs).filter(x => x.kind === 'silo' && (x.build ? x.build.pid : x.owner) === pid).length < 2 &&
    (!(B.rules.income || B.rules.production) || (B.funds[pid] || 0) >= REAL.SILO_COST)
  )
    kind = 'silo'; // missiles: up to two silos
  else if (front <= 6 && forts < 2) kind = 'fort';
  if (!kind) return null;
  const ownish = h => B.territory[key(h.c, h.r)] === pid || supplyPoints(B).some(sp => sp.pid === pid && hexDist(sp, h) <= 2);
  const cands = ends.filter(
    n => canBuildAt(kind, n, pid, B) && ownish(n) && (kind === 'fort' ? near(n) <= 4 && near(n) >= 2 : near(n) >= 4)
  );
  const n = cands.sort((a, b) => a.cost + (kind === 'fort' ? near(a) : 0) - (b.cost + (kind === 'fort' ? near(b) : 0)))[0];
  return n ? order(n, kind) : null;
}

function landComponents(B = appState.battle) {
  const def = B.mapDef,
    comp = new Map();
  let id = 0;
  for (let r = 0; r < def.H; r++)
    for (let c = 0; c < def.W; c++) {
      const k = key(c, r);
      if (comp.has(k) || !landPassAt(c, r, B)) continue;
      comp.set(k, ++id);
      const q = [{ c, r }];
      while (q.length) {
        const cur = q.shift();
        for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
          const nk = key(n.c, n.r);
          if (!comp.has(nk) && landPassAt(n.c, n.r, B)) {
            comp.set(nk, id);
            q.push(n);
          }
        }
      }
    }
  return comp;
}

// Loaded: sail to a beach on an enemy-held landmass and unload. Empty: go pick up a stranded unit. Otherwise act like a normal ship.
function planTransport(u, reach, ctx, B = appState.battle) {
  const ends = [...reach.values()].filter(n => n.end);
  if (u.cargo) {
    let best = null;
    for (const n of ends)
      for (const h of landingSpots(n, B)) {
        const onEnemyLand = !ctx.enemyLand.length || ctx.enemyComps.has(ctx.comp.get(key(h.c, h.r)));
        if (!onEnemyLand) continue;
        const sc = -ctx.nearest(h) - n.cost * 0.1;
        if (!best || sc > best.sc) best = { sc, n, h };
      }
    if (best)
      return best.n.cost === 0
        ? { type: 'unload', unload: { c: best.h.c, r: best.h.r } }
        : { type: 'move', path: pathTo(best.n), target: null, unload: { c: best.h.c, r: best.h.r } };
    const toward = ctx.enemyLand.length ? ctx.enemyLand : null;
    const goal = h => (toward ? Math.min(...toward.map(e => hexDist(e, h))) : ctx.nearest(h));
    const n = ends.sort((a, b) => goal(a) - goal(b))[0];
    return n && n.cost > 0 ? { type: 'move', path: pathTo(n), target: null } : { type: 'hold' };
  }
  const waiting = ctx.stranded.filter(x => !x.in);
  if (!waiting.length) return null;
  const n = ends.sort(
    (a, b) =>
      Math.min(...waiting.map(x => Math.max(0, hexDist(x, a) - 1))) * 10 +
      a.cost * 0.1 -
      (Math.min(...waiting.map(x => Math.max(0, hexDist(x, b) - 1))) * 10 + b.cost * 0.1)
  )[0];
  return n && n.cost > 0 ? { type: 'move', path: pathTo(n), target: null } : { type: 'hold' };
}

// Orders for every AI army. humanAI: strategy to play the human army with (headless tests), or null to skip it.
function planAllAI(humanAI, B = appState.battle) {
  const out = {};
  for (const p of B.players) {
    if (!allAlive(B).some(u => u.pid === p.id)) continue;
    const ai = p.ai || humanAI;
    if (ai) Object.assign(out, planAI(Object.assign({}, p, { ai }), B));
  }
  return out;
}

// Mines (rule): engineers and destroyers near the enemy sometimes lay one where they stand.
function planMines(ctx) {
  const { B, mine, orders, nearest } = ctx;
  if (!B.rules.mines) return;
  for (const u of mine) {
    if (orders[u.id] || !canLayMine(u, B) || nearest(u) > 5) continue;
    if (rng(B) < AI_WEIGHTS.mineChance) orders[u.id] = { type: 'mine' };
  }
}

// Information operations (rule): rifle squads near the enemy sometimes broadcast instead of fighting.
function planBroadcasts(ctx) {
  const { B, mine, orders, nearest } = ctx;
  if (!B.rules.infoOps || !(B.rules.morale || (B.rules.fog && B.rules.intelFade))) return;
  for (const u of mine)
    if (!orders[u.id] && canBroadcast(u, B) && nearest(u) <= REAL.BROADCAST_RANGE && rng(B) < AI_WEIGHTS.broadcastChance)
      orders[u.id] = { type: 'broadcast' };
}
// Ammunition types (rule): load armor-piercing if the nearest enemy in sight is armored, otherwise high-explosive.
function chooseAmmo(ctx) {
  const { B, mine, orders, enemies } = ctx;
  if (!B.rules.ammo) return;
  for (const u of mine) {
    if (!orders[u.id] || !usesAmmoTypes(UNIT_TYPES[u.type]) || !enemies.length) continue;
    const e = enemies.reduce((a, b) => (hexDist(a, u) <= hexDist(b, u) ? a : b));
    orders[u.id] = Object.assign({}, orders[u.id], { ammo: armoredTarget(UNIT_TYPES[e.type]) ? 'ap' : 'he' });
  }
}

// Missiles (rule): launch each ready silo at the most valuable target in sight and range: warships, artillery,
// structures and clusters first, never where the splash would catch our own side.
function planMissiles(ctx) {
  const { B, p, orders } = ctx;
  if (!B.rules.missiles) return;
  const value = u => ({ battleship: 60, carrier: 60, ship: 40, arty: 35, tank: 25, sub: 30, lst: 25 })[u.type] || 12;
  for (const s of ownSilos(B, p.id)) {
    if (!siloReady(B, s)) continue;
    let best = null,
      bs = AI_WEIGHTS.strikeMin;
    const cands = new Map();
    for (const e of aliveUnits(B)) if (isEnemy(e.pid, p.id, B) && canSee(p.id, e, B)) cands.set(key(e.c, e.r), { c: e.c, r: e.r });
    for (const [k, x] of Object.entries(B.structs)) if (x.owner != null && isEnemy(x.owner, p.id, B)) cands.set(k, keyHex(k));
    for (const h of cands.values()) {
      if (!strikeTargetOk(B, p.id, s.k, h)) continue;
      if (aliveUnits(B).some(u => !isEnemy(u.pid, p.id, B) && hexDist(u, h) <= 1)) continue; // no friendly fire
      let sc = 0;
      for (const u of aliveUnits(B))
        if (isEnemy(u.pid, p.id, B)) sc += u.c === h.c && u.r === h.r ? value(u) : hexDist(u, h) === 1 ? value(u) / 3 : 0;
      const st = B.structs[key(h.c, h.r)];
      if (st && st.owner != null && isEnemy(st.owner, p.id, B)) sc += STRUCTS[st.kind].value + (st.kind === 'silo' ? 30 : 0);
      if (sc > bs) {
        bs = sc;
        best = h;
      }
    }
    if (best) orders['strike:' + s.k] = { type: 'strike', target: { c: best.c, r: best.r } };
  }
}
// City development (rule): with spare funds, invest in one city a turn: a threatened city for its defense,
// otherwise a rear city for its income.
function planInvest(ctx) {
  const { B, p, orders, nearest } = ctx;
  if (!B.rules.cityDev || !B.rules.income) return;
  const mineC = Object.keys(B.cities).filter(k => investOk(B, p.id, k));
  if (!mineC.length || (B.funds[p.id] || 0) < 10 + Math.min(...mineC.map(k => REAL.CITY_LEVEL_COST[cityLevel(B.cities[k]) + 1]))) return;
  const threatened = mineC.filter(k => nearest(keyHex(k)) <= 6);
  const pick = (threatened.length ? threatened : mineC).sort((a, b) => nearest(keyHex(b)) - nearest(keyHex(a)))[0];
  orders['invest:' + pick] = { type: 'invest' };
}
