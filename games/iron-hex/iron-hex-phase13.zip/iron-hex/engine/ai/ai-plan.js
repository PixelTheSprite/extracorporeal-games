// AI order planning.
// ---------- AI ----------
// AI scoring weights, in one place for tuning. Hex scores are summed per candidate hex; the best hex wins.
const AI_WEIGHTS = {
  // objectives (campaign) and escorts
  escortDistance: 6,
  escortThreat: 1.6,
  escortStray: 10,
  guardRadius: 3,
  guardPull: 2,
  objectiveCapturer: 6,
  objectiveOther: 2,
  huntEscort: 15,
  // attacking
  killShot: 35,
  finishWounded: 15,
  counterFire: 0.5,
  threatMoving: 0.5,
  threatHolding: 0.35,
  cover: 20,
  jitter: 1.5,
  // captures (cities, structures, capitals under Capital loss)
  finishCapture: 80,
  captureStructure: 55,
  captureCity: 45,
  captureCapital: 70,
  // supply, morale and movement habits
  brokenRetreat: 10,
  feintPull: 5,
  homeDistance: 6,
  homeArrive: 40,
  resupplyEmpty: 8,
  resupplyLow: 4,
  paintGround: 6,
  attritionAvoid: 12,
  // realism rules
  commandAvoid: 4,
  counterBattery: 20,
  mineChance: 0.3,
  vpCity: 20,
  broadcastChance: 0.2,
  strikeMin: 40, // a launch must be worth at least this much
  stayDugIn: 4,
  supplyAvoid: 10,
  highGround: 5,
  engineerBehindFront: 15,
  engineerNearFriends: 5,
  fuelReserve: 60,
  holdInSupply: 20,
  holdInStalemate: -20,
};
// Plans every order for one AI army. Split into steps that share one context object:
// what the army knows (aiContext), transport pairings, deception, then each unit in turn.
function planAI(p, B = appState.battle) {
  const ctx = aiContext(p, B);
  planTransportPairs(ctx);
  planDeception(ctx);
  planMines(ctx);
  planBroadcasts(ctx);
  planMissiles(ctx);
  planInvest(ctx);
  for (const u of ctx.mine) planUnit(ctx, u);
  chooseAmmo(ctx);
  if (ctx.B.rules.production) planProduction(p, B);
  return ctx.orders;
}
// Everything the army knows before it plans: enemies, threats, routes, supply, and the scoring helpers.
function aiContext(p, B = appState.battle) {
  const S = STRATS[p.ai] || STRATS.balanced,
    obj = B.objective;
  const mine = aliveUnits(B)
    .filter(u => u.pid === p.id)
    .sort((a, b) => UNIT_TYPES[b.type].move - UNIT_TYPES[a.type].move);
  // Under fog of war the AI knows only what its team sees, plus its sightings (decoys included); with nothing
  // known at all it heads for the enemy capitals.
  const fog = fogOn(B);
  if (fog) computeVision(B);
  const enemies = aliveUnits(B).filter(u => isEnemy(u.pid, p.id, B) && canSee(p.id, u, B));
  const contacts = fog ? sightingsFor(p.id, B) : [];
  const enemyCapitals = B.players.filter(o => isEnemy(o.id, p.id, B) && inFight(o.id, B)).map(o => B.mapDef.spawns[o.id]);
  let huntPoints =
    enemies.length || contacts.length ? enemies.map(e => ({ c: e.c, r: e.r })).concat(contacts) : fog ? enemyCapitals.slice() : [];
  // With Capital loss on, taking a capital knocks an army out, so enemy capitals are always worth heading for.
  if (B.rules.capitalLoss) huntPoints = huntPoints.concat(enemyCapitals);
  if (B.rules.missiles)
    huntPoints = huntPoints.concat(
      Object.entries(B.structs)
        .filter(([, x]) => x.kind === 'silo' && x.owner != null && isEnemy(x.owner, p.id, B))
        .map(([k]) => keyHex(k))
    );
  const isEnemyCapital = h => enemyCapitals.some(c => c.c === h.c && c.r === h.r);
  const orders = {},
    reserved = new Set(mine.map(u => lkey(u, u.c, u.r)));
  // Stalemate breaker: after STALL_TURNS turns with no damage dealt by anyone, every AI pushes forward.
  const stall = (B.quiet || 0) >= STALL_TURNS;
  // Late in a battle every AI presses harder and takes more risks, so armies meet before the turn limit.
  const limit = B.turnLimit || turnLimit(B.mapDef),
    late = clamp((B.turn - limit * 0.5) / (limit * 0.5), 0, 1);
  const riskW = S.risk * (1 - 0.4 * late);
  const attritionNow = B.rules.attrition && B.turn + 2 >= Math.ceil(limit * ATTRITION_FROM);
  const approachW =
    late * 3 +
    S.approach +
    (p.ai === 'defensive' ? B.turn * 0.06 : 0) +
    Math.max(0, B.turn - 8) * 0.12 +
    (stall ? 2 + (B.quiet - STALL_TURNS) * 0.5 : 0);
  const threatAt = (u, h) => {
    let th = 0;
    for (const e of enemies) {
      if (!canHit(e, u, B)) continue;
      const E = UNIT_TYPES[e.type];
      if (hexDist(e, h) <= E.move * 0.75 + E.range[1]) th += expDmg(e, u, h, false, B);
    }
    return th;
  };
  const nearest = h => huntPoints.reduce((m, e) => Math.min(m, hexDist(e, h)), huntPoints.length ? Infinity : 0);
  // Approach is measured by travel cost over terrain, not straight-line distance, so units route around ridges.
  const fields = {};
  const fieldFor = dom => fields[dom] || (fields[dom] = distField(dom, huntPoints, B));
  const approachDist = (u, h) => {
    const dom = UNIT_TYPES[u.type].domain;
    if (dom === 'air') return nearest(h);
    const f = fieldFor(dom).get(key(h.c, h.r));
    return f == null ? nearest(h) * 1.5 : f;
  };
  // Ferry logic: a land unit is stranded if no enemy land unit shares its landmass.
  const comp = landComponents(B);
  const enemyLand = enemies.filter(e => UNIT_TYPES[e.type].domain === 'land');
  const enemyComps = new Set(enemyLand.map(e => comp.get(key(e.c, e.r))));
  const stranded = x => enemyLand.length && UNIT_TYPES[x.type].domain === 'land' && !enemyComps.has(comp.get(key(x.c, x.r)));
  // Logistics awareness: where is home, and who is running low?
  const ownHexes = Object.entries(B.territory || {})
    .filter(([, v]) => friendlyGround(v, p.id, B))
    .map(([k]) => {
      const [c, r] = unkey(k);
      return { c, r };
    });
  const distOwn = h => (ownHexes.length ? ownHexes.reduce((m, o) => Math.min(m, hexDist(o, h)), Infinity) : 0);
  const lowSupply = x => x.ammo <= 1 || (x.maxFuel && x.fuel <= x.maxFuel * 0.35);
  let flagsThisTurn = 0;
  // Enemy structures (finished or under construction) and our own ports, for bombardment and resupply scoring.
  const enemyStructs = Object.entries(B.structs || {})
    .map(([k, s]) => {
      const [c, r] = unkey(k);
      return { c, r, s };
    })
    .filter(x => {
      const o = x.s.build ? x.s.build.pid : x.s.owner;
      return o != null && isEnemy(o, p.id, B);
    });
  const ownPorts = armyStructs(p.id, 'port', B),
    ownFields = armyStructs(p.id, 'airfield', B).concat(B.rules.carriers ? mine.filter(x => UNIT_TYPES[x.type].deck) : []); // carriers are airfields too
  const fighters = mine.filter(x => !UNIT_TYPES[x.type].repairs && !(isTransport(x) && UNIT_TYPES[x.type].domain === 'sea'));
  const front = fighters.length ? Math.min(...fighters.map(x => nearest(x))) : 0; // how close our closest fighter is to the enemy
  const friendDist = h => (fighters.length ? Math.min(...fighters.map(x => hexDist(x, h))) : 0);
  const territoryGame = victory(B).mode === 'territory';
  return {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    flagsThisTurn,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  };
}
// Transports pick up passengers: LSTs collect stranded units, APCs carry infantry toward the fighting.
function planTransportPairs(ctx) {
  const {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  } = ctx;
  for (const t of mine) {
    if (!isTransport(t) || t.cargo || orders[t.id]) continue;
    const T0 = UNIT_TYPES[t.type];
    // LSTs pick up stranded units; APCs pick up infantry that is still far from the fighting.
    const c =
      T0.domain === 'sea'
        ? mine.find(x => stranded(x) && !orders[x.id] && canCarry(t, x) && hexDist(x, t) === 1)
        : mine.find(x => !orders[x.id] && canCarry(t, x) && hexDist(x, t) === 1 && nearest(x) > 5);
    if (c) {
      orders[t.id] = { type: 'load', cargo: c.id };
      orders[c.id] = { type: 'board', transport: t.id };
    } else if (T0.domain === 'sea') {
      // Sail next to a stranded unit and load it in the same turn.
      reserved.delete(lkey(t, t.c, t.r));
      const reach = reachable(t, k => reserved.has(k), B);
      let pick = null;
      for (const n of reach.values()) {
        if (!n.end || n.cost === 0) continue;
        const x = mine.find(x => stranded(x) && !orders[x.id] && canCarry(t, x) && hexDist(x, n) === 1);
        if (x && (!pick || n.cost < pick.n.cost)) pick = { n, x };
      }
      if (pick) {
        orders[t.id] = { type: 'move', path: pathTo(pick.n), target: null, load: pick.x.id };
        orders[pick.x.id] = { type: 'board', transport: t.id };
        reserved.add(lkey(t, pick.n.c, pick.n.r));
      } else reserved.add(lkey(t, t.c, t.r));
    }
  }
}
// AI deception (with fog and decoys): decoys now and then, and a 6-turn feint by one fast unit.
function planDeception(ctx) {
  const {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  } = ctx;
  if (fog && B.rules.decoys && B.rules.aiDeception) {
    if ((B.decoys || []).filter(d => d.pid === p.id).length < 2 && rng(B) < 0.5) {
      const cand = mine.find(u => !orders[u.id] && canPlantDecoy(u, B) && nearest(u) > 3);
      if (cand) orders[cand.id] = { type: 'decoy' };
    }
    B.feints = B.feints || {};
    const f = B.feints[p.id],
      fu = f && unitById(f.unitId, B);
    if (B.turn >= 3 && (!f || B.turn > f.until || !fu || fu.hp <= 0)) {
      const targets = supplyPoints(B).filter(
        sp =>
          isEnemy(sp.pid, p.id, B) && !(B.mapDef.spawns[sp.pid] && B.mapDef.spawns[sp.pid].c === sp.c && B.mapDef.spawns[sp.pid].r === sp.r)
      );
      const u = mine
        .filter(x => UNIT_TYPES[x.type].domain === 'land' && !UNIT_TYPES[x.type].repairs && !x.in && !isTransport(x) && !orders[x.id])
        .sort((a, b) => UNIT_TYPES[b.type].move - UNIT_TYPES[a.type].move)[0];
      if (u && targets.length) {
        const t = targets[Math.floor(rng(B) * targets.length)];
        B.feints[p.id] = { unitId: u.id, target: { c: t.c, r: t.r }, until: B.turn + 6 };
        B.stats.feints = (B.stats.feints || 0) + 1;
      }
    }
  }
}
