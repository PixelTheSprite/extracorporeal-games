// AI order planning, part 2: one unit's order (planUnit).
// One unit's order: score every reachable hex (and holding still) and pick the best.
function planUnit(ctx, u) {
  const W = AI_WEIGHTS;
  const {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  } = ctx;
  const feint = (B.feints || {})[p.id];

  if (orders[u.id]) return; // already paired for loading
  reserved.delete(lkey(u, u.c, u.r));
  const T = UNIT_TYPES[u.type];
  const reach = reachable(u, k => reserved.has(k), B);
  // Aircraft and ships with a home base (airfield / port) head there when low on supplies or badly damaged.
  const home = T.domain === 'air' ? ownFields : T.domain === 'sea' ? ownPorts : null;
  const distHome = h => (home && home.length ? Math.min(...home.map(x => hexDist(x, h))) : Infinity);
  // Bingo fuel: aircraft turn for home while they still have fuel for the trip back plus one turn of margin.
  const bingo =
    T.domain === 'air' &&
    u.fuel != null &&
    home &&
    home.length &&
    u.fuel <= (distHome(u) + T.move) * (T.fuelRate || 1) + 2 * (T.upkeep ?? AIR_UPKEEP);
  // Damaged units retreat to repair only below a third of their health, and not during a stalemate.
  const wantsHome = !!(home && home.length && (lowSupply(u) || bingo || (!stall && u.hp < u.maxHp / 3)));
  const aw = u.ammo === 0 || wantsHome || broken(u, B) ? 0 : approachW; // out of ammo, heading home or broken: stop advancing
  const feinting = feint && feint.unitId === u.id && B.turn <= feint.until;
  if (stranded(u)) {
    // Head for the nearest empty transport; pairing happens once they're adjacent.
    const ferry = mine
      .filter(x => isTransport(x) && !x.cargo && UNIT_TYPES[x.type].domain === 'sea' && canCarry(x, u))
      .sort((a, b) => hexDist(a, u) - hexDist(b, u))[0];
    if (ferry && hexDist(ferry, u) > 1) {
      const n = [...reach.values()].filter(n => n.end).sort((a, b) => hexDist(a, ferry) - hexDist(b, ferry) || a.cost - b.cost)[0];
      if (n && n.cost > 0) {
        const path = pathTo(n);
        orders[u.id] = { type: 'move', path, target: null };
        const f = path[path.length - 1];
        reserved.add(lkey(u, f.c, f.r));
        return;
      }
    }
  }
  const escortee = obj && obj.type === 'escort' && u.id === obj.unitId;
  // Campaign objectives: the attacker (army 0) pushes to the target; defenders stay near what they guard.
  // Applied to every option, holding included, so standing still is never free.
  const objCost = h => {
    if (!obj || !obj.target) return 0;
    const dT = hexDist(h, obj.target);
    if (p.id === 0) {
      if (escortee) return dT * W.escortDistance + threatAt(u, h) * W.escortThreat + Math.max(0, friendDist(h) - 1) * W.escortStray; // heads in carefully, never ahead of its escorts
      return T.domain === 'land' ? dT * (obj.type === 'capture' && T.captures ? W.objectiveCapturer : W.objectiveOther) : 0;
    }
    return T.domain === 'land' ? Math.max(0, dT - W.guardRadius) * W.guardPull : 0;
  };
  if (T.repairs && !escortee) {
    const plan = planEngineer(u, reach, mine, B);
    if (plan) {
      orders[u.id] = plan;
      const f = plan.path ? plan.path[plan.path.length - 1] : { c: u.c, r: u.r };
      reserved.add(lkey(u, f.c, f.r));
      return;
    }
  }
  if (T.carry && T.domain === 'land' && u.cargo) {
    const plan = planAPC(u, reach, nearest, p.id, B);
    if (plan) {
      orders[u.id] = plan;
      const f = plan.path ? plan.path[plan.path.length - 1] : { c: u.c, r: u.r };
      reserved.add(lkey(u, f.c, f.r));
      return;
    }
  }
  if (T.carry && T.domain === 'sea') {
    const plan = planTransport(u, reach, { comp, enemyComps, enemyLand, nearest, stranded: mine.filter(x => stranded(x)) }, B);
    if (plan) {
      orders[u.id] = plan;
      const f = plan.path ? plan.path[plan.path.length - 1] : { c: u.c, r: u.r };
      reserved.add(lkey(u, f.c, f.r));
      return;
    }
  }
  let best = null;
  for (const node of reach.values()) {
    if (!node.end) continue;
    const h = { c: node.c, r: node.r };
    let atk = 0,
      tgt = null;
    if (u.ammo > 0)
      for (const e of enemies) {
        if (!canHit(u, e, B) || !inRange(u.type, h, e, B)) continue;
        const d = expDmg(u, e, e, false, B);
        const counter = canHit(e, u, B) && inRange(e.type, e, h, B) ? expDmg(e, u, h, false, B) * W.counterFire * riskW : 0;
        const sc =
          d +
          (d >= e.hp ? W.killShot : 0) +
          S.focus * (1 - e.hp / e.maxHp) * W.finishWounded -
          counter +
          (obj && obj.type === 'escort' && e.id === obj.unitId ? W.huntEscort : 0) +
          (UNIT_TYPES[e.type].indirect && revealed(e, B) ? W.counterBattery : 0);
        if (sc > atk) {
          atk = sc;
          tgt = e;
        }
      }
    const cover = T.domain === 'land' ? terrainDef(T, tileAt(h.c, h.r, B).t, B) * W.cover : 0;
    const realism =
      T.domain !== 'land'
        ? 0
        : (B.rules.supplyLines && !inSupply(B, u, h) ? -W.supplyAvoid : 0) +
          (B.rules.elevation && elevAt(h, B) >= 2 ? W.highGround : 0) +
          (B.rules.command && outOfCommand(u, h, B) ? -W.commandAvoid : 0);
    let score =
      atk * S.atk - threatAt(u, h) * riskW * W.threatMoving - approachDist(u, h) * aw + cover * S.cover + realism + rng(B) * W.jitter;
    if (T.captures && capturable(h, p.id, B)) {
      const site = captureSite(h, B);
      score +=
        (site.capPid === p.id ? W.finishCapture : site.kind ? W.captureStructure : W.captureCity) +
        (B.rules.vp ? W.vpCity : 0) +
        (B.rules.capitalLoss && isEnemyCapital(h) ? W.captureCapital : 0);
    }
    // Bombard an enemy structure from here (used when there is no unit to shoot)
    let satk = 0,
      stgt = null;
    if (u.ammo > 0 && effOf(T).land)
      for (const es of enemyStructs) {
        if (!inRange(u.type, h, es, B)) continue;
        const d = structDamage(u, es.s, undefined, B),
          v = STRUCTS[es.s.kind].value,
          sc = v * Math.min(1, d / es.s.hp) + (d >= es.s.hp ? v : 0);
        if (sc > satk) {
          satk = sc;
          stgt = es;
        }
      }
    if (!tgt && stgt) score += satk * S.atk;
    if (broken(u, B)) score -= distOwn(h) * W.brokenRetreat; // broken: fall back toward supply
    if (feinting) score -= hexDist(h, feint.target) * W.feintPull; // the feint
    if (wantsHome) {
      // aircraft and ships go back to their own airfield or port to rearm and repair
      const dh = Math.min(...home.map(x => hexDist(x, h)));
      score -= dh * W.homeDistance;
      if (T.domain === 'air' ? dh === 0 : dh <= 1) score += W.homeArrive;
    } else if (lowSupply(u)) score -= distOwn(h) * (u.ammo === 0 ? W.resupplyEmpty : W.resupplyLow);
    {
      const ow = B.territory[key(h.c, h.r)];
      if (territoryGame && !isAir(u) && ow !== p.id && !grants(ow, p.id, 'territory', B)) score += W.paintGround + node.cost;
    } // painting more ground (not an ally's)
    if (attritionNow && !isAir(u) && !friendlyGround(B.territory[key(h.c, h.r)], p.id, B)) score -= W.attritionAvoid; // attrition: stay in supply
    score -= objCost(h);
    if (T.repairs && !stall) {
      // engineers stay behind the front line and close to friends (until a stalemate)
      const nh = nearest(h);
      if (nh < front + 1) score -= (front + 1 - nh) * W.engineerBehindFront;
      const fd = friendDist(h);
      if (fd > 2) score -= (fd - 2) * W.engineerNearFriends;
    }
    if (T.domain === 'air' && u.fuel != null && u.fuel - (node.cost + distOwn(h)) * (T.fuelRate || 1) - (T.upkeep ?? AIR_UPKEEP) < 0)
      score -= W.fuelReserve; // keep enough fuel to get home
    if (!best || score > best.score) best = { score, node, tgt, stgt: tgt ? null : stgt };
  }
  let holdScore =
    (B.rules.entrench ? (u.dug || 0) * W.stayDugIn : 0) + // don't throw away a dug-in position lightly
    (B.rules.supplyLines && T.domain === 'land' && !inSupply(B, u) ? -W.supplyAvoid : 0) +
    (lowSupply(u) && B.territory[key(u.c, u.r)] === p.id ? W.holdInSupply : 0) +
    (stall ? W.holdInStalemate : S.hold) -
    threatAt(u, u) * riskW * W.threatHolding -
    approachDist(u, u) * aw;
  holdScore -= objCost(u);
  if (broken(u, B)) holdScore -= distOwn(u) * W.brokenRetreat;
  if (feinting) holdScore -= hexDist(u, feint.target) * W.feintPull;
  if (attritionNow && !isAir(u) && !friendlyGround(B.territory[key(u.c, u.r)], p.id, B)) holdScore -= W.attritionAvoid;
  // Staying put pays the same "far from home" cost as moving, so units that need supplies don't just wait.
  if (wantsHome) {
    const dh = distHome(u);
    holdScore -= dh * W.homeDistance;
    if (T.domain === 'air' ? dh === 0 : dh <= 1) holdScore += W.homeArrive;
  } else if (lowSupply(u)) holdScore -= distOwn(u) * (u.ammo === 0 ? W.resupplyEmpty : W.resupplyLow);
  let final = { c: u.c, r: u.r };
  if (!best || (!best.tgt && holdScore > best.score)) orders[u.id] = { type: 'hold' };
  else if (best.node.cost === 0)
    orders[u.id] = best.tgt
      ? { type: 'fire', target: best.tgt.id }
      : best.stgt
        ? { type: 'fire', starget: { c: best.stgt.c, r: best.stgt.r } }
        : { type: 'hold' };
  else {
    const path = pathTo(best.node);
    if (B.rules.engage && best.tgt && T.domain !== 'air')
      orders[u.id] = { type: 'engage', target: best.tgt.id }; // aircraft keep a planned path so the fuel-home check holds
    else if (B.rules.engage && p.ai === 'aggressive' && !best.tgt) orders[u.id] = { type: 'amove', path };
    else
      orders[u.id] = Object.assign(
        { type: 'move', path, target: best.tgt ? best.tgt.id : null },
        best.stgt ? { starget: { c: best.stgt.c, r: best.stgt.r } } : {}
      );
    final = path[path.length - 1];
  }
  // Capture a city we're ending on; otherwise plant a forward flag far from home.
  const stays = final.c === u.c && final.r === u.r;
  if (T.captures && capturable(final, p.id, B)) {
    orders[u.id] = stays
      ? { type: 'capture' }
      : { type: 'move', path: pathTo(best.node), target: best.tgt ? best.tgt.id : null, capture: true };
  } else if (
    T.domain === 'land' &&
    ctx.flagsThisTurn < (territoryGame ? 2 : 1) &&
    !(best && best.tgt) &&
    canFlagAt(final, B) &&
    B.territory[key(final.c, final.r)] !== p.id &&
    distOwn(final) >= 2
  ) {
    const o = orders[u.id];
    if (o.type === 'move' || o.type === 'amove') {
      o.flag = true;
      ctx.flagsThisTurn++;
    } else if (o.type === 'hold') {
      orders[u.id] = { type: 'flag' };
      ctx.flagsThisTurn++;
    }
  }
  // Engineers with nothing to repair lay road wherever they stop.
  if (T.builds && !(best && best.tgt) && canRoadAt(final, B)) {
    const o = orders[u.id];
    if (o.type === 'move' || o.type === 'amove') {
      if (!o.flag) o.road = true;
    } else if (o.type === 'hold') orders[u.id] = { type: 'road' };
  }
  reserved.add(lkey(u, final.c, final.r));
}
