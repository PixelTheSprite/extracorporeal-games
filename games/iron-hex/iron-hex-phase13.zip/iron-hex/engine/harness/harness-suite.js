// Regression suites, part 2: the named suites of battle setups and runSuite.
// Named suites of battle setups.
// Each case's seed comes from its label (FNV-1a hash), so adding or reordering cases never changes the others.
function seedFor(label) {
  let h = 2166136261;
  for (let i = 0; i < label.length; i++) h = Math.imul(h ^ label.charCodeAt(i), 16777619) >>> 0;
  return 1000 + (h % 900000);
}
function suiteCases(name) {
  const cases = [];
  const add = (label, settings, extra = {}) => cases.push(Object.assign({ label, seed: seedFor(label), settings }, extra));
  const extras = () => {
    add('Territory victory, 60% for 3 turns', { rules: RULES_ON, victory: HOLD60 });
    add('Island Hop, every unit type', { rules: RULES_ON, victory: DESTROY, mapId: 'islands', roster: FULL_ROSTER });
    add(
      'Defensive vs defensive',
      { rules: RULES_ON, victory: DESTROY, strategies: ['player', 'defensive', 'defensive', 'defensive'] },
      { humanAI: 'defensive' }
    );
    add(
      'Defensive vs defensive, classic rules',
      { rules: RULES_OFF, victory: DESTROY, strategies: ['player', 'defensive', 'defensive', 'defensive'] },
      { humanAI: 'defensive' }
    );
    add('4 armies, random map, every unit type', {
      rules: RULES_ON,
      victory: DESTROY,
      armies: 4,
      mapId: 'random',
      randomSeed: 4242,
      roster: FULL_ROSTER,
    });
    const stDef = genMap('strait', 1942, 'Sandstorm Strait');
    add(
      'Infrastructure layout, every unit type',
      { rules: RULES_ON, victory: DESTROY, roster: FULL_ROSTER, layout: { mapId: 'strait', structs: autoLayout(stDef, 2) } },
      { infra: true }
    );
    add('Real map: Donbas', { rules: RULES_ON, victory: DESTROY, mapId: 'real-donbas' });
    add('Real map: Taiwan Strait, every unit type', {
      rules: RULES_ON,
      victory: DESTROY,
      mapId: 'real-taiwan',
      roster: FULL_ROSTER,
      playSide: 1,
    });
    add(
      '2 vs 2, random map',
      { rules: RULES_ON, victory: DESTROY, armies: 4, mapId: 'random', randomSeed: 5150, teams: [0, 0, 1, 1] },
      { teamCheck: true }
    );
    add(
      '2 vs 2, Suwałki Gap alliances',
      { rules: RULES_ON, victory: DESTROY, armies: 4, mapId: 'real-suwalki', teams: [0, 1, 0, 1] },
      { teamCheck: true }
    );
    add(
      '2 vs 2, territory victory, you grant allies nothing',
      {
        rules: RULES_ON,
        victory: HOLD60,
        armies: 4,
        mapId: 'random',
        randomSeed: 6161,
        teams: [0, 1, 1, 0],
        grants: { territory: false, resupply: false, passage: false },
      },
      { teamCheck: true }
    );
    add(
      'Infrastructure layout, classic rules',
      { rules: RULES_OFF, victory: DESTROY, roster: FULL_ROSTER, layout: { mapId: 'strait', structs: autoLayout(stDef, 2) } },
      { infra: true }
    );
  };
  // The first case is also used for the determinism, save round-trip and migration checks, so it turns everything on.
  add('Everything on', { rules: RULES_ALL, victory: DESTROY }, { p7: true });
  // Realism rules (Phase 11), each on top of the core rules, plus all of them together.
  const p11 = () => {
    for (const k of P11_KEYS)
      add(
        `Core rules + ${RULES[k].label}`,
        {
          rules: Object.assign(
            {},
            RULES_ON,
            { [k]: true },
            k === 'surrender' ? { supplyLines: true, morale: true } : k === 'infoOps' ? { morale: true } : {}
          ),
          victory: DESTROY,
        },
        { real: true }
      );
    add(
      'All realism rules',
      { rules: Object.assign({}, RULES_ON, Object.fromEntries(P11_KEYS.map(k => [k, true]))), victory: DESTROY },
      { real: true }
    );
    add(
      'All realism rules, territory, every unit type',
      { rules: Object.assign({}, RULES_ON, Object.fromEntries(P11_KEYS.map(k => [k, true]))), victory: HOLD60, roster: FULL_ROSTER },
      { real: true }
    );
  };
  // Missiles and city development (Phase 12).
  const p12 = () => {
    const eng = { tank: 2, inf: 2, eng: 2, aa: 1, ship: 1, battleship: 1, lst: 1 };
    add(
      'Core rules + Missile silos',
      { rules: Object.assign({}, RULES_ON, { missiles: true }), victory: DESTROY, roster: eng },
      { p12: true }
    );
    add(
      'Core rules + Missile silos, economy',
      { rules: Object.assign({}, RULES_ON, { missiles: true, income: true, production: true }), victory: DESTROY, roster: eng },
      { p12: true }
    );
    add(
      'Core rules + City development',
      { rules: Object.assign({}, RULES_ON, { cityDev: true, income: true, production: true }), victory: DESTROY },
      { p12: true }
    );
    add(
      'Missiles and city development together',
      {
        rules: Object.assign({}, RULES_ON, { missiles: true, cityDev: true, income: true, production: true }),
        victory: DESTROY,
        roster: eng,
      },
      { p12: true }
    );
  };
  const p7 = () => {
    for (const k of P7_KEYS)
      add(
        `Core rules + ${RULES[k].label}`,
        {
          rules: Object.assign(
            {},
            RULES_ON,
            { [k]: true },
            ['intelFade', 'decoys', 'aiDeception'].includes(k) ? { fog: true, decoys: k === 'aiDeception' ? true : k === 'decoys' } : {}
          ),
          victory: DESTROY,
        },
        { p7: true }
      );
    add(
      'Everything on, 2 vs 2',
      { rules: RULES_ALL, victory: DESTROY, armies: 4, mapId: 'random', randomSeed: 7171, teams: [0, 0, 1, 1] },
      { p7: true, teamCheck: true }
    );
    add('Everything on, territory victory, every unit type', { rules: RULES_ALL, victory: HOLD60, roster: FULL_ROSTER }, { p7: true });
  };
  if (name === 'quick') {
    p7();
    p11();
    p12();
    add('All rules on', { rules: RULES_ON, victory: DESTROY });
    add('All rules off', { rules: RULES_OFF, victory: DESTROY });
    for (const k of RULE_KEYS.concat(ENDGAME_KEYS))
      add(`Only ${RULES[k].label}`, { rules: Object.assign({}, RULES_OFF, { [k]: true }), victory: DESTROY });
    extras();
  } else {
    p7();
    p11();
    p12();
    // Every real-world map (all of its sides), and a large generated custom map
    for (const m of REAL_MAPS)
      add(`Real map: ${m.name}, ${m.spawns.length} sides`, {
        rules: RULES_ON,
        victory: DESTROY,
        mapId: m.id,
        armies: m.spawns.length,
        roster: FULL_ROSTER,
      });
    const big = genMap('custom', 77, 'Huge custom', { W: 40, H: 30, water: 40, mountains: 30, forest: 40, desert: 20 });
    big.id = 'custom-test';
    add('Custom 40 × 30 map, 4 armies', { rules: RULES_ON, victory: DESTROY, mapId: big.id, customMap: big, armies: 4 });
    // Every combination of the six rule toggles, under both victory conditions (128 battles).
    // ... and the two endgame rules cycle through all four on/off combinations across these 128 battles.
    for (let m = 0; m < 64; m++) {
      for (const [vi, victory] of [
        [0, DESTROY],
        [1, HOLD60],
      ]) {
        const e = (m * 2 + vi) % 4;
        const rules = Object.assign(Object.fromEntries(RULE_KEYS.map((k, i) => [k, !!(m & (1 << i))])), {
          exhaust: !!(e & 1),
          attrition: !!(e & 2),
        });
        const on =
          RULE_KEYS.concat(ENDGAME_KEYS)
            .filter(k => rules[k])
            .map(k => RULES[k].short)
            .join(', ') || 'no rules';
        add(`${on} | ${vi ? 'territory 60%' : 'destruction'}`, { rules, victory });
      }
    }
    extras();
  }
  return cases;
}
// Runs a suite and returns rows of { label, status:'pass'|'warn'|'fail', detail, ms }.
// A battle that reaches the turn limit is a warning (a likely stalemate), not a failure.
async function runSuite(name, onProgress = () => {}, shouldStop = () => false) {
  const cases = suiteCases(name),
    rows = [],
    total = cases.length + 15;
  let done = 0;
  // onProgress may return a promise (the browser uses it to yield a frame so the page stays responsive).
  const push = async row => {
    rows.push(row);
    await onProgress(++done / total, row);
  };
  const problems = validateAll();
  await push({
    label: 'Data validation (unit types and maps)',
    status: problems.length ? 'fail' : 'pass',
    detail: problems.length
      ? problems.join('; ')
      : `${Object.keys(UNIT_TYPES).length} unit types, ${MAP_PRESETS.length} generated and ${REAL_MAPS.length} real-world maps`,
    ms: 0,
  });
  for (const c of cases) {
    if (shouldStop()) return rows;
    const r = await runHeadlessBattle(c);
    const ffBad = r.ok && c.teamCheck && r.stats.friendlyFire;
    await push({
      label: c.label,
      ms: r.ms,
      status: !r.ok || ffBad ? 'fail' : r.reason === 'timeout' ? 'warn' : 'pass',
      detail: r.ok
        ? `${r.winner} won by ${r.reason === 'timeout' ? 'turn limit' : r.reason} on turn ${r.turns}` +
          (c.infra || r.stats.built
            ? `; structures built ${r.stats.built}, captured ${r.stats.captured}, destroyed ${r.stats.destroyed}, airfield landings ${r.stats.landings}, port calls ${r.stats.portCalls}`
            : '') +
          (c.teamCheck ? `; allies hit each other ${r.stats.friendlyFire || 0} times` : '') +
          (c.real
            ? `; surrendered ${r.stats.surrendered || 0}, friction ${r.stats.friction || 0}, mines laid ${r.stats.minesLaid || 0} hit ${r.stats.minesHit || 0}, reinforced ${r.stats.reinforced || 0}, broadcasts ${r.stats.broadcasts || 0}`
            : '') +
          (c.p7
            ? `; produced ${r.stats.produced || 0}, decoys ${r.stats.decoys || 0} (${r.stats.decoysExposed || 0} exposed), feints ${r.stats.feints || 0}, storms ${r.stats.storms || 0}, units broken ${r.stats.broken || 0}`
            : '')
        : r.error,
    });
    if (r.ok) c.result = r;
  }
  if (shouldStop()) return rows;
  await checkUnitEditor(push);
  await checkCampaign(push);
  await checkLooksAndRecords(rows, push);
  await checkTurnLimitGate(cases, push);
  await checkMultiTurnOrders(push);
  await checkReplay(push);
  // Infrastructure gate: across the battles, the AI must build, land on airfields and put in at ports.
  const sum = k => cases.reduce((s, c) => s + (c.result ? c.result.stats[k] : 0), 0);
  const used = {
    built: sum('built'),
    landings: sum('landings'),
    portCalls: sum('portCalls'),
    captured: sum('captured'),
    destroyed: sum('destroyed'),
  };
  await push({
    label: 'AI uses infrastructure',
    ms: 0,
    status: used.built && used.landings && used.portCalls ? 'pass' : 'fail',
    detail: `${used.built} structures built, ${used.landings} airfield landings, ${used.portCalls} port calls, ${used.captured} captured, ${used.destroyed} destroyed across ${cases.length} battles`,
  });
  const c0 = cases[0],
    first = c0.result || (await runHeadlessBattle(c0)),
    again = await runHeadlessBattle(c0);
  await push({
    label: 'Determinism: same seed twice',
    ms: again.ms,
    status: first.ok && again.ok && first.hash === again.hash ? 'pass' : 'fail',
    detail: first.ok && again.ok ? `state ${first.hash} vs ${again.hash}` : again.error || first.error,
  });
  const rt = await runHeadlessBattle(Object.assign({}, c0, { roundTripAt: 5 }));
  await push({
    label: 'Save and reload at turn 5 gives the same battle',
    ms: rt.ms,
    status: rt.ok && rt.hash === first.hash ? 'pass' : 'fail',
    detail: rt.ok ? `state ${rt.hash} vs ${first.hash}` : rt.error,
  });
  const mg = await runHeadlessBattle(Object.assign({}, c0, { migrateFromV1: true }));
  await push({
    label: 'Version 1 save upgrades and plays to the end',
    ms: mg.ok ? mg.ms : 0,
    status: mg.ok ? 'pass' : 'fail',
    detail: mg.ok ? `upgraded to version ${mg.version}; ${mg.winner} won on turn ${mg.turns}` : mg.error,
  });
  return rows;
}
