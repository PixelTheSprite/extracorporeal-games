// Headless battles and the regression suites. Shared by tests/run.mjs (Node) and the in-game Diagnostics screen.
// A headless battle swaps in NullView and its own settings, plays AI against AI to the end, then restores
// whatever battle and settings were active before.
const RULE_KEYS = ['zoc', 'realtime', 'engage', 'terrRadius', 'terrPaint', 'terrSpread'],
  ENDGAME_KEYS = ['exhaust', 'attrition'];
const P11_ROSTERS = {
  artillery: { tank: 2, inf: 2, eng: 1, arty: 2 },
  subs: { tank: 1, inf: 2, ship: 1, sub: 2, lst: 1 },
  carriers: { tank: 1, inf: 2, plane: 2, carrier: 1, ship: 1, lst: 1 },
  mines: { tank: 2, inf: 2, eng: 2, ship: 1, lst: 1 },
};
const P11_KEYS = [
  'supplyLines',
  'entrench',
  'suppression',
  'facing',
  'urban',
  'elevation',
  'surrender',
  'command',
  'friction',
  'ew',
  'airSup',
  'aaUmbrella',
  'artillery',
  'subs',
  'mines',
  'carriers',
  'rail',
  'seasons',
  'reinforce',
  'vp',
  'infoOps',
  'ammo',
];
const P7_KEYS = ['fog', 'intelFade', 'decoys', 'aiDeception', 'income', 'production', 'capitalLoss', 'weather', 'morale'];
const RULES_ON = Object.fromEntries(
  RULE_KEYS.concat(ENDGAME_KEYS)
    .map(k => [k, true])
    .concat(P7_KEYS.map(k => [k, false]))
);
const RULES_OFF = Object.fromEntries(RULE_KEYS.concat(ENDGAME_KEYS, P7_KEYS, P11_KEYS, ['missiles', 'cityDev']).map(k => [k, false]));
const P12_KEYS = ['missiles', 'cityDev'];
const RULES_ALL = Object.fromEntries(RULE_KEYS.concat(ENDGAME_KEYS, P7_KEYS, P11_KEYS, P12_KEYS).map(k => [k, true]));
const FULL_ROSTER = Object.fromEntries(BASE_TYPES.map(t => [t, 1])); // the original twelve (rule-gated units have their own cases)
const DESTROY = { mode: 'destruction', pct: 60, hold: 3 },
  HOLD60 = { mode: 'territory', pct: 60, hold: 3 };

// Compact fingerprint of everything that affects the rest of the battle.
function stateHash(B) {
  const units = everyUnit(B).map(u => [
    u.id,
    u.type,
    u.pid,
    u.c,
    u.r,
    u.hp,
    u.ammo,
    u.fuel == null ? null : Math.round(u.fuel * 1000),
    u.in || 0,
    u.cargo || 0,
    u.dug || 0,
    u.supp || 0,
    u.cut || 0,
    u.face || 0,
  ]);
  const terr = Object.keys(B.territory || {})
    .sort()
    .map(k => k + '=' + B.territory[k]);
  return hashString(
    JSON.stringify([
      B.turn,
      B.rngState,
      units,
      terr,
      B.flags,
      B.cities,
      Object.keys(B.roads || {}).sort(),
      B.holds,
      B.quiet,
      B.structs,
      B.stats,
    ])
  );
}
// Turns the current battle's save into the version-1 shape (no seed, rules, logistics or fuel) for migration tests.
function toV1Save() {
  const d = clone(snapshot()),
    b = d.battle;
  d.version = 1;
  for (const k of ['seed', 'rngState', 'rules', 'victory', 'holds', 'quiet', 'territory', 'flags', 'cities', 'roads', 'structs', 'stats'])
    delete b[k];
  for (const u of b.units) {
    delete u.fuel;
    delete u.maxFuel;
  }
  return d;
}
// cfg: { label, seed, settings:{...overrides of defaultSettings()}, humanAI, roundTripAt, migrateFromV1 }
async function runHeadlessBattle(cfg) {
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, ai: R.aiOrders, view: VIEW };
  VIEW = NullView;
  const t0 = Date.now();
  let res;
  try {
    appState.settings = Object.assign(defaultSettings(), clone(cfg.settings || {}));
    newBattle(cfg.seed);
    let out = { end: false },
      migrated = null;
    while (!out.end) {
      const B = appState.battle;
      if (cfg.migrateFromV1 && B.turn === 1 && migrated == null) {
        migrated = applySave(toV1Save());
        if (!migrated) throw new Error('version 1 save was rejected');
        R.map = buildMap(appState.battle.mapDef);
        ensureLogistics(appState.battle);
      }
      if (cfg.roundTripAt && B.turn === cfg.roundTripAt && !B._reloaded) {
        if (!applySave(clone(snapshot()))) throw new Error('save was rejected on reload');
        R.map = buildMap(appState.battle.mapDef);
        ensureLogistics(appState.battle);
        appState.battle._reloaded = true;
      }
      out = await simulateTurn(planAllAI(cfg.humanAI || 'balanced'));
    }
    const B = appState.battle,
      win = out.winner !== undefined ? out.winner : pickWinner(out.remaining);
    res = {
      ok: true,
      reason: out.reason,
      turns: B.turn,
      winner: win ? win.name : 'none',
      hash: stateHash(B),
      version: SAVE_VERSION,
      units: B.units.length,
      stats: Object.assign({}, B.stats),
      ms: Date.now() - t0,
    };
  } catch (e) {
    res = {
      ok: false,
      error: String((e && e.stack) || e)
        .split('\n')
        .slice(0, 3)
        .join(' | '),
      ms: Date.now() - t0,
    };
  } finally {
    appState.battle = saved.battle;
    appState.settings = saved.settings;
    R.map = saved.map;
    R.aiOrders = saved.ai;
    VIEW = saved.view;
  }
  return res;
}
// Unit Editor fixture: a canned lookup answer (what Claude would return), parsed into a custom unit.
const LOOKUP_FIXTURE = {
  found: true,
  name: 'T-34-85',
  short: 'T-34',
  role: 'Medium tank',
  domain: 'land',
  era: 'WWII',
  country: 'Soviet Union',
  stats: {
    speed: { value: 55, unit: 'km/h', note: 'road speed' },
    maneuver: { value: 16, unit: 'hp/tonne' },
    armor: { value: 90, unit: 'mm', note: 'turret front' },
    firepower: { value: 120, unit: 'mm', note: '85 mm ZiS-S-53' },
  },
  game: { range: [1, 2], ammo: 6, fuel: 24, abilities: [], eff: { land: 1, sea: 0.6, air: 0 } },
  sources: ['Zaloga, T-34-85 Medium Tank (1996)'],
  confidence: 'high',
};
const FIXTURE_ART = [
  '......kkkkk.....',
  '.....kttlttk....',
  '.....ktttttkkkkk',
  '..kkkkkkkkkkkkk.',
  '.kttttttttttttk.',
  'kddddddddddddddk',
  'kwgwgwgwgwgwgwwk',
  '..kkkkkkkkkkkk..',
];
function fixtureUnit() {
  const d = parseLookup('```json\n' + JSON.stringify(LOOKUP_FIXTURE) + '\n```');
  d.id = 'u_t34fixture';
  d.art = FIXTURE_ART;
  return unitFromDraft(d);
}
