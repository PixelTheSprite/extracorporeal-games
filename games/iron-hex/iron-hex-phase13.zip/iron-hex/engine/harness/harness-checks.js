// Regression suites, part 3: the scenario checks (unit editor, campaign, looks and records, turn limit, replay, multi-turn orders).
// Unit Editor: a lookup answer becomes a valid unit; it fights; a save carrying it reloads where it was never installed.
async function checkUnitEditor(push) {
  const T = fixtureUnit(),
    probs = registerCustomUnit(T);
  await push({
    label: 'Unit Editor: lookup answer becomes a valid unit',
    ms: 0,
    status: probs.length ? 'fail' : 'pass',
    detail: probs.length
      ? probs.join('; ')
      : `${T.name}: speed ${T.stats.speed}, maneuver ${T.stats.maneuver}, armor ${T.stats.armor}, firepower ${T.stats.firepower}; move ${T.move}, HP ${T.hp}`,
  });
  if (!probs.length) {
    const cb = await runHeadlessBattle({
      label: 'custom',
      seed: 4321,
      settings: { rules: RULES_ON, victory: DESTROY, roster: { u_t34fixture: 2, tank: 1, inf: 2, plane: 1, ship: 1 } },
    });
    let reload = 'not run';
    if (cb.ok) {
      // fresh-browser check: snapshot a battle with the unit, forget the unit, then load the save
      const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
      VIEW = NullView;
      appState.settings = Object.assign(defaultSettings(), { roster: { u_t34fixture: 1, tank: 1 } });
      newBattle(99);
      const snap = clone(snapshot());
      unregisterCustomUnit('u_t34fixture');
      reload = applySave(snap) && UNIT_TYPES.u_t34fixture ? 'ok' : 'failed';
      appState.battle = saved.battle;
      appState.settings = saved.settings;
      R.map = saved.map;
      VIEW = saved.view;
    }
    await push({
      label: 'Unit Editor: custom unit fights and survives save/load',
      ms: cb.ms || 0,
      status: cb.ok && reload === 'ok' ? 'pass' : 'fail',
      detail: cb.ok ? `${cb.winner} won by ${cb.reason} on turn ${cb.turns}; reload in a fresh browser ${reload}` : cb.error,
    });
  }
  unregisterCustomUnit('u_t34fixture');
  // Security: a custom unit id that could break out of page markup is refused, and so is a save carrying one.
  const evil = Object.assign(fixtureUnit(), { id: 'u_x" onmouseover="alert(1)' });
  const refused = registerCustomUnit(evil).length > 0 && !UNIT_TYPES[evil.id];
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  VIEW = NullView;
  appState.settings = defaultSettings();
  newBattle(5);
  const snap = clone(snapshot());
  snap.battle.customTypes = { [evil.id]: evil };
  const saveRefused = !applySave(snap);
  appState.battle = saved.battle;
  appState.settings = saved.settings;
  R.map = saved.map;
  VIEW = saved.view;
  await push({
    label: 'Security: unsafe custom unit ids are refused',
    ms: 0,
    status: refused && saveRefused ? 'pass' : 'fail',
    detail: `registering: ${refused ? 'refused' : 'ACCEPTED'}; loading a save that carries one: ${saveRefused ? 'refused' : 'ACCEPTED'}`,
  });
}
// Campaign: every mission plays to a decision, and the whole campaign plays through with carried-over veterans.
async function checkCampaign(push) {
  const t0 = Date.now(),
    saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  VIEW = NullView;
  appState.settings = defaultSettings();
  const play = async () => {
    let out = { end: false };
    while (!out.end) out = await simulateTurn(planAllAI('balanced'));
    return out;
  };
  try {
    const results = [];
    // every mission of every built-in campaign (the Iron Coast first, so its seeds never move)
    for (const C of BUILTIN_CAMPAIGNS)
      for (const id of Object.keys(C.missions)) {
        const st = newCampaignState(C);
        st.mission = id;
        newMissionBattle(st, C, 500 + results.length);
        const out = await play();
        results.push(
          `${C.missions[id].title}: ${out.reason === 'objective' ? 'won' : out.reason === 'destruction' ? (out.remaining[0] && out.remaining[0].id === 0 ? 'won' : 'lost') : 'lost'} on turn ${appState.battle.turn}`
        );
      }
    await push({ label: 'Campaign: every mission plays to a decision', ms: Date.now() - t0, status: 'pass', detail: results.join('; ') });
    const bad = BUILTIN_CAMPAIGNS.flatMap(c => validateCampaign(c).map(x => c.name + ': ' + x));
    await push({
      label: 'Campaigns: built-in definitions are valid',
      ms: 0,
      status: bad.length ? 'fail' : 'pass',
      detail: bad.join('; ') || BUILTIN_CAMPAIGNS.map(c => `${c.name}, ${campaignLength(c)} missions per path`).join('; '),
    });
    // whole campaign, retrying lost missions up to 3 times each
    let st = newCampaignState(),
      played = [],
      tries = 0,
      promoted = 0;
    while (!st.done && tries < 12) {
      tries++;
      newMissionBattle(st, CAMPAIGN, 900 + tries);
      const out = await play(),
        B = appState.battle;
      const won = out.winner ? out.winner.id === 0 : out.remaining.length === 1 && out.remaining[0].id === 0;
      const res = campaignAfterMission(st, B, won);
      played.push(`${CAMPAIGN.missions[st.mission].title} ${won ? 'won' : 'lost'}`);
      promoted += res.promotions.length;
      st = res.state;
      if (!st.roster.length) break;
    }
    const vets = st.roster.filter(u => u.xp > 0).length;
    await push({
      label: 'Campaign: plays through with veterans carried over',
      ms: Date.now() - t0,
      status: st.done && played.length >= 3 && vets ? 'pass' : played.length >= 3 ? 'warn' : 'fail',
      detail: `${played.join(' → ')}; ${st.roster.length} units left, ${vets} with experience, ${promoted} promotions`,
    });
  } catch (e) {
    await push({
      label: 'Campaign: missions',
      ms: Date.now() - t0,
      status: 'fail',
      detail: String((e && e.stack) || e)
        .split('\n')
        .slice(0, 2)
        .join(' | '),
    });
  } finally {
    appState.battle = saved.battle;
    appState.settings = saved.settings;
    R.map = saved.map;
    VIEW = saved.view;
  }
}
// Looks and records: every medieval sprite is valid; unlocks follow the ladder; records summarize.
async function checkLooksAndRecords(rows, push) {
  const p = [];
  for (const [t, rows] of Object.entries(SKIN_ART.medieval)) {
    if (!UNIT_TYPES[t]) p.push(`medieval look for unknown unit ${t}`);
    p.push(...validateArt(rows).map(x => `${t} ${x}`));
  }
  for (const t of BASE_TYPES) if (!SKIN_ART.medieval[t] || !SKIN_NAMES.medieval[t]) p.push(`no medieval look for ${t}`);
  const prof = { units: { tank: { battles: 3, kills: 12, wins: 1, special: 0 }, inf: { battles: 2, kills: 0, wins: 0, special: 0 } } };
  const ok = unlockedPeriods(prof, 'tank').join() === 'modern,medieval,ancient' && unlockedPeriods(prof, 'inf').join() === 'modern';
  const sum = summarizeRecords([
    { at: '1', result: 'win', turns: 20, mapName: 'A', opponents: ['balanced'] },
    { at: '2', result: 'win', turns: 12, mapName: 'B', opponents: ['aggressive'] },
    { at: '3', result: 'loss', turns: 30, mapName: 'A', opponents: ['balanced'] },
  ]);
  const recOk =
    sum.wins === 2 && sum.losses === 1 && sum.fastestWin.turns === 12 && sum.bestStreak === 2 && sum.streak === 0 && sum.byMap.A.w === 1;
  await push({
    label: 'Looks and records: sprites, unlock ladder, leaderboard summary',
    ms: 0,
    status: !p.length && ok && recOk ? 'pass' : 'fail',
    detail: p.length
      ? p.join('; ')
      : `${Object.keys(SKIN_ART.medieval).length} medieval sprites valid; unlocks ${ok ? 'follow the ladder' : 'WRONG'}; summary ${recOk ? 'correct' : 'WRONG'}`,
  });
}
// Phase 6 gate: fewer than 1 in 20 battles reach the turn limit.
async function checkTurnLimitGate(cases, push) {
  const done = cases.filter(c => c.result),
    to = done.filter(c => c.result.reason === 'timeout').length,
    ex = done.filter(c => c.result.reason === 'exhaustion').length;
  await push({
    label: 'Battles reaching the turn limit',
    ms: 0,
    status: to * 20 < done.length ? 'pass' : 'warn',
    detail: `${to} of ${done.length} (${Math.round((100 * to) / Math.max(1, done.length))}%); ${ex} ended by supply exhaustion`,
  });
}
// Multi-turn orders: a far-off move gets there over several turns; Overwatch stands until changed.
// Replays: play a full battle with every rule on, then replay it from its opening state; the final state must match.
async function checkReplay(push) {
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  let ok = false,
    detail = '';
  try {
    VIEW = NullView;
    appState.settings = defaultSettings();
    Object.assign(appState.settings.rules, RULES_ALL, { vp: false }); // every rule but victory points, whose war weariness ends battles early
    newBattle(seedFor('replay check'));
    let out = { end: false };
    while (!out.end) out = await simulateTurn(planAllAI('balanced'));
    const B = appState.battle,
      want = stateHash(B),
      rep = replayOf(B),
      turns = rep.log.length;
    const size = JSON.stringify(rep).length;
    if (!loadReplayStart(rep)) throw new Error('replay start would not load');
    let o = { end: false };
    for (let i = 0; i < turns && !o.end; i++) o = await replayTurn(rep, i);
    const got = stateHash(appState.battle);
    ok = got === want;
    detail = `${turns} turns replayed; final state ${got} vs ${want}; replay ${Math.round(size / 1024)} KB`;
  } catch (e) {
    detail = String((e && e.message) || e);
  }
  appState.battle = saved.battle;
  appState.settings = saved.settings;
  R.map = saved.map;
  VIEW = saved.view;
  await push({ label: 'Replay reproduces the battle exactly', ms: 0, status: ok ? 'pass' : 'fail', detail });
}
async function checkMultiTurnOrders(push) {
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  VIEW = NullView;
  appState.settings = defaultSettings();
  newBattle(321);
  let detail = '',
    ok = false;
  try {
    const B = appState.battle,
      u = B.units.find(x => x.pid === 0 && x.type === 'tank'),
      f = travelField(u, 4);
    const far = [...f.values()].filter(n => n.turns === 3).sort((a, b) => a.cost - b.cost)[0];
    const hold = B.units.find(x => x.pid === 0 && x.type === 'inf');
    noteStanding(B, u, { type: 'move', multi: { dest: { c: far.c, r: far.r } } });
    noteStanding(B, hold, { type: 'hold' });
    let turns = 0,
      arrived = false,
      held = true;
    while (turns < 8 && !arrived) {
      B.orders = {};
      const notes = applyStanding(B);
      if (notes.some(n => n.includes('arrived'))) {
        arrived = true;
        break;
      }
      if (!B.orders[hold.id] || B.orders[hold.id].type !== 'hold') held = false;
      const ai = planAllAI(null);
      Object.assign(ai, B.orders);
      const out = await simulateTurn(ai);
      turns++;
      if (out.end) break;
    }
    ok = arrived && held && turns >= 2;
    detail = `a hex about 3 turns away reached in ${turns} turns${arrived ? '' : ' (not reached)'}; Overwatch ${held ? 'stood every turn' : 'was lost'}`;
  } catch (e) {
    detail = String((e && e.message) || e);
  }
  appState.battle = saved.battle;
  appState.settings = saved.settings;
  R.map = saved.map;
  VIEW = saved.view;
  await push({ label: 'Multi-turn move and standing Overwatch', ms: 0, status: ok ? 'pass' : 'fail', detail });
}
