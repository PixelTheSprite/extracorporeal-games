// Realism rules, part 4 (batch 4): seasons, reinforcements, victory points, information operations, ammunition.
// ---- Batch 4: seasons, timed reinforcements, victory points and war weariness, information operations, ammunition ----
Object.assign(REAL, {
  SEASON_LEN: 15,
  MUD_COST: 0.5,
  SNOW_COST: 0.5,
  ICE_COST: 2,
  REINFORCE_EVERY: 8,
  REINFORCE_UNITS: 2,
  VP_PER_CITY: 1,
  VP_PER_CAPITAL: 3,
  VP_TARGET_PER_CITY: 3,
  WEARINESS: 0.6,
  BROADCAST_RANGE: 3,
  BROADCAST_MORALE: 10,
  BROADCAST_VERIFY: 2,
  AMMO_GOOD: 1.25,
  AMMO_BAD_AP: 0.7,
  AMMO_BAD_HE: 0.75,
});
const SEASONS = ['Spring', 'Summer', 'Autumn', 'Winter'];
// Seasons: the battle starts in a seeded season and moves on every SEASON_LEN turns.
function seasonOf(B = appState.battle) {
  if (!B || !B.rules || !B.rules.seasons || B.seasonStart == null) return null;
  return SEASONS[(B.seasonStart + Math.floor((B.turn - 1) / REAL.SEASON_LEN)) % 4];
}
// Extra cost for a ground unit stepping off-road onto (c, r); Infinity-free: null means "no change".
function seasonCost(T, t, onRoad, B = appState.battle) {
  const s = seasonOf();
  if (!s || T.domain !== 'land' || onRoad || TERRAIN[t].water) return 0;
  if (s === 'Winter') return REAL.SNOW_COST; // snow slows everyone off-road
  const raining = realOn('weather', B) && cond(B).w === 'rain';
  if ((s === 'Spring' || s === 'Autumn' || raining) && !T.foot) return REAL.MUD_COST; // mud bogs down vehicles
  return 0;
}
// Winter freezes the shallows: ground units can cross them.
const frozenCost = (T, t) => (seasonOf() === 'Winter' && T.domain === 'land' && t === 'w' ? REAL.ICE_COST : null);

// Timed reinforcements: every REINFORCE_EVERY turns, two units from the army's own roster arrive at its capital.
function logReinforcements(B) {
  if (!B.rules.reinforce || B.turn % REAL.REINFORCE_EVERY !== 0) return false;
  let ev = false;
  for (const p of B.players) {
    if (!inFight(p.id, B)) continue;
    const cap = B.mapDef.spawns[p.id],
      city = cap && B.cities[key(cap.c, cap.r)];
    if (!city || city.owner !== p.id) continue; // cut off from home: no reinforcements
    const pool = ((B.rosterTypes || {})[p.id] || []).filter(t => typeAllowed(t, B.rules));
    if (!pool.length) continue;
    B.reinforced = B.reinforced || {};
    for (let i = 0; i < REAL.REINFORCE_UNITS; i++) {
      if (allAlive(B).filter(u => u.pid === p.id).length >= ARMY_CAP) break;
      const n = (B.reinforced[p.id] = (B.reinforced[p.id] || 0) + 1),
        type = pool[(n - 1) % pool.length],
        T = UNIT_TYPES[type];
      const site = T.domain === 'land' || T.domain === 'air' ? cap : productionSites(B, p.id, type)[0];
      const h = site && (placeNewUnit(B, type, site) || freeNear(B, type, site, 2)); // a crowded capital: arrive within 2 hexes
      if (!h) continue;
      const u = {
        id: B.nextId++,
        pid: p.id,
        type,
        name: `${T.short} W${n}`,
        c: h.c,
        r: h.r,
        hp: T.hp,
        maxHp: T.hp,
        ammo: T.ammo,
        maxAmmo: T.ammo,
        fuel: T.fuel ?? null,
        maxFuel: T.fuel ?? null,
      };
      if (moraleOn(B)) u.morale = MORALE_START;
      const t = tileAt(h.c, h.r, B);
      u.px = t.wx;
      u.py = t.wy;
      u.pz = t.z + (T.domain === 'air' ? 1.4 : 0);
      u.dispHp = u.hp;
      B.units.push(u);
      floatText(u, 'Reinforcements', '#9fe86a');
      B.stats.reinforced = (B.stats.reinforced || 0) + 1;
      ev = true;
    }
  }
  return ev;
}

// Victory points and war weariness.
const vpTarget = B => REAL.VP_TARGET_PER_CITY * Math.max(3, Object.keys(B.cities || {}).length);
const armyValue = units => units.reduce((s, u) => s + priceOf(UNIT_TYPES[u.type]), 0);
function initVictoryPoints(B) {
  if (!B.rules.vp) return;
  B.vp = {};
  B.startValue = {};
  for (const p of B.players) B.startValue[p.id] = armyValue(B.units.filter(u => u.pid === p.id));
}
// Each turn: cities score for their holders' teams (an enemy capital counts triple).
function scoreVictoryPoints(B) {
  if (!B.rules.vp) return;
  B.vp = B.vp || {};
  for (const [k, c] of Object.entries(B.cities || {})) {
    if (c.owner == null || !inFight(c.owner, B)) continue;
    const isCap = B.mapDef.spawns.some((s, i) => key(s.c, s.r) === k && i !== c.owner);
    const t = teamOf(c.owner, B);
    B.vp[t] = (B.vp[t] || 0) + (isCap ? REAL.VP_PER_CAPITAL : REAL.VP_PER_CITY);
  }
}
// War weariness: an army that has lost more than WEARINESS of its starting strength sues for peace.
function warWeary(B, pid) {
  if (!B.rules.vp || !B.startValue || !B.startValue[pid]) return false;
  const lost = armyValue(everyUnit(B).filter(u => u.pid === pid && u.hp <= 0));
  return lost >= REAL.WEARINESS * B.startValue[pid];
}
const vpWinner = B => {
  if (!B.rules.vp || !B.vp) return null;
  const t = Object.keys(B.vp).find(t => B.vp[t] >= vpTarget(B));
  return t == null ? null : +t;
};

// Information operations: a rifle squad broadcasts. Enemy units within range lose morale unless enough of their
// own side is around to verify; with fog and fading intel, the enemy also gets a false report nearby.
const canBroadcast = (u, B = appState.battle) => realOn('infoOps', B) && UNIT_TYPES[u.type].captures && !u.in;
function logBroadcasts(B, st) {
  if (!B.rules.infoOps) return false;
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st && st.get(u.id);
    if (!s || s.o.type !== 'broadcast' || !canBroadcast(u, B)) continue;
    floatText(u, 'Broadcast', '#cfe3ff');
    B.stats.broadcasts = (B.stats.broadcasts || 0) + 1;
    ev = true;
    for (const e of aliveUnits(B)) {
      if (!isEnemy(e.pid, u.pid, B) || hexDist(e, u) > REAL.BROADCAST_RANGE) continue;
      const verifiers = aliveUnits(B).filter(o => o !== e && friendOf(o.pid, e.pid, B) && hexDist(o, e) <= 2).length;
      if (verifiers >= REAL.BROADCAST_VERIFY) continue; // checked against what their comrades see: no effect
      if (moraleOn(B) && e.morale != null) {
        e.morale = Math.max(0, e.morale - REAL.BROADCAST_MORALE);
        B.stats.demoralized = (B.stats.demoralized || 0) + 1;
      }
    }
    if (B.rules.fog && B.rules.intelFade) {
      const def = B.mapDef,
        near = neighborsRaw(u.c, u.r, def.W, def.H).filter(n => !TERRAIN[tileAt(n.c, n.r, B).t].water);
      if (near.length) {
        const n = near[Math.floor(rng(B) * near.length)];
        for (const p of B.players)
          if (isEnemy(p.id, u.pid, B)) {
            const I = ((B.intel = B.intel || {})[teamOf(p.id, B)] = (B.intel || {})[teamOf(p.id, B)] || {});
            I['f' + u.id + '_' + B.turn] = { c: n.c, r: n.r, type: 'tank', pid: u.pid, turn: B.turn, conf: 0.6, decoy: true };
          }
      }
    }
  }
  return ev;
}

// Ammunition types: armor-piercing against vehicles and ships, high-explosive against soldiers and structures.
const usesAmmoTypes = T => !!T && (T.id === 'tank' || T.id === 'arty' || T.id === 'ship' || T.id === 'battleship' || T.ammoTypes);
const armoredTarget = T => (T.domain === 'land' && !T.foot) || T.domain === 'sea';
function ammoDamage(att, tgt, B = appState.battle) {
  if (!realOn('ammo', B)) return 1;
  const A = UNIT_TYPES[att.type],
    T = UNIT_TYPES[tgt.type];
  if (!usesAmmoTypes(A) || T.domain === 'air') return 1;
  const ap = (att.ammoType || 'he') === 'ap';
  if (armoredTarget(T)) return ap ? REAL.AMMO_GOOD : REAL.AMMO_BAD_HE;
  return ap ? REAL.AMMO_BAD_AP : REAL.AMMO_GOOD;
}
const ammoStructDamage = (att, B = appState.battle) =>
  realOn('ammo', B) && usesAmmoTypes(UNIT_TYPES[att.type]) ? ((att.ammoType || 'he') === 'he' ? REAL.AMMO_GOOD : REAL.AMMO_BAD_AP) : 1;

// The nearest free hex (within `radius`) where a unit of this type can stand.
function freeNear(B, type, site, radius) {
  const T = UNIT_TYPES[type],
    def = B.mapDef,
    air = T.domain === 'air';
  const ok = h =>
    !unitAtLayer(h.c, h.r, air, B) &&
    (air || (T.domain === 'sea' ? TERRAIN[tileAt(h.c, h.r, B).t].water : landPassAt(h.c, h.r, B) && tileAt(h.c, h.r, B).t !== 'm'));
  let best = null;
  for (let r = site.r - radius; r <= site.r + radius; r++)
    for (let c = site.c - radius - 1; c <= site.c + radius + 1; c++) {
      if (r < 0 || c < 0 || r >= def.H || c >= def.W) continue;
      const h = { c, r },
        d = hexDist(site, h);
      if (d <= radius && ok(h) && (!best || d < best.d)) best = { c, r, d };
    }
  return best;
}
