// Realism rules, batch 1 (Phase 11): supply lines, entrenchment, suppression, armor facing, urban combat,
// elevation and surrender. Each is its own Battle settings toggle, off by default. Starting values are below,
// in one place, to be tuned with the A/B harness.
const REAL = {
  DIG_MAX: 3,
  DIG_PER: 0.1, // entrenchment: up to 3 levels, 10% less damage taken per level
  SUPPRESS_SHARE: 0.25,
  SUPPRESS_DMG: 0.5, // losing 25% of max HP in a turn suppresses for the next turn: no moving, half damage
  FACE_SIDE: 1.25,
  FACE_REAR: 1.5, // armored vehicles hit from the side or rear
  URBAN_FOOT_DEF: 0.45,
  URBAN_VEH_DEF: 0.1,
  URBAN_VEH_COST: 1, // cities: soldiers on foot well covered, vehicles exposed and slowed
  ELEV_DOWN: 1.15,
  ELEV_UP: 0.9, // firing downhill / uphill
  SURRENDER_CUT: 2,
  SURRENDER_HP: 0.25, // cut off for 2 turns (or surrounded), and broken or below 25% HP
};
const realOn = (k, B = appState.battle) => {
  return !!(B && B.rules && B.rules[k]);
};
const isVehicle = T => T.domain === 'land' && !T.foot;
const elevAt = (h, B = appState.battle) => TERRAIN[tileAt(h.c, h.r, B).t].elev;

// ---- combat ----
// Terrain cover a target gets (urban combat changes cities).
function terrainDef(T, t, B = appState.battle) {
  if (t === 'c' && realOn('urban', B) && T.domain === 'land') return T.foot ? REAL.URBAN_FOOT_DEF : REAL.URBAN_VEH_DEF;
  return TERRAIN[t].def;
}
// One multiplier for the realism rules, applied to every hit.
function realismDamage(att, tgt, pos, B = appState.battle) {
  const A = UNIT_TYPES[att.type],
    T = UNIT_TYPES[tgt.type];
  let m = 1;
  if (realOn('entrench', B) && T.domain === 'land' && tgt.dug) m *= 1 - REAL.DIG_PER * tgt.dug;
  if (realOn('suppression', B) && att.supp) m *= REAL.SUPPRESS_DMG;
  if (realOn('facing', B) && isVehicle(T) && tgt.face) {
    const a = toWorld(att.c, att.r),
      t = toWorld(pos.c, pos.r),
      dx = a.x - t.x,
      dy = a.y - t.y,
      len = Math.hypot(dx, dy) || 1;
    const dot = (dx * tgt.face[0] + dy * tgt.face[1]) / len; // 1 = attacker straight ahead, -1 = straight behind
    m *= dot >= 0.5 ? 1 : dot <= -0.5 ? REAL.FACE_REAR : REAL.FACE_SIDE;
  }
  if (realOn('elevation', B) && A.domain === 'land' && T.domain === 'land') {
    const d = elevAt(att, B) - elevAt(pos, B);
    m *= d > 0 ? REAL.ELEV_DOWN : d < 0 ? REAL.ELEV_UP : 1;
  }
  return m * commandAirDamage(att, tgt, pos, B) * ammoDamage(att, tgt, B);
}
// Elevation: long-range ground weapons reach one hex further firing down from higher ground.
function elevationRange(type, from, to, B = appState.battle) {
  if (!realOn('elevation', B)) return 0;
  const T = UNIT_TYPES[type];
  return T.domain === 'land' && T.range[1] >= 2 && elevAt(from, B) > elevAt(to, B) ? 1 : 0;
}
// Elevation: ground observers on hills or mountains see one hex further.
const elevationSight = (u, B = appState.battle) => (realOn('elevation', B) && !isAir(u) && elevAt(u, B) >= 2 ? 1 : 0);
// Urban combat: vehicles pay extra to enter a city.
const urbanCost = (T, t, B = appState.battle) => (t === 'c' && realOn('urban', B) && isVehicle(T) ? REAL.URBAN_VEH_COST : 0);
// Suppressed units can't move this turn.
const suppressed = (u, B = appState.battle) => realOn('suppression', B) && !!u.supp;
// Armor facing: remember which way a unit last moved (a unit vector in world space).
function noteFacing(u, from, to) {
  const a = toWorld(from.c, from.r),
    b = toWorld(to.c, to.r),
    dx = b.x - a.x,
    dy = b.y - a.y,
    len = Math.hypot(dx, dy) || 1;
  u.face = [Math.round((dx / len) * 1000) / 1000, Math.round((dy / len) * 1000) / 1000];
}

// ---- supply lines ----
// Hexes from which each army's ground units can trace supply: start at its supply points (and those of allies
// that grant it resupply) and spread over its friendly ground and roads, never through enemy-held hexes.
function supplyNet(B, pid) {
  B._supply = B._supply || {};
  const kk = B.turn + '|' + pid;
  if (B._supply[kk]) return B._supply[kk];
  const def = B.mapDef,
    sup = suppliersOf(pid, B),
    seen = new Set(),
    queue = [];
  const enemyAt = h => aliveUnits(B).some(u => !isAir(u) && u.c === h.c && u.r === h.r && isEnemy(u.pid, pid, B));
  for (const sp of supplyPoints(B))
    if (sup.includes(sp.pid)) {
      const k = key(sp.c, sp.r);
      if (!seen.has(k)) {
        seen.add(k);
        queue.push(sp);
      }
    }
  while (queue.length) {
    const h = queue.shift();
    for (const n of neighborsRaw(h.c, h.r, def.W, def.H)) {
      const k = key(n.c, n.r);
      if (seen.has(k) || TERRAIN[tileAt(n.c, n.r, B).t].water) continue;
      const own = B.territory[k],
        road = B.roads && B.roads[k];
      if ((own == null || !friendlyGround(own, pid, B)) && !road) continue;
      if (enemyAt(n)) continue;
      seen.add(k);
      queue.push(n);
    }
  }
  return (B._supply[kk] = seen);
}
// In supply: on the network, or right next to it (the front line).
function inSupply(B, u, at = u) {
  const net = supplyNet(B, u.pid);
  return net.has(key(at.c, at.r)) || neighborsRaw(at.c, at.r, B.mapDef.W, B.mapDef.H).some(n => net.has(key(n.c, n.r)));
}
// End of turn, before resupply: count turns each ground unit has been cut off.
function logSupplyLines(B) {
  if (!B.rules.supplyLines) return false;
  B._supply = {};
  let ev = false;
  for (const u of aliveUnits(B)) {
    if (UNIT_TYPES[u.type].domain !== 'land') continue;
    const was = u.cut || 0;
    u.cut = inSupply(B, u) ? 0 : was + 1;
    if (u.cut === 1) {
      floatText(u, 'Cut off', '#ffb03a');
      ev = true;
    }
  }
  return ev;
}
const cutOff = (u, B = appState.battle) => realOn('supplyLines', B) && (u.cut || 0) > 0;

// ---- end of turn: entrenchment, suppression, surrender ----
function surrounded(B, u) {
  const T = UNIT_TYPES[u.type];
  const ns = neighborsRaw(u.c, u.r, B.mapDef.W, B.mapDef.H).filter(n => costAt(T, n.c, n.r, undefined, B) != null);
  const hostile = n =>
    aliveUnits(B).some(e => isEnemy(e.pid, u.pid, B) && !isAir(e) && hexDist(e, n) <= 1 && !(e.c === u.c && e.r === u.r));
  return ns.length > 0 && ns.every(hostile);
}
function logRealism(B, st) {
  let ev = false;
  for (const u of aliveUnits(B)) {
    const T = UNIT_TYPES[u.type],
      s = st && st.get(u.id);
    if (B.rules.entrench) {
      const moved = s && s.hist && s.hist.length > 1;
      const was = u.dug || 0;
      u.dug = T.domain === 'land' && !u.in && !moved ? Math.min(REAL.DIG_MAX, was + 1) : 0;
      if (u.dug > was && u.dug === REAL.DIG_MAX) floatText(u, 'Dug in', '#c8b27a');
    }
    if (B.rules.suppression) {
      const lost = Math.max(0, (u.hp0 ?? u.hp) - u.hp);
      u.supp = lost >= u.maxHp * REAL.SUPPRESS_SHARE && u.hp > 0 ? 1 : 0; // suppressed for the next turn only
      if (u.supp) {
        floatText(u, 'Suppressed', '#ffb03a');
        ev = true;
      }
    }
    if (B.rules.surrender && T.domain === 'land' && !u.in && (broken(u, B) || u.hp < u.maxHp * REAL.SURRENDER_HP)) {
      if ((B.rules.supplyLines && (u.cut || 0) >= REAL.SURRENDER_CUT) || surrounded(B, u)) {
        u.hp = 0;
        u.surrendered = true;
        floatText(u, 'Surrendered', '#ffffff');
        B.stats.surrendered = (B.stats.surrendered || 0) + 1;
        ev = true;
      }
    }
  }
  return ev;
}
