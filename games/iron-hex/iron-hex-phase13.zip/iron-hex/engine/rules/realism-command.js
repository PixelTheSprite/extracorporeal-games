// Realism rules, part 2 (batch 2): command and air.
// ---- Batch 2: command and air ----
// Starting values (tune with the A/B harness).
Object.assign(REAL, {
  COMMAND_RANGE: 6,
  COMMAND_SLOW: 1, // ground units this far from every command post move 1 hex less
  FRICTION_BASE: 0.05,
  FRICTION_SHAKEN: 0.1,
  FRICTION_BROKEN: 0.2,
  FRICTION_NO_COMMAND: 0.05,
  FRICTION_JAMMED: 0.1,
  JAM_RANGE: 3,
  JAM_SIGHT: 2, // drones jam enemies within 3 hexes: sight -2, out of command
  AIRSUP_RANGE: 4,
  AIRSUP_DMG: 1.1,
  AIRSUP_EVADE: 10,
  UMBRELLA_RANGE: 2,
  UMBRELLA_DMG: 0.8,
});
const isJammer = T => T.id === 'drone' || !!T.jammer;
const isFighter = T => T.domain === 'air' && effOf(T).air > 0;
const isAAUnit = T => T.id === 'aa' || !!T.aa;
const friendOf = (a, b, B = appState.battle) => a === b || isAlly(a, b, B);

// Command posts: the army's held capital, its depots and airfields, and its half-tracks (mobile command).
function commandPosts(B, pid) {
  const out = [],
    cap = B.mapDef.spawns[pid],
    capCity = cap && B.cities[key(cap.c, cap.r)];
  if (capCity && capCity.owner === pid) out.push(cap);
  for (const [k, s] of Object.entries(B.structs || {}))
    if (!s.build && s.owner === pid && (s.kind === 'depot' || s.kind === 'airfield')) {
      const [c, r] = unkey(k);
      out.push({ c, r });
    }
  for (const u of aliveUnits(B)) if (u.pid === pid && u.type === 'apc') out.push(u);
  return out;
}
// Electronic warfare: an enemy drone within range jams you, unless one of your side's drones is close enough to counter it.
function jammed(u, B = appState.battle) {
  if (!realOn('ew', B)) return false;
  const near = f => aliveUnits(B).some(o => o !== u && isJammer(UNIT_TYPES[o.type]) && f(o.pid) && hexDist(o, u) <= REAL.JAM_RANGE);
  return near(p => isEnemy(p, u.pid, B)) && !near(p => friendOf(p, u.pid, B));
}
function outOfCommand(u, at = u, B = appState.battle) {
  if (!realOn('command', B) || UNIT_TYPES[u.type].domain !== 'land') return false;
  if (jammed(u, B)) return true;
  return !commandPosts(B, u.pid).some(p => p !== u && hexDist(p, at) <= REAL.COMMAND_RANGE);
}
// A unit's movement this turn (command radius can slow ground units).
const moveOf = (u, B = appState.battle) => {
  const T = UNIT_TYPES[u.type];
  return outOfCommand(u, undefined, B) ? Math.max(1, T.move - REAL.COMMAND_SLOW) : T.move;
};
const jamSight = (u, B = appState.battle) => (jammed(u, B) ? -REAL.JAM_SIGHT : 0);

// Air superiority: the side whose fighters (and only theirs) are within range controls the air over a hex.
function airControl(at, B = appState.battle) {
  const teams = new Set(
    aliveUnits(B)
      .filter(o => isFighter(UNIT_TYPES[o.type]) && hexDist(o, at) <= REAL.AIRSUP_RANGE)
      .map(o => teamOf(o.pid, B))
  );
  return teams.size === 1 ? [...teams][0] : null;
}
// Extra damage multipliers for batch 2 (folded into realismDamage).
function commandAirDamage(att, tgt, pos, B = appState.battle) {
  const A = UNIT_TYPES[att.type];
  let m = 1;
  if (realOn('airSup', B) && airControl(att, B) === teamOf(att.pid, B)) m *= REAL.AIRSUP_DMG;
  if (
    realOn('aaUmbrella', B) &&
    A.domain === 'air' &&
    aliveUnits(B).some(o => isAAUnit(UNIT_TYPES[o.type]) && friendOf(o.pid, tgt.pid, B) && hexDist(o, pos) <= REAL.UMBRELLA_RANGE)
  )
    m *= REAL.UMBRELLA_DMG;
  return m;
}
// Bombers and drones flying where the enemy controls the air are easier to hit.
function airSupEvade(u, B = appState.battle) {
  if (!realOn('airSup', B) || !isAir(u) || isFighter(UNIT_TYPES[u.type])) return 0;
  const ctl = airControl(u, B);
  return ctl != null && ctl !== teamOf(u.pid, B) ? -REAL.AIRSUP_EVADE : 0;
}
// Order friction, rolled as the turn starts (on the battle's seeded generator, so replays repeat it): a move
// stops halfway, or a unit loses track of its target.
function applyFriction(B, st) {
  if (!B.rules.friction) return;
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (!s || s.o.type === 'hold') continue;
    let p = REAL.FRICTION_BASE + (broken(u, B) ? REAL.FRICTION_BROKEN : shaken(u, B) ? REAL.FRICTION_SHAKEN : 0);
    if (realOn('command', B) && outOfCommand(u, undefined, B)) p += REAL.FRICTION_NO_COMMAND;
    if (jammed(u, B)) p += REAL.FRICTION_JAMMED;
    if (rng(B) >= p) continue;
    const o = s.o;
    if (o.path && o.path.length > 2) s.o = Object.assign({}, o, { path: o.path.slice(0, Math.ceil(o.path.length / 2)) });
    else if (o.target != null) s.o = Object.assign({}, o, { target: null });
    else continue;
    s.confused = true;
    floatText(u, 'Confusion', '#ffb03a');
    B.stats.friction = (B.stats.friction || 0) + 1;
  }
}
