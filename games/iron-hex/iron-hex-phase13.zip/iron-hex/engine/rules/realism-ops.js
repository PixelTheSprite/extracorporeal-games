// Realism rules, part 3 (batch 3): artillery, submarines, mines, carriers, railways and demolition.
// ---- Batch 3: artillery, submarines, mines, carriers, railways and demolition ----
Object.assign(REAL, { MINE_MAX: 6, MINE_LAND_DMG: 30, MINE_SEA_DMG: 40, RAIL_COST: 1 / 3 });
const RAIL_COST = 1 / 3;
// Railways: roads running through your own (or a resupplying ally's) territory cost a third.
function railFor(pid, c, r, B = appState.battle) {
  if (pid == null || !realOn('rail', B)) return false;
  const own = B.territory[key(c, r)];
  return own != null && friendlyGround(own, pid, B);
}
// Artillery: indirect fire. It can shoot at anything a friendly unit can see (a spotter), never on a turn it moved.
function spotted(pid, e, B = appState.battle) {
  if (fogOn(B)) return canSee(pid, e, B);
  return aliveUnits(B).some(
    o => !o.in && !isEnemy(o.pid, pid, B) && !UNIT_TYPES[o.type].indirect && hexDist(o, e) <= sightOf(o, B) && losClear(o, e, isAir(o), B)
  );
}
const movedThisTurn = (u, B = appState.battle) => u.mv === B.turn;
const cannotFireAfterMoving = (u, from = u, B = appState.battle) =>
  UNIT_TYPES[u.type].setup && (movedThisTurn(u, B) || from.c !== u.c || from.r !== u.r);
// Counter-battery: a battery that fires gives its position away to every enemy until the end of the next turn.
const revealed = (u, B = appState.battle) => u.rev != null && u.rev >= B.turn;
// Submarines: hidden unless an enemy unit is within 1 hex, or an anti-submarine ship within 2.
function subDetected(pid, u, B = appState.battle) {
  return aliveUnits(B).some(
    o => !o.in && !isEnemy(o.pid, pid, B) && o.pid !== u.pid && (hexDist(o, u) <= 1 || (UNIT_TYPES[o.type].asw && hexDist(o, u) <= 2))
  );
}
const isSub = (u, B = appState.battle) => realOn('subs', B) && !!UNIT_TYPES[u.type].stealth;
// Carriers: an aircraft over a friendly carrier has landed (like an airfield).
const carrierUnder = (u, B = appState.battle) =>
  realOn('carriers', B) &&
  aliveUnits(B).some(o => o !== u && UNIT_TYPES[o.type].deck && o.c === u.c && o.r === u.r && friendOf(o.pid, u.pid, B));
// Mines: B.mines[key] = { pid, sea }, hidden from the enemy until triggered.
const canLayMine = (u, B = appState.battle) => {
  const T = UNIT_TYPES[u.type];
  if (!B.rules.mines || !(T.builds || T.asw)) return false;
  if (Object.values(B.mines || {}).filter(m => m.pid === u.pid).length >= REAL.MINE_MAX) return false;
  return !(B.mines || {})[key(u.c, u.r)];
};
function logMines(B, st) {
  if (!B.rules.mines) return false;
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st && st.get(u.id);
    if (!s || s.o.type !== 'mine' || !canLayMine(u, B)) continue;
    (B.mines = B.mines || {})[key(u.c, u.r)] = { pid: u.pid, sea: UNIT_TYPES[u.type].domain === 'sea' };
    floatText(u, 'Mine laid', '#c8b27a');
    B.stats.minesLaid = (B.stats.minesLaid || 0) + 1;
    ev = true;
  }
  return ev;
}
// A unit has just stepped onto (c, r): enemy mines go off, unless an engineer clears a land mine safely.
// Returns true if the unit must stop.
function stepOnMine(B, u) {
  const k = key(u.c, u.r),
    m = B.mines && B.mines[k];
  if (!m || isAir(u) || !isEnemy(m.pid, u.pid, B)) return false;
  delete B.mines[k];
  if (!m.sea && UNIT_TYPES[u.type].builds) {
    floatText(u, 'Mine cleared', '#9fe86a');
    B.stats.minesCleared = (B.stats.minesCleared || 0) + 1;
    return false;
  }
  const dmg = m.sea ? REAL.MINE_SEA_DMG : REAL.MINE_LAND_DMG;
  u.hp = Math.max(0, u.hp - dmg);
  floatText(u, `Mine! -${dmg}`, '#ff6a4a');
  B.stats.minesHit = (B.stats.minesHit || 0) + 1;
  return true;
}
// Demolition: an engineer blows an adjacent bridge (any side's) at the end of the turn.
const bridgeNextTo = (u, B = appState.battle) => {
  const def = B.mapDef;
  return (
    neighborsRaw(u.c, u.r, def.W, def.H)
      .concat([{ c: u.c, r: u.r }])
      .find(n => {
        const s = builtAt(n.c, n.r, B);
        return s && s.kind === 'bridge';
      }) || null
  );
};
const canDemolish = (u, B = appState.battle) => realOn('rail', B) && !!UNIT_TYPES[u.type].builds && !!bridgeNextTo(u, B);
function logDemolish(B, st) {
  if (!B.rules.rail) return false;
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st && st.get(u.id);
    if (!s || s.o.type !== 'demolish') continue;
    const h = bridgeNextTo(u, B);
    if (!h) continue;
    destroyStructAt(B, h.c, h.r);
    floatText(u, 'Bridge blown', '#ff9a6a');
    B.stats.bridgesBlown = (B.stats.bridgesBlown || 0) + 1;
    ev = true;
  }
  return ev;
}

// Removes a structure, as when it is shot to pieces (a destroyed bridge drops the ground units on it).
function destroyStructAt(B, c, r) {
  const k = key(c, r),
    s = B.structs[k];
  if (!s) return;
  delete B.structs[k];
  B.stats.destroyed++;
  if (s.kind === 'silo') B.stats.silosLost = (B.stats.silosLost || 0) + 1;
  if (s.kind === 'bridge')
    for (const u of aliveUnits(B))
      if (u.c === c && u.r === r && UNIT_TYPES[u.type].domain === 'land') {
        u.hp = 0;
        if (u.cargo) {
          const cg = unitById(u.cargo, B);
          if (cg) cg.hp = 0;
        }
      }
}
