// Rendering, part 2: hex geometry, tiles and units.
// Projected geometry and colors for one hex at the current camera (cached on the tile until the camera changes).
function tileGeom(t, P, sig) {
  if (t.g && t.g.sig === sig) return t.g;
  const v = appState.prefs.view,
    T = TERRAIN[t.t];
  const g = (t.g = { sig, t, hidden: true });
  const pc = P(t.wx, t.wy, t.z);
  if (!pc) return g;
  const pts = [];
  for (let i = 0; i < 6; i++) {
    const p = P(t.wx + HEX_CORNERS[i][0], t.wy + HEX_CORNERS[i][1], t.z);
    if (!p) return g;
    pts.push(p);
  }
  const hz = v === 'ground' ? clamp((pc.depth - 9) / 24, 0, 0.65) : 0;
  Object.assign(g, {
    hidden: false,
    d: pc.d,
    s: pc.s,
    pts,
    fill: col(T.rgb, 1, hz),
    px: Math.max(1, Math.round(pc.s / 12)),
    alpha: hz > 0.05 ? 1 - hz * 0.6 : 1,
    waveFill: T.water ? col(T.rgb, 1.45, hz) : null,
    sides: [],
    specks: [],
    decor: [],
  });
  if (v !== 'top')
    for (let i = 0; i < 6; i++) {
      const n = t.edge[i],
        nz = n ? n.z : -0.5;
      if (nz >= t.z - 0.001) continue;
      const j = (i + 1) % 6;
      const lo1 = P(t.wx + HEX_CORNERS[i][0], t.wy + HEX_CORNERS[i][1], nz),
        lo2 = P(t.wx + HEX_CORNERS[j][0], t.wy + HEX_CORNERS[j][1], nz);
      if (!lo1 || !lo2) continue;
      g.sides.push({ q: [pts[i], pts[j], lo2, lo1], fill: col(T.rgb, 0.5 + 0.28 * Math.max(0, Math.cos((i * Math.PI) / 3 - 0.6)), hz) });
    }
  if (pc.s >= 7)
    for (const sp of t.speck) {
      const p = P(t.wx + sp.ox, t.wy + sp.oy, t.z);
      if (p) g.specks.push({ x: Math.round(p.x), y: Math.round(p.y), fill: col(T.rgb, sp.v, hz) });
    }
  for (const d of t.decor) {
    const p = P(t.wx + d.ox, t.wy + d.oy, t.z);
    if (!p) continue;
    const spr = DECOR[d.k];
    g.decor.push({ spr, x: p.x, y: p.y + (v === 'top' ? (spr.h * p.s) / 24 : 0), sc: (p.s / 12) * d.s });
  }
  const fp = P(t.wx + 0.35, t.wy + 0.15, t.z),
    cp = P(t.wx - 0.5, t.wy + 0.1, t.z);
  g.flagAt = fp && { x: fp.x, y: fp.y, sc: clamp(fp.s / 12, 0.5, 4) * 1.2 };
  g.cityAt = cp && { x: cp.x, y: cp.y, sc: clamp(cp.s / 12, 0.5, 4) };
  const mp = P(t.wx, t.wy + 0.3, t.z),
    op = P(t.wx + 0.55, t.wy + 0.25, t.z);
  g.mid = mp && { x: mp.x, y: mp.y, sc: clamp(mp.s / 12, 0.5, 4) };
  g.ownAt = op && { x: op.x, y: op.y, sc: clamp(op.s / 12, 0.5, 4) };
  return g;
}
function drawTile(g, P, now, overlay) {
  const ctx = R.ctx,
    t = g.t,
    T = TERRAIN[t.t],
    pts = g.pts,
    s = g.s,
    px = g.px,
    B = appState.battle,
    k = t.k;
  for (const sd of g.sides) {
    ctx.fillStyle = sd.fill;
    tracePoly(ctx, sd.q);
    ctx.fill();
  }
  ctx.fillStyle = g.fill;
  tracePoly(ctx, pts);
  ctx.fill();
  if (s >= 6)
    for (const sp of g.specks) {
      // level of detail: terrain specks only when hexes are big enough to show them
      ctx.fillStyle = sp.fill;
      ctx.fillRect(sp.x, sp.y, px, px);
    }
  if (T.water && s >= 7) {
    ctx.fillStyle = g.waveFill;
    for (let k2 = 0; k2 < 2; k2++) {
      const p = P(t.wx + Math.sin(now / 900 + t.wave + k2 * 2) * 0.3 + (k2 ? 0.25 : -0.3), t.wy + (k2 ? 0.3 : -0.25), t.z);
      if (p) ctx.fillRect(Math.round(p.x), Math.round(p.y), 3 * px, px);
    }
  }
  const TR = B.territory || {},
    own = TR[k];
  if (own != null) {
    ctx.fillStyle = R.terrFill[own];
    tracePoly(ctx, pts);
    ctx.fill();
  }
  const RD = B.roads;
  if (RD && RD[k] && s >= 5) {
    if (!g.road) {
      // road segment geometry, built the first time this hex shows a road at this camera
      g.road = {
        ctr: P(t.wx, t.wy, t.z),
        mids: [0, 1, 2, 3, 4, 5].map(i =>
          P(t.wx + (Math.cos((i * Math.PI) / 3) * SQ3) / 2, t.wy + (Math.sin((i * Math.PI) / 3) * SQ3) / 2, t.z)
        ),
        alt: [P(t.wx - 0.45, t.wy, t.z), P(t.wx + 0.45, t.wy, t.z)],
      };
    }
    const w = Math.max(2, Math.round(s / 5)),
      ends = [];
    for (let i = 0; i < 6; i++) {
      const n = t.edge[i];
      if (n && RD[n.k]) ends.push(g.road.mids[i]);
    }
    const segs = ends.length ? ends : g.road.alt,
      ctr = g.road.ctr;
    for (const [c2, lw] of [
      ['#5a4024', w + 2],
      ['#b8945a', w],
      ['#e2c890', Math.max(1, w / 3)],
    ]) {
      ctx.strokeStyle = c2;
      ctx.lineWidth = lw;
      ctx.lineCap = 'round';
      for (const e of segs)
        if (e && ctr) {
          ctx.beginPath();
          ctx.moveTo(ctr.x, ctr.y);
          ctx.lineTo(e.x, e.y);
          ctx.stroke();
        }
    }
    ctx.lineCap = 'butt';
    ctx.lineWidth = 1;
  }
  if (fogShade(k)) {
    ctx.fillStyle = 'rgba(8,10,24,.42)';
    tracePoly(ctx, pts);
    ctx.fill();
  }
  const ov = overlay.get(k);
  if (ov) {
    ctx.fillStyle = ov;
    tracePoly(ctx, pts);
    ctx.fill();
  }
  if (s >= 6) {
    ctx.strokeStyle = 'rgba(0,0,0,.22)';
    ctx.lineWidth = 1;
    tracePoly(ctx, pts);
    ctx.stroke();
  }
  if (own != null) {
    // border where territory changes hands
    ctx.strokeStyle = ARMIES[own].light;
    ctx.lineWidth = s >= 9 ? 2 : 1;
    for (let i = 0; i < 6; i++) {
      const n = t.edge[i];
      if (n && TR[n.k] === own) continue;
      const j = (i + 1) % 6;
      ctx.beginPath();
      ctx.moveTo(pts[i].x, pts[i].y);
      ctx.lineTo(pts[j].x, pts[j].y);
      ctx.stroke();
    }
    ctx.lineWidth = 1;
  }
  if (R.hover === t && !R.busy) {
    ctx.strokeStyle = 'rgba(255,255,255,.8)';
    tracePoly(ctx, pts);
    ctx.stroke();
  }
  if (!R.cacheDraw && R.sel && R.sel.c === t.c && R.sel.r === t.r && Math.floor(now / 250) % 2 === 0) {
    ctx.strokeStyle = '#ffe04a';
    ctx.lineWidth = 2;
    tracePoly(ctx, pts);
    ctx.stroke();
    ctx.lineWidth = 1;
  }
  if (g.alpha < 1) ctx.globalAlpha = g.alpha;
  for (const d of g.decor) drawSprite(ctx, d.spr, d.x, d.y, d.sc, false);
  ctx.globalAlpha = 1;
  const fl = R.flagIdx.get(k);
  if (fl && g.flagAt) drawSprite(ctx, FLAG_SPR[fl.pid], g.flagAt.x, g.flagAt.y, g.flagAt.sc, false);
  const so = B.structs && B.structs[k];
  if (so && g.mid) drawStruct(ctx, so, g, t);
  strategicLabels(t, B); // silo charge, city levels
  const city = B.cities && B.cities[k];
  if (city) {
    if (city.owner != null && g.cityAt) drawSprite(ctx, FLAG_SPR[city.owner], g.cityAt.x, g.cityAt.y, g.cityAt.sc, false);
    if (city.capPid != null)
      R.labels.push({ x: t.wx, y: t.wy, z: t.z, text: `${city.prog}/${CAPTURE_TURNS}`, color: ARMIES[city.capPid].light });
  }
}

function drawUnit(u, P, now) {
  const ctx = R.ctx,
    v = appState.prefs.view,
    air = isAir(u),
    T = UNIT_TYPES[u.type];
  const g = P(u.px, u.py, u.pz);
  if (!g) return;
  const sc = clamp(g.s / 12, 0.4, 7);
  let p = g,
    lift = 0;
  if (air) {
    if (v === 'top') lift = g.s * 0.55;
    else {
      p = P(u.px, u.py, u.pz + 1.2) || g;
    }
    ctx.fillStyle = 'rgba(0,0,0,.35)';
    ctx.beginPath();
    ctx.ellipse(g.x, g.y + (v === 'top' ? g.s * 0.3 : 0), 6 * sc, 2 * sc, 0, 0, Math.PI * 2);
    ctx.fill();
    lift += Math.round(Math.sin(now / 280 + u.id) * sc);
  }
  let yb = p.y - lift + (v === 'top' ? g.s * 0.45 : 0);
  if (T.domain === 'sea') yb += 1.5 * sc;
  const fp = P(u.px + (u.fx || 1) * 0.4, u.py + (u.fy || 0) * 0.4, u.pz);
  const flip = fp ? fp.x < g.x - 0.01 : false;
  const hit = now - (u.hitT || -1e9) < 140;
  const spr = spriteFor(u, hit);
  if (u.gone || (u.hp <= 0 && !(u.dispHp > 0))) return;
  const box = drawSprite(ctx, spr, p.x, yb, sc, flip);
  if (T.domain === 'sea') {
    ctx.fillStyle = 'rgba(255,255,255,.75)';
    const w = Math.round((spr.w * sc) / 2) + 1;
    ctx.fillRect(
      Math.round(p.x + (flip ? w - 2 * sc : -w)),
      Math.round(yb - 2 * sc),
      Math.max(2, Math.round(2 * sc)),
      Math.max(1, Math.round(sc))
    );
  }
  if (u.cargo && !hit) {
    const c = unitById(u.cargo);
    if (c) drawSprite(ctx, spriteFor(c), p.x + (flip ? -3 : 3) * sc, yb - 3.5 * sc, sc * 0.5, flip);
  }
  R.boxes.push({ u, ...box });
  // HP bar + team pip
  const bw = 14,
    bx = Math.round(p.x - bw / 2),
    by = Math.round(box.y0 - 5);
  ctx.fillStyle = '#1b140e';
  ctx.fillRect(bx - 1, by - 1, bw + 2, 4);
  const pct = (u.dispHp ?? u.hp) / u.maxHp;
  ctx.fillStyle = pct < 0.34 ? '#d23a22' : pct < 0.67 ? '#f5c518' : '#7cd84a';
  ctx.fillRect(bx, by, Math.max(1, Math.round(bw * pct)), 2);
  if (shapesOn())
    drawArmyShape(ctx, u.pid, bx - 5, by + 1); // shape markers (accessibility)
  else {
    ctx.fillStyle = ARMIES[u.pid].color;
    ctx.fillRect(bx - 4, by - 1, 3, 4);
  }
  if (R.sel && R.sel.id === u.id) {
    const ay = by - 6 - (Math.floor(now / 200) % 2);
    ctx.fillStyle = '#1b140e';
    ctx.fillRect(Math.round(p.x) - 3, ay - 1, 7, 4);
    ctx.fillStyle = '#ffe04a';
    ctx.fillRect(Math.round(p.x) - 2, ay, 5, 1);
    ctx.fillRect(Math.round(p.x) - 1, ay + 1, 3, 1);
    ctx.fillRect(Math.round(p.x), ay + 2, 1, 1);
  }
  const o = appState.battle.orders[u.id];
  if (u.pid === me() && o && !R.busy) {
    ctx.fillStyle = '#1b140e';
    ctx.fillRect(bx + bw + 2, by - 1, 5, 5);
    ctx.fillStyle = o.type === 'hold' ? '#a8d4ff' : '#7cd84a';
    ctx.fillRect(bx + bw + 3, by, 3, 3);
  }
}
