// Rendering, part 3: order arrows, text, effects and structures.
function centerOf(c, r, lift = 0.05) {
  const t = tileAt(c, r);
  return [t.wx, t.wy, t.z + lift];
}

function drawOrders(P, now) {
  if (R.busy) return;
  const ctx = R.ctx,
    B = appState.battle;
  const line = (pts, color, dash) => {
    const q = pts.map(a => P(...a));
    if (q.some(x => !x)) return;
    ctx.strokeStyle = '#1b140e';
    ctx.lineWidth = 3;
    ctx.setLineDash([]);
    ctx.beginPath();
    q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.stroke();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.setLineDash(dash ? [3, 2] : []);
    ctx.lineDashOffset = -Math.floor(now / 80);
    ctx.stroke();
    ctx.setLineDash([]);
  };
  const cross = (x, y, z) => {
    const p = P(x, y, z);
    if (!p) return;
    ctx.strokeStyle = '#ff4a2a';
    ctx.lineWidth = 1;
    const r = 5 + (Math.floor(now / 200) % 2);
    ctx.strokeRect(Math.round(p.x - r), Math.round(p.y - r), r * 2, r * 2);
    ctx.fillStyle = '#ff4a2a';
    ctx.fillRect(Math.round(p.x) - 1, Math.round(p.y) - 1, 2, 2);
  };
  const drawOne = (u, o) => {
    let from = [u.px, u.py, u.pz + 0.05];
    if (o.path) {
      line(
        o.path.map(h => centerOf(h.c, h.r)),
        o.type === 'amove' ? '#ff9a2a' : '#ffe04a',
        true
      );
      const d = o.path[o.path.length - 1];
      from = centerOf(d.c, d.r);
    }
    if (o.multi && o.path) {
      // where each turn of a multi-turn move should end
      const T = UNIT_TYPES[u.type];
      let acc = 0,
        turn = 1;
      for (let i = 1; i < o.path.length; i++) {
        const c = costAt(T, o.path[i].c, o.path[i].r) || 1;
        if (acc + c > T.move * turn + 1e-9) {
          const h = o.path[i - 1],
            q = P(...centerOf(h.c, h.r));
          if (q && turn < o.multi.turns) {
            ctx.fillStyle = '#ffe04a';
            ctx.beginPath();
            ctx.arc(q.x, q.y, Math.max(3, q.s * 0.22), 0, Math.PI * 2);
            ctx.fill();
            drawText(ctx, String(turn), q.x, q.y - Math.max(6, q.s * 0.5), '#ffe04a');
          }
          turn++;
        }
        acc += c;
      }
    }
    if (o.target) {
      const t = unitById(o.target);
      if (t && t.hp > 0) {
        const tz = t.pz + (isAir(t) ? 1.2 : 0.3);
        line([from, [t.px, t.py, tz]], '#ff4a2a', o.type === 'engage');
        cross(t.px, t.py, tz);
      }
    }
    if (o.unload) {
      const h = centerOf(o.unload.c, o.unload.r);
      line([from, h], '#7cf06a', false);
      const q = P(...h);
      if (q) {
        ctx.fillStyle = '#7cf06a';
        ctx.fillRect(Math.round(q.x) - 2, Math.round(q.y) - 2, 4, 4);
      }
    }
    if (o.type === 'load' || o.load) {
      const c = unitById(o.type === 'load' ? o.cargo : o.load);
      if (c) line([from, [c.px, c.py, c.pz + 0.05]], '#7cf06a', true);
    }
    const mid = o.type === 'repair' ? o.mend : o.repair;
    if (mid) {
      const t = unitById(mid);
      if (t) line([from, [t.px, t.py, t.pz + 0.3]], '#7cf06a', true);
    }
    const sb = o.type === 'build' ? o : o.build;
    if (sb) {
      // ghost scaffold where the structure will go
      const site = sb.kind === 'bridge' ? sb.at : o.path ? o.path[o.path.length - 1] : { c: u.c, r: u.r };
      const q = P(...centerOf(site.c, site.r));
      if (q) {
        ctx.globalAlpha = 0.7;
        drawSprite(ctx, STRUCT_SPR.scaffold, q.x, q.y + 2, clamp(q.s / 12, 0.6, 3), false);
        ctx.globalAlpha = 1;
      }
    }
    if (o.starget) {
      const c3 = centerOf(o.starget.c, o.starget.r, 0.2);
      line([from, c3], '#ff4a2a', false);
      cross(...c3);
    }
    if (o.road || o.type === 'road') {
      const q = P(...from);
      if (q) {
        const w = Math.max(3, Math.round(q.s / 4));
        ctx.fillStyle = '#1b140e';
        ctx.fillRect(Math.round(q.x - w / 2) - 1, Math.round(q.y) - 2, w + 2, 4);
        ctx.fillStyle = '#e8c47a';
        ctx.fillRect(Math.round(q.x - w / 2), Math.round(q.y) - 1, w, 2);
      }
    }
    if (o.flag || o.type === 'flag' || o.capture || o.type === 'capture') {
      const q = P(from[0] + 0.3, from[1], from[2]);
      if (q) {
        ctx.globalAlpha = 0.75;
        drawSprite(ctx, FLAG_SPR[u.pid], q.x, q.y, clamp(q.s / 12, 0.6, 3), false);
        ctx.globalAlpha = 1;
      }
    }
  };
  for (const u of aliveUnits()) if (u.pid === me() && B.orders[u.id]) drawOne(u, B.orders[u.id]);
  if (R.sel && R.pending) drawOne(R.sel, { path: R.pending.path, target: null });
}

function drawText(ctx, text, x, y, color) {
  ctx.font = '8px "Press Start 2P", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#1b140e';
  for (const [dx, dy] of [
    [-1, 0],
    [1, 0],
    [0, -1],
    [0, 1],
    [1, 1],
  ])
    ctx.fillText(text, Math.round(x) + dx, Math.round(y) + dy);
  ctx.fillStyle = color;
  ctx.fillText(text, Math.round(x), Math.round(y));
}

function drawEffects(P, now) {
  const ctx = R.ctx;
  for (let i = R.fx.length - 1; i >= 0; i--) {
    const e = R.fx[i],
      p = (now - e.t0) / e.dur;
    if (p >= 1) {
      R.fx.splice(i, 1);
      continue;
    }
    if (p < 0) continue;
    if (e.k === 'proj') {
      const x = lerp(e.ax, e.bx, p),
        y = lerp(e.ay, e.by, p),
        z = lerp(e.az, e.bz, p) + Math.sin(Math.PI * p) * e.arc;
      const q = P(x, y, z);
      if (!q) continue;
      const liftTop = appState.prefs.view === 'top' ? Math.sin(Math.PI * p) * e.arc * q.s * 0.6 : 0;
      const q0 = P(
        lerp(e.ax, e.bx, Math.max(0, p - 0.06)),
        lerp(e.ay, e.by, Math.max(0, p - 0.06)),
        lerp(e.az, e.bz, Math.max(0, p - 0.06)) + Math.sin(Math.PI * Math.max(0, p - 0.06)) * e.arc
      );
      ctx.strokeStyle = e.style === 'air' ? '#fff27a' : '#ffb03a';
      ctx.lineWidth = e.style === 'sea' ? 2 : 1;
      if (q0) {
        ctx.beginPath();
        ctx.moveTo(q0.x, q0.y - liftTop);
        ctx.lineTo(q.x, q.y - liftTop);
        ctx.stroke();
      }
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(Math.round(q.x) - 1, Math.round(q.y - liftTop) - 1, 2, 2);
      continue;
    }
    const q = P(e.x, e.y, e.z);
    if (!q) continue;
    const sc = clamp(q.s / 12, 0.5, 6);
    if (e.k === 'boom') {
      const r = (2 + p * 5 * e.size) * sc;
      ctx.fillStyle = p < 0.15 ? '#ffffff' : p < 0.4 ? '#ffe04a' : p < 0.7 ? '#ff8a2a' : 'rgba(90,80,70,' + (1 - p) + ')';
      ctx.beginPath();
      ctx.arc(Math.round(q.x), Math.round(q.y - 3 * sc), Math.max(1, r), 0, Math.PI * 2);
      ctx.fill();
      if (p < 0.6) {
        ctx.fillStyle = '#ffcc3a';
        ctx.beginPath();
        ctx.arc(Math.round(q.x), Math.round(q.y - 3 * sc), Math.max(1, r * 0.5), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = p < 0.5 ? '#ffe04a' : '#6a5a4a';
      for (const pt of e.parts)
        ctx.fillRect(
          Math.round(q.x + pt.vx * p * 14 * sc),
          Math.round(q.y - 3 * sc + (pt.vy * p + p * p * 1.5) * 12 * sc),
          Math.max(1, Math.round(sc)),
          Math.max(1, Math.round(sc))
        );
    } else if (e.k === 'flash') {
      ctx.fillStyle = '#fff27a';
      const r = Math.round(4 * sc * (1 - p));
      ctx.fillRect(Math.round(q.x) - r, Math.round(q.y - 4 * sc), r * 2, Math.max(1, Math.round(sc)));
      ctx.fillRect(Math.round(q.x) - 1, Math.round(q.y - 4 * sc) - r, Math.max(1, Math.round(sc)), r * 2);
    } else if (e.k === 'dust') {
      ctx.fillStyle = `rgba(220,200,160,${0.7 * (1 - p)})`;
      const r = Math.max(1, Math.round((1 + p * 3) * sc));
      ctx.fillRect(Math.round(q.x - r), Math.round(q.y - r - p * 4 * sc), r * 2, r * 2);
    } else if (e.k === 'text') {
      ctx.globalAlpha = p > 0.7 ? (1 - p) / 0.3 : 1;
      drawText(ctx, e.text, q.x, q.y - 16 - p * 14, e.color);
      ctx.globalAlpha = 1;
    }
  }
}

// A structure on its hex: sprite, owner's flag (capturable kinds), scaffold and progress while building,
// HP bar when damaged, and capture progress.
function drawStruct(ctx, so, g, t) {
  const S = STRUCTS[so.kind],
    spr = STRUCT_SPR[so.kind],
    m = g.mid;
  if (so.build) ctx.globalAlpha = 0.45;
  drawSprite(ctx, spr, m.x, m.y, m.sc, false);
  ctx.globalAlpha = 1;
  if (so.build) {
    drawSprite(ctx, STRUCT_SPR.scaffold, m.x, m.y, m.sc, false);
    R.labels.push({ x: t.wx, y: t.wy, z: t.z, text: `${so.build.prog}/${so.build.need}`, color: ARMIES[so.build.pid].light });
  } else if (S.capture && so.owner != null && g.ownAt) drawSprite(ctx, FLAG_SPR[so.owner], g.ownAt.x, g.ownAt.y, g.ownAt.sc, false);
  if (so.hp < so.maxHp) {
    const bw = Math.max(8, Math.round(spr.w * m.sc * 0.8)),
      bx = Math.round(m.x - bw / 2),
      by = Math.round(m.y + 2);
    ctx.fillStyle = '#1b140e';
    ctx.fillRect(bx - 1, by - 1, bw + 2, 4);
    ctx.fillStyle = so.hp / so.maxHp < 0.34 ? '#d23a22' : '#f5c518';
    ctx.fillRect(bx, by, Math.max(1, Math.round((bw * so.hp) / so.maxHp)), 2);
  }
  if (so.capPid != null) R.labels.push({ x: t.wx, y: t.wy, z: t.z, text: `${so.prog}/${CAPTURE_TURNS}`, color: ARMIES[so.capPid].light });
}
