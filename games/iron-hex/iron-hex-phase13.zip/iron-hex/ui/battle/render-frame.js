// ---------- Rendering ----------
function resizeCanvas() {
  if (!R.cvs) return;
  const st = $('#stage').getBoundingClientRect();
  R.PX = st.width < 600 ? 2 : 3;
  R.cvs.width = Math.max(1, Math.ceil(st.width / R.PX));
  R.cvs.height = Math.max(1, Math.ceil(st.height / R.PX));
  R.ctx.imageSmoothingEnabled = false;
}

window.addEventListener('resize', () => {
  resizeCanvas();
  positionMenu(menuAnchor());
});

const HAZE = [196, 222, 236];

function col(rgb, mul, hz = 0) {
  const r = clamp(rgb[0] * mul, 0, 255),
    g = clamp(rgb[1] * mul, 0, 255),
    b = clamp(rgb[2] * mul, 0, 255);
  return `rgb(${Math.round(lerp(r, HAZE[0], hz))},${Math.round(lerp(g, HAZE[1], hz))},${Math.round(lerp(b, HAZE[2], hz))})`;
}

function drawBackground(now) {
  const ctx = R.ctx,
    cw = R.cvs.width,
    ch = R.cvs.height,
    v = appState.prefs.view;
  if (v !== 'ground') {
    ctx.fillStyle = '#1a3060';
    ctx.fillRect(0, 0, cw, ch);
    ctx.fillStyle = '#23407a';
    const off = Math.floor(now / 120) % 16;
    for (let y = 0; y < ch; y += 8) for (let x = ((y / 8) % 2) * 8 - off; x < cw; x += 16) ctx.fillRect(x, y, 5, 1);
    return;
  }
  const hor = Math.round(ch * 0.24);
  const bands = ['#4a8ed8', '#5ea0e0', '#74b2e6', '#8cc2ea', '#a8d2ee', '#c4def0'];
  const bh = Math.ceil(hor / bands.length);
  bands.forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.fillRect(0, i * bh, cw, bh + 1);
  });
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 5; i++) {
    const x = ((((i * 97 + now / 200 - R.cam.angle * 60) % (cw + 60)) + cw + 60) % (cw + 60)) - 40,
      y = 6 + ((i * 13) % Math.max(10, hor - 20));
    ctx.fillRect(Math.round(x), y, 22, 4);
    ctx.fillRect(Math.round(x) + 5, y - 3, 12, 3);
  }
  ctx.fillStyle = '#8fa4c0';
  for (let x = 0; x < cw; x += 3) {
    const h = 4 + Math.abs(Math.sin((x + R.cam.angle * 120) / 17)) * 7 + Math.abs(Math.sin((x + R.cam.angle * 120) / 7)) * 2;
    ctx.fillRect(x, hor - Math.round(h), 3, Math.round(h));
  }
  ctx.fillStyle = col(TERRAIN['~'].rgb, 1, 0.55);
  ctx.fillRect(0, hor, cw, ch - hor);
}

function render(now) {
  const ctx = R.ctx,
    v = appState.prefs.view;
  const c = R.cam;
  c.angle += (c.angleT - c.angle) * 0.18;
  if (Math.abs(c.angleT - c.angle) > 0.002) positionMenu(menuAnchor());
  ctx.save();
  if (R.shake > 0.3 && !reducedMotion()) {
    ctx.translate(Math.round((Math.random() - 0.5) * R.shake), Math.round((Math.random() - 0.5) * R.shake));
    R.shake *= 0.86;
  } else R.shake = 0;
  drawBackground(now);
  const P = makeProj();
  // Hex geometry is cached per camera position: re-projected only when the camera, view or canvas changes.
  const sig = camSig() + '|' + (appState.prefs.palette || 'standard'); // recolor cached tiles when the palette changes
  // While panning on the cached terrain, skip re-projecting every hex (done once the camera stops).
  const panning =
    R.prevFrameSig !== sig &&
    R.terrCanvas &&
    appState.prefs.view !== 'ground' &&
    R.terrShape ===
      `${appState.prefs.view}|${c.zoom}|${c.angle.toFixed(4)}|${ctx.canvas.width}|${ctx.canvas.height}|${appState.prefs.palette || ''}` &&
    !R.mode.startsWith('move');
  if (!panning && (R.tileSig !== sig || R.tileMap !== R.map)) {
    R.tileSig = sig;
    R.tileMap = R.map;
    R.tileOrder = R.map.list
      .map(t => tileGeom(t, P, sig))
      .filter(g => !g.hidden)
      .sort((a, b) => a.d - b.d);
  }
  const us = [];
  for (const u of appState.battle.units) {
    if (u.in || u.gone || (u.hp <= 0 && !(u.dispHp > 0)) || !drawnForYou(u)) continue;
    const p = P(u.px, u.py, u.pz);
    if (p) us.push({ d: p.d + 0.02 + (isAir(u) ? 0.05 : 0), u });
  }
  us.sort((a, b) => a.d - b.d);
  R.pick = R.tileOrder;
  R.boxes = [];
  R.labels = [];
  if (!R.terrFill) R.terrFill = ARMY_RGB().map(c => `rgba(${c[0]},${c[1]},${c[2]},.38)`);
  R.flagIdx = new Map((appState.battle.flags || []).map(f => [key(f.c, f.r), f]));
  const overlay = buildOverlay();
  // Terrain cache: while the camera is still, the hexes (with territory, fog, overlays, flags, cities and
  // structures) are drawn once into an offscreen canvas and copied each frame; units go on top. While the camera
  // moves, everything is drawn directly, units interleaved by depth as before.
  const B = appState.battle,
    camMoving = R.prevFrameSig !== sig;
  R.prevFrameSig = sig;
  // Panning in the top and tilted views is a pure shift: reuse the cached terrain at an offset until the camera stops.
  const c0 = R.cam,
    shape = `${appState.prefs.view}|${c0.zoom}|${c0.angle.toFixed(4)}|${ctx.canvas.width}|${ctx.canvas.height}|${appState.prefs.palette || ''}`;
  const o = P(0, 0, 0);
  const shiftOk =
    camMoving &&
    R.terrCanvas &&
    R.terrShape === shape &&
    appState.prefs.view !== 'ground' &&
    o &&
    R.terrOrigin &&
    !R.mode.startsWith('move');
  if (shiftOk) {
    ctx.drawImage(R.terrCanvas, Math.round(o.x - R.terrOrigin.x), Math.round(o.y - R.terrOrigin.y));
    R.labels = [];
    for (const x of us) drawUnit(x.u, P, now);
  } else if (camMoving) {
    let j = 0; // merge units into the depth-sorted tiles
    for (const g of R.tileOrder) {
      while (j < us.length && us[j].d < g.d) drawUnit(us[j++].u, P, now);
      drawTile(g, P, now, overlay);
    }
    while (j < us.length) drawUnit(us[j++].u, P, now);
  } else {
    let ok = '';
    for (const [k, v] of overlay) ok += k + v;
    const terrKey = [
      sig,
      ok,
      B.visKey || '',
      B.turn,
      R.worldVer || 0,
      R.flagIdx.size,
      Object.keys(B.territory || {}).length,
      (R.sel && !R.cacheSelOk) || '',
    ].join('|');
    const cv = ctx.canvas;
    if (!R.terrCanvas || R.terrKey !== terrKey || R.terrCanvas.width !== cv.width || R.terrCanvas.height !== cv.height) {
      R.terrCanvas = R.terrCanvas || document.createElement('canvas');
      R.terrCanvas.width = cv.width;
      R.terrCanvas.height = cv.height;
      const off = R.terrCanvas.getContext('2d');
      off.imageSmoothingEnabled = false;
      off.clearRect(0, 0, cv.width, cv.height);
      R.ctx = off;
      R.cacheDraw = true;
      R.labels = [];
      for (const g of R.tileOrder) drawTile(g, P, now, overlay);
      R.cacheLabels = R.labels.slice();
      R.cacheDraw = false;
      R.ctx = ctx;
      R.terrKey = terrKey;
      R.terrShape = shape;
      R.terrOrigin = P(0, 0, 0);
    }
    ctx.drawImage(R.terrCanvas, 0, 0);
    R.labels = (R.cacheLabels || []).slice();
    if (R.sel && Math.floor(now / 250) % 2 === 0) {
      // the selected hex blinks: drawn live, not cached
      const g = R.tileOrder.find(x => x.t.c === R.sel.c && x.t.r === R.sel.r);
      if (g) {
        ctx.strokeStyle = '#ffe04a';
        ctx.lineWidth = 2;
        tracePoly(ctx, g.pts);
        ctx.stroke();
        ctx.lineWidth = 1;
      }
    }
    for (const x of us) drawUnit(x.u, P, now);
  }
  drawOrders(P, now);
  drawSightings(P, now);
  drawOwnMines(P);
  drawObjective(P, now);
  drawEffects(P, now);
  drawCursor(ctx);
  for (const l of R.labels) {
    const q = P(l.x, l.y, l.z);
    if (q) drawText(ctx, l.text, q.x, q.y - 22, l.color);
  }
  ctx.restore();
  if (v === 'ground') {
    // vignette edge for depth
    ctx.fillStyle = 'rgba(0,0,0,.18)';
    ctx.fillRect(0, R.cvs.height - 2, R.cvs.width, 2);
  }
}

function buildOverlay() {
  const o = new Map();
  // AA umbrellas (realism rule): tint the hexes each visible anti-aircraft unit covers (blue yours, red the enemy's).
  if (appState.battle.rules.aaUmbrella && !R.replay) {
    const B = appState.battle;
    for (const a of aliveUnits()) {
      if (!isAAUnit(UNIT_TYPES[a.type]) || !drawnForYou(a)) continue;
      const col = isEnemy(me(), a.pid) ? 'rgba(255,80,80,.13)' : 'rgba(90,150,255,.12)';
      for (let r = a.r - REAL.UMBRELLA_RANGE; r <= a.r + REAL.UMBRELLA_RANGE; r++)
        for (let c = a.c - REAL.UMBRELLA_RANGE - 1; c <= a.c + REAL.UMBRELLA_RANGE + 1; c++)
          if (r >= 0 && c >= 0 && r < B.mapDef.H && c < B.mapDef.W && hexDist(a, { c, r }) <= REAL.UMBRELLA_RANGE && !o.has(key(c, r)))
            o.set(key(c, r), col);
    }
  }
  strikeOverlay(o); // missile targeting range and ordered launches
  if (R.mode === 'move' && R.travel) {
    const a = { 2: 0.32, 3: 0.17, 4: 0.07 };
    for (const n of R.travel.values()) if (n.turns >= 2 && a[n.turns]) o.set(key(n.c, n.r), `rgba(90,170,255,${a[n.turns]})`);
  }
  if (R.mode === 'move' && R.reach) for (const n of R.reach.values()) if (n.end && n.cost > 0) o.set(key(n.c, n.r), 'rgba(90,170,255,.45)');
  if (R.mode === 'dest' && R.pending) {
    const d = R.pending.path[R.pending.path.length - 1];
    o.set(key(d.c, d.r), 'rgba(90,170,255,.6)');
  }
  if (R.mode === 'target' && R.targets) for (const e of R.targets.list) o.set(key(e.c, e.r), 'rgba(255,70,40,.5)');
  if (R.mode === 'unload' && R.unload) for (const h of R.unload.list) o.set(key(h.c, h.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'load' && R.loadList) for (const e of R.loadList) o.set(key(e.c, e.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'repair' && R.repair) for (const e of R.repair.list) o.set(key(e.c, e.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'bridge' && R.bridge) for (const e of R.bridge.list) o.set(key(e.c, e.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'starget' && R.starget) for (const e of R.starget.list) o.set(key(e.c, e.r), 'rgba(255,70,40,.5)');
  return o;
}

function tracePoly(ctx, pts) {
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.closePath();
}

const camSig = () => {
  const c = R.cam;
  return `${appState.prefs.view}|${c.x}|${c.y}|${c.zoom}|${c.angle.toFixed(4)}|${R.cvs.width}|${R.cvs.height}`;
};
