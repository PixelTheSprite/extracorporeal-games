// Standing and multi-turn orders for your army (army 0).
// B.standing[unitId] = { type:'hold' }                       Overwatch / Hold that carries over every turn
//                    | { type:'move', dest:{c,r}, last, stuck } a move to a hex more than one turn away
// At the start of each turn applyStanding() turns them back into ordinary orders: a standing hold becomes this
// turn's hold; a standing move is re-planned from where the unit now is, and the unit moves as far as its
// movement allows along the route. A different order (or Clear order) replaces the standing one.
const TRAVEL_TURNS = 4,
  STANDING_STUCK = 2;
// Cheapest route by terrain alone (other units are ignored; they're dealt with turn by turn), up to maxTurns
// of movement (and, for aircraft, the fuel on board). Each node gets turns = roughly how many turns away it is.
function travelField(u, maxTurns = TRAVEL_TURNS, B = appState.battle) {
  const T = UNIT_TYPES[u.type],
    def = B.mapDef,
    mv = T.move;
  const limit = Math.min(mv * maxTurns, u.fuel == null ? Infinity : u.fuel / (T.fuelRate || 1));
  const start = { c: u.c, r: u.r, cost: 0, prev: null, turns: 0 };
  const dist = new Map([[key(u.c, u.r), start]]),
    open = heapOf(n => n.cost, [start]);
  while (open.length) {
    const cur = open.shift();
    if (cur !== dist.get(key(cur.c, cur.r))) continue;
    for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
      const c = costAt(T, n.c, n.r, u.pid, B);
      if (c == null) continue;
      const nc = cur.cost + c;
      if (nc > limit + 1e-9) continue;
      const k = key(n.c, n.r),
        old = dist.get(k);
      if (!old || old.cost > nc + 1e-9) {
        const node = { c: n.c, r: n.r, cost: nc, prev: cur };
        dist.set(k, node);
        open.push(node);
      }
    }
  }
  for (const n of dist.values()) n.turns = n.cost ? Math.max(1, Math.ceil(n.cost / mv - 1e-9)) : 0;
  return dist;
}
// Turn standing orders into this turn's orders. Returns short notes ("Sherman A arrived") for the HUD.
function applyStanding(B = appState.battle, pid = 0) {
  B.standing = B.standing || {};
  const notes = [];
  for (const [id, s] of Object.entries(B.standing)) {
    const u = unitById(+id, B);
    if (!u || u.hp <= 0 || u.pid !== pid || u.in) {
      delete B.standing[id];
      continue;
    }
    if (s.type === 'hold') {
      B.orders[u.id] = { type: 'hold', standing: true };
      continue;
    }
    if (s.type === 'move') {
      if (u.c === s.dest.c && u.r === s.dest.r) {
        delete B.standing[id];
        notes.push(`${u.name} arrived`);
        continue;
      }
      const moved = !s.last || s.last.c !== u.c || s.last.r !== u.r;
      s.stuck = moved ? 0 : (s.stuck || 0) + 1;
      s.last = { c: u.c, r: u.r };
      const n = travelField(u, 12, B).get(key(s.dest.c, s.dest.r));
      if (!n || s.stuck >= STANDING_STUCK) {
        delete B.standing[id];
        notes.push(`${u.name} can't get through to its destination`);
        continue;
      }
      B.orders[u.id] = { type: 'move', path: pathTo(n), target: null, multi: { dest: { c: s.dest.c, r: s.dest.r }, turns: n.turns } };
    }
  }
  return notes;
}
// Record what a newly given order means for standing orders.
function noteStanding(B, u, o) {
  B.standing = B.standing || {};
  if (o && o.type === 'hold') B.standing[u.id] = { type: 'hold' };
  else if (o && o.multi) B.standing[u.id] = { type: 'move', dest: { c: o.multi.dest.c, r: o.multi.dest.r } };
  else delete B.standing[u.id];
}
