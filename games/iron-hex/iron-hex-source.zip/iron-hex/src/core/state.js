// Application state, save snapshots, versioned save migrations.
// ---------- App state (single source of truth for persisted data) ----------
function defaultSettings() {
  return {
    armies: 2,
    strategies: ['player', 'balanced', 'aggressive', 'defensive'],
    mapId: 'strait',
    randomSeed: Math.floor(Math.random() * 1e6),
    rules: {
      zoc: true,
      realtime: true,
      engage: true,
      terrRadius: true,
      terrPaint: true,
      terrSpread: true,
      exhaust: true,
      attrition: false,
      fog: false,
      intelFade: false,
      decoys: false,
      aiDeception: false,
      income: false,
      production: false,
      capitalLoss: false,
      weather: false,
      morale: false,
      supplyLines: false,
      entrench: false,
      suppression: false,
      facing: false,
      urban: false,
      elevation: false,
      surrender: false,
      command: false,
      friction: false,
      ew: false,
      airSup: false,
      aaUmbrella: false,
      artillery: false,
      subs: false,
      mines: false,
      carriers: false,
      rail: false,
      seasons: false,
      reinforce: false,
      vp: false,
      infoOps: false,
      ammo: false,
      missiles: false,
      cityDev: false,
    },
    budget: 0,
    hotseat: 1, // players on this device (Quick battle)
    teams: [0, 1, 2, 3],
    grants: { territory: true, resupply: true, passage: true },
    victory: { mode: 'destruction', pct: 60, hold: 3 },
    roster: Object.assign({}, DEFAULT_ROSTER),
    skins: ['modern', 'modern', 'modern', 'modern'],
    skinUnlocked: [],
  };
}
const appState = {
  screen: 'start',
  settings: defaultSettings(),
  battle: null, // { turn, mapDef, players, units, nextId, orders }
  prefs: { sound: true, view: 'iso' },
  library: { type: 'tank', pid: 0 }, // Unit library selection
};

// Runtime-only render/interaction state (never saved)
const R = {
  map: null,
  cvs: null,
  ctx: null,
  PX: 3,
  session: 0,
  cam: { x: 0, y: 0, zoom: 12, angle: Math.PI / 4, angleT: Math.PI / 4 },
  sel: null,
  mode: 'idle',
  pending: null,
  reach: null,
  targets: null,
  hover: null,
  pick: [],
  boxes: [],
  fx: [],
  tweens: [],
  shake: 0,
  busy: false,
  aiOrders: {},
  ended: false,
  drag: null,
  pointers: new Map(),
};

// ---------- Persistence: File System Access API with localStorage fallback ----------
const LS_SAVE = 'ironhex_save',
  LS_AUTO = 'ironhex_autosave',
  LS_PREFS = 'ironhex_prefs';

// The saved fields of one unit.
const saveUnit = u => ({
  id: u.id,
  pid: u.pid,
  type: u.type,
  name: u.name,
  c: u.c,
  r: u.r,
  hp: u.hp,
  maxHp: u.maxHp,
  ammo: u.ammo,
  maxAmmo: u.maxAmmo,
  vet: u.vet || 0,
  morale: u.morale ?? null,
  dug: u.dug || 0,
  supp: u.supp || 0,
  cut: u.cut || 0,
  face: u.face || null,
  mv: u.mv || 0,
  rev: u.rev ?? null,
  ammoType: u.ammoType || null,
  cid: u.cid || null,
  fuel: u.fuel ?? null,
  maxFuel: u.maxFuel ?? null,
  cargo: u.cargo || null,
  in: u.in || null,
});
function snapshot(B = appState.battle) {
  return {
    app: 'iron-hex',
    version: SAVE_VERSION,
    savedAt: new Date().toISOString(),
    settings: appState.settings,
    battle: {
      turn: B.turn,
      mode: B.mode || 'single',
      log: B.log || null,
      replayStart: B.replayStart || null,
      mapDef: B.mapDef,
      players: B.players,
      nextId: B.nextId,
      rules: B.rules,
      victory: B.victory,
      holds: B.holds,
      seed: B.seed,
      rngState: B.rngState,
      quiet: B.quiet || 0,
      territory: B.territory,
      flags: B.flags,
      cities: B.cities,
      roads: B.roads,
      structs: B.structs,
      stats: B.stats,
      customTypes: B.customTypes || {},
      teams: B.teams,
      diplo: B.diplo || {},
      mines: B.mines || {},
      engaged: !!B.engaged,
      idle: B.idle || 0,
      seasonStart: B.seasonStart ?? null,
      vp: B.vp || null,
      startValue: B.startValue || null,
      rosterTypes: B.rosterTypes || null,
      reinforced: B.reinforced || null,
      standing: B.standing || {},
      intel: B.intel || {},
      decoys: B.decoys || [],
      nextDecoy: B.nextDecoy || 1,
      funds: B.funds || {},
      built: B.built || {},
      prodQueue: B.prodQueue || {},
      weather: B.weather || null,
      feints: B.feints || {},
      tally: B.tally || newTally(),
      skins: B.skins || [],
      skinUnlocked: B.skinUnlocked || [],
      objective: B.objective || null,
      campaign: B.campaign || null,
      turnLimit: B.turnLimit || null,
      units: B.units.map(saveUnit),
      fallen: (B.fallen || []).map(saveUnit),
    },
  };
}

function fallbackSave(data, k = LS_SAVE) {
  return store.set(k, data);
}

function fallbackLoad(k = LS_SAVE) {
  return store.get(k, null);
}

// ---- Versioned saves ---------------------------------------------------
// Bump SAVE_VERSION whenever the save format changes, and add a migration that upgrades
// the previous version. Saves are always migrated forward on load; newer saves are rejected.
const SAVE_VERSION = 10;
const MIGRATIONS = {
  // v2 -> v3: infrastructure. Older battles simply have none yet.
  // v3 -> v4: battles carry the definitions of any custom units they use.
  // v4 -> v5: tally (leaderboard and looks), looks per army, campaign objective and veteran ranks.
  // v5 -> v6: teams and diplomacy (older battles are free-for-all).
  // v6 -> v7: fog and intel, decoys, economy, weather and morale (all off in older battles).
  // v7 -> v8: the single economy rule became three (income, production, capital loss); old battles keep all three.
  // v8 -> v9: standing and multi-turn orders.
  // v9 -> v10: destroyed units move to B.fallen.
  // v9 -> v10: destroyed units move to B.fallen; the rule key "ticks" is now "realtime"; custom units' "cost" is "moveCost".
  9: d => {
    const b = d.battle;
    b.fallen = (b.fallen || []).concat(b.units.filter(u => u.hp <= 0));
    b.units = b.units.filter(u => u.hp > 0);
    for (const r of [b.rules, d.settings && d.settings.rules])
      if (r && 'ticks' in r) {
        r.realtime = r.ticks;
        delete r.ticks;
      }
    for (const T of Object.values(b.customTypes || {}))
      if (T.cost && !T.moveCost) {
        T.moveCost = T.cost;
        delete T.cost;
      }
    d.version = 10;
    return d;
  },
  8: d => {
    d.battle.standing = d.battle.standing || {};
    d.version = 9;
    return d;
  },
  7: d => {
    for (const r of [d.battle.rules, d.settings && d.settings.rules])
      if (r && 'economy' in r) {
        r.income = r.production = r.capitalLoss = !!r.economy;
        delete r.economy;
      }
    d.version = 8;
    return d;
  },
  6: d => {
    const b = d.battle;
    b.intel = b.intel || {};
    b.decoys = b.decoys || [];
    b.funds = b.funds || {};
    b.prodQueue = b.prodQueue || {};
    b.weather = b.weather || null;
    d.version = 7;
    return d;
  },
  5: d => {
    const b = d.battle;
    b.teams = b.teams || b.players.map(p => p.id);
    b.diplo = b.diplo || {};
    d.version = 6;
    return d;
  },
  4: d => {
    const b = d.battle;
    b.tally = b.tally || newTally();
    b.skins = b.skins || [];
    b.skinUnlocked = b.skinUnlocked || [];
    b.objective = b.objective || null;
    b.campaign = b.campaign || null;
    d.version = 5;
    return d;
  },
  3: d => {
    d.battle.customTypes = d.battle.customTypes || {};
    d.version = 4;
    return d;
  },
  2: d => {
    d.battle.structs = d.battle.structs || {};
    d.battle.stats = d.battle.stats || { built: 0, captured: 0, destroyed: 0, landings: 0, portCalls: 0 };
    d.version = 3;
    return d;
  },
  // v1 -> v2: seeded battle RNG and stalemate tracking. Battles saved before rules or victory
  // conditions existed keep the classic behavior they were played with.
  1: d => {
    const b = d.battle;
    b.rules = Object.assign(
      { zoc: false, ticks: false, engage: false, terrRadius: false, terrPaint: false, terrSpread: false },
      b.rules || {}
    );
    b.victory = b.victory || { mode: 'destruction', pct: 50, hold: 3 };
    b.holds = b.holds || {};
    b.quiet = b.quiet || 0;
    if (b.seed == null) b.seed = (Math.random() * 4294967296) >>> 0;
    if (b.rngState == null) b.rngState = b.seed;
    d.version = 2;
    return d;
  },
};
function migrateSave(d) {
  let v = d.version || 1;
  if (v > SAVE_VERSION) throw new Error(`This save is version ${v}, newer than this build (version ${SAVE_VERSION}).`);
  while (v < SAVE_VERSION) {
    d = MIGRATIONS[v](d);
    v = d.version;
  }
  return d;
}
function applySave(data) {
  if (!data || data.app !== 'iron-hex' || !data.battle) return false;
  try {
    data = migrateSave(data);
  } catch (e) {
    console.warn(e.message);
    return false;
  }
  // Custom unit types travel with the battle: register any this browser doesn't have yet.
  const typeProblems = [];
  for (const T of Object.values(data.battle.customTypes || {})) if (!UNIT_TYPES[T.id]) typeProblems.push(...registerCustomUnit(clone(T)));
  if (typeProblems.length) {
    console.warn('Save rejected:', typeProblems.join('; '));
    return false;
  }
  const problems = validateMapDef(data.battle.mapDef).concat(
    (data.battle.units || []).filter(u => !UNIT_TYPES[u.type]).map(u => `unknown unit type "${u.type}"`)
  );
  if (problems.length) {
    console.warn('Save rejected:', problems.join('; '));
    return false;
  }
  appState.settings = Object.assign(appState.settings, data.settings || {});
  appState.battle = data.battle;
  R.map = buildMap(appState.battle.mapDef);
  attachMap(appState.battle, R.map); // a loaded battle is complete on its own (the interface rebuilds it too)
  appState.battle.orders = {};
  return true;
}
