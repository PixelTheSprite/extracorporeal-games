// Core utilities, the seeded battle RNG, and the VIEW hook layer.
// Game logic never touches the DOM: every visual or audio effect goes through VIEW,
// which is NullView (instant, silent) in headless runs and BrowserView in the game.
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

const lerp = (a, b, t) => a + (b - a) * t;

function mulberry32(a) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const hash3 = (a, b, c) => (Math.imul(a + 1, 73856093) ^ Math.imul(b + 1, 19349663) ^ Math.imul(c + 1, 83492791)) >>> 0;

const hexToRgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));

// Browser storage as JSON. Every access is guarded: storage can be missing (Node, private modes), full, or hold bad data.
const store = {
  get(k, fallback = null) {
    try {
      const v = typeof localStorage === 'undefined' ? null : localStorage.getItem(k);
      return v == null ? fallback : JSON.parse(v);
    } catch (e) {
      return fallback;
    }
  },
  set(k, v) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
      return true;
    } catch (e) {
      return false;
    }
  },
  remove(k) {
    try {
      localStorage.removeItem(k);
    } catch (e) {}
  },
};
const storedList = k => {
  const v = store.get(k, []);
  return Array.isArray(v) ? v : [];
};
// Deep copy of plain data (saves, settings, definitions).
const clone = o => JSON.parse(JSON.stringify(o));
const escapeHtml = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

// ---- View hooks -------------------------------------------------------
// NullView: used for headless battles (Node test runner, in-game diagnostics). Everything is instant and silent.
const NullView = {
  missile: () => Promise.resolve(),
  sleep: () => Promise.resolve(),
  tween: (dur, fn) => {
    fn(1);
    return Promise.resolve();
  },
  text() {},
  fx() {},
  boom() {},
  sfx() {},
  banner() {},
  cards() {},
  hud() {},
  shake() {},
  shot: () => Promise.resolve(),
  sshot: () => Promise.resolve(),
};
let VIEW = NullView; // the browser build swaps in BrowserView at boot
const sleep = ms => VIEW.sleep(ms);
const floatText = (u, text, color) => VIEW.text(u, text, color);
const addFx = e => VIEW.fx(e);
const boom = (x, y, z, size) => VIEW.boom(x, y, z, size);
const sfx = name => VIEW.sfx(name);

// ---- Seeded battle RNG -------------------------------------------------
// All game-affecting randomness (hit rolls, damage spread, AI tie-breaks) comes from here.
// The state lives in the battle (B.rngState), so a saved battle resumes the exact same sequence.
// Purely visual randomness (dust, shot timing) keeps using Math.random and never touches this.
function rng(B = appState.battle) {
  let a = (B.rngState = (B.rngState + 0x6d2b79f5) | 0);
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
// FNV-1a hash of a string, as 8 hex digits (used to compare battle states in tests).
function hashString(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

// Priority queue for the pathfinders. Ties pop in insertion order, which is exactly the order the earlier
// "stable sort, then shift" produced, so routes (and battle results) are unchanged, just faster.
class MinHeap {
  constructor(prio) {
    this.a = [];
    this.prio = prio;
    this.seq = 0;
  }
  get length() {
    return this.a.length;
  }
  push(x) {
    this.a.push({ x, p: this.prio(x), s: this.seq++ });
    let i = this.a.length - 1;
    while (i > 0) {
      const j = (i - 1) >> 1;
      if (this.lt(i, j)) {
        [this.a[i], this.a[j]] = [this.a[j], this.a[i]];
        i = j;
      } else break;
    }
  }
  shift() {
    const top = this.a[0],
      last = this.a.pop();
    if (this.a.length) {
      this.a[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1,
          r = l + 1;
        let m = i;
        if (l < this.a.length && this.lt(l, m)) m = l;
        if (r < this.a.length && this.lt(r, m)) m = r;
        if (m === i) break;
        [this.a[i], this.a[m]] = [this.a[m], this.a[i]];
        i = m;
      }
    }
    return top.x;
  }
  lt(i, j) {
    const A = this.a[i],
      B = this.a[j];
    return A.p < B.p || (A.p === B.p && A.s < B.s);
  }
}
const heapOf = (prio, items = []) => {
  const h = new MinHeap(prio);
  for (const x of items) h.push(x);
  return h;
};
