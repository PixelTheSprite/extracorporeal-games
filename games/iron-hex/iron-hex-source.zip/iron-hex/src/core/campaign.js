// Campaign: linked missions on generated maps, with objectives, veterans and a branch.
// A mission is a battle with its own map, rosters, rules, turn limit and objective (B.objective).
// Units that survive a mission carry over (B.units[].cid links them to the campaign roster) and earn ranks.

const VET_XP = [0, 3, 8, 15]; // experience needed for ranks 0–3
const VET_DAMAGE = 0.05,
  VET_EVADE = 3; // per rank: +5% damage dealt, +3 points of evasion
const rankFor = xp => VET_XP.reduce((r, need, i) => (xp >= need ? i : r), 0);
const RANK_NAME = ['Recruit', 'Regular', 'Veteran', 'Elite'];
// After each victory, replacements (as Recruits) top the force up to at least this many units, so a campaign can't soft-lock.
const MIN_FORCE = 8,
  REPLACEMENTS = ['tank', 'inf', 'at', 'inf', 'tank', 'aa'];

const CAMPAIGN = {
  id: 'iron-coast',
  name: 'The Iron Coast',
  intro:
    'The Crimson Rebels hold the Iron Coast and its harbors. Falcon Corps lands with a small task force; every unit that survives carries its experience into the next fight.',
  start: 'm1',
  roster: [
    ['tank', 'Sherman "Anvil"'],
    ['tank', 'Sherman "Hammer"'],
    ['inf', '1st Rifles'],
    ['inf', '2nd Rifles'],
    ['at', 'Bazooka Team'],
    ['eng', 'Sapper Cole'],
    ['plane', 'Mustang "Kestrel"'],
    ['lst', 'LST "Ferry"'],
  ],
  missions: {
    m1: {
      title: 'Landfall',
      map: { seed: 2101, W: 26, H: 18, water: 42, mountains: 22, forest: 35, desert: 10, name: 'Iron Coast: the beaches' },
      brief:
        'Take the town nearest the middle of the coast and hold it for two turns. Infantry captures; everything else keeps them alive.',
      objective: { type: 'capture', hold: 2 },
      turnLimit: 30,
      enemy: { strategy: 'defensive', roster: { tank: 1, inf: 2, at: 1, aa: 1, ship: 1 } },
      next: { within: 16, fast: 'm2a', slow: 'm2b' },
      branchNote: 'Win within 16 turns to press on to the airfield; a slower win means holding the ridge first.',
    },
    m2a: {
      title: 'Pursuit',
      map: { seed: 2202, W: 28, H: 20, water: 30, mountains: 30, forest: 30, desert: 20, name: 'Iron Coast: the airfield' },
      brief: 'The Rebels are falling back on their airfield. Destroy it (or capture it with infantry) before they can regroup.',
      objective: { type: 'destroyStruct', kind: 'airfield' },
      turnLimit: 32,
      layout: { enemy: ['airfield', 'depot'], player: ['depot'] },
      enemy: { strategy: 'balanced', roster: { tank: 2, inf: 2, aa: 1, plane: 1 } },
      reinforcements: [['bomber', 'B-17 "Big Friend"']],
      next: 'm3',
    },
    m2b: {
      title: 'Hold the Ridge',
      map: { seed: 2303, W: 26, H: 18, water: 25, mountains: 40, forest: 35, desert: 5, name: 'Iron Coast: the ridge' },
      brief: 'A Rebel counterattack is coming. Keep at least one unit alive for twelve turns.',
      objective: { type: 'survive', turns: 12 },
      turnLimit: 12,
      enemy: { strategy: 'aggressive', roster: { tank: 3, inf: 2, at: 1, plane: 1, bomber: 1 } },
      reinforcements: [['aa', 'M19 "Umbrella"']],
      next: 'm3',
    },
    m3: {
      title: 'The Iron Gate',
      map: { seed: 2404, W: 30, H: 22, water: 35, mountains: 30, forest: 30, desert: 15, name: 'Iron Coast: the Iron Gate' },
      brief:
        'Get Sapper Cole within two hexes of the Rebel capital to open the Iron Gate. If Cole falls, the mission fails. Keep your units around him.',
      objective: { type: 'escort', unitName: 'Sapper Cole' },
      turnLimit: 34,
      layout: { enemy: ['fort', 'depot'] },
      enemy: { strategy: 'defensive', roster: { tank: 1, inf: 2, at: 1, aa: 1, ship: 1 } },
      reinforcements: [
        ['tank', 'Sherman "Bulwark"'],
        ['inf', '3rd Rifles'],
      ],
      next: null,
    },
  },
};
// Which mission follows: a mission id, null (the end), or a speed branch { within, fast, slow }: win within
// `within` turns to go to `fast`, otherwise `slow`. Plain data, so editor-made campaigns can be saved and shared.
function nextMission(m, out) {
  const n = m.next;
  if (typeof n === 'function') return n(out); // older definitions
  if (n && typeof n === 'object') return out.turns <= n.within ? n.fast : n.slow;
  return n || null;
}

// The second built-in campaign: island to island, with ships, landing craft and a typhoon.
const ARCHIPELAGO = {
  id: 'archipelago',
  name: 'Operation Archipelago',
  intro:
    'Island by island across the Crimson Rebels’ Pacific chain. Ships and landing craft matter as much as tanks, and the weather turns. Survivors carry their experience forward.',
  start: 'a1',
  roster: [
    ['inf', '1st Marines'],
    ['inf', '2nd Marines'],
    ['tank', 'Sherman "Surf"'],
    ['at', 'Bazooka "Reef"'],
    ['eng', 'Seabee Ortiz'],
    ['plane', 'Mustang "Gull"'],
    ['ship', 'Fletcher "Picket"'],
    ['lst', 'LST "Mule"'],
  ],
  missions: {
    a1: {
      title: 'Beachhead',
      map: { seed: 3101, W: 26, H: 18, water: 55, mountains: 15, forest: 40, desert: 15, name: 'Archipelago: Coral Atoll' },
      brief: 'Seize the island town nearest the middle and hold it for two turns. The LST ferries troops across the water.',
      objective: { type: 'capture', hold: 2 },
      turnLimit: 30,
      enemy: { strategy: 'defensive', roster: { inf: 3, at: 1, aa: 1, ship: 1 } },
      next: { within: 18, fast: 'a2', slow: 'a2b' },
      branchNote: 'Take it within 18 turns to strike the airstrip next; a slower win means riding out the typhoon first.',
    },
    a2: {
      title: 'The Airstrip',
      map: { seed: 3202, W: 28, H: 20, water: 45, mountains: 20, forest: 35, desert: 20, name: 'Archipelago: Palm Strip' },
      brief: 'Rebel aircraft fly from an airstrip on the big island. Destroy it, or capture it with infantry.',
      objective: { type: 'destroyStruct', kind: 'airfield' },
      turnLimit: 32,
      layout: { enemy: ['airfield', 'fort'], player: ['depot'] },
      enemy: { strategy: 'balanced', roster: { tank: 1, inf: 2, aa: 1, plane: 2 } },
      reinforcements: [['aa', 'M19 "Palm"']],
      next: 'a3',
    },
    a2b: {
      title: 'Typhoon',
      map: { seed: 3303, W: 26, H: 18, water: 50, mountains: 25, forest: 30, desert: 10, name: 'Archipelago: Storm Reef' },
      brief:
        'Typhoon season: weather is on, and storms ground aircraft. The Rebels counterattack under the clouds. Keep at least one unit alive for ten turns.',
      objective: { type: 'survive', turns: 10 },
      turnLimit: 10,
      rules: { weather: true },
      enemy: { strategy: 'aggressive', roster: { tank: 2, inf: 3, at: 1, ship: 1 } },
      reinforcements: [['battleship', 'Iowa "Thunder"']],
      next: 'a3',
    },
    a3: {
      title: 'The Admiral’s Landing',
      map: { seed: 3404, W: 30, H: 22, water: 50, mountains: 25, forest: 30, desert: 15, name: 'Archipelago: Fortress Isle' },
      brief: 'Bring Seabee Ortiz within two hexes of the Rebel capital to wire the harbor defenses. If Ortiz falls, the mission fails.',
      objective: { type: 'escort', unitName: 'Seabee Ortiz' },
      turnLimit: 36,
      layout: { enemy: ['fort', 'port', 'depot'] },
      enemy: { strategy: 'defensive', roster: { tank: 2, inf: 2, at: 1, aa: 1, ship: 2 } },
      reinforcements: [
        ['tank', 'Sherman "Breaker"'],
        ['inf', '3rd Marines'],
      ],
      next: null,
    },
  },
};
const BUILTIN_CAMPAIGNS = [CAMPAIGN, ARCHIPELAGO];

// The number of missions on the longest path through a campaign (branches count once).
function campaignLength(def) {
  const depth = (id, seen) => {
    const m = def.missions[id];
    if (!m || seen.has(id)) return 0;
    seen.add(id);
    const n = m.next,
      nexts = n && typeof n === 'object' ? [n.fast, n.slow] : n ? [n] : [];
    return 1 + Math.max(0, ...nexts.map(x => depth(x, new Set(seen))));
  };
  return depth(def.start, new Set());
}

// Checks a campaign definition (editor-made or imported) before it can be played. Returns a list of problems.
const OBJECTIVE_TYPES = ['capture', 'destroyStruct', 'survive', 'escort'];
function validateCampaign(def) {
  const out = [],
    is = (ok, msg) => {
      if (!ok) out.push(msg);
    };
  const int = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  const str = (v, max) => typeof v === 'string' && v.trim().length > 0 && v.length <= max;
  if (!def || typeof def !== 'object') return ['Not a campaign.'];
  is(typeof def.id === 'string' && /^[a-z0-9_-]{1,48}$/.test(def.id), 'Campaign id must be lowercase letters, digits, - or _.');
  is(str(def.name, 60), 'The campaign needs a name (up to 60 characters).');
  is(typeof def.intro === 'string' && def.intro.length <= 600, 'The introduction is too long (600 characters at most).');
  is(Array.isArray(def.roster) && def.roster.length >= 1 && def.roster.length <= 16, 'The starting force needs 1 to 16 units.');
  for (const r of def.roster || [])
    is(Array.isArray(r) && UNIT_TYPES[r[0]] && str(r[1], 40), `Starting unit "${(r && r[1]) || '?'}" needs a known type and a name.`);
  const ids = Object.keys(def.missions || {});
  is(ids.length >= 1 && ids.length <= 12, 'A campaign needs 1 to 12 missions.');
  is(ids.includes(def.start), 'The first mission must be one of the missions.');
  const names = new Set((def.roster || []).map(r => r && r[1]));
  for (const id of ids) {
    const m = def.missions[id],
      w = `Mission "${(m && m.title) || id}"`;
    if (!m || typeof m !== 'object') {
      out.push(`${w} is empty.`);
      continue;
    }
    is(/^[a-z0-9_-]{1,24}$/.test(id), `${w}: mission ids must be short lowercase codes.`);
    is(str(m.title, 60), `${w} needs a title.`);
    is(typeof m.brief === 'string' && m.brief.length <= 600, `${w}: the briefing is too long.`);
    const mp = m.map || {};
    is(
      int(mp.seed, 0, 1e9) &&
        int(mp.W, 12, 40) &&
        int(mp.H, 10, 30) &&
        ['water', 'mountains', 'forest', 'desert'].every(k => int(mp[k], 0, 100)),
      `${w}: the map settings are out of range.`
    );
    const o = m.objective || {};
    is(OBJECTIVE_TYPES.includes(o.type), `${w}: unknown objective.`);
    if (o.type === 'capture') is(int(o.hold, 1, 6), `${w}: hold for 1 to 6 turns.`);
    if (o.type === 'destroyStruct') is(!!STRUCTS[o.kind], `${w}: unknown structure to destroy.`);
    if (o.type === 'survive') is(int(o.turns, 3, 40), `${w}: survive for 3 to 40 turns.`);
    if (o.type === 'escort')
      is(
        names.has(o.unitName) || ids.some(j => (def.missions[j].reinforcements || []).some(r => r[1] === o.unitName)),
        `${w}: the escorted unit must be in the starting force or a reinforcement.`
      );
    is(int(m.turnLimit, 5, 80), `${w}: turn limit 5 to 80.`);
    const e = m.enemy || {};
    is(!!STRATS[e.strategy], `${w}: unknown enemy strategy.`);
    const er = Object.entries(e.roster || {});
    is(
      er.length > 0 && er.every(([t, n]) => UNIT_TYPES[t] && int(n, 0, 6)) && er.reduce((a, [, n]) => a + n, 0) >= 1,
      `${w}: the enemy needs 1 or more units of known types (up to 6 of each).`
    );
    for (const r of m.reinforcements || [])
      is(Array.isArray(r) && UNIT_TYPES[r[0]] && str(r[1], 40), `${w}: every reinforcement needs a known type and a name.`);
    for (const k of Object.keys(m.rules || {})) is(RULES[k] && typeof m.rules[k] === 'boolean', `${w}: unknown rule "${k}".`);
    for (const k of [...((m.layout || {}).enemy || []), ...((m.layout || {}).player || [])])
      is(!!STRUCTS[k], `${w}: unknown structure "${k}".`);
    const n = m.next,
      ok = x => x === null || ids.includes(x);
    is(
      n == null || (typeof n === 'string' && ok(n)) || (typeof n === 'object' && int(n.within, 1, 80) && ok(n.fast) && ok(n.slow)),
      `${w}: the next mission must exist.`
    );
  }
  if (!out.length && campaignLength(def) === 0) out.push('The campaign has no playable path.');
  return out;
}
// A fresh campaign: the starting roster as campaign units with experience.
function newCampaignState(def = CAMPAIGN) {
  return {
    id: def.id,
    mission: def.start,
    roster: def.roster.map(([type, name], i) => ({ cid: 'c' + (i + 1), type, name, xp: 0 })),
    nextCid: def.roster.length + 1,
    history: [],
    done: false,
    won: false,
    startedAt: new Date().toISOString(),
  };
}
function missionMapDef(m) {
  const def = genMap('custom', m.map.seed, m.map.name, m.map);
  def.id = 'campaign-' + m.map.seed;
  def.spawns = def.spawns.slice(0, 2);
  return def;
}
// Builds the mission battle: your campaign units vs the mission's enemy roster, with the objective resolved on the map.
function newMissionBattle(state, def = CAMPAIGN, seed) {
  const m = def.missions[state.mission],
    mapDef = missionMapDef(m);
  const S = appState.settings;
  const saved = {
    armies: S.armies,
    mapId: S.mapId,
    customMap: S.customMap,
    playSide: S.playSide,
    layout: S.layout,
    strategies: S.strategies,
    victory: S.victory,
    armyRosters: S.armyRosters,
    rules: S.rules,
  };
  Object.assign(S, {
    armies: 2,
    mapId: mapDef.id,
    customMap: mapDef,
    playSide: 0,
    layout: null,
    strategies: ['player', m.enemy.strategy],
    rules: Object.assign({}, S.rules, m.rules || {}), // a mission can switch rules on or off (e.g. weather)
    victory: { mode: 'destruction', pct: 60, hold: 3 },
    armyRosters: [
      state.roster.map(u => ({ type: u.type, name: u.name, cid: u.cid, vet: rankFor(u.xp) })),
      rosterList(m.enemy.roster).map(([type, name]) => ({ type, name })),
    ],
  });
  try {
    const solo = { hotseat: S.hotseat, seats: S.seats }; // missions are single-player
    S.hotseat = 1;
    delete S.seats;
    newBattle(seed);
    S.hotseat = solo.hotseat;
    if (solo.seats) S.seats = solo.seats;
  } finally {
    Object.assign(S, saved);
  }
  const B = appState.battle;
  B.campaign = { id: def.id, mission: state.mission, title: m.title };
  B.turnLimit = m.turnLimit;
  // structures from the mission layout, next to each side's spawn
  if (m.layout) {
    const add = (pid, kinds) => {
      for (const s of autoLayout({ ...mapDef, spawns: [mapDef.spawns[pid]] }, 1, kinds))
        if (!B.structs[key(s.c, s.r)]) B.structs[key(s.c, s.r)] = newStruct(s.kind, pid);
    };
    if (m.layout.enemy) add(1, m.layout.enemy);
    if (m.layout.player) add(0, m.layout.player);
    B.territory = {};
    applySupplyRings(B, supplyPoints(B), B.rules.terrRadius);
  }
  B.objective = resolveObjective(B, m.objective);
  return B;
}
// Turns a mission's objective into concrete targets on this map.
function resolveObjective(B, o) {
  const def = B.mapDef,
    mid = toWorld(def.W / 2, def.H / 2);
  const ob = { type: o.type, hold: o.hold || 0, turns: o.turns || 0, progress: 0 };
  if (o.type === 'capture') {
    const cities = Object.keys(B.cities)
      .filter(k => !def.spawns.some(s => key(s.c, s.r) === k))
      .map(k => {
        const [c, r] = unkey(k);
        return { c, r };
      });
    const t = cities.sort((a, b) => {
      const wa = toWorld(a.c, a.r),
        wb = toWorld(b.c, b.r);
      return Math.hypot(wa.x - mid.x, wa.y - mid.y) - Math.hypot(wb.x - mid.x, wb.y - mid.y);
    })[0];
    ob.target = t;
    ob.text = `Capture the town at the center and hold it for ${o.hold} turns`;
  } else if (o.type === 'destroyStruct') {
    const k = Object.keys(B.structs).find(k => B.structs[k].kind === o.kind && B.structs[k].owner === 1);
    const [c, r] = unkey(k);
    ob.target = { c, r };
    ob.key = k;
    ob.text = `Destroy or capture the enemy ${STRUCTS[o.kind].name.toLowerCase()}`;
  } else if (o.type === 'survive') {
    ob.text = `Survive for ${o.turns} turns`;
  } else if (o.type === 'escort') {
    const u = B.units.find(x => x.pid === 0 && x.name === o.unitName);
    ob.unitId = u ? u.id : null;
    ob.target = def.spawns[1];
    ob.unitName = o.unitName;
    ob.text = `Bring ${o.unitName} within 2 hexes of the enemy capital`;
  }
  return ob;
}
// Called at the end of each mission turn: { win:true|false, text } when the objective is decided, or null.
function checkObjective(B) {
  const o = B.objective;
  if (!o) return null;
  if (o.type === 'capture') {
    const city = B.cities[key(o.target.c, o.target.r)];
    o.progress = city && city.owner === 0 ? o.progress + 1 : 0;
    if (o.progress >= o.hold) return { win: true, text: `Held the town for ${o.hold} turns.` };
  } else if (o.type === 'destroyStruct') {
    const s = B.structs[o.key];
    if (!s) return { win: true, text: 'The enemy airfield is destroyed.' };
    if (s.owner === 0) return { win: true, text: 'The enemy airfield is captured.' };
  } else if (o.type === 'survive') {
    o.progress = B.turn;
    if (B.turn >= o.turns) return { win: true, text: `Held out for ${o.turns} turns.` };
  } else if (o.type === 'escort') {
    const u = unitById(o.unitId, B);
    if (!u || u.hp <= 0) return { win: false, text: `${o.unitName} was lost.` };
    const host = u.in ? unitById(u.in, B) : u;
    if (hexDist(host, o.target) <= 2) return { win: true, text: `${o.unitName} reached the Iron Gate.` };
  }
  return null;
}
// After a mission: survivors gain experience (1 per mission + 2 per kill), the fallen leave the roster,
// reinforcements join, and the next mission is chosen. A loss keeps the pre-mission roster for a retry.
function campaignAfterMission(state, B, won, def = CAMPAIGN) {
  const m = def.missions[state.mission],
    s = clone(state),
    promotions = [],
    fallen = [];
  s.history.push({ mission: state.mission, title: m.title, won, turns: B.turn, at: new Date().toISOString() });
  if (!won) return { state: s, promotions, fallen, replaced: [], next: state.mission };
  const byCid = Object.fromEntries(B.units.filter(u => u.pid === 0 && u.cid).map(u => [u.cid, u]));
  s.roster = s.roster.filter(cu => {
    const bu = byCid[cu.cid];
    if (!bu || bu.hp <= 0) {
      fallen.push(cu.name);
      return false;
    }
    const before = rankFor(cu.xp);
    cu.xp += 1 + 2 * ((B.tally && B.tally.byUnit[bu.id]) || 0);
    if (rankFor(cu.xp) > before) promotions.push(`${cu.name} is now ${RANK_NAME[rankFor(cu.xp)]}`);
    return true;
  });
  for (const [type, name] of m.reinforcements || []) s.roster.push({ cid: 'c' + s.nextCid++, type, name, xp: 0 });
  const replaced = [];
  for (let i = 0; s.roster.length < MIN_FORCE; i++) {
    const type = REPLACEMENTS[i % REPLACEMENTS.length],
      name = `${UNIT_TYPES[type].short} (replacement ${s.nextCid})`;
    s.roster.push({ cid: 'c' + s.nextCid++, type, name, xp: 0 });
    replaced.push(name);
  }
  const next = nextMission(m, { turns: B.turn, won });
  if (next) s.mission = next;
  else {
    s.done = true;
    s.won = true;
  }
  return { state: s, promotions, fallen, replaced, next };
}
