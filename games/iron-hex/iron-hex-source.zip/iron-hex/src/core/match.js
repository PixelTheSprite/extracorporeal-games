// Online matches over the hosted runtime's shared database (or any object with the same API: tests use an
// in-memory one). Players submit orders asynchronously; when every human seat has submitted (or the turn's
// deadline passes), whichever device first takes the turn's lease resolves it and writes the result. Everyone
// else loads that result, so devices can never drift apart.
//
// Layout, all under matches/<mid>:
//   matches/<mid>                    { name, host, created, status: 'open'|'playing'|'finished', seats, deadlineHours,
//                                      turn, turnStarted, result }  seats: [{ human, ai }] (claims live in seats/<i>)
//   matches/<mid>/seats/<i>          { uid }                                     who sits in seat i
//   matches/<mid>/data/state(.N)     the battle at the start of `turn` (chunked JSON; replay log stripped)
//   matches/<mid>/data/start(.N)     the opening state, for replays
//   matches/<mid>/orders/<turn>_<i>  { uid, orders, prod, grants }               seat i's orders for that turn
//   matches/<mid>/log/<turn>         { entry }                                   that turn's replay log entry
//   matches/<mid>/locks/<turn>       lease document: whoever acquires it resolves the turn
// Trust model (chosen): orders are hidden in the interface but readable by a determined player; submitted orders
// are checked against the battle (units must belong to the seat, paths must be connected) before they're used.

const MATCH_CHUNK = 200000,
  MATCH_LOCK_MS = 120000,
  MATCH_SEATS_MAX = 4;
const ORDER_TYPES = new Set([
  'move',
  'amove',
  'hold',
  'fire',
  'unload',
  'capture',
  'build',
  'board',
  'road',
  'repair',
  'load',
  'flag',
  'engage',
  'decoy',
  'mine',
  'demolish',
  'broadcast',
]);

// ---- chunked JSON documents (the store caps documents at 256 KiB) ----
async function putBig(db, path, value) {
  const json = JSON.stringify(value),
    parts = Math.max(1, Math.ceil(json.length / MATCH_CHUNK));
  for (let i = 0; i < parts; i++) await db.doc(`${path}.${i}`).set({ s: json.slice(i * MATCH_CHUNK, (i + 1) * MATCH_CHUNK) });
  await db.doc(path).set({ parts, at: Date.now() });
}
async function getBig(db, path) {
  const head = await db.doc(path).get();
  if (!head.exists) return null;
  let json = '';
  for (let i = 0; i < head.data().parts; i++) {
    const p = await db.doc(`${path}.${i}`).get();
    if (!p.exists) return null;
    json += p.data().s;
  }
  return JSON.parse(json);
}

// A battle snapshot without its replay log (the log lives in log/<turn>; the opening state in data/start).
function matchSnapshot(B = appState.battle) {
  const s = snapshot(B);
  s.battle.log = null;
  s.battle.replayStart = null;
  return s;
}

// Run fn with this battle as the current one, restoring whatever was there before (the caller's own view).
async function withBattle(data, fn) {
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, me: appState.me };
  try {
    if (!applySave(clone(data))) throw new Error('match state would not load');
    return await fn(appState.battle);
  } finally {
    appState.battle = saved.battle;
    appState.settings = saved.settings;
    R.map = saved.map;
    appState.me = saved.me;
  }
}

// ---- creating and joining ----
// setup: { name, settings (Quick battle settings), seats: [{ human:true } | { human:false, ai:'balanced' }], deadlineHours }
// The creator takes seat 0. Returns the match id.
async function createMatch(db, uid, setup) {
  const seats = setup.seats
    .slice(0, MATCH_SEATS_MAX)
    .map((s, i) => (i === 0 || s.human ? { human: true } : { human: false, ai: s.ai || 'balanced' }));
  const mid = 'm' + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  let start, state;
  try {
    VIEW = NullView;
    appState.settings = Object.assign(clone(setup.settings), {
      armies: seats.length,
      seats,
      hotseat: 1,
      strategies: seats.map(s => s.ai || 'balanced'),
    });
    newBattle(Math.floor(Math.random() * 1e9));
    start = JSON.parse(appState.battle.replayStart);
    state = matchSnapshot();
  } finally {
    appState.battle = saved.battle;
    appState.settings = saved.settings;
    R.map = saved.map;
    VIEW = saved.view;
  }
  await putBig(db, `matches/${mid}/data/start`, start);
  await putBig(db, `matches/${mid}/data/state`, state);
  await db.doc(`matches/${mid}/seats/0`).set({ uid });
  const open = seats.some((s, i) => s.human && i > 0);
  await db.doc(`matches/${mid}`).set({
    name: String(setup.name || 'Match').slice(0, 60),
    host: uid,
    created: Date.now(),
    status: open ? 'open' : 'playing',
    seats,
    deadlineHours: setup.deadlineHours || 0,
    turn: 1,
    turnStarted: Date.now(),
    result: null,
    mapName: state.battle.mapDef.name,
    armies: state.battle.players.map(p => p.name),
  });
  return mid;
}
// Claim seat i with the store's lease pattern (claim, check it's free, write), so two people can't both win it.
async function claimSeat(db, mid, uid, i) {
  const m = await db.doc(`matches/${mid}`).get();
  if (!m.exists || m.data().status === 'finished' || !(m.data().seats[i] || {}).human) return { ok: false, why: 'That seat isn’t open.' };
  const ref = db.doc(`matches/${mid}/seats/${i}`);
  const lease = await ref.acquire({ holder: uid, ttlMs: 5000 });
  if (!lease.acquired) return { ok: false, why: 'Someone else is taking that seat right now.' };
  const cur = await ref.get();
  if (cur.exists && cur.data().uid && cur.data().uid !== uid) return { ok: false, why: 'That seat is taken.' };
  await ref.set({ uid });
  const claims = await seatClaims(db, mid, m.data().seats);
  if (m.data().status === 'open' && m.data().seats.every((s, k) => !s.human || claims[k]))
    await db.doc(`matches/${mid}`).update({ status: 'playing', turnStarted: Date.now() });
  return { ok: true };
}
async function seatClaims(db, mid, seats) {
  const out = [];
  for (let i = 0; i < seats.length; i++) {
    const d = await db.doc(`matches/${mid}/seats/${i}`).get();
    out.push(d.exists ? d.data().uid || null : null);
  }
  return out;
}
const mySeat = (claims, uid) => claims.indexOf(uid);
// The host can start without waiting: empty human seats become AI armies.
async function startWithAI(db, mid, uid) {
  const ref = db.doc(`matches/${mid}`),
    m = (await ref.get()).data();
  if (!m || m.host !== uid || m.status !== 'open') return false;
  const claims = await seatClaims(db, mid, m.seats);
  const seats = m.seats.map((s, i) => (s.human && !claims[i] ? { human: false, ai: 'balanced' } : s));
  const state = await getBig(db, `matches/${mid}/data/state`);
  seats.forEach((s, i) => {
    if (!s.human) state.battle.players[i].ai = s.ai;
  });
  await putBig(db, `matches/${mid}/data/state`, state);
  const start = await getBig(db, `matches/${mid}/data/start`);
  seats.forEach((s, i) => {
    if (!s.human) start.battle.players[i].ai = s.ai;
  });
  await putBig(db, `matches/${mid}/data/start`, start);
  await ref.update({ seats, status: 'playing', turnStarted: Date.now() });
  return true;
}

// ---- turns ----
async function submitOrders(db, mid, uid, seat, turn, payload) {
  await db
    .doc(`matches/${mid}/orders/${turn}_${seat}`)
    .set({ uid, at: Date.now(), orders: payload.orders || {}, prod: payload.prod || [], grants: payload.grants || null });
}
async function submittedSeats(db, mid, match) {
  const out = [];
  for (let i = 0; i < match.seats.length; i++) {
    if (!match.seats[i].human) continue;
    const d = await db.doc(`matches/${mid}/orders/${match.turn}_${i}`).get();
    if (d.exists) out.push(i);
  }
  return out;
}
const deadlinePassed = (match, now = Date.now()) => !!match.deadlineHours && now - match.turnStarted > match.deadlineHours * 3600000;
// Orders from a seat, kept only if they make sense for that seat's units (trust, but don't crash on nonsense).
function sanitizeOrders(B, seat, orders) {
  const out = {},
    inMap = h => h && Number.isInteger(h.c) && Number.isInteger(h.r) && h.c >= 0 && h.r >= 0 && h.c < B.mapDef.W && h.r < B.mapDef.H;
  for (const [id, o] of Object.entries(orders || {})) {
    // army actions: a strike from this seat's silo, an investment in this seat's city
    if (id.startsWith('strike:')) {
      const sl = B.structs[id.slice(7)];
      if (sl && sl.owner === seat && o && o.type === 'strike' && o.target)
        out[id] = { type: 'strike', target: { c: +o.target.c, r: +o.target.r } };
      continue;
    }
    if (id.startsWith('invest:')) {
      const ci = B.cities[id.slice(7)];
      if (ci && ci.owner === seat && o && o.type === 'invest') out[id] = { type: 'invest' };
      continue;
    }
    const u = unitById(+id, B);
    if (!u || u.pid !== seat || u.hp <= 0 || !o || !ORDER_TYPES.has(o.type)) continue;
    if (
      o.path &&
      !(
        Array.isArray(o.path) &&
        o.path.length <= 80 &&
        o.path.every((h, i) => inMap(h) && (i === 0 ? h.c === u.c && h.r === u.r : hexDist(h, o.path[i - 1]) === 1))
      )
    )
      continue;
    out[id] = o;
  }
  return out;
}
// Try to resolve the current turn. `simulate(orders)` runs the turn on the current battle (animated in the
// interface, headless in tests) and returns simulateTurn's result. Returns { resolved, out } or { resolved:false }.
async function resolveMatchTurn(db, mid, uid, simulate) {
  const ref = db.doc(`matches/${mid}`);
  const m0 = (await ref.get()).data();
  if (!m0 || m0.status !== 'playing') return { resolved: false };
  // Wait only for human seats whose army is still fighting (a defeated player has nothing to order).
  const state0 = await getBig(db, `matches/${mid}/data/state`);
  const fighting = i => state0.battle.units.some(u => u.pid === i && u.hp > 0);
  const done = await submittedSeats(db, mid, m0),
    humans = m0.seats.map((s, i) => (s.human && fighting(i) ? i : -1)).filter(i => i >= 0);
  if (!humans.every(i => done.includes(i)) && !deadlinePassed(m0)) return { resolved: false };
  const lease = await db.doc(`matches/${mid}/locks/${m0.turn}`).acquire({ holder: uid, ttlMs: MATCH_LOCK_MS });
  if (!lease.acquired) return { resolved: false };
  const m = (await ref.get()).data();
  if (m.turn !== m0.turn || m.status !== 'playing') return { resolved: false }; // someone else already did it
  const state = await getBig(db, `matches/${mid}/data/state`);
  const subs = {};
  for (const i of done) subs[i] = (await db.doc(`matches/${mid}/orders/${m.turn}_${i}`).get()).data();
  if (!applySave(clone(state))) return { resolved: false };
  const B = appState.battle;
  B.log = [];
  const orders = {};
  for (const [i, sub] of Object.entries(subs)) {
    Object.assign(orders, sanitizeOrders(B, +i, sub.orders));
    if (B.rules.production) (B.prodQueue = B.prodQueue || {})[i] = (sub.prod || []).slice(0, BUYS_PER_TURN + extraBuys(B, +i));
    if (sub.grants && typeof sub.grants === 'object') B.diplo[i] = sub.grants;
  }
  for (const p of B.players) if (p.ai && allAlive().some(u => u.pid === p.id)) Object.assign(orders, planAI(p));
  const out = await simulate(orders);
  const entry = B.log[0];
  await db.doc(`matches/${mid}/log/${m.turn}`).set({ entry: JSON.stringify(entry) });
  await putBig(db, `matches/${mid}/data/state`, matchSnapshot());
  const winner = out.end ? (out.winner !== undefined ? out.winner : pickWinner(out.remaining)) : null;
  await ref.update({
    turn: B.turn,
    turnStarted: Date.now(),
    status: out.end ? 'finished' : 'playing',
    result: out.end ? { reason: out.reason, winnerTeam: winner ? teamOf(winner.id) : null, turns: B.turn } : null,
  });
  return { resolved: true, out };
}
// The match's replay: opening state plus every turn's log entry.
async function matchReplay(db, mid) {
  const m = (await db.doc(`matches/${mid}`).get()).data();
  const start = await getBig(db, `matches/${mid}/data/start`);
  const log = [];
  for (let t = 1; t < (m.status === 'finished' ? m.result.turns + 1 : m.turn); t++) {
    const d = await db.doc(`matches/${mid}/log/${t}`).get();
    if (d.exists) log.push(JSON.parse(d.data().entry));
  }
  return {
    app: 'iron-hex-replay',
    version: 1,
    meta: { title: m.name, mapName: m.mapName, armies: m.armies, turns: log.length, online: true },
    start: JSON.stringify(start),
    log,
  };
}
