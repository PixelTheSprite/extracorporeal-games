// Hex math: pointy-top hexes in odd-r offset coordinates.
// ---------- Hex math (pointy-top, odd-r offset) ----------
const SQ3 = Math.sqrt(3);

const toWorld = (c, r) => ({ x: SQ3 * (c + 0.5 * (r & 1)), y: 1.5 * r });

// Hex keys are "c,r" strings (key() makes them); unkey() turns one back into [c, r].
const unkey = k => k.split(',').map(Number);
const offToAxial = (c, r) => ({ q: c - (r - (r & 1)) / 2, r });

// Hot path (the AI calls it constantly): same math as offToAxial, without allocating.
function hexDist(a, b) {
  const dq = a.c - (a.r - (a.r & 1)) / 2 - (b.c - (b.r - (b.r & 1)) / 2),
    dr = a.r - b.r;
  return (Math.abs(dq) + Math.abs(dr) + Math.abs(dq + dr)) / 2;
}

const NB_EVEN = [
  [1, 0],
  [0, -1],
  [-1, -1],
  [-1, 0],
  [-1, 1],
  [0, 1],
];

const NB_ODD = [
  [1, 0],
  [1, -1],
  [0, -1],
  [-1, 0],
  [0, 1],
  [1, 1],
];

function neighborsRaw(c, r, W, H) {
  return (r & 1 ? NB_ODD : NB_EVEN).map(([dc, dr]) => ({ c: c + dc, r: r + dr })).filter(n => n.c >= 0 && n.r >= 0 && n.c < W && n.r < H);
}

const HEX_CORNERS = [0, 1, 2, 3, 4, 5].map(i => {
  const a = (Math.PI / 180) * (60 * i - 30);
  return [Math.cos(a), Math.sin(a)];
});

const key = (c, r) => c + ',' + r;
