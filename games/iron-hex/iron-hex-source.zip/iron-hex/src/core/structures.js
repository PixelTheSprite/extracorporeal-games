// Infrastructure: airfields, ports, bridges, depots and fortifications.
// A structure on hex "c,r" lives in B.structs[key]: { kind, owner, hp, maxHp, build, capPid, prog }.
//   build: null when finished, or { pid, prog, need } while an engineer is still building it (a "scaffold").
//   owner: army id, or null for a neutral structure placed by a layout.
// Airfields, ports and depots are supply points that infantry can capture like cities.
// Bridges and fortifications serve whoever uses them, so they can only be destroyed.
const STRUCTS = {
  airfield: {
    name: 'Airfield',
    turns: 3,
    hp: 80,
    armor: 3,
    capture: true,
    supply: true,
    value: 25,
    desc: 'Supply point. Your planes that end a turn on it land: full fuel and ammo, +10% HP, and no fuel burned that turn.',
  },
  port: {
    name: 'Port',
    turns: 2,
    hp: 80,
    armor: 3,
    capture: true,
    supply: true,
    value: 25,
    desc: 'Supply point on a coast. Your ships next to it get full fuel and ammo and +15% HP every turn.',
  },
  bridge: {
    name: 'Bridge',
    turns: 2,
    hp: 60,
    armor: 4,
    capture: false,
    supply: false,
    value: 12,
    desc: 'Built onto a shallow-water hex. Ground units can cross; ships still pass underneath. Anyone can use it, so it can only be destroyed. Ground units on it fall in if it is destroyed.',
  },
  depot: {
    name: 'Depot',
    turns: 1,
    hp: 60,
    armor: 2,
    capture: true,
    supply: true,
    value: 15,
    desc: 'Supply point. Your units within 2 hexes are fully rearmed every turn.',
  },
  silo: {
    name: 'Missile silo',
    turns: 4,
    hp: 70,
    armor: 3,
    capture: true,
    value: 30,
    rule: 'missiles',
    desc: 'Charges a missile over several turns (faster with more cities held). Launch: hits one hex hard, with splash around it, anywhere your side can see within 10 hexes.',
  },
  fort: {
    name: 'Fortification',
    turns: 1,
    hp: 100,
    armor: 6,
    capture: false,
    supply: false,
    value: 10,
    desc: 'A ground unit standing in it takes 25% less damage. Anyone can use it, so it can only be destroyed.',
  },
};
const STRUCT_ORDER = ['airfield', 'port', 'bridge', 'depot', 'fort', 'silo'];
// Structures that come with a rule (the missile silo) can only be built while it's on.
const structAllowed = (kind, rules) => !STRUCTS[kind].rule || !!(rules && rules[STRUCTS[kind].rule]);
const FORT_COVER = 0.75,
  AIRFIELD_REPAIR = 0.1,
  PORT_REPAIR = 0.15,
  DEPOT_RANGE = 2;

const structAt = (c, r, B = appState.battle) => {
  const S = B && B.structs;
  return S ? S[key(c, r)] || null : null;
};
const builtAt = (c, r, B = appState.battle) => {
  const s = structAt(c, r, B);
  return s && !s.build ? s : null;
};
const bridgeAt = (c, r, B = appState.battle) => {
  const s = builtAt(c, r, B);
  return !!s && s.kind === 'bridge';
};
// Ground units can stand on land, or on water with a finished bridge.
const landPassAt = (c, r, B = appState.battle) => MOVE_COST.land[tileAt(c, r, B).t] != null || bridgeAt(c, r, B);

// Terrain rule for a structure, shared by engineers and the layout editor. ter: terrain code; coastal: next to water.
function siteOk(kind, ter, coastal) {
  if (kind === 'bridge') return ter === 'w';
  if (TERRAIN[ter].water || ter === 'c' || ter === 'm') return false;
  return kind === 'port' ? coastal : true;
}
const isCoastal = (rows, W, H, c, r) => neighborsRaw(c, r, W, H).some(n => TERRAIN[rows[n.r][n.c]].water);
// Can army pid build (or keep building) this kind at hex h right now?
function canBuildAt(kind, h, pid, B = appState.battle) {
  const def = B.mapDef;
  if (!structAllowed(kind, B.rules)) return false;
  if (!siteOk(kind, tileAt(h.c, h.r, B).t, isCoastal(def.rows, def.W, def.H, h.c, h.r))) return false;
  if (def.spawns.some(sp => sp.c === h.c && sp.r === h.r)) return false;
  const s = structAt(h.c, h.r, B);
  if (s) return !!s.build && s.kind === kind && s.build.pid === pid; // only continue your own scaffold of the same kind
  if (kind === 'bridge') return !unitAtLayer(h.c, h.r, false, B);
  return true;
}
const newStruct = (kind, owner, build) => ({
  kind,
  owner,
  hp: STRUCTS[kind].hp,
  maxHp: STRUCTS[kind].hp,
  build: build || null,
  capPid: null,
  prog: 0,
});
// Structures this unit may bombard: anything not its own army's, including scaffolds.
function canBombard(u, s, B = appState.battle) {
  if (u.ammo <= 0 || !effOf(UNIT_TYPES[u.type]).land) return false;
  const o = s.build ? s.build.pid : s.owner;
  return o == null || isEnemy(o, u.pid, B);
}
function bombardTargets(u, from, B = appState.battle) {
  const out = [];
  for (const [k, s] of Object.entries(B.structs || {})) {
    const [c, r] = unkey(k);
    if (canBombard(u, s, B) && inRange(u.type, from, { c, r }, B)) out.push({ c, r });
  }
  return out;
}
function structDamage(att, s, rand = 1, B = appState.battle) {
  const A = UNIT_TYPES[att.type],
    eff = effOf(A).land;
  if (!eff) return 0;
  const base = 10 + A.stats.firepower * 4,
    hpF = 0.5 + (0.5 * att.hp) / att.maxHp;
  return Math.max(1, Math.round(base * eff * hpF * (1 - STRUCTS[s.kind].armor * 0.06) * ammoStructDamage(att, B) * rand));
}
// Finished structures of one army, as [{ c, r, s }].
function armyStructs(pid, kind, B = appState.battle) {
  const out = [];
  for (const [k, s] of Object.entries(B.structs || {})) {
    if (s.build || s.owner !== pid || (kind && s.kind !== kind)) continue;
    const [c, r] = unkey(k);
    out.push({ c, r, s });
  }
  return out;
}

// ---- Layouts (made in the Infrastructure Editor, applied when a Quick battle starts) ----
// layout: { id, name, mapId, seed, structs:[{ c, r, kind, owner }] }  (owner: army index or null)
function validateLayout(layout, def) {
  const p = [];
  if (!layout || !Array.isArray(layout.structs)) return ['layout: missing structures'];
  const seen = new Set();
  for (const s of layout.structs) {
    const at = `${s.kind} at ${s.c},${s.r}`;
    if (!STRUCTS[s.kind]) {
      p.push(`layout: unknown structure "${s.kind}"`);
      continue;
    }
    if (s.c < 0 || s.r < 0 || s.c >= def.W || s.r >= def.H) {
      p.push(`layout: ${at} is off the map`);
      continue;
    }
    if (!siteOk(s.kind, def.rows[s.r][s.c], isCoastal(def.rows, def.W, def.H, s.c, s.r))) p.push(`layout: ${at} is on the wrong terrain`);
    if (def.spawns.some(sp => sp.c === s.c && sp.r === s.r)) p.push(`layout: ${at} is on a spawn point`);
    if (seen.has(s.c + ',' + s.r)) p.push(`layout: two structures at ${s.c},${s.r}`);
    seen.add(s.c + ',' + s.r);
    if (s.owner != null && !(Number.isInteger(s.owner) && s.owner >= 0 && s.owner < 4)) p.push(`layout: ${at} has an unknown owner`);
  }
  return p;
}
// Applies a layout to the new battle B. Structures owned by armies that aren't playing become neutral.
function applyLayout(B, layout) {
  if (!layout || validateLayout(layout, B.mapDef).length) return 0;
  for (const s of layout.structs)
    B.structs[key(s.c, s.r)] = newStruct(s.kind, s.owner != null && s.owner < B.players.length ? s.owner : null);
  return layout.structs.length;
}
// Places an airfield, port and depot near each army's spawn: the editor's "Auto-place" button and the test suites.
function autoLayout(def, armies, kinds = ['airfield', 'port', 'depot']) {
  const used = new Set(def.spawns.map(sp => sp.c + ',' + sp.r)),
    structs = [];
  for (let pid = 0; pid < armies; pid++) {
    const sp = def.spawns[pid];
    for (const kind of kinds) {
      const seen = new Set([sp.c + ',' + sp.r]),
        q = [sp];
      while (q.length) {
        const cur = q.shift(),
          k = cur.c + ',' + cur.r;
        if (!used.has(k) && siteOk(kind, def.rows[cur.r][cur.c], isCoastal(def.rows, def.W, def.H, cur.c, cur.r))) {
          used.add(k);
          structs.push({ c: cur.c, r: cur.r, kind, owner: pid });
          break;
        }
        for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
          const nk = n.c + ',' + n.r;
          if (!seen.has(nk)) {
            seen.add(nk);
            q.push(n);
          }
        }
      }
    }
  }
  return structs;
}
