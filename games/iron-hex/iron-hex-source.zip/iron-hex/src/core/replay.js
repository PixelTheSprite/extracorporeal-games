// Replays. A battle is fully determined by its opening state and, for each turn, every army's orders plus the
// random-number state, production queue and diplomacy they resolved with (the AI's planning draws on the same generator, so it's recorded
// rather than re-run). B.replayStart is the opening snapshot (a JSON string); B.log holds one entry per turn.
function startReplayLog(B) {
  B.log = [];
  B.replayStart = null;
  B.replayStart = JSON.stringify(Object.assign(snapshot(B), { replayOf: true }));
}
function recordTurn(B, orders) {
  if (!B.log) return;
  // Planning can also queue purchases and change diplomacy; both affect the turn, so they're recorded too.
  B.log.push({
    turn: B.turn,
    rng: B.rngState,
    orders: clone(orders),
    prod: clone(B.prodQueue || {}),
    diplo: clone(B.diplo || {}),
    feints: clone(B.feints || {}),
    feintCount: (B.stats && B.stats.feints) || 0,
  }); // AI planning bookkeeping
}
// A replay as one plain object: what Replays stores, exports and shares.
function replayOf(B, meta = {}) {
  if (!B.replayStart || !B.log) return null;
  return { app: 'iron-hex-replay', version: 1, meta, start: B.replayStart, log: clone(B.log) };
}
// Rebuild the battle at the start of a replay (turn 1). Returns false if the replay can't be loaded.
function loadReplayStart(rep) {
  try {
    const data = typeof rep.start === 'string' ? JSON.parse(rep.start) : rep.start;
    if (!applySave(data)) return false;
    appState.battle.log = null; // replaying shouldn't record a second log
    return true;
  } catch (e) {
    return false;
  }
}
// Play replay turn i (0-based) on the current battle.
async function replayTurn(rep, i, B = appState.battle) {
  const e = rep.log[i];
  if (!e) return { end: true };

  B.rngState = e.rng;
  B.prodQueue = clone(e.prod || {});
  B.diplo = clone(e.diplo || {});
  B.feints = clone(e.feints || {});
  if (e.feintCount) B.stats.feints = e.feintCount;
  return simulateTurn(clone(e.orders), B);
}
