// Turn simulation: simultaneous movement in ticks, fire, transfers, logistics, outcome.
/* Resolution runs as a short simulation of TICKS steps.
   Movement: each unit banks movement points every tick and steps one hex when it can afford the next hex.
   Faster units act first within a tick. Enemies block hexes; zones of control halt movement.
   Fire: with real-time fire on, every unit shoots during the ticks as enemies come into range;
   otherwise everyone fires once after movement, as in the original prototype. */
const TICKS = 8,
  TICK_MS = 230;

// Simulates one turn from everyone's orders. Pure game logic: visuals and sound go through VIEW.
// Returns { end:false } or { end:true, remaining, reason } with reason 'destruction' | 'territory' | 'timeout'.
// Simulates one turn from everyone's orders. Pure game logic: visuals and sound go through VIEW.
// Returns { end:false } or { end:true, remaining, reason } with reason 'destruction' | 'territory' | 'timeout' |
// 'exhaustion' | 'objective' | 'objective-failed'.
async function simulateTurn(orders, B = appState.battle) {
  recordTurn(B, orders);
  pruneFallen(B);
  const { st, holding, pending } = turnState(B, orders);
  applyInvestments(B, orders); // city development
  await fireMissiles(B, orders); // missile launches happen as the turn opens
  await movementTicks(B, st, holding, pending);
  settleStacks(st, B);
  if (doTransfers(st, B)) await sleep(500);
  await sleep(150);
  if (!B.rules.realtime) await classicFire(B, st, holding, pending);
  else reportUnfired(st, B);
  await Promise.all(pending);
  if (B.units.some(u => u.gone && u.goneTurn === B.turn)) await sleep(700);
  await logistics(st, B);
  for (const u of B.units) u.dispHp = u.hp;
  VIEW.cards();
  return turnOutcome(B, st);
}
// Per-unit state for this turn (orders, movement points, shots), who is holding, and the shot animations to await.
function turnState(B, orders) {
  const st = new Map();
  for (const u of B.units) {
    u.hp0 = u.hp;
    u.kills0 = 0;
  }
  for (const u of aliveUnits(B)) {
    const o = orders[u.id] || { type: 'hold' };
    if (o.ammo && usesAmmoTypes(UNIT_TYPES[u.type])) u.ammoType = o.ammo === 'ap' ? 'ap' : 'he'; // ammunition types: loaded as ordered
    u.dispHp = u.hp;
    st.set(u.id, {
      o,
      mp: 0,
      idx: 0,
      hist: [{ c: u.c, r: u.r }],
      tie: rng(B),
      moving: ['move', 'amove', 'engage'].includes(o.type),
      shots: 0,
      cd: 0,
      contact: false,
    });
  }
  applyFriction(B, st); // order friction (optional rule)
  const holding = new Set([...st].filter(([, s]) => s.o.type === 'hold').map(([id]) => id));
  const pending = [];
  return { st, holding, pending };
}
// Movement in TICKS steps; with real-time fire on, every unit also fires as soon as an enemy is in range.
async function movementTicks(B, st, holding, pending) {
  const fx = { fireBanner: false, moveSfx: false };
  for (let tick = 0; tick < TICKS; tick++) {
    if (B.rules.fog) computeVision(B); // fire only at what you can see
    // ---- Movement step
    const movers = aliveUnits(B)
      .filter(u => st.get(u.id) && st.get(u.id).moving)
      .sort((a, b) => UNIT_TYPES[b.type].stats.speed - UNIT_TYPES[a.type].stats.speed || st.get(a.id).tie - st.get(b.id).tie);
    const steps = [];
    for (const u of movers) {
      const s = st.get(u.id);
      if (u.hp <= 0 || grounded(u, B) || suppressed(u, B)) {
        s.moving = false;
        continue;
      }
      s.mp += moveOf(u, B) / TICKS;
      const nx = planStep(u, s, B);
      if (!nx) continue;
      const cost = costAt(UNIT_TYPES[u.type], nx.c, nx.r, u.pid, B);
      if (cost == null) {
        s.moving = false;
        continue;
      }
      const burn = cost * (UNIT_TYPES[u.type].fuelRate || 1);
      if (u.fuel != null && u.fuel + 1e-6 < burn) {
        s.moving = false;
        floatText(u, 'Out of fuel', '#ffb03a');
        continue;
      }
      if (s.mp + 1e-6 < cost) continue; // still building up to the next hex
      const occ = aliveUnits(B).filter(o => o !== u && o.c === nx.c && o.r === nx.r && isAir(o) === isAir(u));
      if (occ.some(o => isEnemy(o.pid, u.pid, B))) {
        markContact(u, s);
        continue;
      } // enemy in the way
      if (occ.some(o => o.pid !== u.pid && !grants(o.pid, u.pid, 'passage', B))) continue; // an ally who doesn't grant passage: wait
      if (occ.length && (nx.final || s.o.type === 'engage')) continue; // wait for a friend to clear
      const zocHere = B.rules.zoc && inZOC(u, nx, B);
      if (zocHere && occ.length) {
        markContact(u, s);
        continue;
      } // never stop on top of a friend
      s.mp -= cost;
      if (u.fuel != null) u.fuel = Math.max(0, u.fuel - burn);
      const from = { c: u.c, r: u.r };
      u.c = nx.c;
      u.r = nx.r;
      if (B.rules.facing) noteFacing(u, from, nx);
      u.mv = B.turn; // moved this turn (artillery can't fire after moving)
      if (stepOnMine(B, u)) s.moving = false; // mines stop a unit in its tracks
      if (s.o.path) s.idx++;
      s.hist.push({ c: u.c, r: u.r });
      steps.push({ u, from, to: { c: u.c, r: u.r } });
      if (zocHere) markContact(u, s);
      if (nx.final) s.moving = false;
    }
    if (steps.length) {
      if (!fx.moveSfx) {
        sfx('move');
        fx.moveSfx = true;
      }
      await VIEW.tween(TICK_MS, p => {
        for (const m of steps) {
          const a = tileAt(m.from.c, m.from.r, B),
            b = tileAt(m.to.c, m.to.r, B);
          m.u.px = lerp(a.wx, b.wx, p);
          m.u.py = lerp(a.wy, b.wy, p);
          m.u.pz = lerp(a.z, b.z, p);
          m.u.fx = b.wx - a.wx;
          m.u.fy = b.wy - a.wy;
          if (UNIT_TYPES[m.u.type].domain === 'land' && Math.random() < 0.06)
            addFx({ k: 'dust', x: m.u.px, y: m.u.py, z: m.u.pz, dur: 500 });
        }
      });
    }

    // ---- Real-time fire step
    if (B.rules.realtime) {
      const shots = [],
        sshots = [];
      for (const u of aliveUnits(B)) {
        const s = st.get(u.id);
        if (!s) continue;
        if (s.cd > 0) {
          s.cd--;
          continue;
        }
        const maxShots = holding.has(u.id) ? 2 : 1; // Overwatch can fire twice
        if (u.ammo <= 0 || s.shots >= maxShots) continue;
        if (s.o.starget && !s.sdone) {
          // ordered to bombard a structure: fire once it's in range, hold until the last tick
          const at = s.o.starget,
            so = structAt(at.c, at.r, B);
          if (so && canBombard(u, so, B) && inRange(u.type, u, at, B)) {
            sshots.push({ u, at, s: so, dmg: structDamage(u, so, 0.85 + rng(B) * 0.3, B) });
            s.sdone = true;
            continue;
          }
          if (so && tick < TICKS - 1) continue;
        }
        const t = chooseTarget(u, s, tick === TICKS - 1, B);
        if (t) shots.push(makeShot(u, t, holding, B));
      }
      applyStructShots(sshots, st, pending, B);
      if (shots.length || sshots.length) {
        if (!fx.fireBanner) {
          VIEW.banner('Fire!');
          fx.fireBanner = true;
        }
        applyShots(shots, st, pending, B);
        await sleep(160);
      } else if (!steps.length) await sleep(40);
    } else if (!steps.length && !aliveUnits(B).some(u => st.get(u.id) && st.get(u.id).moving)) break;
  }
}
// Real-time fire off: everyone shoots once after movement.
async function classicFire(B, st, holding, pending) {
  {
    const shots = [],
      sshots = [];
    for (const u of aliveUnits(B)) {
      const s = st.get(u.id);
      if (!s || u.ammo <= 0 || s.o.type === 'hold') continue;
      if (s.o.starget) {
        const at = s.o.starget,
          so = structAt(at.c, at.r, B);
        if (so && canBombard(u, so, B) && inRange(u.type, u, at, B))
          sshots.push({ u, at, s: so, dmg: structDamage(u, so, 0.85 + rng(B) * 0.3, B) });
        else if (so) floatText(u, 'Out of range', '#cfe3ff');
        continue;
      }
      let t = null;
      if (s.o.target) {
        const tt = unitById(s.o.target, B);
        if (tt && tt.hp > 0 && !tt.in) {
          if (canHit(u, tt, B) && inRange(u.type, u, tt, B)) t = tt;
          else {
            floatText(u, 'Out of range', '#cfe3ff');
            continue;
          }
        }
      } else if (s.o.type === 'amove') t = bestTargetInRange(u, B);
      if (t) shots.push(makeShot(u, t, holding, B));
    }
    if (shots.length || sshots.length) {
      VIEW.banner('Fire!');
      await sleep(350);
      applyShots(shots, st, pending, B);
      applyStructShots(sshots, st, pending, B);
    }
  }
}
// Real-time fire: ordered targets that were never in range get an "Out of range" note.
function reportUnfired(st, B = appState.battle) {
  {
    for (const u of aliveUnits(B)) {
      const s = st.get(u.id);
      if (!s || !s.o.target || s.shots > 0) continue;
      const t = unitById(s.o.target, B);
      if (t && t.hp > 0 && !t.in) floatText(u, 'Out of range', '#cfe3ff');
    }
  }
}
// After the turn: quiet-turn count, armies knocked out, objectives, territory holds, exhaustion, turn limit,
// then weather, the turn counter and intel for the next turn.
async function turnOutcome(B, st) {
  B.quiet = st.dmg ? 0 : (B.quiet || 0) + 1; // the AI's stalemate breaker reads this
  B.stats.dmgAll = (B.stats.dmgAll || 0) + (st.dmg || 0) + (B.stats.missileDmg || 0) - (B.stats.missileDmgCounted || 0); // all damage (missile share metric)
  B.stats.missileDmgCounted = B.stats.missileDmg || 0;
  // Supply exhaustion counts quiet turns only once the armies have made contact, so slow approaches never end a battle early.
  if (st.dmg) B.engaged = true;
  B.idle = st.dmg || !B.engaged ? 0 : (B.idle || 0) + 1;
  const remaining = B.players.filter(p => inFight(p.id, B) && !capitalLost(B, p.id) && !warWeary(B, p.id)); // war weariness: an exhausted army sues for peace
  const scuttled = allAlive(B).filter(u => !remaining.some(p => p.id === u.pid));
  for (const u of scuttled) {
    u.hp = 0;
    u.dispHp = 0;
    u.gone = true;
    u.goneTurn = B.turn;
    boom(u.px, u.py, u.pz + 0.2, 2);
    floatText(u, 'Scuttled', '#ff6a4a');
  }
  if (scuttled.length) {
    sfx('boom');
    VIEW.cards();
    await sleep(900);
  }
  if (teamsIn(remaining, B).length <= 1)
    return { end: true, remaining, reason: 'destruction', winner: remaining.find(p => p.id === 0) || remaining[0] || null };
  if (B.objective) {
    const r = checkObjective(B);
    if (r)
      return {
        end: true,
        remaining,
        reason: r.win ? 'objective' : 'objective-failed',
        winner: r.win ? B.players[0] : B.players[1],
        detail: r.text,
      };
    if (B.turn >= (B.turnLimit || turnLimit(B.mapDef)))
      return { end: true, remaining, reason: 'objective-failed', winner: B.players[1], detail: 'Ran out of time.' };
  }
  const V = victory(B);
  if (V.mode === 'territory') {
    // Teams hold territory together: holds are counted per team (a team of one in free-for-all).
    if (!B.holds) B.holds = {};
    const teams = teamsIn(remaining, B);
    for (const p of B.players) {
      const t = teamOf(p.id, B);
      B.holds[t] = teams.includes(t) && teamShare(B, t) * 100 >= V.pct ? (B.holds[t] || 0) + 1 : 0;
    }
    const won = teams.filter(t => B.holds[t] >= V.hold).sort((a, b) => teamShare(B, b) - teamShare(B, a))[0];
    if (won != null) {
      const ws = remaining.filter(p => teamOf(p.id, B) === won);
      return { end: true, remaining: ws, reason: 'territory', winner: ws.find(p => p.id === 0) || ws[0] };
    }
    VIEW.hud();
  }
  // Victory points (optional rule): cities score each turn; the first team to the target wins.
  scoreVictoryPoints(B);
  const vt = vpWinner(B);
  if (vt != null) {
    const ws = remaining.filter(p => teamOf(p.id, B) === vt);
    if (ws.length) return { end: true, remaining: ws, reason: 'points', winner: ws.find(p => p.id === 0) || ws[0] };
  }
  if (B.rules.exhaust && !B.objective && (B.idle || 0) >= EXHAUST_TURNS)
    return { end: true, remaining, reason: 'exhaustion', winner: pickWinner(remaining, true, B) };
  if (B.turn >= (B.turnLimit || turnLimit(B.mapDef))) return { end: true, remaining, reason: 'timeout' };
  if (B.rules.weather) advanceWeather(B);
  B.turn++;
  if (B.rules.fog) updateIntel(B);
  return { end: false, remaining };
}
// Winner among the armies still fighting: the last team standing, or the best team by territory
// (territory games) or score (destruction games, supply exhaustion). Returns one army of the winning team,
// your own if you're on it.
function pickWinner(remaining, byScore, B = appState.battle) {
  const V = victory(B);
  if (!remaining.length) return null;
  const teams = teamsIn(remaining, B);
  // Every battle has teams (free-for-all is a team per army), so the winner is always picked by team.
  const best = teams
    .slice()
    .sort((a, b) => (!byScore && V.mode === 'territory' ? teamShare(B, b) - teamShare(B, a) : teamScore(B, b) - teamScore(B, a)))[0];
  const ws = remaining.filter(p => teamOf(p.id, B) === best);
  return ws.find(p => p.id === 0) || ws[0];
}

// Next hex a unit wants this tick, or null when it has arrived, lost its target, or halted.
function planStep(u, s, B = appState.battle) {
  const o = s.o;
  if (o.type === 'engage') {
    const t = unitById(o.target, B);
    if (!t || t.hp <= 0 || t.in || u.ammo <= 0) {
      s.moving = false;
      return null;
    }
    if (canHit(u, t, B) && inRange(u.type, u, t, B)) {
      s.moving = false;
      return null;
    }
    const n = stepToward(u, t, B);
    if (!n) {
      s.moving = false;
      return null;
    }
    return { c: n.c, r: n.r, final: false };
  }
  if (o.type === 'amove' && u.ammo > 0 && bestTargetInRange(u, B)) {
    s.moving = false;
    return null;
  }
  const p = o.path;
  if (!p || s.idx >= p.length - 1) {
    s.moving = false;
    return null;
  }
  return { c: p[s.idx + 1].c, r: p[s.idx + 1].r, final: s.idx + 1 === p.length - 1 };
}

function markContact(u, s) {
  s.moving = false;
  if (!s.contact) {
    s.contact = true;
    floatText(u, 'Contact!', '#ffd84a');
  }
}

// Designated targets get priority; units hold that shot until the last tick, then take any target in range.
function chooseTarget(u, s, last, B = appState.battle) {
  const tid = s.o.target;
  if (tid) {
    const t = unitById(tid, B);
    if (t && t.hp > 0 && !t.in && canHit(u, t, B) && inRange(u.type, u, t, B)) return t;
    if (t && t.hp > 0 && !t.in && !last) return null;
  }
  return bestTargetInRange(u, B);
}

function makeShot(u, t, holding, B = appState.battle) {
  const overwatch = B.rules.realtime && holding.has(u.id);
  const ev = evadeOf(t, B) * (holding.has(t.id) ? 0.5 : 1) * (overwatch ? 0.5 : 1);
  const hit = rng(B) >= ev;
  let dmg = hit ? calcDamage(u, t, tileAt(t.c, t.r, B).t, holding.has(t.id), 0.85 + rng(B) * 0.3, undefined, B) : 0;
  if (overwatch && hit) dmg = Math.round(dmg * 1.2);
  return { u, t, hit, dmg };
}

// Shots at structures. A destroyed bridge drops the ground units standing on it into the water.
function applyStructShots(sshots, st, pending, B = appState.battle) {
  for (const sh of sshots) {
    const k = key(sh.at.c, sh.at.r);
    if (B.structs[k] !== sh.s) continue; // already destroyed by an earlier shot this batch
    sh.u.ammo = Math.max(0, sh.u.ammo - 1);
    const s = st.get(sh.u.id);
    if (s) {
      s.shots++;
      s.cd = 2;
    }
    st.dmg = (st.dmg || 0) + sh.dmg;
    sh.s.hp -= sh.dmg;
    if (sh.s.hp <= 0) {
      sh.destroyed = true;
      delete B.structs[k];
      B.stats.destroyed++;
      if (sh.s.kind === 'silo') B.stats.silosLost = (B.stats.silosLost || 0) + 1;
      if (sh.s.kind === 'bridge')
        for (const u of aliveUnits(B))
          if (u.c === sh.at.c && u.r === sh.at.r && UNIT_TYPES[u.type].domain === 'land') {
            u.hp = 0;
            if (u.cargo) {
              const c = unitById(u.cargo, B);
              if (c) c.hp = 0;
            }
            sh.drowned = (sh.drowned || []).concat(u);
          }
    }
    pending.push(VIEW.sshot(sh));
  }
}
// All shots in a batch were computed from the same state, so they land simultaneously.
function applyShots(shots, st, pending, B = appState.battle) {
  for (const sh of shots) {
    sh.u.ammo = Math.max(0, sh.u.ammo - 1);
    if (UNIT_TYPES[sh.u.type].indirect) sh.u.rev = B.turn + 1; // counter-battery: firing gives you away
    const wasAlive = sh.t.hp > 0;
    if (wasAlive && sh.t.hp - sh.dmg <= 0) sh.u.kills0 = (sh.u.kills0 || 0) + 1;
    sh.t.hp = Math.max(0, sh.t.hp - sh.dmg);
    if (!isEnemy(sh.u.pid, sh.t.pid, B)) B.stats.friendlyFire = (B.stats.friendlyFire || 0) + 1; // must stay 0
    if (wasAlive && sh.t.hp <= 0 && sh.u.pid === 0 && isEnemy(0, sh.t.pid, B)) {
      // the human army's kills (leaderboard, looks, veterans)
      tallyAdd(B, 'kills', sh.u.type);
      tallyAdd(B, 'byUnit', sh.u.id);
      if (isCounterKill(sh.u, sh.t)) tallyAdd(B, 'special', sh.u.type);
    }
    const s = st.get(sh.u.id);
    if (s) {
      s.shots++;
      s.cd = 2;
    }
    const ts = st.get(sh.t.id);
    if (ts && sh.t.hp <= 0) ts.moving = false;
    if (sh.t.hp <= 0 && sh.t.cargo) {
      const c = unitById(sh.t.cargo, B);
      if (c) {
        c.hp = 0;
        c.dispHp = 0;
        c.gone = true;
        c.goneTurn = B.turn;
      }
    }
    st.dmg = (st.dmg || 0) + sh.dmg;
    pending.push(VIEW.shot(sh));
  }
}

// Loading and unloading happen once movement is over. Landed units act from next turn.
function doTransfers(st, B = appState.battle) {
  let any = false;
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (!s || !isTransport(u)) continue;
    const o = s.o;
    if (o.type === 'load' || o.load) {
      // stationary Load, or Move + load
      const cid = o.type === 'load' ? o.cargo : o.load;
      const c = unitById(cid, B);
      const co = st.get(cid);
      if (c && c.hp > 0 && !c.in && !u.cargo && hexDist(u, c) === 1 && co && co.o.type === 'board') {
        c.in = u.id;
        u.cargo = c.id;
        any = true;
        addFx({ k: 'dust', x: c.px, y: c.py, z: c.pz, dur: 500 });
        floatText(u, 'Loaded', '#9fe86a');
      } else {
        floatText(u, 'Load failed', '#cfe3ff');
        any = true;
      }
    }
    if (o.unload && u.cargo) {
      const c = unitById(u.cargo, B),
        spots = landingSpots(u, B);
      if (!c || !spots.length) {
        floatText(u, "Can't land", '#cfe3ff');
        any = true;
        continue;
      }
      spots.sort((a, b) => hexDist(a, o.unload) - hexDist(b, o.unload));
      const h = spots[0],
        t = tileAt(h.c, h.r, B);
      c.in = null;
      u.cargo = null;
      c.c = h.c;
      c.r = h.r;
      c.px = t.wx;
      c.py = t.wy;
      c.pz = t.z;
      c.dispHp = c.hp;
      c.fx = t.wx - u.px;
      c.fy = t.wy - u.py;
      addFx({ k: 'dust', x: t.wx, y: t.wy, z: t.z, dur: 600 });
      floatText(c, 'Landed!', '#9fe86a');
      any = true;
      if (u.pid === 0) tallyAdd(B, 'special', u.type);
    }
  }
  if (any) {
    sfx('order');
    VIEW.cards();
  }
  return any;
}

// A unit that passed through a friend and was then stopped steps back to the last free hex on its route.
function settleStacks(st, B = appState.battle) {
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (!s) continue;
    const stacked = () => aliveUnits(B).some(o => o !== u && o.pid === u.pid && isAir(o) === isAir(u) && o.c === u.c && o.r === u.r);
    while (s.hist.length > 1 && stacked()) {
      s.hist.pop();
      const h = s.hist[s.hist.length - 1];
      u.c = h.c;
      u.r = h.r;
    }
    const t = tileAt(u.c, u.r, B);
    u.px = t.wx;
    u.py = t.wy;
    u.pz = t.z;
  }
}
