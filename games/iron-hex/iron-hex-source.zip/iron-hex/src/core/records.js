// Leaderboard records and the per-unit-type profile behind skin unlocks. Pure functions: the interface
// stores records and the profile in this browser; tests feed them fabricated data.

// What the human army (army 0) did this battle, kept on B.tally and saved with the battle.
//   kills[type]   enemy units destroyed by that unit type
//   special[type] uses of the type's specialty (see SPECIALTY below)
//   byUnit[id]    kills per unit (veteran experience in campaigns)
const newTally = () => ({ kills: {}, special: {}, byUnit: {} });
// The looks tally counts only in single-player (online, the device resolving a turn isn't necessarily yours).
const tallyAdd = (B, field, key, n = 1) => {
  if (battleMode(B) !== 'single' || B.tutorial) return;
  if (!B.tally) B.tally = newTally();
  B.tally[field][key] = (B.tally[field][key] || 0) + n;
};
// Specialties: captures (infantry), repairs, builds, unloads (transports), and "counter kills": destroying a target
// the attacker is especially good against (damage multiplier of at least 1.2, e.g. anti-aircraft vs planes).
const SPECIALTY_LABEL = 'captures, repairs, structures built, landings, or kills against its favored targets';
const isCounterKill = (att, tgt) => {
  const A = UNIT_TYPES[att.type],
    T = UNIT_TYPES[tgt.type];
  return effOf(A)[T.domain] * ((A.bonusVs && A.bonusVs[tgt.type]) || 1) >= 1.2;
};

// One finished battle, from the human army's point of view.
function battleRecord(B, out, mode, extra = {}) {
  const me = B.players[0],
    win = out.remaining.length === 1 ? out.remaining[0] : null;
  const winner = out.winner !== undefined ? out.winner : win || pickWinner(out.remaining, undefined, B);
  const result = !winner ? 'draw' : winner.id === 0 ? 'win' : 'loss';
  return Object.assign(
    {
      at: new Date().toISOString(),
      mode,
      mapId: B.mapDef.id || null,
      mapName: B.mapDef.name,
      size: `${B.mapDef.W}×${B.mapDef.H}`,
      armies: B.players.length,
      side: me.name,
      opponents: B.players.slice(1).map(p => p.ai || 'balanced'),
      victory: (B.victory || {}).mode || 'destruction',
      result,
      winner: winner ? winner.name : null,
      reason: out.reason,
      turns: B.turn,
      lost: everyUnit(B).filter(u => u.pid === me() && u.hp <= 0).length,
      fielded: everyUnit(B).filter(u => u.pid === me()).length,
      kills: Object.values((B.tally || {}).kills || {}).reduce((s, n) => s + n, 0),
    },
    extra
  );
}
function summarizeRecords(records) {
  const s = {
    battles: records.length,
    wins: 0,
    losses: 0,
    draws: 0,
    fastestWin: null,
    bestStreak: 0,
    streak: 0,
    byMap: {},
    byOpponent: {},
  };
  let run = 0;
  for (const r of records.slice().sort((a, b) => (a.at < b.at ? -1 : 1))) {
    s[r.result === 'win' ? 'wins' : r.result === 'loss' ? 'losses' : 'draws']++;
    run = r.result === 'win' ? run + 1 : 0;
    s.bestStreak = Math.max(s.bestStreak, run);
    if (r.result === 'win' && (!s.fastestWin || r.turns < s.fastestWin.turns)) s.fastestWin = { turns: r.turns, mapName: r.mapName };
    const m = (s.byMap[r.mapName] = s.byMap[r.mapName] || { name: r.mapName, w: 0, l: 0, d: 0, fastest: null });
    m[r.result === 'win' ? 'w' : r.result === 'loss' ? 'l' : 'd']++;
    if (r.result === 'win' && (m.fastest == null || r.turns < m.fastest)) m.fastest = r.turns;
    for (const o of new Set(r.opponents)) {
      const x = (s.byOpponent[o] = s.byOpponent[o] || { name: o, w: 0, l: 0, d: 0 });
      x[r.result === 'win' ? 'w' : r.result === 'loss' ? 'l' : 'd']++;
    }
  }
  s.streak = run;
  s.winRate = s.battles ? Math.round((100 * s.wins) / s.battles) : 0;
  return s;
}
// Profile: per built-in unit type, { battles, kills, wins, special }. Custom units don't earn looks.
const emptyProfile = () => ({ units: {} });
function applyBattleToProfile(profile, B, won) {
  const p = clone(profile || emptyProfile()),
    before = {};
  const types = [
    ...new Set(
      everyUnit(B)
        .filter(u => u.pid === 0 && !UNIT_TYPES[u.type].custom)
        .map(u => u.type)
    ),
  ];
  for (const t of types) {
    before[t] = unlockedPeriods(p, t);
    const e = (p.units[t] = p.units[t] || { battles: 0, kills: 0, wins: 0, special: 0 });
    e.battles++;
    e.kills += (B.tally && B.tally.kills[t]) || 0;
    e.special += (B.tally && B.tally.special[t]) || 0;
    if (won && B.units.some(u => u.pid === 0 && u.type === t && u.hp > 0)) e.wins++;
  }
  const unlocked = [];
  for (const t of types) for (const per of unlockedPeriods(p, t)) if (!before[t].includes(per)) unlocked.push({ type: t, period: per });
  return { profile: p, unlocked };
}
