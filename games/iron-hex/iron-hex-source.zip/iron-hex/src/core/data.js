// Static game data: terrain, unit types (0–10 stats from real vehicles), armies, AI strategies, roster.
// ---------- Data: terrain ----------
const TERRAIN = {
  '~': { name: 'Deep sea', color: '#2b58a0', elev: -1, water: true, def: 0 },
  w: { name: 'Shallows', color: '#4a8ed2', elev: 0, water: true, def: 0 },
  s: { name: 'Sand', color: '#e2c27a', elev: 1, def: 0 },
  p: { name: 'Plains', color: '#8cb04a', elev: 1, def: 0 },
  f: { name: 'Forest', color: '#4a8236', elev: 1, def: 0.15 },
  h: { name: 'Hills', color: '#b09a58', elev: 2, def: 0.2 },
  m: { name: 'Mountains', color: '#8a7d70', elev: 3, def: 0.3 },
  c: { name: 'City', color: '#b8aa94', elev: 1, def: 0.25 },
};

for (const k in TERRAIN) TERRAIN[k].rgb = hexToRgb(TERRAIN[k].color);

const tileZ = t => (t === '~' ? -0.14 : t === 'w' ? -0.07 : TERRAIN[t].elev * 0.28);

const MOVE_COST = {
  land: { s: 1, p: 1, f: 2, h: 2, m: 3, c: 1 },
  sea: { '~': 1, w: 1 },
  air: { '~': 1, w: 1, s: 1, p: 1, f: 1, h: 1, m: 1, c: 1 },
};

// Attack effectiveness: attacker domain -> target domain (0 = cannot engage)
const EFF = {
  land: { land: 1.0, sea: 0.6, air: 0 },
  air: { land: 1.1, sea: 1.2, air: 0.9 },
  sea: { land: 0.9, sea: 1.0, air: 0.7 },
};

// ---------- Data: units (stats normalized 0–10 from real-world reference data) ----------
const UNIT_TYPES = {
  tank: {
    id: 'tank',
    short: 'Sherman',
    name: 'M4 Sherman',
    role: 'Medium tank',
    domain: 'land',
    stats: { speed: 6, maneuver: 5, armor: 4, firepower: 5 },
    range: [1, 2],
    ammo: 6,
    fuel: 24,
    source: 'Modeled on the M4A3 Sherman medium tank (WWII, United States).',
    norm: [
      ['Speed', '≈ 40 km/h road', '0–70 km/h (tracked vehicles)', 6],
      ['Maneuverability', '≈ 13 hp/tonne', '0–25 hp/tonne', 5],
      ['Armor', '51–76 mm front', '0–200 mm', 4],
      ['Firepower', '75 mm M3 gun', '0–200 mm penetration', 5],
    ],
  },
  plane: {
    id: 'plane',
    short: 'Mustang',
    name: 'P-51 Mustang',
    role: 'Fighter-bomber',
    domain: 'air',
    stats: { speed: 9, maneuver: 8, armor: 1, firepower: 5 },
    range: [0, 1],
    ammo: 3,
    fuel: 30,
    source: 'Modeled on the P-51D Mustang fighter (WWII, United States).',
    norm: [
      ['Speed', '≈ 700 km/h', '0–800 km/h (piston aircraft)', 9],
      ['Maneuverability', 'Excellent roll and turn for its class', 'Relative to WWII fighters', 8],
      ['Armor', 'Pilot armor plate only', 'Relative to armored attack aircraft', 1],
      ['Firepower', '6 × .50 cal MG, up to 2 × 1,000 lb bombs', 'Relative to WWII attack aircraft', 5],
    ],
  },
  inf: {
    id: 'inf',
    short: 'Rifles',
    name: 'Rifle squad',
    role: 'Infantry',
    domain: 'land',
    stats: { speed: 1, maneuver: 7, armor: 0, firepower: 3 },
    range: [1, 1],
    ammo: 8,
    captures: true,
    foot: true,
    moveCost: { s: 1, p: 1, f: 1, h: 1, m: 2, c: 1 }, // on foot: forests and hills are easy, mountains passable
    eff: { land: 1.0, sea: 0.4, air: 0 },
    source: 'Modeled on a WWII US Army rifle squad (12 soldiers). The only unit that can capture cities.',
    norm: [
      ['Speed', '≈ 5 km/h on foot', '0–70 km/h (ground units)', 1],
      ['Maneuverability', 'Uses cover, crosses rough terrain', 'Relative to ground vehicles', 7],
      ['Armor', 'None', '0–200 mm', 0],
      ['Firepower', 'M1 rifles, BAR, 2.36" bazooka', 'Relative to ground units', 3],
    ],
  },
  eng: {
    id: 'eng',
    short: 'Engineer',
    name: 'Combat engineer',
    role: 'Motorcycle engineer',
    domain: 'land',
    stats: { speed: 10, maneuver: 8, armor: 0, firepower: 1 },
    range: [1, 1],
    ammo: 4,
    fuel: 20,
    repairs: true,
    builds: true,
    foot: true,
    eff: { land: 1.0, sea: 0.3, air: 0 },
    source: 'Modeled on a WWII US Army combat engineer riding a Harley-Davidson WLA motorcycle. Repairs adjacent units and builds roads.',
    norm: [
      ['Speed', '≈ 105 km/h top speed', '0–70 km/h (ground units), capped at 10', 10],
      ['Maneuverability', 'Light, nimble motorcycle', 'Relative to ground vehicles', 8],
      ['Armor', 'None', '0–200 mm', 0],
      ['Firepower', 'M1 carbine or Thompson SMG', 'Relative to ground units', 1],
    ],
  },
  lst: {
    id: 'lst',
    short: 'LST',
    name: 'LST-1 class',
    role: 'Tank landing ship',
    domain: 'sea',
    stats: { speed: 3, maneuver: 2, armor: 4, firepower: 2 },
    range: [1, 2],
    ammo: 4,
    fuel: 36,
    carry: 1,
    minMove: 3,
    eff: { land: 0, sea: 0, air: 0.9 }, // light anti-aircraft guns only
    source: 'Modeled on the LST-1 class tank landing ship (WWII, United States). Carries one land unit and lands it on an adjacent beach.',
    norm: [
      ['Speed', '≈ 11 knots', '0–40 knots (surface warships)', 3],
      ['Maneuverability', 'Flat-bottomed, slow to turn', 'Relative to WWII warships', 2],
      ['Armor', 'Unarmored, but large (≈ 4,000 t loaded) and heavily compartmented', 'Relative durability', 4],
      ['Firepower', 'Light AA: 40 mm and 20 mm guns', 'Relative to WWII surface combatants', 2],
    ],
  },
  aa: {
    id: 'aa',
    short: 'M19 AA',
    name: 'M19 MGMC',
    role: 'Anti-aircraft tank',
    domain: 'land',
    stats: { speed: 8, maneuver: 5, armor: 1, firepower: 6 },
    range: [1, 2],
    ammo: 6,
    fuel: 22,
    eff: { land: 0.4, sea: 0.3, air: 1.4 },
    source: 'Modeled on the M19 Multiple Gun Motor Carriage (WWII, United States): twin 40 mm Bofors guns on an M24 light-tank chassis.',
    norm: [
      ['Speed', '≈ 56 km/h road', '0–70 km/h (ground units)', 8],
      ['Maneuverability', '≈ 12.5 hp/tonne', '0–25 hp/tonne', 5],
      ['Armor', '≈ 13–25 mm', '0–200 mm', 1],
      ['Firepower', 'Twin 40 mm Bofors (anti-aircraft)', 'Relative to WWII ground units', 6],
    ],
  },
  apc: {
    id: 'apc',
    short: 'Half-track',
    name: 'M3 Half-track',
    role: 'Armored personnel carrier',
    domain: 'land',
    stats: { speed: 10, maneuver: 6, armor: 1, firepower: 2 },
    range: [1, 1],
    ammo: 4,
    fuel: 22,
    carry: 1,
    carryKinds: 'foot',
    eff: { land: 1.0, sea: 0.3, air: 0.3 },
    source: 'Modeled on the M3 half-track personnel carrier (WWII, United States). Carries one infantry-type unit over land.',
    norm: [
      ['Speed', '≈ 72 km/h road', '0–70 km/h (ground units), capped at 10', 10],
      ['Maneuverability', '≈ 15 hp/tonne', '0–25 hp/tonne', 6],
      ['Armor', '6–13 mm', '0–200 mm', 1],
      ['Firepower', '.50 cal M2 machine gun', 'Relative to ground units', 2],
    ],
  },
  at: {
    id: 'at',
    short: 'Bazooka',
    name: 'Bazooka team',
    role: 'Anti-tank infantry',
    domain: 'land',
    stats: { speed: 1, maneuver: 6, armor: 0, firepower: 5 },
    range: [1, 1],
    ammo: 3,
    captures: true,
    foot: true,
    moveCost: { s: 1, p: 1, f: 1, h: 1, m: 2, c: 1 },
    eff: { land: 1.0, sea: 0.5, air: 0 },
    bonusVs: { tank: 1.5, aa: 1.5, apc: 1.5 },
    source:
      'Modeled on a WWII US Army bazooka team armed with the M1 2.36" rocket launcher. Extra damage against armored vehicles; can capture cities.',
    norm: [
      ['Speed', '≈ 5 km/h on foot', '0–70 km/h (ground units)', 1],
      ['Maneuverability', 'Uses cover, crosses rough terrain', 'Relative to ground vehicles', 6],
      ['Armor', 'None', '0–200 mm', 0],
      ['Firepower', 'M1 bazooka, ≈ 100 mm penetration', '0–200 mm penetration', 5],
    ],
  },
  bomber: {
    id: 'bomber',
    short: 'B-17',
    name: 'B-17 Flying Fortress',
    role: 'Heavy bomber',
    domain: 'air',
    stats: { speed: 6, maneuver: 2, armor: 3, firepower: 9 },
    range: [0, 0],
    ammo: 2,
    fuel: 36,
    eff: { land: 1.3, sea: 1.3, air: 0 },
    source:
      'Modeled on the B-17G Flying Fortress (WWII, United States). Bombs ground and naval targets directly below it; cannot attack aircraft.',
    norm: [
      ['Speed', '≈ 460 km/h', '0–800 km/h (piston aircraft)', 6],
      ['Maneuverability', 'Heavy four-engine bomber', 'Relative to WWII fighters', 2],
      ['Armor', 'Crew armor plate, very rugged airframe', 'Relative to armored attack aircraft', 3],
      ['Firepower', 'Up to ≈ 3,600 kg of bombs', 'Relative to WWII attack aircraft', 9],
    ],
  },
  drone: {
    id: 'drone',
    short: 'Predator',
    name: 'MQ-1 Predator',
    role: 'Strike drone',
    domain: 'air',
    stats: { speed: 3, maneuver: 3, armor: 0, firepower: 4 },
    range: [0, 1],
    ammo: 2,
    fuel: 40,
    minMove: 4,
    upkeep: 1,
    fuelRate: 0.5,
    eff: { land: 1.0, sea: 0.8, air: 0 },
    source:
      'Modeled on the MQ-1 Predator (modern, United States), the one non-WWII unit. A light, fuel-efficient strike aircraft: half fuel per hex and 1 fuel per turn aloft.',
    norm: [
      ['Speed', '≈ 217 km/h top speed', '0–800 km/h (piston aircraft)', 3],
      ['Maneuverability', 'Slow, long-winged loiterer', 'Relative to WWII fighters', 3],
      ['Armor', 'None', 'Relative to armored attack aircraft', 0],
      ['Firepower', '2 × AGM-114 Hellfire missiles', 'Relative to WWII attack aircraft', 4],
    ],
  },
  battleship: {
    id: 'battleship',
    short: 'Iowa',
    name: 'Iowa-class',
    role: 'Battleship',
    domain: 'sea',
    stats: { speed: 8, maneuver: 3, armor: 9, firepower: 10 },
    range: [2, 4],
    ammo: 6,
    fuel: 50,
    eff: { land: 1.0, sea: 1.2, air: 0.5 },
    source: 'Modeled on the Iowa-class battleship (WWII, United States). Long-range guns that cannot hit targets right next to it.',
    norm: [
      ['Speed', '≈ 33 knots', '0–40 knots (surface warships)', 8],
      ['Maneuverability', 'Long hull, wide turning circle', 'Relative to WWII warships', 3],
      ['Armor', '307 mm belt', 'Relative to battleship belt armor', 9],
      ['Firepower', '9 × 16"/50 guns', 'Relative to WWII surface combatants', 10],
    ],
  },
  ship: {
    id: 'ship',
    short: 'Fletcher',
    name: 'Fletcher-class',
    role: 'Destroyer',
    domain: 'sea',
    asw: true, // anti-submarine warfare: can find and attack submarines
    stats: { speed: 9, maneuver: 6, armor: 2, firepower: 7 },
    range: [1, 3],
    ammo: 8,
    fuel: 40,
    source: 'Modeled on the Fletcher-class destroyer (WWII, United States).',
    norm: [
      ['Speed', '≈ 36.5 knots', '0–40 knots (surface warships)', 9],
      ['Maneuverability', 'Agile hull, tight turning circle', 'Relative to WWII warships', 6],
      ['Armor', 'Light splinter plating', 'Relative to battleship belt armor', 2],
      ['Firepower', '5 × 5"/38 guns, 10 torpedoes', 'Relative to WWII surface combatants', 7],
    ],
  },
  // ---- Units that come with realism rules (Phase 11, batch 3): only offered when their rule is on ----
  arty: {
    id: 'arty',
    short: 'M7 Priest',
    name: 'M7 Priest',
    role: 'Self-propelled howitzer',
    domain: 'land',
    rule: 'artillery',
    stats: { speed: 6, maneuver: 3, armor: 2, firepower: 9 },
    range: [2, 5],
    ammo: 6,
    eff: { land: 1.2, sea: 0.6, air: 0 },
    setup: true,
    indirect: true,
    source: 'Modeled on the M7 Priest 105 mm self-propelled howitzer (WWII, United States).',
    norm: [
      ['Speed', '≈ 39 km/h', '0–70 km/h (tracked vehicles)', 6],
      ['Maneuverability', 'Heavy, slow to turn', 'Relative to WWII armor', 3],
      ['Armor', 'Light, open-topped', 'Relative to WWII tanks', 2],
      ['Firepower', '105 mm howitzer, about 11 km range', 'Relative to WWII ground weapons', 9],
    ],
  },
  sub: {
    id: 'sub',
    short: 'Gato',
    name: 'Gato-class',
    role: 'Submarine',
    domain: 'sea',
    rule: 'subs',
    stats: { speed: 5, maneuver: 5, armor: 2, firepower: 7 },
    range: [1, 1],
    ammo: 6,
    fuel: 50,
    eff: { land: 0, sea: 1.6, air: 0 },
    stealth: true,
    source: 'Modeled on the Gato-class submarine (WWII, United States).',
    norm: [
      ['Speed', '≈ 21 knots surfaced, 9 submerged', '0–40 knots (warships)', 5],
      ['Maneuverability', 'Dives to evade', 'Relative to WWII warships', 5],
      ['Armor', 'Pressure hull only', 'Relative to battleship belt armor', 2],
      ['Firepower', '10 torpedo tubes', 'Relative to WWII surface combatants', 7],
    ],
  },
  carrier: {
    id: 'carrier',
    short: 'Essex',
    name: 'Essex-class',
    role: 'Aircraft carrier',
    domain: 'sea',
    rule: 'carriers',
    stats: { speed: 8, maneuver: 3, armor: 4, firepower: 2 },
    range: [1, 2],
    ammo: 4,
    fuel: 60,
    eff: { land: 0, sea: 0.3, air: 0.8 },
    deck: true,
    source: 'Modeled on the Essex-class aircraft carrier (WWII, United States).',
    norm: [
      ['Speed', '≈ 33 knots', '0–40 knots (warships)', 8],
      ['Maneuverability', 'A large hull', 'Relative to WWII warships', 3],
      ['Armor', 'Belt and deck armor', 'Relative to battleship belt armor', 4],
      ['Firepower', 'Anti-aircraft guns only (its aircraft do the fighting)', 'Relative to WWII surface combatants', 2],
    ],
  },
};

// Game values derived from the 0–10 stats (the future Unit Editor will reuse this)
function derive(T) {
  const s = T.stats;
  const mul = { land: 0.6, air: 0.75, sea: 0.6 }[T.domain];
  T.move = Math.max(T.minMove || 2, Math.round(s.speed * mul)); // minMove: gameplay floor so slow transports stay useful
  T.hp = { land: 70, air: 55, sea: 90 }[T.domain] + s.armor * 6;
  T.evade = s.maneuver * 2; // percent
}

Object.values(UNIT_TYPES).forEach(derive);

// Starting units for every army in Quick battle.
// Display order for units (library, roster picker, starting roster)
const TYPE_ORDER = [
  'tank',
  'aa',
  'apc',
  'inf',
  'at',
  'eng',
  'plane',
  'bomber',
  'drone',
  'ship',
  'battleship',
  'lst',
  'arty',
  'sub',
  'carrier',
];
// The original twelve (rule-gated units excluded): what every army can always field.
const BASE_TYPES = TYPE_ORDER.slice(0, 12);
// Rule-gated units (artillery, submarines, carriers) are only available with their rule on.
const typeAllowed = (t, rules) => !UNIT_TYPES[t] || !UNIT_TYPES[t].rule || !!(rules && rules[UNIT_TYPES[t].rule]);

const DEFAULT_ROSTER = { tank: 2, inf: 2, eng: 1, plane: 1, ship: 1, lst: 1 };

const ROSTER_MAX_EACH = 4,
  ROSTER_MAX_TOTAL = 16;

// Expands a {type: count} roster into [[type, name], ...]: "Sherman A", "Sherman B", or just "Mustang" when there's one.
function rosterList(r) {
  const out = [];
  for (const t of TYPE_ORDER) {
    // rule-gated units only when their rule is on (the battle being set up reads appState.settings)
    const n = r && typeAllowed(t, appState.settings && appState.settings.rules) ? r[t] || 0 : 0;
    for (let i = 0; i < n; i++) out.push([t, UNIT_TYPES[t].short + (n > 1 ? ' ' + 'ABCD'.charAt(i) : '')]);
  }
  return out;
}

const rosterTotal = r => TYPE_ORDER.reduce((s, t) => s + ((r && r[t]) || 0), 0);

const currentRoster = () => appState.settings.roster || DEFAULT_ROSTER;

// Logistics tuning
const MAX_FLAGS = 3,
  CAPTURE_TURNS = 2,
  RESUPPLY_AMMO = 2,
  AIR_UPKEEP = 2,
  REPAIR_PCT = 0.1;

const ROAD_FLOOR = 0.5;
const SPREAD_RADIUS = 3; // territory spread only claims hexes within this distance of one of the army's supply points
const STALL_TURNS = 4; // turns with no damage before every AI is ordered forward
const EXHAUST_TURNS = 6,
  ATTRITION_FROM = 0.6,
  ATTRITION_DMG = 0.05; // endgame rules
const MAX_TURNS = 60; // turn limit on a standard 26 × 18 map; see turnLimit()
// Bigger maps get longer battles: travel distances grow with the square root of the map's area.
const turnLimit = (def = appState.battle.mapDef) => Math.round(MAX_TURNS * Math.max(1, Math.sqrt((def.W * def.H) / (26 * 18))));

// Movement cost for a unit type on a terrain code (null = impassable). Types can override their domain's table.
// Terrain cost for a unit type: its own moveCost table (soldiers on foot) or its domain's.
const costOf = (T, t) => {
  const v = (T.moveCost || MOVE_COST[T.domain])[t];
  return v == null ? null : v;
};

// Cost to enter a specific hex: terrain cost, minus 1 on a road for ground units.
const costAt = (T, c, r, pid, B = appState.battle) => {
  const v = costOf(T, tileAt(c, r, B).t);
  if (v == null) return T.domain === 'land' && bridgeAt(c, r, B) ? 1 : frozenCost(T, tileAt(c, r, B).t); // bridges (and winter ice) carry ground units over shallows
  const roads = B && B.roads;
  const onRoad = !!(roads && roads[key(c, r)]);
  const u = v + urbanCost(T, tileAt(c, r, B).t, B) + seasonCost(T, tileAt(c, r, B).t, onRoad, B); // urban combat; mud and snow off-road
  if (T.domain === 'land' && roads && roads[key(c, r)] && railFor(pid, c, r, B)) return RAIL_COST; // railways: roads through your own territory
  return T.domain === 'land' && roads && roads[key(c, r)] ? Math.max(ROAD_FLOOR, u - 1) : u;
};

const DOMAIN_LABEL = { land: 'Ground', sea: 'Naval', air: 'Air' };

const ARMY_RGB = () => ARMIES.map(a => hexToRgb(a.color));

const ARMIES = [
  { name: 'Falcon Corps', color: '#3f7fd6', dark: '#23488a', light: '#a8d4ff' },
  { name: 'Crimson Rebels', color: '#d0402a', dark: '#7a2014', light: '#ffb09a' },
  { name: 'Viper Brigade', color: '#7a9a2a', dark: '#44581a', light: '#d6ee98' },
  { name: 'Scorpion Legion', color: '#e0a52a', dark: '#8a5e0e', light: '#ffe39a' },
];

const STRATS = {
  aggressive: {
    label: 'Aggressive',
    desc: 'Charges the nearest enemy and trades hits freely.',
    atk: 1.3,
    risk: 0.25,
    approach: 2.2,
    cover: 0.3,
    focus: 0.6,
    hold: -8,
  },
  balanced: {
    label: 'Balanced',
    desc: 'Advances under cover and looks for good trades.',
    atk: 1.0,
    risk: 0.6,
    approach: 1.1,
    cover: 0.8,
    focus: 1,
    hold: 0,
  },
  defensive: {
    label: 'Defensive',
    desc: 'Holds strong ground and punishes anyone who closes in.',
    atk: 0.9,
    risk: 1.1,
    approach: 0.25,
    cover: 1.5,
    focus: 0.5,
    hold: 6,
  },
};
