// Territory, supply points, flags, captures, repairs, roads, resupply and fuel.
// ---------- Territory & logistics ----------
// Something infantry can capture at h: a city, or a finished airfield, port or depot.
function captureSite(h, B = appState.battle) {
  const k = key(h.c, h.r);
  if (B.cities && B.cities[k]) return B.cities[k];
  const s = B.structs && B.structs[k];
  return s && !s.build && STRUCTS[s.kind].capture ? s : null;
}
const capturable = (h, pid, B = appState.battle) => {
  const c = captureSite(h, B);
  return !!c && (c.owner == null || isEnemy(c.owner, pid, B));
};

const canRoadAt = (h, B = appState.battle) => {
  return MOVE_COST.land[tileAt(h.c, h.r, B).t] != null && !(B.roads && B.roads[key(h.c, h.r)]);
};

const repairTargets = (u, at, B = appState.battle) =>
  aliveUnits(B).filter(o => (o.pid === u.pid || isAlly(o.pid, u.pid, B)) && o !== u && hexDist(o, at) === 1 && o.hp < o.maxHp); // engineers fix allies too

const flagAt = (c, r, B = appState.battle) => (B.flags || []).find(f => f.c === c && f.r === r);

const canFlagAt = (h, B = appState.battle) => {
  const t = tileAt(h.c, h.r, B).t;
  return MOVE_COST.land[t] != null && t !== 'c' && !flagAt(h.c, h.r, B) && !structAt(h.c, h.r, B);
};

function supplyPoints(B) {
  const pts = [];
  for (const [k, c] of Object.entries(B.cities))
    if (c.owner != null) {
      const [cc, rr] = unkey(k);
      pts.push({ c: cc, r: rr, pid: c.owner });
    }
  for (const f of B.flags) pts.push({ c: f.c, r: f.r, pid: f.pid });
  for (const [k, s] of Object.entries(B.structs || {}))
    if (!s.build && s.owner != null && STRUCTS[s.kind].supply) {
      const [cc, rr] = unkey(k);
      pts.push({ c: cc, r: rr, pid: s.owner });
    }
  return pts;
}

// Rings around supply points override other claims every turn; overlaps stay neutral. The supply hex itself always belongs to its owner.
// Who gets a hex that several armies claim at once (painting or supply rings). A claimant drops out where
// the current owner, or another claimant, shares territory with it; allies sharing both ways settle on the
// lower army number; anything still contested turns neutral (undefined). Free-for-all: same as before.
function settleClaim(set, current, B = appState.battle) {
  let c = [...set];
  if (current != null) c = c.filter(p => p === current || !grants(current, p, 'territory', B));
  if (c.length > 1) c = c.filter(p => !c.some(o => o !== p && grants(o, p, 'territory', B) && !grants(p, o, 'territory', B)));
  if (c.length > 1 && c.every(p => !isEnemy(p, c[0], B))) c = [Math.min(...c)];
  return c.length === 1 ? c[0] : c.length === 0 ? current : undefined;
}
function applySupplyRings(B, pts, radius) {
  const T = B.territory,
    def = B.mapDef,
    claims = new Map();
  if (radius)
    for (const sp of pts)
      for (const n of neighborsRaw(sp.c, sp.r, def.W, def.H)) {
        const k = key(n.c, n.r);
        if (!claims.has(k)) claims.set(k, new Set());
        claims.get(k).add(sp.pid);
      }
  for (const [k, set] of claims) {
    const w = settleClaim(set, null, B);
    if (w == null) delete T[k];
    else T[k] = w;
  }
  for (const sp of pts) T[key(sp.c, sp.r)] = sp.pid;
}

// Order: painting (where units went) -> spread (into neutral only) -> supply rings.
function updateTerritory(B, st) {
  const T = B.territory,
    def = B.mapDef;
  if (B.rules.terrPaint && st) {
    const claims = new Map();
    for (const u of aliveUnits(B)) {
      if (isAir(u)) continue;
      const s = st.get(u.id);
      if (!s) continue;
      for (const h of s.hist) {
        const k = key(h.c, h.r);
        if (!claims.has(k)) claims.set(k, new Set());
        claims.get(k).add(u.pid);
      }
    }
    for (const [k, set] of claims) {
      const w = settleClaim(set, T[k], B);
      if (w === undefined) delete T[k];
      else if (w != null) T[k] = w;
    }
  }
  const pts = supplyPoints(B);
  if (B.rules.terrSpread && B.turn % 2 === 0) {
    // spreads on even turns only
    const claims = new Map();
    for (const p of B.players) {
      const src = pts.filter(sp => sp.pid === p.id);
      if (!src.length) continue;
      const seen = new Set(src.map(sp => key(sp.c, sp.r))),
        q = src.map(sp => ({ c: sp.c, r: sp.r }));
      while (q.length) {
        const cur = q.shift();
        for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
          const k = key(n.c, n.r);
          if (seen.has(k)) continue;
          seen.add(k);
          if (T[k] === p.id) q.push(n);
          else if (T[k] == null && src.some(sp => hexDist(sp, n) <= SPREAD_RADIUS)) {
            if (!claims.has(k)) claims.set(k, new Set());
            claims.get(k).add(p.id);
          }
        }
      }
    }
    for (const [k, set] of claims) if (set.size === 1) T[k] = [...set][0];
  }
  applySupplyRings(B, pts, B.rules.terrRadius);
}

// Fills in logistics state for new battles and for saves made before territory existed.
function ensureLogistics(B) {
  if (!B.cities) {
    B.cities = {};
    for (const t of B.map.list) if (t.t === 'c') B.cities[key(t.c, t.r)] = { owner: null, capPid: null, prog: 0 };
    for (const p of B.players) {
      const sp = B.mapDef.spawns[p.id],
        c = B.cities[key(sp.c, sp.r)];
      if (c) c.owner = p.id;
    }
  }
  if (!B.flags) B.flags = [];
  if (!B.roads) B.roads = {};
  if (!B.structs) B.structs = {};
  if (!B.stats) B.stats = { built: 0, captured: 0, destroyed: 0, landings: 0, portCalls: 0 };
  if (!B.territory) {
    B.territory = {};
    applySupplyRings(B, supplyPoints(B), B.rules.terrRadius);
  }
  for (const u of B.units) {
    const T = UNIT_TYPES[u.type];
    if (u.fuel === undefined) {
      u.fuel = T.fuel ?? null;
      u.maxFuel = T.fuel ?? null;
    }
  }
}

// End of turn, in order: flags, captures, engineers, territory, supply and fuel, decoys, attrition, economy,
// morale and intel. Each step returns whether it showed something worth a pause.
const LOGISTICS_STEPS = [
  logTearDownFlags,
  logPlantFlags,
  logCaptures,
  logEngineerWork,
  logWreckScaffolds,
  logBuild,
  logMines,
  logDemolish,
  logTerritory,
  logSupplyLines,
  logSupply,
  logDecoys,
  logBroadcasts,
  logAttrition,
  logRealism,
  logReinforcements,
  logMissiles,
  logCityDev,
  logEconomyMoraleIntel,
];
async function logistics(st, B = appState.battle) {
  let ev = false;
  for (const step of LOGISTICS_STEPS) ev = step(B, st) || ev;
  VIEW.cards();
  VIEW.hud();
  if (ev) await sleep(1000);
}
// Enemy ground units standing on a flag tear it down
function logTearDownFlags(B, st) {
  let ev = false;
  B.flags = B.flags.filter(f => {
    const e = aliveUnits(B).find(u => isEnemy(u.pid, f.pid, B) && !isAir(u) && u.c === f.c && u.r === f.r);
    if (e) {
      floatText(e, 'Flag torn down', '#ff9a6a');
      ev = true;
      return false;
    }
    return true;
  });
  return ev;
}
// Plant flags where units ended up (oldest flag is retired past the limit)
function logPlantFlags(B, st) {
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (!s || !(s.o.type === 'flag' || s.o.flag)) continue;
    if (!canFlagAt(u, B)) {
      floatText(u, 'No flag here', '#cfe3ff');
      ev = true;
      continue;
    }
    B.flags.push({ c: u.c, r: u.r, pid: u.pid, turn: B.turn });
    const mine = B.flags.filter(f => f.pid === u.pid);
    if (mine.length > MAX_FLAGS) B.flags.splice(B.flags.indexOf(mine[0]), 1);
    floatText(u, 'Flag planted', '#9fe86a');
    ev = true;
  }
  return ev;
}
// Captures: infantry ordered to capture, standing on the city at turn end. Two turns in a row captures it.
function logCaptures(B, st) {
  let ev = false;
  const sites = Object.entries(B.cities).concat(Object.entries(B.structs).filter(([, s]) => !s.build && STRUCTS[s.kind].capture));
  for (const [k, city] of sites) {
    const [c, r] = unkey(k),
      label = city.kind ? STRUCTS[city.kind].name : 'City';
    const inf = aliveUnits(B).find(
      u =>
        u.c === c &&
        u.r === r &&
        UNIT_TYPES[u.type].captures &&
        (city.owner == null || isEnemy(u.pid, city.owner, B)) &&
        st.get(u.id) &&
        (st.get(u.id).o.type === 'capture' || st.get(u.id).o.capture)
    );
    if (!inf) {
      city.capPid = null;
      city.prog = 0;
      continue;
    }
    if (city.capPid === inf.pid) city.prog++;
    else {
      city.capPid = inf.pid;
      city.prog = 1;
    }
    if (city.prog >= CAPTURE_TURNS) {
      cityCaptured(B, city); // city development: a captured city drops a level
      city.owner = inf.pid;
      city.capPid = null;
      city.prog = 0;
      floatText(inf, label + ' captured!', '#ffe04a');
      sfx('fanfare');
      if (city.kind) B.stats.captured++;
      if (inf.pid === 0) tallyAdd(B, 'special', inf.type);
    } else floatText(inf, `Capturing ${city.prog}/${CAPTURE_TURNS}`, '#ffe04a');
    ev = true;
  }
  return ev;
}
// Engineers: repair an adjacent friend (+10% of max HP) and build roads where they ended up
function logEngineerWork(B, st) {
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (!s) continue;
    const o = s.o;
    const mid = o.type === 'repair' ? o.mend : o.repair;
    if (mid) {
      const t = unitById(mid, B);
      if (!t || t.hp <= 0 || t.in || hexDist(t, u) !== 1) {
        floatText(u, 'Repair failed', '#cfe3ff');
        ev = true;
      } else {
        const amt = Math.min(t.maxHp - t.hp, Math.ceil(t.maxHp * REPAIR_PCT));
        if (amt > 0) {
          t.hp += amt;
          t.dispHp = t.hp;
          floatText(t, '+' + amt + ' HP', '#7cf06a');
          ev = true;
          if (u.pid === 0) tallyAdd(B, 'special', u.type);
        }
      }
    }
    if (o.type === 'road' || o.road) {
      if (canRoadAt(u, B)) {
        B.roads[key(u.c, u.r)] = true;
        floatText(u, 'Road built', '#e8c47a');
      } else floatText(u, 'No road here', '#cfe3ff');
      ev = true;
    }
  }
  return ev;
}
// An enemy ground unit standing on an unfinished structure wrecks the scaffold
function logWreckScaffolds(B, st) {
  let ev = false;
  for (const [k, s] of Object.entries(B.structs)) {
    if (!s.build) continue;
    const [c, r] = unkey(k);
    const e = aliveUnits(B).find(u => !isAir(u) && u.c === c && u.r === r && isEnemy(u.pid, s.build.pid, B));
    if (e) {
      delete B.structs[k];
      floatText(e, 'Scaffold wrecked', '#ff9a6a');
      ev = true;
    }
  }
  return ev;
}
// Engineers build: one step of progress per engineer per turn; bigger structures need more turns
function logBuild(B, st) {
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (!s) continue;
    const o = s.o;
    const b = o.type === 'build' ? o : o.build;
    if (!b) continue;
    const at = b.kind === 'bridge' ? b.at : { c: u.c, r: u.r }; // land structures go where the engineer ends up
    if ((b.kind === 'bridge' && hexDist(u, at) !== 1) || !canBuildAt(b.kind, at, u.pid, B)) {
      floatText(u, "Can't build here", '#cfe3ff');
      ev = true;
      continue;
    }
    const k = key(at.c, at.r);
    if (b.kind === 'silo' && !B.structs[k] && (B.rules.income || B.rules.production)) {
      if ((B.funds[u.pid] || 0) < REAL.SILO_COST) {
        floatText(u, `Needs ${REAL.SILO_COST} funds`, '#cfe3ff');
        ev = true;
        continue;
      }
      B.funds[u.pid] -= REAL.SILO_COST; // a silo costs funds when the economy is on
    }
    const site = B.structs[k] || (B.structs[k] = newStruct(b.kind, u.pid, { pid: u.pid, prog: 0, need: STRUCTS[b.kind].turns }));
    site.build.prog++;
    if (site.build.prog >= site.build.need) {
      site.build = null;
      B.stats.built++;
      if (b.kind === 'silo') {
        B.stats.silosBuilt = (B.stats.silosBuilt || 0) + 1;
        if (B.stats.firstSilo == null) B.stats.firstSilo = u.pid;
      }
      floatText(u, STRUCTS[b.kind].name + ' built!', '#9fe86a');
      sfx('order');
      if (u.pid === 0) tallyAdd(B, 'special', u.type);
    } else floatText(u, `Building ${site.build.prog}/${site.build.need}`, '#e8c47a');
    ev = true;
  }
  return ev;
}
// Territory
function logTerritory(B, st) {
  let ev = false;
  updateTerritory(B, st);
  return ev;
}
// Fuel burn, resupply in friendly territory, crashes
function logSupply(B, st) {
  let ev = false;
  const pts = supplyPoints(B);
  for (const u of allAlive(B)) {
    const T = UNIT_TYPES[u.type],
      host = u.in ? unitById(u.in, B) : u;
    // Airfield: a plane ending its turn on its own airfield lands (no fuel burned, full rearm, light repairs).
    const field =
      T.domain === 'air' &&
      !u.in &&
      (() => {
        const f = builtAt(u.c, u.r, B);
        return (f && f.kind === 'airfield' && friendlyGround(f.owner, u.pid, B)) || carrierUnder(u, B); // carriers are airfields at sea
      })();
    const sup = suppliersOf(u.pid, B);
    const port = T.domain === 'sea' && !u.in && sup.some(o => armyStructs(o, 'port', B).some(p => hexDist(p, u) <= 1));
    const depot = host && sup.some(o => armyStructs(o, 'depot', B).some(p => hexDist(p, host) <= DEPOT_RANGE));
    if (T.domain === 'air' && u.fuel != null && !field && !grounded(u, B)) u.fuel = Math.max(0, u.fuel - (T.upkeep ?? AIR_UPKEEP));
    if (field || port) {
      const amt = Math.min(u.maxHp - u.hp, Math.ceil(u.maxHp * (field ? AIRFIELD_REPAIR : PORT_REPAIR)));
      u.ammo = u.maxAmmo;
      if (u.fuel != null) u.fuel = u.maxFuel;
      u.hp += amt;
      if (field) B.stats.landings++;
      else B.stats.portCalls++;
      floatText(u, field ? 'Landed' + (amt ? ' +' + amt + ' HP' : '') : 'Port' + (amt ? ' +' + amt + ' HP' : ''), '#9fe86a');
      ev = true;
      continue;
    }
    if (depot && u.ammo < u.maxAmmo) {
      u.ammo = u.maxAmmo;
      if (!u.in) {
        floatText(u, 'Rearmed', '#9fe86a');
        ev = true;
      }
    }
    // Harbor rule: ships also resupply next to one of their army's flags or cities (ports will replace this).
    const harbor = T.domain === 'sea' && !u.in && pts.some(sp => friendlyGround(sp.pid, u.pid, B) && hexDist(sp, host) <= 1);
    if (host && !cutOff(u, B) && (friendlyGround(B.territory[key(host.c, host.r)], u.pid, B) || harbor)) {
      // cut-off units can't resupply
      let got = false;
      if (u.ammo < u.maxAmmo) {
        u.ammo = Math.min(u.maxAmmo, u.ammo + RESUPPLY_AMMO);
        got = true;
      }
      if (u.fuel != null && u.fuel < u.maxFuel) {
        u.fuel = u.maxFuel;
        got = true;
      }
      if (got && !u.in) {
        floatText(u, 'Resupplied', '#9fe86a');
        ev = true;
      }
    }
    if (T.domain === 'air' && u.fuel != null && u.fuel <= 0) {
      u.hp = 0;
      u.dispHp = 0;
      u.gone = true;
      u.goneTurn = B.turn;
      boom(u.px, u.py, u.pz + 0.4, 3);
      floatText(u, 'Out of fuel', '#ff6a4a');
      sfx('bigboom');
      ev = true;
    }
  }
  return ev;
}
// Decoys planted this turn (soldiers on foot with a Decoy order)
function logDecoys(B, st) {
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (s && s.o.type === 'decoy' && plantDecoy(B, u)) ev = true;
  }
  return ev;
}
// Attrition (optional rule): late in a battle, units that end a turn out of supply lose health.
function logAttrition(B, st) {
  let ev = false;
  if (B.rules.attrition && B.turn >= Math.ceil((B.turnLimit || turnLimit(B.mapDef)) * ATTRITION_FROM)) {
    for (const u of aliveUnits(B)) {
      if (u.in || (B.rules.supplyLines ? !cutOff(u, B) : friendlyGround(B.territory[key(u.c, u.r)], u.pid, B))) continue; // with supply lines, attrition hits cut-off units
      const loss = Math.max(1, Math.ceil(u.maxHp * ATTRITION_DMG));
      u.hp = Math.max(0, u.hp - loss);
      floatText(u, u.hp ? `Attrition -${loss}` : 'Lost to attrition', '#ff9a6a');
      ev = true;
      if (!u.hp && u.cargo) {
        const c = unitById(u.cargo, B);
        if (c) c.hp = 0;
      }
    }
  }
  return ev;
}
// Production and income (economy rules), morale, and what each side now sees
function logEconomyMoraleIntel(B, st) {
  let ev = false;
  if (B.rules.income || B.rules.production) {
    const n = B.units.length;
    runProduction(B);
    if (B.units.length > n) {
      ev = true;
      sfx('order');
    }
  }
  if (B.rules.morale) updateMorale(B);
  if (B.rules.fog) updateIntel(B);
  return ev;
}
