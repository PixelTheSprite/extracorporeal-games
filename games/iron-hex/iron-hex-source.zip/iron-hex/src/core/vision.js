// Fog of war (rule 'fog') and intel: fading sightings ('intelFade'), decoys ('decoys'), AI deception ('aiDeception').
// Each team sees what its armies' units see (sight by unit type; forests and hills block ground observers unless
// they stand on hills or mountains; mountains block everyone on the ground; aircraft see over everything) plus
// one hex around its supply points. What a team has seen is kept in B.intel[team] as sightings of enemy units.
const SIGHT = { land: 3, sea: 4, air: 5 },
  SIGHT_BY_TYPE = { drone: 6, bomber: 4, lst: 3 };
const DECOY_TURNS = 6,
  DECOY_MAX = 3,
  DECOY_EXPOSE = 2;
const fogOn = (B = appState.battle) => {
  return !!(B && B.rules && B.rules.fog);
};
function sightOf(u, B = appState.battle) {
  const T = UNIT_TYPES[u.type],
    c = cond(B);
  let s = (T.sight ?? SIGHT_BY_TYPE[u.type] ?? SIGHT[T.domain]) + elevationSight(u, B) + jamSight(u, B);
  if (c.night) s -= 1;
  if (c.w === 'fog') s -= isAir(u) ? 2 : 1;
  return Math.max(1, s);
}
function hexAtWorld(x, y, W, H) {
  const r0 = Math.round(y / 1.5);
  let best = null,
    bd = Infinity;
  for (let r = r0 - 1; r <= r0 + 1; r++) {
    if (r < 0 || r >= H) continue;
    const c0 = Math.round(x / SQ3 - 0.5 * (r & 1));
    for (let c = c0 - 1; c <= c0 + 1; c++) {
      if (c < 0 || c >= W) continue;
      const w = toWorld(c, r),
        d = (w.x - x) ** 2 + (w.y - y) ** 2;
      if (d < bd) {
        bd = d;
        best = { c, r };
      }
    }
  }
  return best;
}
function losClear(from, to, air, B = appState.battle) {
  if (air) return true;
  const def = B.mapDef,
    a = toWorld(from.c, from.r),
    b = toWorld(to.c, to.r),
    n = hexDist(from, to) * 3;
  const own = def.rows[from.r][from.c],
    high = own === 'h' || own === 'm';
  for (let i = 1; i < n; i++) {
    const p = hexAtWorld(a.x + ((b.x - a.x) * i) / n, a.y + ((b.y - a.y) * i) / n, def.W, def.H);
    if (!p || (p.c === from.c && p.r === from.r) || (p.c === to.c && p.r === to.r)) continue;
    const t = def.rows[p.r][p.c];
    if (t === 'm' && own !== 'm') return false;
    if ((t === 'f' || t === 'h') && !high) return false;
  }
  return true;
}
// B.vis[team] = Set of visible hex keys (not saved; rebuilt whenever needed).
function computeVision(B = appState.battle) {
  // Cached: rebuilt only when a unit moves, boards, dies or changes hands, supply points change, or day/weather turns.
  const c0 = cond(B),
    vkey =
      B.turn +
      c0.w +
      c0.night +
      '|' +
      B.units.map(u => (u.hp > 0 && !u.in ? u.id + ':' + u.c + ',' + u.r : '')).join(';') +
      '|' +
      supplyPoints(B)
        .map(p => p.pid + ':' + p.c + ',' + p.r)
        .join(';');
  if (B.vis && B.visKey === vkey) return B.vis;
  const vis = {},
    def = B.mapDef;
  for (const p of B.players) vis[teamOf(p.id, B)] = vis[teamOf(p.id, B)] || new Set();
  for (const u of aliveUnits(B)) {
    if (u.in) continue;
    const set = vis[teamOf(u.pid, B)];
    if (!set) continue;
    const s = sightOf(u, B),
      air = isAir(u);
    for (let r = Math.max(0, u.r - s); r <= Math.min(def.H - 1, u.r + s); r++)
      for (let c = Math.max(0, u.c - s - 1); c <= Math.min(def.W - 1, u.c + s + 1); c++) {
        const h = { c, r },
          k = key(c, r);
        if (set.has(k) || hexDist(u, h) > s) continue;
        if (losClear(u, h, air, B)) set.add(k);
      }
  }
  for (const sp of supplyPoints(B)) {
    const set = vis[teamOf(sp.pid, B)];
    if (!set) continue;
    set.add(key(sp.c, sp.r));
    for (const n of neighborsRaw(sp.c, sp.r, def.W, def.H)) set.add(key(n.c, n.r));
  }
  B.vis = vis;
  B.visTurn = B.turn;
  B.visKey = vkey;
  return vis;
}
// Can army `pid` see this unit right now? Your own and allied units are always visible to you.
function canSee(pid, u, B = appState.battle) {
  if (!isEnemy(pid, u.pid, B)) return true;
  if (isSub(u, B) && !subDetected(pid, u, B)) return false; // submarines hide, fog or not
  if (!fogOn(B) || revealed(u, B)) return true; // a battery that just fired gives itself away

  if (!B.vis) computeVision(B);
  const set = B.vis[teamOf(pid, B)];
  return !!set && set.has(key(u.c, u.r));
}
// End of turn (and battle start): record what each team sees, fade or forget the rest, expose nearby decoys.
function updateIntel(B = appState.battle) {
  if (!fogOn(B)) return;
  const vis = computeVision(B),
    fade = !!B.rules.intelFade,
    c = cond(B);
  B.intel = B.intel || {};
  const exposed = new Set();
  for (const tm of Object.keys(vis)) {
    const I = (B.intel[tm] = B.intel[tm] || {}),
      set = vis[tm];
    const obs = aliveUnits(B).filter(u => String(teamOf(u.pid, B)) === tm && !u.in);
    const dist = h => obs.reduce((m, o) => Math.min(m, hexDist(o, h)), 99);
    for (const e of aliveUnits(B)) {
      if (e.in || String(teamOf(e.pid, B)) === tm || !set.has(key(e.c, e.r))) continue;
      let conf = 1;
      if (fade) {
        const d = dist(e);
        conf = d <= 2 ? 1 : d <= 4 ? 0.8 : 0.6;
        if (c.night || c.w === 'fog') conf -= 0.1;
      }
      I[e.id] = { c: e.c, r: e.r, type: conf >= 0.7 ? e.type : null, pid: e.pid, turn: B.turn, conf: Math.round(conf * 100) / 100 };
    }
    for (const dc of B.decoys || []) {
      if (String(teamOf(dc.pid, B)) === tm || !set.has(key(dc.c, dc.r))) continue;
      if (dist(dc) <= DECOY_EXPOSE) {
        exposed.add(dc.id);
        delete I['d' + dc.id];
        continue;
      }
      I['d' + dc.id] = { c: dc.c, r: dc.r, type: dc.mimic, pid: dc.pid, turn: B.turn, conf: fade ? 0.8 : 1, decoy: true };
    }
    for (const [id, s] of Object.entries(I)) {
      if (s.turn === B.turn) continue;
      const isDecoy = id[0] === 'd',
        real = !isDecoy && unitById(+id, B);
      if ((!isDecoy && (!real || real.hp <= 0)) || set.has(key(s.c, s.r))) {
        delete I[id];
        continue;
      } // gone, or we looked and it isn't there
      if (fade) {
        s.conf = Math.round((s.conf - 0.2) * 100) / 100;
        if (s.conf < 0.15) delete I[id];
        else if (s.conf < 0.7) s.type = null;
      } else if (B.turn - s.turn >= 2) delete I[id];
    }
  }
  B.decoys = (B.decoys || []).filter(d => {
    if (exposed.has(d.id)) {
      floatText(
        { px: tileAt(d.c, d.r, B).wx, py: tileAt(d.c, d.r, B).wy, pz: tileAt(d.c, d.r, B).z, type: 'inf' },
        'Decoy exposed',
        '#cfe3ff'
      );
      B.stats.decoysExposed = (B.stats.decoysExposed || 0) + 1;
      return false;
    }
    if (B.turn - d.turn0 >= DECOY_TURNS) {
      for (const I of Object.values(B.intel)) delete I['d' + d.id];
      return false;
    }
    return true;
  });
}
// Sightings this army can act on (positions it believes enemies are at, decoys included), minus what it sees now.
const sightingsFor = (pid, B = appState.battle) => {
  const I = (B.intel || {})[teamOf(pid, B)] || {};
  return Object.entries(I)
    .filter(
      ([id]) =>
        !(
          id[0] !== 'd' &&
          (() => {
            const u = unitById(+id, B);
            return u && canSee(pid, u, B);
          })()
        )
    )
    .map(([id, s]) => Object.assign({ id }, s));
};
// Planting a decoy: soldiers on foot leave a fake tank on their hex (at most DECOY_MAX per army at a time).
const canPlantDecoy = (u, B = appState.battle) => {
  return !!(B.rules.fog && B.rules.decoys) && !!UNIT_TYPES[u.type].foot && (B.decoys || []).filter(d => d.pid === u.pid).length < DECOY_MAX;
};
function plantDecoy(B, u) {
  if (!canPlantDecoy(u, B)) return false;
  B.decoys = B.decoys || [];
  B.nextDecoy = B.nextDecoy || 1;
  B.decoys.push({ id: B.nextDecoy++, pid: u.pid, c: u.c, r: u.r, mimic: 'tank', turn0: B.turn });
  B.stats.decoys = (B.stats.decoys || 0) + 1;
  floatText(u, 'Decoy planted', '#cfe3ff');
  return true;
}
