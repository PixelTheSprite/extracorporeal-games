// Realism rules, batch 1 (Phase 11): supply lines, entrenchment, suppression, armor facing, urban combat,
// elevation and surrender. Each is its own Battle settings toggle, off by default. Starting values are below,
// in one place, to be tuned with the A/B harness.
const REAL = {
  DIG_MAX: 3,
  DIG_PER: 0.1, // entrenchment: up to 3 levels, 10% less damage taken per level
  SUPPRESS_SHARE: 0.25,
  SUPPRESS_DMG: 0.5, // losing 25% of max HP in a turn suppresses for the next turn: no moving, half damage
  FACE_SIDE: 1.25,
  FACE_REAR: 1.5, // armored vehicles hit from the side or rear
  URBAN_FOOT_DEF: 0.45,
  URBAN_VEH_DEF: 0.1,
  URBAN_VEH_COST: 1, // cities: soldiers on foot well covered, vehicles exposed and slowed
  ELEV_DOWN: 1.15,
  ELEV_UP: 0.9, // firing downhill / uphill
  SURRENDER_CUT: 2,
  SURRENDER_HP: 0.25, // cut off for 2 turns (or surrounded), and broken or below 25% HP
};
const realOn = (k, B = appState.battle) => {
  return !!(B && B.rules && B.rules[k]);
};
const isVehicle = T => T.domain === 'land' && !T.foot;
const elevAt = (h, B = appState.battle) => TERRAIN[tileAt(h.c, h.r, B).t].elev;

// ---- combat ----
// Terrain cover a target gets (urban combat changes cities).
function terrainDef(T, t, B = appState.battle) {
  if (t === 'c' && realOn('urban', B) && T.domain === 'land') return T.foot ? REAL.URBAN_FOOT_DEF : REAL.URBAN_VEH_DEF;
  return TERRAIN[t].def;
}
// One multiplier for the realism rules, applied to every hit.
function realismDamage(att, tgt, pos, B = appState.battle) {
  const A = UNIT_TYPES[att.type],
    T = UNIT_TYPES[tgt.type];
  let m = 1;
  if (realOn('entrench', B) && T.domain === 'land' && tgt.dug) m *= 1 - REAL.DIG_PER * tgt.dug;
  if (realOn('suppression', B) && att.supp) m *= REAL.SUPPRESS_DMG;
  if (realOn('facing', B) && isVehicle(T) && tgt.face) {
    const a = toWorld(att.c, att.r),
      t = toWorld(pos.c, pos.r),
      dx = a.x - t.x,
      dy = a.y - t.y,
      len = Math.hypot(dx, dy) || 1;
    const dot = (dx * tgt.face[0] + dy * tgt.face[1]) / len; // 1 = attacker straight ahead, -1 = straight behind
    m *= dot >= 0.5 ? 1 : dot <= -0.5 ? REAL.FACE_REAR : REAL.FACE_SIDE;
  }
  if (realOn('elevation', B) && A.domain === 'land' && T.domain === 'land') {
    const d = elevAt(att, B) - elevAt(pos, B);
    m *= d > 0 ? REAL.ELEV_DOWN : d < 0 ? REAL.ELEV_UP : 1;
  }
  return m * commandAirDamage(att, tgt, pos, B) * ammoDamage(att, tgt, B);
}
// Elevation: long-range ground weapons reach one hex further firing down from higher ground.
function elevationRange(type, from, to, B = appState.battle) {
  if (!realOn('elevation', B)) return 0;
  const T = UNIT_TYPES[type];
  return T.domain === 'land' && T.range[1] >= 2 && elevAt(from, B) > elevAt(to, B) ? 1 : 0;
}
// Elevation: ground observers on hills or mountains see one hex further.
const elevationSight = (u, B = appState.battle) => (realOn('elevation', B) && !isAir(u) && elevAt(u, B) >= 2 ? 1 : 0);
// Urban combat: vehicles pay extra to enter a city.
const urbanCost = (T, t, B = appState.battle) => (t === 'c' && realOn('urban', B) && isVehicle(T) ? REAL.URBAN_VEH_COST : 0);
// Suppressed units can't move this turn.
const suppressed = (u, B = appState.battle) => realOn('suppression', B) && !!u.supp;
// Armor facing: remember which way a unit last moved (a unit vector in world space).
function noteFacing(u, from, to) {
  const a = toWorld(from.c, from.r),
    b = toWorld(to.c, to.r),
    dx = b.x - a.x,
    dy = b.y - a.y,
    len = Math.hypot(dx, dy) || 1;
  u.face = [Math.round((dx / len) * 1000) / 1000, Math.round((dy / len) * 1000) / 1000];
}

// ---- supply lines ----
// Hexes from which each army's ground units can trace supply: start at its supply points (and those of allies
// that grant it resupply) and spread over its friendly ground and roads, never through enemy-held hexes.
function supplyNet(B, pid) {
  B._supply = B._supply || {};
  const kk = B.turn + '|' + pid;
  if (B._supply[kk]) return B._supply[kk];
  const def = B.mapDef,
    sup = suppliersOf(pid, B),
    seen = new Set(),
    queue = [];
  const enemyAt = h => aliveUnits(B).some(u => !isAir(u) && u.c === h.c && u.r === h.r && isEnemy(u.pid, pid, B));
  for (const sp of supplyPoints(B))
    if (sup.includes(sp.pid)) {
      const k = key(sp.c, sp.r);
      if (!seen.has(k)) {
        seen.add(k);
        queue.push(sp);
      }
    }
  while (queue.length) {
    const h = queue.shift();
    for (const n of neighborsRaw(h.c, h.r, def.W, def.H)) {
      const k = key(n.c, n.r);
      if (seen.has(k) || TERRAIN[tileAt(n.c, n.r, B).t].water) continue;
      const own = B.territory[k],
        road = B.roads && B.roads[k];
      if ((own == null || !friendlyGround(own, pid, B)) && !road) continue;
      if (enemyAt(n)) continue;
      seen.add(k);
      queue.push(n);
    }
  }
  return (B._supply[kk] = seen);
}
// In supply: on the network, or right next to it (the front line).
function inSupply(B, u, at = u) {
  const net = supplyNet(B, u.pid);
  return net.has(key(at.c, at.r)) || neighborsRaw(at.c, at.r, B.mapDef.W, B.mapDef.H).some(n => net.has(key(n.c, n.r)));
}
// End of turn, before resupply: count turns each ground unit has been cut off.
function logSupplyLines(B) {
  if (!B.rules.supplyLines) return false;
  B._supply = {};
  let ev = false;
  for (const u of aliveUnits(B)) {
    if (UNIT_TYPES[u.type].domain !== 'land') continue;
    const was = u.cut || 0;
    u.cut = inSupply(B, u) ? 0 : was + 1;
    if (u.cut === 1) {
      floatText(u, 'Cut off', '#ffb03a');
      ev = true;
    }
  }
  return ev;
}
const cutOff = (u, B = appState.battle) => realOn('supplyLines', B) && (u.cut || 0) > 0;

// ---- end of turn: entrenchment, suppression, surrender ----
function surrounded(B, u) {
  const T = UNIT_TYPES[u.type];
  const ns = neighborsRaw(u.c, u.r, B.mapDef.W, B.mapDef.H).filter(n => costAt(T, n.c, n.r, undefined, B) != null);
  const hostile = n =>
    aliveUnits(B).some(e => isEnemy(e.pid, u.pid, B) && !isAir(e) && hexDist(e, n) <= 1 && !(e.c === u.c && e.r === u.r));
  return ns.length > 0 && ns.every(hostile);
}
function logRealism(B, st) {
  let ev = false;
  for (const u of aliveUnits(B)) {
    const T = UNIT_TYPES[u.type],
      s = st && st.get(u.id);
    if (B.rules.entrench) {
      const moved = s && s.hist && s.hist.length > 1;
      const was = u.dug || 0;
      u.dug = T.domain === 'land' && !u.in && !moved ? Math.min(REAL.DIG_MAX, was + 1) : 0;
      if (u.dug > was && u.dug === REAL.DIG_MAX) floatText(u, 'Dug in', '#c8b27a');
    }
    if (B.rules.suppression) {
      const lost = Math.max(0, (u.hp0 ?? u.hp) - u.hp);
      u.supp = lost >= u.maxHp * REAL.SUPPRESS_SHARE && u.hp > 0 ? 1 : 0; // suppressed for the next turn only
      if (u.supp) {
        floatText(u, 'Suppressed', '#ffb03a');
        ev = true;
      }
    }
    if (B.rules.surrender && T.domain === 'land' && !u.in && (broken(u, B) || u.hp < u.maxHp * REAL.SURRENDER_HP)) {
      if ((B.rules.supplyLines && (u.cut || 0) >= REAL.SURRENDER_CUT) || surrounded(B, u)) {
        u.hp = 0;
        u.surrendered = true;
        floatText(u, 'Surrendered', '#ffffff');
        B.stats.surrendered = (B.stats.surrendered || 0) + 1;
        ev = true;
      }
    }
  }
  return ev;
}

// ---- Batch 2: command and air ----
// Starting values (tune with the A/B harness).
Object.assign(REAL, {
  COMMAND_RANGE: 6,
  COMMAND_SLOW: 1, // ground units this far from every command post move 1 hex less
  FRICTION_BASE: 0.05,
  FRICTION_SHAKEN: 0.1,
  FRICTION_BROKEN: 0.2,
  FRICTION_NO_COMMAND: 0.05,
  FRICTION_JAMMED: 0.1,
  JAM_RANGE: 3,
  JAM_SIGHT: 2, // drones jam enemies within 3 hexes: sight -2, out of command
  AIRSUP_RANGE: 4,
  AIRSUP_DMG: 1.1,
  AIRSUP_EVADE: 10,
  UMBRELLA_RANGE: 2,
  UMBRELLA_DMG: 0.8,
});
const isJammer = T => T.id === 'drone' || !!T.jammer;
const isFighter = T => T.domain === 'air' && effOf(T).air > 0;
const isAAUnit = T => T.id === 'aa' || !!T.aa;
const friendOf = (a, b, B = appState.battle) => a === b || isAlly(a, b, B);

// Command posts: the army's held capital, its depots and airfields, and its half-tracks (mobile command).
function commandPosts(B, pid) {
  const out = [],
    cap = B.mapDef.spawns[pid],
    capCity = cap && B.cities[key(cap.c, cap.r)];
  if (capCity && capCity.owner === pid) out.push(cap);
  for (const [k, s] of Object.entries(B.structs || {}))
    if (!s.build && s.owner === pid && (s.kind === 'depot' || s.kind === 'airfield')) {
      const [c, r] = unkey(k);
      out.push({ c, r });
    }
  for (const u of aliveUnits(B)) if (u.pid === pid && u.type === 'apc') out.push(u);
  return out;
}
// Electronic warfare: an enemy drone within range jams you, unless one of your side's drones is close enough to counter it.
function jammed(u, B = appState.battle) {
  if (!realOn('ew', B)) return false;
  const near = f => aliveUnits(B).some(o => o !== u && isJammer(UNIT_TYPES[o.type]) && f(o.pid) && hexDist(o, u) <= REAL.JAM_RANGE);
  return near(p => isEnemy(p, u.pid, B)) && !near(p => friendOf(p, u.pid, B));
}
function outOfCommand(u, at = u, B = appState.battle) {
  if (!realOn('command', B) || UNIT_TYPES[u.type].domain !== 'land') return false;
  if (jammed(u, B)) return true;
  return !commandPosts(B, u.pid).some(p => p !== u && hexDist(p, at) <= REAL.COMMAND_RANGE);
}
// A unit's movement this turn (command radius can slow ground units).
const moveOf = (u, B = appState.battle) => {
  const T = UNIT_TYPES[u.type];
  return outOfCommand(u, undefined, B) ? Math.max(1, T.move - REAL.COMMAND_SLOW) : T.move;
};
const jamSight = (u, B = appState.battle) => (jammed(u, B) ? -REAL.JAM_SIGHT : 0);

// Air superiority: the side whose fighters (and only theirs) are within range controls the air over a hex.
function airControl(at, B = appState.battle) {
  const teams = new Set(
    aliveUnits(B)
      .filter(o => isFighter(UNIT_TYPES[o.type]) && hexDist(o, at) <= REAL.AIRSUP_RANGE)
      .map(o => teamOf(o.pid, B))
  );
  return teams.size === 1 ? [...teams][0] : null;
}
// Extra damage multipliers for batch 2 (folded into realismDamage).
function commandAirDamage(att, tgt, pos, B = appState.battle) {
  const A = UNIT_TYPES[att.type];
  let m = 1;
  if (realOn('airSup', B) && airControl(att, B) === teamOf(att.pid, B)) m *= REAL.AIRSUP_DMG;
  if (
    realOn('aaUmbrella', B) &&
    A.domain === 'air' &&
    aliveUnits(B).some(o => isAAUnit(UNIT_TYPES[o.type]) && friendOf(o.pid, tgt.pid, B) && hexDist(o, pos) <= REAL.UMBRELLA_RANGE)
  )
    m *= REAL.UMBRELLA_DMG;
  return m;
}
// Bombers and drones flying where the enemy controls the air are easier to hit.
function airSupEvade(u, B = appState.battle) {
  if (!realOn('airSup', B) || !isAir(u) || isFighter(UNIT_TYPES[u.type])) return 0;
  const ctl = airControl(u, B);
  return ctl != null && ctl !== teamOf(u.pid, B) ? -REAL.AIRSUP_EVADE : 0;
}
// Order friction, rolled as the turn starts (on the battle's seeded generator, so replays repeat it): a move
// stops halfway, or a unit loses track of its target.
function applyFriction(B, st) {
  if (!B.rules.friction) return;
  for (const u of aliveUnits(B)) {
    const s = st.get(u.id);
    if (!s || s.o.type === 'hold') continue;
    let p = REAL.FRICTION_BASE + (broken(u, B) ? REAL.FRICTION_BROKEN : shaken(u, B) ? REAL.FRICTION_SHAKEN : 0);
    if (realOn('command', B) && outOfCommand(u, undefined, B)) p += REAL.FRICTION_NO_COMMAND;
    if (jammed(u, B)) p += REAL.FRICTION_JAMMED;
    if (rng(B) >= p) continue;
    const o = s.o;
    if (o.path && o.path.length > 2) s.o = Object.assign({}, o, { path: o.path.slice(0, Math.ceil(o.path.length / 2)) });
    else if (o.target != null) s.o = Object.assign({}, o, { target: null });
    else continue;
    s.confused = true;
    floatText(u, 'Confusion', '#ffb03a');
    B.stats.friction = (B.stats.friction || 0) + 1;
  }
}

// ---- Batch 3: artillery, submarines, mines, carriers, railways and demolition ----
Object.assign(REAL, { MINE_MAX: 6, MINE_LAND_DMG: 30, MINE_SEA_DMG: 40, RAIL_COST: 1 / 3 });
const RAIL_COST = 1 / 3;
// Railways: roads running through your own (or a resupplying ally's) territory cost a third.
function railFor(pid, c, r, B = appState.battle) {
  if (pid == null || !realOn('rail', B)) return false;
  const own = B.territory[key(c, r)];
  return own != null && friendlyGround(own, pid, B);
}
// Artillery: indirect fire. It can shoot at anything a friendly unit can see (a spotter), never on a turn it moved.
function spotted(pid, e, B = appState.battle) {
  if (fogOn(B)) return canSee(pid, e, B);
  return aliveUnits(B).some(
    o => !o.in && !isEnemy(o.pid, pid, B) && !UNIT_TYPES[o.type].indirect && hexDist(o, e) <= sightOf(o, B) && losClear(o, e, isAir(o), B)
  );
}
const movedThisTurn = (u, B = appState.battle) => u.mv === B.turn;
const cannotFireAfterMoving = (u, from = u, B = appState.battle) =>
  UNIT_TYPES[u.type].setup && (movedThisTurn(u, B) || from.c !== u.c || from.r !== u.r);
// Counter-battery: a battery that fires gives its position away to every enemy until the end of the next turn.
const revealed = (u, B = appState.battle) => u.rev != null && u.rev >= B.turn;
// Submarines: hidden unless an enemy unit is within 1 hex, or an anti-submarine ship within 2.
function subDetected(pid, u, B = appState.battle) {
  return aliveUnits(B).some(
    o => !o.in && !isEnemy(o.pid, pid, B) && o.pid !== u.pid && (hexDist(o, u) <= 1 || (UNIT_TYPES[o.type].asw && hexDist(o, u) <= 2))
  );
}
const isSub = (u, B = appState.battle) => realOn('subs', B) && !!UNIT_TYPES[u.type].stealth;
// Carriers: an aircraft over a friendly carrier has landed (like an airfield).
const carrierUnder = (u, B = appState.battle) =>
  realOn('carriers', B) &&
  aliveUnits(B).some(o => o !== u && UNIT_TYPES[o.type].deck && o.c === u.c && o.r === u.r && friendOf(o.pid, u.pid, B));
// Mines: B.mines[key] = { pid, sea }, hidden from the enemy until triggered.
const canLayMine = (u, B = appState.battle) => {
  const T = UNIT_TYPES[u.type];
  if (!B.rules.mines || !(T.builds || T.asw)) return false;
  if (Object.values(B.mines || {}).filter(m => m.pid === u.pid).length >= REAL.MINE_MAX) return false;
  return !(B.mines || {})[key(u.c, u.r)];
};
function logMines(B, st) {
  if (!B.rules.mines) return false;
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st && st.get(u.id);
    if (!s || s.o.type !== 'mine' || !canLayMine(u, B)) continue;
    (B.mines = B.mines || {})[key(u.c, u.r)] = { pid: u.pid, sea: UNIT_TYPES[u.type].domain === 'sea' };
    floatText(u, 'Mine laid', '#c8b27a');
    B.stats.minesLaid = (B.stats.minesLaid || 0) + 1;
    ev = true;
  }
  return ev;
}
// A unit has just stepped onto (c, r): enemy mines go off, unless an engineer clears a land mine safely.
// Returns true if the unit must stop.
function stepOnMine(B, u) {
  const k = key(u.c, u.r),
    m = B.mines && B.mines[k];
  if (!m || isAir(u) || !isEnemy(m.pid, u.pid, B)) return false;
  delete B.mines[k];
  if (!m.sea && UNIT_TYPES[u.type].builds) {
    floatText(u, 'Mine cleared', '#9fe86a');
    B.stats.minesCleared = (B.stats.minesCleared || 0) + 1;
    return false;
  }
  const dmg = m.sea ? REAL.MINE_SEA_DMG : REAL.MINE_LAND_DMG;
  u.hp = Math.max(0, u.hp - dmg);
  floatText(u, `Mine! -${dmg}`, '#ff6a4a');
  B.stats.minesHit = (B.stats.minesHit || 0) + 1;
  return true;
}
// Demolition: an engineer blows an adjacent bridge (any side's) at the end of the turn.
const bridgeNextTo = (u, B = appState.battle) => {
  const def = B.mapDef;
  return (
    neighborsRaw(u.c, u.r, def.W, def.H)
      .concat([{ c: u.c, r: u.r }])
      .find(n => {
        const s = builtAt(n.c, n.r, B);
        return s && s.kind === 'bridge';
      }) || null
  );
};
const canDemolish = (u, B = appState.battle) => realOn('rail', B) && !!UNIT_TYPES[u.type].builds && !!bridgeNextTo(u, B);
function logDemolish(B, st) {
  if (!B.rules.rail) return false;
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st && st.get(u.id);
    if (!s || s.o.type !== 'demolish') continue;
    const h = bridgeNextTo(u, B);
    if (!h) continue;
    destroyStructAt(B, h.c, h.r);
    floatText(u, 'Bridge blown', '#ff9a6a');
    B.stats.bridgesBlown = (B.stats.bridgesBlown || 0) + 1;
    ev = true;
  }
  return ev;
}

// Removes a structure, as when it is shot to pieces (a destroyed bridge drops the ground units on it).
function destroyStructAt(B, c, r) {
  const k = key(c, r),
    s = B.structs[k];
  if (!s) return;
  delete B.structs[k];
  B.stats.destroyed++;
  if (s.kind === 'silo') B.stats.silosLost = (B.stats.silosLost || 0) + 1;
  if (s.kind === 'bridge')
    for (const u of aliveUnits(B))
      if (u.c === c && u.r === r && UNIT_TYPES[u.type].domain === 'land') {
        u.hp = 0;
        if (u.cargo) {
          const cg = unitById(u.cargo, B);
          if (cg) cg.hp = 0;
        }
      }
}

// ---- Batch 4: seasons, timed reinforcements, victory points and war weariness, information operations, ammunition ----
Object.assign(REAL, {
  SEASON_LEN: 15,
  MUD_COST: 0.5,
  SNOW_COST: 0.5,
  ICE_COST: 2,
  REINFORCE_EVERY: 8,
  REINFORCE_UNITS: 2,
  VP_PER_CITY: 1,
  VP_PER_CAPITAL: 3,
  VP_TARGET_PER_CITY: 3,
  WEARINESS: 0.6,
  BROADCAST_RANGE: 3,
  BROADCAST_MORALE: 10,
  BROADCAST_VERIFY: 2,
  AMMO_GOOD: 1.25,
  AMMO_BAD_AP: 0.7,
  AMMO_BAD_HE: 0.75,
});
const SEASONS = ['Spring', 'Summer', 'Autumn', 'Winter'];
// Seasons: the battle starts in a seeded season and moves on every SEASON_LEN turns.
function seasonOf(B = appState.battle) {
  if (!B || !B.rules || !B.rules.seasons || B.seasonStart == null) return null;
  return SEASONS[(B.seasonStart + Math.floor((B.turn - 1) / REAL.SEASON_LEN)) % 4];
}
// Extra cost for a ground unit stepping off-road onto (c, r); Infinity-free: null means "no change".
function seasonCost(T, t, onRoad, B = appState.battle) {
  const s = seasonOf();
  if (!s || T.domain !== 'land' || onRoad || TERRAIN[t].water) return 0;
  if (s === 'Winter') return REAL.SNOW_COST; // snow slows everyone off-road
  const raining = realOn('weather', B) && cond(B).w === 'rain';
  if ((s === 'Spring' || s === 'Autumn' || raining) && !T.foot) return REAL.MUD_COST; // mud bogs down vehicles
  return 0;
}
// Winter freezes the shallows: ground units can cross them.
const frozenCost = (T, t) => (seasonOf() === 'Winter' && T.domain === 'land' && t === 'w' ? REAL.ICE_COST : null);

// Timed reinforcements: every REINFORCE_EVERY turns, two units from the army's own roster arrive at its capital.
function logReinforcements(B) {
  if (!B.rules.reinforce || B.turn % REAL.REINFORCE_EVERY !== 0) return false;
  let ev = false;
  for (const p of B.players) {
    if (!inFight(p.id, B)) continue;
    const cap = B.mapDef.spawns[p.id],
      city = cap && B.cities[key(cap.c, cap.r)];
    if (!city || city.owner !== p.id) continue; // cut off from home: no reinforcements
    const pool = ((B.rosterTypes || {})[p.id] || []).filter(t => typeAllowed(t, B.rules));
    if (!pool.length) continue;
    B.reinforced = B.reinforced || {};
    for (let i = 0; i < REAL.REINFORCE_UNITS; i++) {
      if (allAlive(B).filter(u => u.pid === p.id).length >= ARMY_CAP) break;
      const n = (B.reinforced[p.id] = (B.reinforced[p.id] || 0) + 1),
        type = pool[(n - 1) % pool.length],
        T = UNIT_TYPES[type];
      const site = T.domain === 'land' || T.domain === 'air' ? cap : productionSites(B, p.id, type)[0];
      const h = site && (placeNewUnit(B, type, site) || freeNear(B, type, site, 2)); // a crowded capital: arrive within 2 hexes
      if (!h) continue;
      const u = {
        id: B.nextId++,
        pid: p.id,
        type,
        name: `${T.short} W${n}`,
        c: h.c,
        r: h.r,
        hp: T.hp,
        maxHp: T.hp,
        ammo: T.ammo,
        maxAmmo: T.ammo,
        fuel: T.fuel ?? null,
        maxFuel: T.fuel ?? null,
      };
      if (moraleOn(B)) u.morale = MORALE_START;
      const t = tileAt(h.c, h.r, B);
      u.px = t.wx;
      u.py = t.wy;
      u.pz = t.z + (T.domain === 'air' ? 1.4 : 0);
      u.dispHp = u.hp;
      B.units.push(u);
      floatText(u, 'Reinforcements', '#9fe86a');
      B.stats.reinforced = (B.stats.reinforced || 0) + 1;
      ev = true;
    }
  }
  return ev;
}

// Victory points and war weariness.
const vpTarget = B => REAL.VP_TARGET_PER_CITY * Math.max(3, Object.keys(B.cities || {}).length);
const armyValue = units => units.reduce((s, u) => s + priceOf(UNIT_TYPES[u.type]), 0);
function initVictoryPoints(B) {
  if (!B.rules.vp) return;
  B.vp = {};
  B.startValue = {};
  for (const p of B.players) B.startValue[p.id] = armyValue(B.units.filter(u => u.pid === p.id));
}
// Each turn: cities score for their holders' teams (an enemy capital counts triple).
function scoreVictoryPoints(B) {
  if (!B.rules.vp) return;
  B.vp = B.vp || {};
  for (const [k, c] of Object.entries(B.cities || {})) {
    if (c.owner == null || !inFight(c.owner, B)) continue;
    const isCap = B.mapDef.spawns.some((s, i) => key(s.c, s.r) === k && i !== c.owner);
    const t = teamOf(c.owner, B);
    B.vp[t] = (B.vp[t] || 0) + (isCap ? REAL.VP_PER_CAPITAL : REAL.VP_PER_CITY);
  }
}
// War weariness: an army that has lost more than WEARINESS of its starting strength sues for peace.
function warWeary(B, pid) {
  if (!B.rules.vp || !B.startValue || !B.startValue[pid]) return false;
  const lost = armyValue(everyUnit(B).filter(u => u.pid === pid && u.hp <= 0));
  return lost >= REAL.WEARINESS * B.startValue[pid];
}
const vpWinner = B => {
  if (!B.rules.vp || !B.vp) return null;
  const t = Object.keys(B.vp).find(t => B.vp[t] >= vpTarget(B));
  return t == null ? null : +t;
};

// Information operations: a rifle squad broadcasts. Enemy units within range lose morale unless enough of their
// own side is around to verify; with fog and fading intel, the enemy also gets a false report nearby.
const canBroadcast = (u, B = appState.battle) => realOn('infoOps', B) && UNIT_TYPES[u.type].captures && !u.in;
function logBroadcasts(B, st) {
  if (!B.rules.infoOps) return false;
  let ev = false;
  for (const u of aliveUnits(B)) {
    const s = st && st.get(u.id);
    if (!s || s.o.type !== 'broadcast' || !canBroadcast(u, B)) continue;
    floatText(u, 'Broadcast', '#cfe3ff');
    B.stats.broadcasts = (B.stats.broadcasts || 0) + 1;
    ev = true;
    for (const e of aliveUnits(B)) {
      if (!isEnemy(e.pid, u.pid, B) || hexDist(e, u) > REAL.BROADCAST_RANGE) continue;
      const verifiers = aliveUnits(B).filter(o => o !== e && friendOf(o.pid, e.pid, B) && hexDist(o, e) <= 2).length;
      if (verifiers >= REAL.BROADCAST_VERIFY) continue; // checked against what their comrades see: no effect
      if (moraleOn(B) && e.morale != null) {
        e.morale = Math.max(0, e.morale - REAL.BROADCAST_MORALE);
        B.stats.demoralized = (B.stats.demoralized || 0) + 1;
      }
    }
    if (B.rules.fog && B.rules.intelFade) {
      const def = B.mapDef,
        near = neighborsRaw(u.c, u.r, def.W, def.H).filter(n => !TERRAIN[tileAt(n.c, n.r, B).t].water);
      if (near.length) {
        const n = near[Math.floor(rng(B) * near.length)];
        for (const p of B.players)
          if (isEnemy(p.id, u.pid, B)) {
            const I = ((B.intel = B.intel || {})[teamOf(p.id, B)] = (B.intel || {})[teamOf(p.id, B)] || {});
            I['f' + u.id + '_' + B.turn] = { c: n.c, r: n.r, type: 'tank', pid: u.pid, turn: B.turn, conf: 0.6, decoy: true };
          }
      }
    }
  }
  return ev;
}

// Ammunition types: armor-piercing against vehicles and ships, high-explosive against soldiers and structures.
const usesAmmoTypes = T => !!T && (T.id === 'tank' || T.id === 'arty' || T.id === 'ship' || T.id === 'battleship' || T.ammoTypes);
const armoredTarget = T => (T.domain === 'land' && !T.foot) || T.domain === 'sea';
function ammoDamage(att, tgt, B = appState.battle) {
  if (!realOn('ammo', B)) return 1;
  const A = UNIT_TYPES[att.type],
    T = UNIT_TYPES[tgt.type];
  if (!usesAmmoTypes(A) || T.domain === 'air') return 1;
  const ap = (att.ammoType || 'he') === 'ap';
  if (armoredTarget(T)) return ap ? REAL.AMMO_GOOD : REAL.AMMO_BAD_HE;
  return ap ? REAL.AMMO_BAD_AP : REAL.AMMO_GOOD;
}
const ammoStructDamage = (att, B = appState.battle) =>
  realOn('ammo', B) && usesAmmoTypes(UNIT_TYPES[att.type]) ? ((att.ammoType || 'he') === 'he' ? REAL.AMMO_GOOD : REAL.AMMO_BAD_AP) : 1;

// The nearest free hex (within `radius`) where a unit of this type can stand.
function freeNear(B, type, site, radius) {
  const T = UNIT_TYPES[type],
    def = B.mapDef,
    air = T.domain === 'air';
  const ok = h =>
    !unitAtLayer(h.c, h.r, air, B) &&
    (air || (T.domain === 'sea' ? TERRAIN[tileAt(h.c, h.r, B).t].water : landPassAt(h.c, h.r, B) && tileAt(h.c, h.r, B).t !== 'm'));
  let best = null;
  for (let r = site.r - radius; r <= site.r + radius; r++)
    for (let c = site.c - radius - 1; c <= site.c + radius + 1; c++) {
      if (r < 0 || c < 0 || r >= def.H || c >= def.W) continue;
      const h = { c, r },
        d = hexDist(site, h);
      if (d <= radius && ok(h) && (!best || d < best.d)) best = { c, r, d };
    }
  return best;
}
