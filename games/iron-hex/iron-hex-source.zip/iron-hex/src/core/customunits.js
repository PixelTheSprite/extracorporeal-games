// Custom units (Unit Editor): the shared stat scales, the lookup prompt and answer parser,
// turning an editor draft into a unit type, and registering custom types with the game.
// A custom unit type has the same shape as the built-ins in UNIT_TYPES, plus custom:true and art (sprite rows).

// How each 0–10 stat is scored, per domain. "max" scales map a real value linearly (capped at 10);
// "rated" stats have no common real-world measure, so they are rated 0–10 against the reference units.
const STAT_SCALES = {
  land: {
    speed: { unit: 'km/h', max: 70, label: 'road speed' },
    maneuver: { unit: 'hp/tonne', max: 25, label: 'power-to-weight' },
    armor: { unit: 'mm', max: 200, label: 'thickest frontal armor' },
    firepower: { unit: 'mm', max: 200, label: 'main weapon penetration, or rated if not an anti-armor weapon', ratedOk: true },
  },
  sea: {
    speed: { unit: 'knots', max: 40, label: 'top speed' },
    maneuver: { rated: true, label: 'agility relative to WWII warships' },
    armor: { unit: 'mm', max: 350, label: 'thickest belt armor (0 if unarmored; use rated for durability without armor)', ratedOk: true },
    firepower: { rated: true, label: 'relative to WWII surface combatants' },
  },
  air: {
    speed: { unit: 'km/h', max: 800, label: 'top speed' },
    maneuver: { rated: true, label: 'relative to WWII fighters' },
    armor: { rated: true, label: 'relative to armored attack aircraft' },
    firepower: { rated: true, label: 'relative to WWII attack aircraft' },
  },
};
const STAT_LABEL = { speed: 'Speed', maneuver: 'Maneuverability', armor: 'Armor', firepower: 'Firepower' };
const SPRITE_KEYS = '.ktdlgws'; // transparent, outline, team, team dark, team light, metal, dark metal, skin
const ART_MAX = { W: 24, H: 16 };
const FOOT_COST = { s: 1, p: 1, f: 1, h: 1, m: 2, c: 1 };
const ABILITIES = {
  captures: 'Captures cities and structures',
  carries: 'Carries one unit',
  repairs: 'Repairs adjacent units',
  builds: 'Builds roads and structures',
  foot: 'Moves on foot (forests and hills cost 1)',
};

const scoreStat = (domain, stat, value) => {
  const s = STAT_SCALES[domain][stat];
  return s.max ? clamp(Math.round((value / s.max) * 10), 0, 10) : clamp(Math.round(value), 0, 10);
};
// The one prompt used for both the built-in lookup and copy-paste. Built-in units are the reference points.
function lookupPrompt(query) {
  const ref = Object.values(UNIT_TYPES)
    .filter(T => !T.custom)
    .map(
      T =>
        `${T.name} (${T.domain}): speed ${T.stats.speed}, maneuver ${T.stats.maneuver}, armor ${T.stats.armor}, firepower ${T.stats.firepower}`
    )
    .join('\n');
  const scales = Object.entries(STAT_SCALES)
    .map(
      ([d, ss]) =>
        `${d}: ` +
        Object.entries(ss)
          .map(([k, s]) => `${k} = ${s.max ? `real value in ${s.unit} (${s.label})` : `rating 0-10 (${s.label})`}`)
          .join('; ')
    )
    .join('\n');
  return `A hex wargame wants game stats for this real vehicle, aircraft or ship: "${query}".
Answer ONLY with one JSON object, no prose, in exactly this shape:
{"found": true, "name": "official designation", "short": "name of at most 10 characters", "role": "e.g. Medium tank", "domain": "land" | "sea" | "air",
 "era": "e.g. WWII", "country": "...",
 "stats": {"speed": {"value": number, "unit": "...", "note": "what the number is"}, "maneuver": {...}, "armor": {...}, "firepower": {...}},
 "game": {"range": [min, max], "ammo": whole number, "fuel": whole number or null, "abilities": [], "eff": {"land": 0-2, "sea": 0-2, "air": 0-2}},
 "sources": ["reference works you are drawing on"], "confidence": "high" | "medium" | "low", "caveats": "variants, uncertainty"}
If you don't recognize it, answer {"found": false, "caveats": "why"}.
For each stat give the real figure in the unit listed for its domain; where the domain says "rating", give "unit": "rating" and a 0-10 value judged against the reference units:
${scales}
Reference units already in the game (0-10 scores):
${ref}
Game values: range in hexes (0 means only the hex directly below, for bombers; 1 adjacent; artillery and battleships 2-4), ammo 2-8 shots, fuel 15-50 (null for infantry).
abilities may include: "captures" (infantry), "carries" (transports), "repairs", "builds" (engineers), "foot" (soldiers on foot).
eff: damage multiplier against ground, naval and air targets (0 = cannot attack that kind; anti-aircraft guns about 1.4 against air).`;
}
// Turns a lookup answer (object or JSON text, possibly in a code fence) into an editor draft. Throws a readable Error.
function parseLookup(answer) {
  let a = answer;
  if (typeof a === 'string') {
    const m = a.match(/\{[\s\S]*\}/);
    if (!m) throw new Error('No JSON object found in the answer.');
    try {
      a = JSON.parse(m[0]);
    } catch (e) {
      throw new Error('The answer is not valid JSON: ' + e.message);
    }
  }
  if (!a || typeof a !== 'object') throw new Error('The answer is not a JSON object.');
  if (a.found === false) throw new Error(`Not recognized${a.caveats ? ': ' + a.caveats : '.'}`);
  const domain = ['land', 'sea', 'air'].includes(a.domain) ? a.domain : null;
  if (!domain) throw new Error('The answer has no domain (land, sea or air).');
  const num = v => (typeof v === 'number' && isFinite(v) ? v : typeof v === 'string' && isFinite(parseFloat(v)) ? parseFloat(v) : null);
  const stats = {};
  for (const k of STAT_KEYS) {
    const s = (a.stats || {})[k] || {},
      sc = STAT_SCALES[domain][k];
    const rated = !sc.max || (sc.ratedOk && String(s.unit || '').toLowerCase() === 'rating');
    const v = num(s.value);
    if (v == null) throw new Error(`The answer has no number for ${STAT_LABEL[k].toLowerCase()}.`);
    stats[k] = { value: v, rated, note: String(s.note || '').slice(0, 120) };
  }
  const g = a.game || {},
    rng = Array.isArray(g.range) ? g.range.map(num) : [];
  const eff = {};
  for (const d of DOMAINS) eff[d] = clamp(num((g.eff || {})[d]) ?? EFF[domain][d], 0, 2);
  const ab = new Set((g.abilities || []).filter(x => ABILITIES[x]));
  return {
    query: a.name || '',
    name: String(a.name || 'New unit').slice(0, 40),
    short: String(a.short || a.name || 'Unit').slice(0, 10),
    role: String(a.role || 'Unit').slice(0, 40),
    domain,
    era: String(a.era || ''),
    country: String(a.country || ''),
    stats,
    range: [clamp(Math.round(rng[0] ?? 1), 0, 4), clamp(Math.round(rng[1] ?? rng[0] ?? 1), 0, 6)],
    ammo: clamp(Math.round(num(g.ammo) ?? 4), 1, 12),
    fuel: domain === 'land' && ab.has('foot') ? null : num(g.fuel) == null ? null : clamp(Math.round(num(g.fuel)), 5, 99),
    eff,
    abilities: [...ab],
    sources: (a.sources || []).map(String).slice(0, 5),
    confidence: String(a.confidence || ''),
    caveats: String(a.caveats || '').slice(0, 300),
  };
}
const SAFE_UNIT_ID = /^u_[a-z0-9_]{1,48}$/;
const slugId = name =>
  'u_' +
  String(name)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '')
    .slice(0, 14) +
  '_' +
  Math.floor(Math.random() * 1e6).toString(36);
// Editor draft -> unit type (same shape as UNIT_TYPES entries). Scores come from the scales unless overridden.
function unitFromDraft(d) {
  const stats = {},
    norm = [];
  for (const k of STAT_KEYS) {
    const s = d.stats[k],
      sc = STAT_SCALES[d.domain][k],
      rated = s.rated || !sc.max;
    // Measured stats are scored on the domain's scale; rated stats are the 0–10 value itself; an override wins.
    stats[k] =
      s.override != null
        ? clamp(Math.round(s.override), 0, 10)
        : rated
          ? clamp(Math.round(s.value), 0, 10)
          : scoreStat(d.domain, k, s.value);
    const real = rated ? s.note || 'Rated' : `${+s.value.toFixed(1)} ${sc.unit}${s.note ? ' (' + s.note + ')' : ''}`;
    norm.push([STAT_LABEL[k], real, rated ? 'Rated against the reference units' : `0–${sc.max} ${sc.unit}, capped at 10`, stats[k]]);
  }
  const ab = new Set(d.abilities);
  const T = {
    id: d.id || slugId(d.name),
    custom: true,
    short: d.short.trim().slice(0, 10) || 'Unit',
    name: d.name.trim().slice(0, 40) || 'New unit',
    role: d.role.trim().slice(0, 40) || 'Unit',
    domain: d.domain,
    stats,
    range: [d.range[0], Math.max(d.range[0], d.range[1])],
    ammo: d.ammo,
    eff: Object.assign({}, d.eff),
    norm,
    source:
      `Custom unit${d.query ? ` modeled on the ${d.name}` : ''}${d.era ? ` (${d.era}${d.country ? ', ' + d.country : ''})` : ''}.` +
      (d.sources && d.sources.length ? ` Sources as given by the lookup: ${d.sources.join('; ')}.` : '') +
      (d.caveats ? ` Caveats: ${d.caveats}` : ''),
    art: d.art.slice(),
  };
  if (d.fuel != null && !(d.domain === 'land' && ab.has('foot'))) T.fuel = d.fuel;
  if (ab.has('captures') && d.domain === 'land') T.captures = true;
  if (ab.has('carries')) {
    T.carry = 1;
    if (d.domain === 'land') T.carryKinds = 'foot';
  }
  if (ab.has('repairs')) T.repairs = true;
  if (ab.has('builds')) T.builds = true;
  if (ab.has('foot') && d.domain === 'land') {
    T.foot = true;
    T.moveCost = Object.assign({}, FOOT_COST);
  }
  return T;
}
// Unit type -> editor draft (to edit an existing custom unit, or start from a built-in one).
function draftFromUnit(T, copy) {
  const stats = {};
  STAT_KEYS.forEach((k, i) => {
    const sc = STAT_SCALES[T.domain][k];
    stats[k] = { value: T.stats[k], rated: true, note: (T.norm && T.norm[i] ? String(T.norm[i][1]) : '').slice(0, 120) };
    if (sc.max) stats[k].override = null;
  });
  const ab = [];
  if (T.captures) ab.push('captures');
  if (T.carry) ab.push('carries');
  if (T.repairs) ab.push('repairs');
  if (T.builds) ab.push('builds');
  if (T.foot || (T.moveCost && T.domain === 'land')) ab.push('foot');
  return {
    id: copy ? null : T.id,
    query: '',
    name: copy ? T.name + ' (custom)' : T.name,
    short: T.short,
    role: T.role,
    domain: T.domain,
    era: '',
    country: '',
    stats,
    range: T.range.slice(),
    ammo: T.ammo,
    fuel: T.fuel ?? null,
    eff: Object.assign({}, effOf(T)),
    abilities: ab,
    sources: [],
    confidence: '',
    caveats: '',
    art: (T.art || (typeof SPRITE_ART !== 'undefined' && SPRITE_ART[T.id]) || ['k']).slice(),
  };
}
function validateArt(rows) {
  const p = [];
  if (!Array.isArray(rows) || !rows.length) return ['art: no pixels'];
  if (rows.length > ART_MAX.H) p.push(`art: at most ${ART_MAX.H} rows tall`);
  if (rows.some(r => typeof r !== 'string' || r.length !== rows[0].length)) p.push('art: every row must be the same width');
  if (rows[0].length > ART_MAX.W) p.push(`art: at most ${ART_MAX.W} pixels wide`);
  if (rows.some(r => [...r].some(ch => !SPRITE_KEYS.includes(ch)))) p.push('art: unknown color key');
  if (rows.every(r => /^\.*$/.test(r))) p.push('art: the sprite is empty');
  return p;
}
// Adds (or replaces) a custom unit type in the game. Returns its problems; registers only if there are none.
function registerCustomUnit(T) {
  if (T && T.cost && !T.moveCost) {
    T.moveCost = T.cost;
    delete T.cost;
  } // older custom units used the name "cost"
  if (!T || typeof T.id !== 'string' || !SAFE_UNIT_ID.test(T.id))
    return [`${String(T && T.id).slice(0, 30)}: custom unit id must look like u_name_123`];
  if (UNIT_TYPES[T.id] && !UNIT_TYPES[T.id].custom) return [`${T.id}: clashes with a built-in unit`];
  const prev = UNIT_TYPES[T.id],
    hadOrder = TYPE_ORDER.includes(T.id);
  UNIT_TYPES[T.id] = T;
  derive(T);
  if (!hadOrder) TYPE_ORDER.push(T.id);
  const p = validateUnitType(T.id, T).concat(validateArt(T.art));
  if (p.length) {
    if (prev) UNIT_TYPES[T.id] = prev;
    else {
      delete UNIT_TYPES[T.id];
      TYPE_ORDER.splice(TYPE_ORDER.indexOf(T.id), 1);
    }
  }
  return p;
}
function unregisterCustomUnit(id) {
  if (!UNIT_TYPES[id] || !UNIT_TYPES[id].custom) return;
  delete UNIT_TYPES[id];
  const i = TYPE_ORDER.indexOf(id);
  if (i >= 0) TYPE_ORDER.splice(i, 1);
}
