// Prices, the point-buy roster budget, and the economy rules: income, mid-battle production, capital loss.
const PRICES = {
  tank: 10,
  aa: 9,
  apc: 7,
  inf: 4,
  at: 6,
  eng: 5,
  plane: 12,
  bomber: 16,
  drone: 6,
  ship: 14,
  battleship: 24,
  lst: 8,
  arty: 11,
  sub: 13,
  carrier: 22,
};
// Custom units are priced from their stats (and domain and reach), between 3 and 30.
const priceOf = T =>
  T.price ??
  PRICES[T.id] ??
  clamp(
    Math.round(
      2 +
        (T.stats.speed + T.stats.maneuver + T.stats.armor + 2 * T.stats.firepower) * 0.45 +
        (T.domain === 'sea' ? 4 : T.domain === 'air' ? 3 : 0) +
        T.range[1]
    ),
    3,
    30
  );
const rosterCost = r => TYPE_ORDER.reduce((s, t) => s + ((r && r[t]) || 0) * priceOf(UNIT_TYPES[t]), 0);
const BUDGETS = [0, 60, 100, 150]; // roster point budgets (0 = no limit)
const START_FUNDS = 15,
  BASE_INCOME = 1,
  CITY_INCOME = 3,
  SITE_INCOME = 2,
  ARMY_CAP = 20,
  BUYS_PER_TURN = 1;
// Income per turn: 1, plus 3 per city and 2 per airfield, port or depot held.
// Capital loss rule: an army whose capital (its starting city) falls to an enemy is out of the battle.
const capitalLost = (B, pid) => {
  if (!B.rules.capitalLoss) return false;
  const sp = B.mapDef.spawns[pid],
    c = sp && B.cities[key(sp.c, sp.r)];
  return !!c && c.owner != null && isEnemy(c.owner, pid, B);
};
function incomeOf(B, pid) {
  const cities = Object.values(B.cities || {}).filter(c => c.owner === pid).length;
  const sites = Object.values(B.structs || {}).filter(s => !s.build && STRUCTS[s.kind].capture && s.owner === pid).length;
  return BASE_INCOME + CITY_INCOME * cities + SITE_INCOME * sites + cityIncome(B, pid);
}
// Where a type can be bought: ground units at your cities; aircraft at your airfields or capital; ships at your ports or coastal cities.
function productionSites(B, pid, type) {
  const dom = UNIT_TYPES[type].domain,
    def = B.mapDef,
    out = [];
  const cap = def.spawns[pid],
    coastal = (c, r) => isCoastal(def.rows, def.W, def.H, c, r);
  for (const [k, ci] of Object.entries(B.cities || {})) {
    if (ci.owner !== pid) continue;
    const [c, r] = unkey(k);
    if (dom === 'land' || (dom === 'sea' && coastal(c, r)) || (dom === 'air' && cap && cap.c === c && cap.r === r)) out.push({ c, r });
  }
  for (const [k, s] of Object.entries(B.structs || {})) {
    if (s.build || s.owner !== pid) continue;
    const [c, r] = unkey(k);
    if ((dom === 'air' && s.kind === 'airfield') || (dom === 'sea' && s.kind === 'port')) out.push({ c, r });
  }
  return out;
}
// A free hex for a new unit at (or next to) its site.
function placeNewUnit(B, type, site) {
  const T = UNIT_TYPES[type],
    def = B.mapDef,
    air = T.domain === 'air';
  const ok = h =>
    !unitAtLayer(h.c, h.r, air, B) &&
    (air || (T.domain === 'sea' ? TERRAIN[tileAt(h.c, h.r, B).t].water : landPassAt(h.c, h.r, B) && tileAt(h.c, h.r, B).t !== 'm'));
  return [site].concat(neighborsRaw(site.c, site.r, def.W, def.H)).find(ok) || null;
}
// End of turn: deliver each army's queued purchases (B.prodQueue[pid] = [{ type, at }]), then pay income.
function runProduction(B) {
  if (!B.rules.income && !B.rules.production) return;
  B.funds = B.funds || {};
  B.built = B.built || {};
  for (const p of B.players) {
    if (!inFight(p.id, B)) {
      B.prodQueue && (B.prodQueue[p.id] = []);
      continue;
    }
    for (const item of (B.rules.production ? (B.prodQueue || {})[p.id] || [] : []).slice(0, BUYS_PER_TURN + extraBuys(B, p.id))) {
      const T = UNIT_TYPES[item.type],
        price = T ? priceOf(T) : Infinity;
      if (!T || (B.funds[p.id] || 0) < price || allAlive(B).filter(u => u.pid === p.id).length >= ARMY_CAP) continue;
      if (!productionSites(B, p.id, item.type).some(s => s.c === item.at.c && s.r === item.at.r)) continue;
      const h = placeNewUnit(B, item.type, item.at);
      if (!h) continue;
      const n = ((B.built[p.id] = B.built[p.id] || {})[item.type] = ((B.built[p.id] || {})[item.type] || 0) + 1);
      const u = {
        id: B.nextId++,
        pid: p.id,
        type: item.type,
        name: `${T.short} R${n}`,
        c: h.c,
        r: h.r,
        hp: T.hp,
        maxHp: T.hp,
        ammo: T.ammo,
        maxAmmo: T.ammo,
        fuel: T.fuel ?? null,
        maxFuel: T.fuel ?? null,
      };
      if (moraleOn(B)) u.morale = MORALE_START;
      if (T.custom) B.customTypes[T.id] = T;
      const t = tileAt(h.c, h.r, B);
      u.px = t.wx;
      u.py = t.wy;
      u.pz = t.z + (air => (air ? 1.4 : 0))(T.domain === 'air');
      u.dispHp = u.hp;
      B.units.push(u);
      B.funds[p.id] -= price;
      B.stats.produced = (B.stats.produced || 0) + 1;
      floatText(u, 'New ' + T.short, '#9fe86a');
    }
    if (B.rules.income) {
      B.funds[p.id] = (B.funds[p.id] || 0) + incomeOf(B, p.id);
      B.stats.cityIncome = (B.stats.cityIncome || 0) + cityIncome(B, p.id); // what developed cities earned (A/B payback)
    }
  }
  B.prodQueue = {};
}
// AI purchases: counter the enemy's air with anti-aircraft and its armor with bazookas, keep enough infantry
// to capture, match enemy ships where there's sea, otherwise buy tanks. At most 1 a turn.
function planProduction(p, B = appState.battle) {
  if (!B.rules.production) return;
  const mine = allAlive(B).filter(u => u.pid === p.id),
    seen = aliveUnits(B).filter(e => isEnemy(e.pid, p.id, B) && canSee(p.id, e, B));
  const count = (list, f) => list.filter(f).length;
  let funds = (B.funds || {})[p.id] || 0;
  const q = [];
  for (let i = 0; i < BUYS_PER_TURN + extraBuys(B, p.id); i++) {
    let want = 'tank';
    if (count(seen, e => isAir(e)) > 2 * count(mine, u => u.type === 'aa')) want = 'aa';
    else if (count(mine, u => UNIT_TYPES[u.type].captures) < 2) want = 'inf';
    else if (count(seen, e => e.type === 'tank') > 2 * count(mine, u => u.type === 'at')) want = 'at';
    else if (
      count(seen, e => UNIT_TYPES[e.type].domain === 'sea') > count(mine, u => UNIT_TYPES[u.type].domain === 'sea') &&
      productionSites(B, p.id, 'ship').length
    )
      want = 'ship';
    if (q.some(x => x.type === want) && want !== 'tank') want = 'inf';
    const price = priceOf(UNIT_TYPES[want]),
      sites = productionSites(B, p.id, want).filter(s => !q.some(x => x.at.c === s.c && x.at.r === s.r));
    if (funds < price || !sites.length) break;
    // build nearest the enemy (or the first site when none is in view)
    const site = sites.sort((a, b) =>
      seen.length ? Math.min(...seen.map(e => hexDist(e, a))) - Math.min(...seen.map(e => hexDist(e, b))) : 0
    )[0];
    q.push({ type: want, at: { c: site.c, r: site.r } });
    funds -= price;
  }
  (B.prodQueue = B.prodQueue || {})[p.id] = q;
}
