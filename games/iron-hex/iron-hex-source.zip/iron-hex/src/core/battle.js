// Battle setup and unit/map query helpers.
// ---------- Battle setup ----------
// seed: optional battle seed (tests pass one); otherwise a random seed is chosen and stored with the battle.
// Who is giving orders at this device: army 0 in single-player, the current player in hot-seat, your seat online.
const me = () => appState.me ?? 0;
const humanSeat = (S, i) => (S.seats ? !!(S.seats[i] && S.seats[i].human) : i < Math.max(1, S.hotseat || 1));
// Battle modes: 'single' (you against the AI), 'hotseat' (several people, one device), 'online' (a shared match).
const battleMode = B => B.mode || 'single';
function newBattle(seed) {
  const S = appState.settings;
  const s0 = (seed ?? Math.random() * 4294967296) >>> 0;
  const mapDef = mapDefFor(S.mapId, S);
  // Real maps name their sides. You command side S.playSide; reorder so your side is army 0 and the
  // other sides follow in the map's order. Battles never have more armies than the map has spawns.
  const armies = Math.min(S.armies, mapDef.spawns.length);
  const order = [...mapDef.spawns.keys()];
  const ps = mapDef.sides ? Math.min(S.playSide || 0, mapDef.spawns.length - 1) : 0;
  if (ps) {
    order.splice(order.indexOf(ps), 1);
    order.unshift(ps);
  }
  mapDef.spawns = order.map(i => mapDef.spawns[i]);
  if (mapDef.sides) mapDef.sides = order.map(i => mapDef.sides[i]);
  const players = [];
  for (let i = 0; i < armies; i++) {
    const side = mapDef.sides && mapDef.sides[i];
    players.push({
      id: i,
      name: side ? side.name : ARMIES[i].name,
      short: side ? side.short : ARMIES[i].name.split(' ')[0],
      // Human seats: army 0 in single-player; the first S.hotseat armies on one device; S.seats[i].human online.
      ai: humanSeat(S, i) ? null : S.strategies[i] || 'balanced',
    });
  }
  const B = {
    turn: 1,
    mode: S.seats ? 'online' : (S.hotseat || 1) > 1 ? 'hotseat' : 'single',
    mapDef,
    players,
    units: [],
    nextId: 1,
    orders: {},
    rules: Object.assign({}, S.rules),
    victory: Object.assign({}, S.victory),
    holds: {},
    seed: s0,
    rngState: s0,
    quiet: 0,
    teams: (S.teams || [])
      .slice(0, armies)
      .map((t, i) => t ?? i)
      .concat([])
      .slice(0, armies),
    diplo: {},
    tally: newTally(),
    skins: (S.skins || []).slice(0, mapDef.spawns.length),
    skinUnlocked: (S.skinUnlocked || []).slice(),
  };
  appState.battle = B;
  R.map = buildMap(mapDef);
  attachMap(B, R.map); // the battle carries its own hex map
  const occupied = new Set();
  const place = (pid, type, name, pred, from, extra) => {
    const start = from;
    const seen = new Set([key(start.c, start.r)]),
      q = [start];
    const air = UNIT_TYPES[type].domain === 'air';
    while (q.length) {
      const cur = q.shift();
      const k = (air ? 'A' : 'S') + key(cur.c, cur.r);
      if (pred(tileAt(cur.c, cur.r).t, cur) && !occupied.has(k)) {
        occupied.add(k);
        const T = UNIT_TYPES[type];
        B.units.push(
          Object.assign(
            {
              id: B.nextId++,
              pid,
              type,
              name,
              c: cur.c,
              r: cur.r,
              hp: T.hp,
              maxHp: T.hp,
              ammo: T.ammo,
              maxAmmo: T.ammo,
              fuel: T.fuel ?? null,
              maxFuel: T.fuel ?? null,
            },
            extra || {}
          )
        );
        return;
      }
      for (const n of neighborsRaw(cur.c, cur.r, mapDef.W, mapDef.H)) {
        const nk = key(n.c, n.r);
        if (!seen.has(nk)) {
          seen.add(nk);
          q.push(n);
        }
      }
    }
  };
  // Ships deploy to real seas: water bodies with deep water in them, not rivers or lakes (which are all shallows),
  // unless the map has no sea at all.
  const bigWater = new Set(),
    seen = new Set();
  for (const t of R.map.list) {
    if (!TERRAIN[t.t].water || seen.has(t.k)) continue;
    const comp = [t.k],
      q = [t];
    seen.add(t.k);
    while (q.length) {
      const cur = q.pop();
      for (const n of neighborsRaw(cur.c, cur.r, mapDef.W, mapDef.H)) {
        const nt = tileAt(n.c, n.r);
        if (TERRAIN[nt.t].water && !seen.has(nt.k)) {
          seen.add(nt.k);
          comp.push(nt.k);
          q.push(nt);
        }
      }
    }
    if (
      comp.filter(k => {
        const [c, r] = unkey(k);
        return tileAt(c, r).t === '~';
      }).length >= 2
    )
      comp.forEach(k => bigWater.add(k));
  }
  const spawnOk = {
    land: t => !TERRAIN[t].water && t !== 'm',
    air: () => true,
    sea: (t, h) => TERRAIN[t].water && (!bigWater.size || bigWater.has(key(h.c, h.r))),
  };
  players.forEach(p => {
    const s = mapDef.spawns[p.id];
    // Campaigns give each army its own roster (with campaign ids and veteran ranks); Quick battle shares one.
    const list = S.armyRosters ? S.armyRosters[p.id] : rosterList(currentRoster()).map(([type, name]) => ({ type, name }));
    for (const x of list) {
      if (!UNIT_TYPES[x.type]) continue;
      place(p.id, x.type, x.name, spawnOk[UNIT_TYPES[x.type].domain], s, x.cid ? { cid: x.cid, vet: x.vet || 0 } : null);
    }
  });
  B.roads = {};
  for (const k of mapDef.roads || []) B.roads[k] = true; // roads drawn into the map
  // Custom unit types in this battle travel with it, so saves and replays work without the Unit Editor's storage.
  B.customTypes = {};
  for (const u of B.units) {
    const T = UNIT_TYPES[u.type];
    if (T.custom) B.customTypes[T.id] = T;
  }
  // Teams: pad to one per army; the human's grants to allies come from the Diplomacy screen, AI allies grant everything.
  while (B.teams.length < B.players.length) B.teams.push(B.teams.length);
  for (const p of B.players)
    for (const o of B.players)
      if (p.id !== o.id && B.teams[p.id] === B.teams[o.id]) {
        (B.diplo[p.id] = B.diplo[p.id] || {})[o.id] = !p.ai
          ? Object.assign({ territory: true, resupply: true, passage: true }, S.grants || {})
          : { territory: true, resupply: true, passage: true };
      }
  B.structs = {};
  B.stats = { built: 0, captured: 0, destroyed: 0, landings: 0, portCalls: 0 };
  applyLayout(B, S.layout);
  ensureLogistics(B);
  // Phase 7 systems (each only when its rule is on)
  B.intel = {};
  B.decoys = [];
  B.funds = {};
  B.prodQueue = {};
  B.feints = {};
  if (B.rules.weather) initWeather(B);
  if (B.rules.seasons) B.seasonStart = Math.floor(rng() * 4); // seasons: a seeded starting season
  initVictoryPoints(B);
  B.rosterTypes = {}; // timed reinforcements draw from each army's starting units
  for (const u of B.units) (B.rosterTypes[u.pid] = B.rosterTypes[u.pid] || []).push(u.type);
  if (B.rules.morale) initMorale(B);
  if (B.rules.income || B.rules.production) for (const p of B.players) B.funds[p.id] = START_FUNDS;
  if (B.rules.fog) updateIntel(B);
  startReplayLog(B);
}

function buildMap(def) {
  const tiles = [];
  for (let r = 0; r < def.H; r++) {
    const row = [];
    for (let c = 0; c < def.W; c++) {
      const t = def.rows[r][c],
        w = toWorld(c, r),
        rnd = mulberry32(hash3(c, r, def.seed | 0));
      const speck = [];
      for (let i = 0; i < 6; i++) speck.push({ ox: (rnd() - 0.5) * 1.2, oy: (rnd() - 0.5) * 1.0, v: rnd() < 0.5 ? 1.16 : 0.84 });
      const decor = [];
      if (t === 'f')
        [
          [-0.4, -0.15],
          [0.35, -0.3],
          [0.05, 0.35],
        ].forEach(([a, b]) => decor.push({ k: 'tree', ox: a + (rnd() - 0.5) * 0.15, oy: b + (rnd() - 0.5) * 0.15, s: 0.8 + rnd() * 0.3 }));
      if (t === 'm') decor.push({ k: 'peak', ox: 0, oy: 0.15, s: 1.25 });
      if (t === 'h') decor.push({ k: 'hill', ox: -0.2, oy: 0.1, s: 1 }, { k: 'hill', ox: 0.3, oy: -0.25, s: 0.8 });
      if (t === 'c') decor.push({ k: 'city', ox: 0, oy: 0.2, s: 1 });
      row.push({
        c,
        r,
        k: key(c, r),
        t,
        wx: w.x,
        wy: w.y,
        z: tileZ(t),
        speck,
        decor,
        edge: [null, null, null, null, null, null],
        wave: rnd() * 6.28,
      });
    }
    tiles.push(row);
  }
  for (const row of tiles)
    for (const t of row) {
      for (const n of neighborsRaw(t.c, t.r, def.W, def.H)) {
        const nt = tiles[n.r][n.c];
        const a = Math.atan2(nt.wy - t.wy, nt.wx - t.wx);
        const i = ((Math.round(a / (Math.PI / 3)) % 6) + 6) % 6;
        t.edge[i] = nt;
      }
    }
  return { def, tiles, list: tiles.flat() };
}

const tileAt = (c, r, B = appState.battle) => B.map.tiles[r][c];

// On-map units. Units aboard a transport (u.in) are off the map: they can't be seen, targeted, or block hexes.
const aliveUnits = (B = appState.battle) => B.units.filter(u => u.hp > 0 && !u.in);

// Everything still alive, including cargo — used for victory checks and army counts.
const allAlive = (B = appState.battle) => B.units.filter(u => u.hp > 0);

const isTransport = u => !!UNIT_TYPES[u.type].carry;

// An army stays in the fight while it has a combat unit or a loaded transport. Empty transports alone can't win.
const fighting = u => !(isTransport(u) && UNIT_TYPES[u.type].domain === 'sea') || !!u.cargo; // an empty LST can't win; an APC still fights

const inFight = (pid, B = appState.battle) => allAlive(B).some(u => u.pid === pid && fighting(u));

// Free land hexes next to a transport where its cargo can come ashore.
function landingSpots(at, B = appState.battle) {
  const def = B.mapDef;
  return neighborsRaw(at.c, at.r, def.W, def.H).filter(n => landPassAt(n.c, n.r, B) && !unitAtLayer(n.c, n.r, false, B));
}

// LSTs carry any land unit except another transport; APCs carry infantry-type units only.
function canCarry(t, o) {
  const T = UNIT_TYPES[t.type],
    O = UNIT_TYPES[o.type];
  if (!T.carry || o === t || O.domain !== 'land' || O.carry) return false;
  if (T.carryKinds === 'foot') return !!O.foot; // half-tracks and other land carriers take soldiers on foot
  return T.carryKinds ? T.carryKinds.includes(o.type) : true;
}

const boardCandidates = (t, B = appState.battle) => aliveUnits(B).filter(o => o.pid === t.pid && canCarry(t, o) && hexDist(o, t) === 1);

const emptyTransportsNear = (u, B = appState.battle) =>
  aliveUnits(B).filter(o => o.pid === u.pid && isTransport(o) && !o.cargo && canCarry(o, u) && hexDist(o, u) === 1);

// Indexed lookup (rebuilt when units are added or the list is pruned).
const unitById = (id, B = appState.battle) => {
  if (B._idxOf !== B.units || B._idxLen !== B.units.length) {
    B._idx = new Map(B.units.map(u => [u.id, u]));
    B._idxOf = B.units;
    B._idxLen = B.units.length;
  }
  return B._idx.get(id);
};
// Every unit that ever fought, the fallen included (records, looks, kill counts).
const everyUnit = B => B.units.concat(B.fallen || []);
// Destroyed units leave the working list at the start of the next turn (after their death has played out), so
// every per-turn scan stops walking past them. They're kept in B.fallen for records.
function pruneFallen(B) {
  const dead = B.units.filter(u => u.hp <= 0);
  if (!dead.length) return;
  B.fallen = (B.fallen || []).concat(dead);
  B.units = B.units.filter(u => u.hp > 0);
}

const isAir = u => UNIT_TYPES[u.type].domain === 'air';

const lkey = (u, c, r) => (isAir(u) ? 'A' : 'S') + key(c, r);

function unitAtLayer(c, r, air, B = appState.battle) {
  return aliveUnits(B).find(u => u.c === c && u.r === r && isAir(u) === air);
}

function initUnitVisuals(B = appState.battle) {
  const cx = (B.mapDef.W * SQ3) / 2,
    cy = B.mapDef.H * 0.75;
  for (const u of B.units) {
    const t = tileAt(u.c, u.r, B);
    u.px = t.wx;
    u.py = t.wy;
    u.pz = t.z;
    u.fx = cx - t.wx;
    u.fy = cy - t.wy;
    u.hitT = -1e9;
  }
}

// A battle's hex map travels with it (B.map), so game logic never needs the global R.map. Not enumerable: it is
// never saved, cloned or fingerprinted (it is rebuilt from mapDef when a battle loads).
function attachMap(B, map) {
  Object.defineProperty(B, 'map', { value: map, writable: true, configurable: true, enumerable: false });
  return B;
}
