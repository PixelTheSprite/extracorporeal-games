// Battle rule toggles and victory conditions.
// ---------- Combat rules (toggled on the Quick Battle screen) ----------
const RULES = {
  zoc: {
    group: 'Combat',
    short: 'ZOC',
    label: 'Zones of control',
    desc: 'Ground and sea units stop when they move next to an enemy. Planes only stop next to enemy planes.',
  },
  realtime: {
    group: 'Combat',
    short: 'Real-time fire',
    label: 'Real-time fire',
    desc: 'Movement plays out step by step and every unit fires the moment an enemy enters range. Hold becomes Overwatch: up to two shots with better aim and damage.',
  },
  engage: {
    group: 'Combat',
    short: 'Engage',
    label: 'Engage orders',
    desc: 'Adds Engage (chase a target and fire once in range) and Attack-move (stop at the first enemy in range).',
  },
  terrRadius: {
    group: 'Territory',
    short: 'Supply radius',
    label: 'Supply radius',
    desc: "Flags and captured cities claim every hex around them (radius 1). Where two armies' rings overlap, the hex stays neutral.",
  },
  terrPaint: {
    group: 'Territory',
    short: 'Paint',
    label: 'Paint territory',
    desc: 'Ground and sea units claim every hex they move through, including enemy territory. Planes do not paint.',
  },
  terrSpread: {
    group: 'Territory',
    short: 'Spread',
    label: 'Territory spread',
    desc: 'Every other turn, territory connected to a supply point grows one hex outward into neutral hexes within 3 hexes of a supply point. It never spreads into enemy territory.',
  },
  exhaust: {
    group: 'Endgame',
    short: 'Exhaustion',
    label: 'Supply exhaustion',
    desc: 'If 6 turns pass with no damage dealt by anyone, the battle ends and the side with the best score wins: remaining unit HP, plus 10 per hex of territory and 50 per city or capturable structure held.',
  },
  attrition: {
    group: 'Endgame',
    short: 'Attrition',
    label: 'Attrition',
    desc: 'From 60% of the turn limit on, units that end a turn outside friendly territory (out of supply) lose 5% of their HP each turn.',
  },
  fog: {
    group: 'Fog and intel',
    short: 'Fog',
    label: 'Fog of war',
    desc: 'You only see what your units (and allies) can see: 3 hexes for ground units, more for ships and aircraft, less at night or in fog. Forests and hills block ground units’ view unless they stand on high ground. Enemies you lose sight of leave a last-known marker.',
  },
  intelFade: {
    group: 'Fog and intel',
    short: 'Fading intel',
    label: 'Fading intel',
    desc: 'Needs Fog of war. Sightings carry a confidence that falls each turn they aren’t refreshed, and units seen at long range (or at night, or in fog) are reported without their type.',
  },
  decoys: {
    group: 'Fog and intel',
    short: 'Decoys',
    label: 'Decoys',
    desc: 'Needs Fog of war. Soldiers on foot can plant a decoy tank (up to 3, lasting 6 turns). Enemies see it as a real sighting until one of their units comes within 2 hexes.',
  },
  aiDeception: {
    group: 'Fog and intel',
    short: 'AI deception',
    label: 'AI deception',
    desc: 'Needs Fog of war and Decoys. AI armies plant decoys and send a fast unit on a feint against one of your secondary positions.',
  },
  income: {
    group: 'Economy',
    short: 'Income',
    label: 'Income',
    desc: 'Armies start with 15 funds and earn 1 a turn, plus 3 per city and 2 per airfield, port or depot they hold.',
  },
  production: {
    group: 'Economy',
    short: 'Production',
    label: 'Mid-battle production',
    desc: 'Buy one unit a turn (🏭 Build, up to 20 per army): ground units at your cities, aircraft at your airfields or capital, ships at your ports or coastal cities. Without Income you only have the starting 15 funds.',
  },
  capitalLoss: {
    group: 'Economy',
    short: 'Capital loss',
    label: 'Capital loss',
    desc: 'An army whose capital (its starting city) is captured by an enemy is out of the battle.',
  },
  weather: {
    group: 'Conditions',
    short: 'Weather',
    label: 'Weather and time of day',
    desc: 'Weather changes every 3 turns (with a forecast): rain makes everyone harder to hit, fog cuts sight and hides infantry, storms ground aircraft. Every 8 turns end with 2 of night: sight −1 and long-range weapons −1 range.',
  },
  morale: {
    group: 'Conditions',
    short: 'Morale',
    label: 'Morale',
    desc: 'Units start at 60 morale and lose it when hit hard, isolated or when friends fall nearby, and regain it near friends, on friendly ground and with kills. Shaken units deal 20% less damage; broken units can’t fire until they rally.',
  },
  supplyLines: {
    group: 'Realism',
    short: 'Supply lines',
    label: 'Supply lines',
    desc: 'Ground units must trace a path over friendly ground or roads to a held city, flag, depot, port or airfield. Cut-off units can’t rearm or refuel (and with Attrition on, they’re the ones that suffer).',
  },
  entrench: {
    group: 'Realism',
    short: 'Entrench',
    label: 'Entrenchment',
    desc: 'Ground units that hold position dig in a level a turn (up to 3); each level cuts damage taken by 10%. Moving loses it.',
  },
  suppression: {
    group: 'Realism',
    short: 'Suppression',
    label: 'Suppression',
    desc: 'A unit that loses a quarter of its HP in one turn is suppressed the next: it can’t move and deals half damage.',
  },
  facing: {
    group: 'Realism',
    short: 'Facing',
    label: 'Armor facing',
    desc: 'Tanks and other vehicles face the way they last moved; hits from the side deal 25% more, from behind 50% more.',
  },
  urban: {
    group: 'Realism',
    short: 'Urban',
    label: 'Urban combat',
    desc: 'Cities give soldiers on foot strong cover (45%) but vehicles little (10%), and vehicles pay 1 extra movement to enter them.',
  },
  elevation: {
    group: 'Realism',
    short: 'Elevation',
    label: 'Elevation',
    desc: 'Firing down from hills or mountains deals 15% more damage (uphill 10% less), long-range weapons reach one hex further from high ground, and ground units on it see one hex further.',
  },
  surrender: {
    group: 'Realism',
    short: 'Surrender',
    label: 'Surrender',
    desc: 'A badly damaged (under 25% HP) or broken ground unit that is surrounded, or cut off for 2 turns with Supply lines on, gives up.',
  },
  command: {
    group: 'Realism',
    short: 'Command',
    label: 'Command radius',
    desc: 'Command posts are your held capital, depots and airfields, and your half-tracks. Ground units more than 6 hexes from all of them (or jammed) move 1 hex less.',
  },
  friction: {
    group: 'Realism',
    short: 'Friction',
    label: 'Order friction',
    desc: 'Each turn a unit has a 5% chance its order goes wrong (a move stops halfway, or it loses its target), more if shaken (+10%), broken (+20%), out of command (+5%) or jammed (+10%).',
  },
  ew: {
    group: 'Realism',
    short: 'EW',
    label: 'Electronic warfare',
    desc: 'Drones jam enemy units within 3 hexes: sight −2, and they count as out of command. A drone of your own within 3 hexes cancels it.',
  },
  airSup: {
    group: 'Realism',
    short: 'Air superiority',
    label: 'Air superiority',
    desc: 'Where only one side’s fighters are within 4 hexes, that side controls the air: its units there deal 10% more damage, and enemy bombers and drones there are 10 points easier to hit.',
  },
  aaUmbrella: {
    group: 'Realism',
    short: 'AA umbrellas',
    label: 'AA umbrellas',
    desc: 'Aircraft attacking a target within 2 hexes of that side’s anti-aircraft unit deal 20% less damage. Umbrellas are shown on the map.',
  },
  artillery: {
    group: 'Realism',
    short: 'Artillery',
    label: 'Artillery',
    desc: 'Adds the M7 Priest self-propelled howitzer (range 2–5). It fires at anything a friendly unit can see, but not on a turn it moves; firing gives its position away until the end of the next turn, and enemy artillery hunts it.',
  },
  subs: {
    group: 'Realism',
    short: 'Submarines',
    label: 'Submarines',
    desc: 'Adds the Gato-class submarine. Enemies only see it within 1 hex (2 for destroyers), and only destroyers can attack it; its torpedoes hit ships hard.',
  },
  mines: {
    group: 'Realism',
    short: 'Mines',
    label: 'Mines',
    desc: 'Engineers lay land mines and destroyers sea mines (Lay mine; up to 6 per army), hidden from the enemy. An enemy entering one takes 30 damage (40 at sea) and stops; engineers clear land mines safely.',
  },
  carriers: {
    group: 'Realism',
    short: 'Carriers',
    label: 'Carriers',
    desc: 'Adds the Essex-class carrier. Your aircraft ending a turn over it land as at an airfield: refueled, rearmed, repaired.',
  },
  rail: {
    group: 'Realism',
    short: 'Railways',
    label: 'Railways and demolition',
    desc: 'Roads through your own territory act as railways (a third of the movement cost). Engineers can blow up an adjacent bridge (Blow bridge).',
  },
  seasons: {
    group: 'Realism',
    short: 'Seasons',
    label: 'Seasons',
    desc: 'The battle starts in a season and moves on every 15 turns. Spring and autumn mud (and rain, with Weather on) slows vehicles off-road; winter snow slows every ground unit off-road, but frozen shallows can be crossed on foot or by vehicle.',
  },
  reinforce: {
    group: 'Realism',
    short: 'Reinforcements',
    label: 'Timed reinforcements',
    desc: 'Every 8 turns each army receives 2 units, drawn in turn from its starting force, at its capital (if it still holds it).',
  },
  vp: {
    group: 'Realism',
    short: 'Victory points',
    label: 'Victory points and war weariness',
    desc: 'Cities score 1 point a turn for their holder’s team (an enemy capital 3); the first team to 3 points per city on the map wins. An army that loses 60% of its starting strength sues for peace and leaves the battle.',
  },
  infoOps: {
    group: 'Realism',
    short: 'Info ops',
    label: 'Information operations',
    desc: 'Rifle squads can Broadcast: enemy units within 3 hexes lose 10 morale (needs Morale) unless 2 of their own are nearby to verify, and with Fog and Fading intel the enemy gets a false report nearby.',
  },
  ammo: {
    group: 'Realism',
    short: 'Ammunition',
    label: 'Ammunition types',
    desc: 'Tanks, artillery and warships load armor-piercing (25% more against vehicles and ships, 30% less against soldiers) or high-explosive rounds (25% more against soldiers and structures, 25% less against armor).',
  },
  missiles: {
    group: 'Strategic',
    short: 'Missiles',
    label: 'Missile silos',
    desc: 'Engineers can build missile silos (4 turns; 15 funds with the economy on). A silo charges one missile in about 5 turns (1 turn faster for every 2 cities you hold, at least 2). Launch from the HUD: 60 damage to one hex and 20 to the hexes around it, anywhere your side can see within 10 hexes. Anti-aircraft units and warships near the target can intercept (40% each, up to 80%).',
  },
  cityDev: {
    group: 'Strategic',
    short: 'City development',
    label: 'City development',
    desc: 'Needs Income. Invest in a city you hold to raise it to level 2 (20 funds) or 3 (35 funds), 3 turns each. Each level above 1 adds 2 income, 10% less damage to units in the city and 5% healing a turn; level 3 cities add a purchase a turn and speed up nearby silos. A captured city drops a level.',
  },
};

// Battles saved before rules existed have no rules object and play with classic resolution.
const rules = (B = appState.battle) =>
  (B && B.rules) || {
    zoc: false,
    realtime: false,
    engage: false,
    terrRadius: false,
    terrPaint: false,
    terrSpread: false,
  };

function rulesSummary(r) {
  const on = Object.keys(RULES)
    .filter(k => r[k])
    .map(k => RULES[k].label.toLowerCase());
  return on.length ? on.join(', ') : 'classic rules';
}

// ---------- Victory conditions ----------
const VICTORY = {
  destruction: {
    label: 'Enemy unit destruction',
    desc: 'Win by destroying every enemy army. An army is out when only empty transports remain.',
  },
  territory: {
    label: 'Territory control',
    desc: 'Win by holding a share of the map for several turns in a row. Destroying every enemy still wins too.',
  },
};

// Battles saved before victory conditions existed play to destruction.
const victory = (B = appState.battle) => (B && B.victory) || { mode: 'destruction', pct: 50, hold: 3 };

function victorySummary(v) {
  return v.mode === 'territory' ? `hold ${v.pct}% of the map for ${v.hold} turn${v.hold > 1 ? 's' : ''}` : 'destroy all enemy units';
}

const territoryShare = (B, pid) => Object.values(B.territory || {}).filter(v => v === pid).length / (B.mapDef.W * B.mapDef.H);

// A hex is in an enemy zone of control if an enemy on the same layer (air vs surface) is adjacent.
function inZOC(u, h, B = appState.battle) {
  const air = isAir(u);
  return aliveUnits(B).some(e => isEnemy(e.pid, u.pid, B) && isAir(e) === air && hexDist(e, h) === 1);
}
