// AI order planning.
// ---------- AI ----------
// AI scoring weights, in one place for tuning. Hex scores are summed per candidate hex; the best hex wins.
const AI_WEIGHTS = {
  // objectives (campaign) and escorts
  escortDistance: 6,
  escortThreat: 1.6,
  escortStray: 10,
  guardRadius: 3,
  guardPull: 2,
  objectiveCapturer: 6,
  objectiveOther: 2,
  huntEscort: 15,
  // attacking
  killShot: 35,
  finishWounded: 15,
  counterFire: 0.5,
  threatMoving: 0.5,
  threatHolding: 0.35,
  cover: 20,
  jitter: 1.5,
  // captures (cities, structures, capitals under Capital loss)
  finishCapture: 80,
  captureStructure: 55,
  captureCity: 45,
  captureCapital: 70,
  // supply, morale and movement habits
  brokenRetreat: 10,
  feintPull: 5,
  homeDistance: 6,
  homeArrive: 40,
  resupplyEmpty: 8,
  resupplyLow: 4,
  paintGround: 6,
  attritionAvoid: 12,
  // realism rules
  commandAvoid: 4,
  counterBattery: 20,
  mineChance: 0.3,
  vpCity: 20,
  broadcastChance: 0.2,
  strikeMin: 40, // a launch must be worth at least this much
  stayDugIn: 4,
  supplyAvoid: 10,
  highGround: 5,
  engineerBehindFront: 15,
  engineerNearFriends: 5,
  fuelReserve: 60,
  holdInSupply: 20,
  holdInStalemate: -20,
};
// Plans every order for one AI army. Split into steps that share one context object:
// what the army knows (aiContext), transport pairings, deception, then each unit in turn.
function planAI(p, B = appState.battle) {
  const ctx = aiContext(p, B);
  planTransportPairs(ctx);
  planDeception(ctx);
  planMines(ctx);
  planBroadcasts(ctx);
  planMissiles(ctx);
  planInvest(ctx);
  for (const u of ctx.mine) planUnit(ctx, u);
  chooseAmmo(ctx);
  if (ctx.B.rules.production) planProduction(p, B);
  return ctx.orders;
}
// Everything the army knows before it plans: enemies, threats, routes, supply, and the scoring helpers.
function aiContext(p, B = appState.battle) {
  const S = STRATS[p.ai] || STRATS.balanced,
    obj = B.objective;
  const mine = aliveUnits(B)
    .filter(u => u.pid === p.id)
    .sort((a, b) => UNIT_TYPES[b.type].move - UNIT_TYPES[a.type].move);
  // Under fog of war the AI knows only what its team sees, plus its sightings (decoys included); with nothing
  // known at all it heads for the enemy capitals.
  const fog = fogOn(B);
  if (fog) computeVision(B);
  const enemies = aliveUnits(B).filter(u => isEnemy(u.pid, p.id, B) && canSee(p.id, u, B));
  const contacts = fog ? sightingsFor(p.id, B) : [];
  const enemyCapitals = B.players.filter(o => isEnemy(o.id, p.id, B) && inFight(o.id, B)).map(o => B.mapDef.spawns[o.id]);
  let huntPoints =
    enemies.length || contacts.length ? enemies.map(e => ({ c: e.c, r: e.r })).concat(contacts) : fog ? enemyCapitals.slice() : [];
  // With Capital loss on, taking a capital knocks an army out, so enemy capitals are always worth heading for.
  if (B.rules.capitalLoss) huntPoints = huntPoints.concat(enemyCapitals);
  if (B.rules.missiles)
    huntPoints = huntPoints.concat(
      Object.entries(B.structs)
        .filter(([, x]) => x.kind === 'silo' && x.owner != null && isEnemy(x.owner, p.id, B))
        .map(([k]) => keyHex(k))
    );
  const isEnemyCapital = h => enemyCapitals.some(c => c.c === h.c && c.r === h.r);
  const orders = {},
    reserved = new Set(mine.map(u => lkey(u, u.c, u.r)));
  // Stalemate breaker: after STALL_TURNS turns with no damage dealt by anyone, every AI pushes forward.
  const stall = (B.quiet || 0) >= STALL_TURNS;
  // Late in a battle every AI presses harder and takes more risks, so armies meet before the turn limit.
  const limit = B.turnLimit || turnLimit(B.mapDef),
    late = clamp((B.turn - limit * 0.5) / (limit * 0.5), 0, 1);
  const riskW = S.risk * (1 - 0.4 * late);
  const attritionNow = B.rules.attrition && B.turn + 2 >= Math.ceil(limit * ATTRITION_FROM);
  const approachW =
    late * 3 +
    S.approach +
    (p.ai === 'defensive' ? B.turn * 0.06 : 0) +
    Math.max(0, B.turn - 8) * 0.12 +
    (stall ? 2 + (B.quiet - STALL_TURNS) * 0.5 : 0);
  const threatAt = (u, h) => {
    let th = 0;
    for (const e of enemies) {
      if (!canHit(e, u, B)) continue;
      const E = UNIT_TYPES[e.type];
      if (hexDist(e, h) <= E.move * 0.75 + E.range[1]) th += expDmg(e, u, h, false, B);
    }
    return th;
  };
  const nearest = h => huntPoints.reduce((m, e) => Math.min(m, hexDist(e, h)), huntPoints.length ? Infinity : 0);
  // Approach is measured by travel cost over terrain, not straight-line distance, so units route around ridges.
  const fields = {};
  const fieldFor = dom => fields[dom] || (fields[dom] = distField(dom, huntPoints, B));
  const approachDist = (u, h) => {
    const dom = UNIT_TYPES[u.type].domain;
    if (dom === 'air') return nearest(h);
    const f = fieldFor(dom).get(key(h.c, h.r));
    return f == null ? nearest(h) * 1.5 : f;
  };
  // Ferry logic: a land unit is stranded if no enemy land unit shares its landmass.
  const comp = landComponents(B);
  const enemyLand = enemies.filter(e => UNIT_TYPES[e.type].domain === 'land');
  const enemyComps = new Set(enemyLand.map(e => comp.get(key(e.c, e.r))));
  const stranded = x => enemyLand.length && UNIT_TYPES[x.type].domain === 'land' && !enemyComps.has(comp.get(key(x.c, x.r)));
  // Logistics awareness: where is home, and who is running low?
  const ownHexes = Object.entries(B.territory || {})
    .filter(([, v]) => friendlyGround(v, p.id, B))
    .map(([k]) => {
      const [c, r] = unkey(k);
      return { c, r };
    });
  const distOwn = h => (ownHexes.length ? ownHexes.reduce((m, o) => Math.min(m, hexDist(o, h)), Infinity) : 0);
  const lowSupply = x => x.ammo <= 1 || (x.maxFuel && x.fuel <= x.maxFuel * 0.35);
  let flagsThisTurn = 0;
  // Enemy structures (finished or under construction) and our own ports, for bombardment and resupply scoring.
  const enemyStructs = Object.entries(B.structs || {})
    .map(([k, s]) => {
      const [c, r] = unkey(k);
      return { c, r, s };
    })
    .filter(x => {
      const o = x.s.build ? x.s.build.pid : x.s.owner;
      return o != null && isEnemy(o, p.id, B);
    });
  const ownPorts = armyStructs(p.id, 'port', B),
    ownFields = armyStructs(p.id, 'airfield', B).concat(B.rules.carriers ? mine.filter(x => UNIT_TYPES[x.type].deck) : []); // carriers are airfields too
  const fighters = mine.filter(x => !UNIT_TYPES[x.type].repairs && !(isTransport(x) && UNIT_TYPES[x.type].domain === 'sea'));
  const front = fighters.length ? Math.min(...fighters.map(x => nearest(x))) : 0; // how close our closest fighter is to the enemy
  const friendDist = h => (fighters.length ? Math.min(...fighters.map(x => hexDist(x, h))) : 0);
  const territoryGame = victory(B).mode === 'territory';
  return {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    flagsThisTurn,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  };
}
// Transports pick up passengers: LSTs collect stranded units, APCs carry infantry toward the fighting.
function planTransportPairs(ctx) {
  const {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  } = ctx;
  for (const t of mine) {
    if (!isTransport(t) || t.cargo || orders[t.id]) continue;
    const T0 = UNIT_TYPES[t.type];
    // LSTs pick up stranded units; APCs pick up infantry that is still far from the fighting.
    const c =
      T0.domain === 'sea'
        ? mine.find(x => stranded(x) && !orders[x.id] && canCarry(t, x) && hexDist(x, t) === 1)
        : mine.find(x => !orders[x.id] && canCarry(t, x) && hexDist(x, t) === 1 && nearest(x) > 5);
    if (c) {
      orders[t.id] = { type: 'load', cargo: c.id };
      orders[c.id] = { type: 'board', transport: t.id };
    } else if (T0.domain === 'sea') {
      // Sail next to a stranded unit and load it in the same turn.
      reserved.delete(lkey(t, t.c, t.r));
      const reach = reachable(t, k => reserved.has(k), B);
      let pick = null;
      for (const n of reach.values()) {
        if (!n.end || n.cost === 0) continue;
        const x = mine.find(x => stranded(x) && !orders[x.id] && canCarry(t, x) && hexDist(x, n) === 1);
        if (x && (!pick || n.cost < pick.n.cost)) pick = { n, x };
      }
      if (pick) {
        orders[t.id] = { type: 'move', path: pathTo(pick.n), target: null, load: pick.x.id };
        orders[pick.x.id] = { type: 'board', transport: t.id };
        reserved.add(lkey(t, pick.n.c, pick.n.r));
      } else reserved.add(lkey(t, t.c, t.r));
    }
  }
}
// AI deception (with fog and decoys): decoys now and then, and a 6-turn feint by one fast unit.
function planDeception(ctx) {
  const {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  } = ctx;
  if (fog && B.rules.decoys && B.rules.aiDeception) {
    if ((B.decoys || []).filter(d => d.pid === p.id).length < 2 && rng(B) < 0.5) {
      const cand = mine.find(u => !orders[u.id] && canPlantDecoy(u, B) && nearest(u) > 3);
      if (cand) orders[cand.id] = { type: 'decoy' };
    }
    B.feints = B.feints || {};
    const f = B.feints[p.id],
      fu = f && unitById(f.unitId, B);
    if (B.turn >= 3 && (!f || B.turn > f.until || !fu || fu.hp <= 0)) {
      const targets = supplyPoints(B).filter(
        sp =>
          isEnemy(sp.pid, p.id, B) && !(B.mapDef.spawns[sp.pid] && B.mapDef.spawns[sp.pid].c === sp.c && B.mapDef.spawns[sp.pid].r === sp.r)
      );
      const u = mine
        .filter(x => UNIT_TYPES[x.type].domain === 'land' && !UNIT_TYPES[x.type].repairs && !x.in && !isTransport(x) && !orders[x.id])
        .sort((a, b) => UNIT_TYPES[b.type].move - UNIT_TYPES[a.type].move)[0];
      if (u && targets.length) {
        const t = targets[Math.floor(rng(B) * targets.length)];
        B.feints[p.id] = { unitId: u.id, target: { c: t.c, r: t.r }, until: B.turn + 6 };
        B.stats.feints = (B.stats.feints || 0) + 1;
      }
    }
  }
}
// One unit's order: score every reachable hex (and holding still) and pick the best.
function planUnit(ctx, u) {
  const W = AI_WEIGHTS;
  const {
    p,
    B,
    S,
    obj,
    mine,
    fog,
    enemies,
    contacts,
    enemyCapitals,
    huntPoints,
    isEnemyCapital,
    orders,
    reserved,
    stall,
    limit,
    late,
    riskW,
    attritionNow,
    approachW,
    threatAt,
    nearest,
    fields,
    fieldFor,
    approachDist,
    comp,
    enemyLand,
    enemyComps,
    stranded,
    ownHexes,
    distOwn,
    lowSupply,
    enemyStructs,
    ownPorts,
    ownFields,
    fighters,
    front,
    friendDist,
    territoryGame,
  } = ctx;
  const feint = (B.feints || {})[p.id];

  if (orders[u.id]) return; // already paired for loading
  reserved.delete(lkey(u, u.c, u.r));
  const T = UNIT_TYPES[u.type];
  const reach = reachable(u, k => reserved.has(k), B);
  // Aircraft and ships with a home base (airfield / port) head there when low on supplies or badly damaged.
  const home = T.domain === 'air' ? ownFields : T.domain === 'sea' ? ownPorts : null;
  const distHome = h => (home && home.length ? Math.min(...home.map(x => hexDist(x, h))) : Infinity);
  // Bingo fuel: aircraft turn for home while they still have fuel for the trip back plus one turn of margin.
  const bingo =
    T.domain === 'air' &&
    u.fuel != null &&
    home &&
    home.length &&
    u.fuel <= (distHome(u) + T.move) * (T.fuelRate || 1) + 2 * (T.upkeep ?? AIR_UPKEEP);
  // Damaged units retreat to repair only below a third of their health, and not during a stalemate.
  const wantsHome = !!(home && home.length && (lowSupply(u) || bingo || (!stall && u.hp < u.maxHp / 3)));
  const aw = u.ammo === 0 || wantsHome || broken(u, B) ? 0 : approachW; // out of ammo, heading home or broken: stop advancing
  const feinting = feint && feint.unitId === u.id && B.turn <= feint.until;
  if (stranded(u)) {
    // Head for the nearest empty transport; pairing happens once they're adjacent.
    const ferry = mine
      .filter(x => isTransport(x) && !x.cargo && UNIT_TYPES[x.type].domain === 'sea' && canCarry(x, u))
      .sort((a, b) => hexDist(a, u) - hexDist(b, u))[0];
    if (ferry && hexDist(ferry, u) > 1) {
      const n = [...reach.values()].filter(n => n.end).sort((a, b) => hexDist(a, ferry) - hexDist(b, ferry) || a.cost - b.cost)[0];
      if (n && n.cost > 0) {
        const path = pathTo(n);
        orders[u.id] = { type: 'move', path, target: null };
        const f = path[path.length - 1];
        reserved.add(lkey(u, f.c, f.r));
        return;
      }
    }
  }
  const escortee = obj && obj.type === 'escort' && u.id === obj.unitId;
  // Campaign objectives: the attacker (army 0) pushes to the target; defenders stay near what they guard.
  // Applied to every option, holding included, so standing still is never free.
  const objCost = h => {
    if (!obj || !obj.target) return 0;
    const dT = hexDist(h, obj.target);
    if (p.id === 0) {
      if (escortee) return dT * W.escortDistance + threatAt(u, h) * W.escortThreat + Math.max(0, friendDist(h) - 1) * W.escortStray; // heads in carefully, never ahead of its escorts
      return T.domain === 'land' ? dT * (obj.type === 'capture' && T.captures ? W.objectiveCapturer : W.objectiveOther) : 0;
    }
    return T.domain === 'land' ? Math.max(0, dT - W.guardRadius) * W.guardPull : 0;
  };
  if (T.repairs && !escortee) {
    const plan = planEngineer(u, reach, mine, B);
    if (plan) {
      orders[u.id] = plan;
      const f = plan.path ? plan.path[plan.path.length - 1] : { c: u.c, r: u.r };
      reserved.add(lkey(u, f.c, f.r));
      return;
    }
  }
  if (T.carry && T.domain === 'land' && u.cargo) {
    const plan = planAPC(u, reach, nearest, p.id, B);
    if (plan) {
      orders[u.id] = plan;
      const f = plan.path ? plan.path[plan.path.length - 1] : { c: u.c, r: u.r };
      reserved.add(lkey(u, f.c, f.r));
      return;
    }
  }
  if (T.carry && T.domain === 'sea') {
    const plan = planTransport(u, reach, { comp, enemyComps, enemyLand, nearest, stranded: mine.filter(x => stranded(x)) }, B);
    if (plan) {
      orders[u.id] = plan;
      const f = plan.path ? plan.path[plan.path.length - 1] : { c: u.c, r: u.r };
      reserved.add(lkey(u, f.c, f.r));
      return;
    }
  }
  let best = null;
  for (const node of reach.values()) {
    if (!node.end) continue;
    const h = { c: node.c, r: node.r };
    let atk = 0,
      tgt = null;
    if (u.ammo > 0)
      for (const e of enemies) {
        if (!canHit(u, e, B) || !inRange(u.type, h, e, B)) continue;
        const d = expDmg(u, e, e, false, B);
        const counter = canHit(e, u, B) && inRange(e.type, e, h, B) ? expDmg(e, u, h, false, B) * W.counterFire * riskW : 0;
        const sc =
          d +
          (d >= e.hp ? W.killShot : 0) +
          S.focus * (1 - e.hp / e.maxHp) * W.finishWounded -
          counter +
          (obj && obj.type === 'escort' && e.id === obj.unitId ? W.huntEscort : 0) +
          (UNIT_TYPES[e.type].indirect && revealed(e, B) ? W.counterBattery : 0);
        if (sc > atk) {
          atk = sc;
          tgt = e;
        }
      }
    const cover = T.domain === 'land' ? terrainDef(T, tileAt(h.c, h.r, B).t, B) * W.cover : 0;
    const realism =
      T.domain !== 'land'
        ? 0
        : (B.rules.supplyLines && !inSupply(B, u, h) ? -W.supplyAvoid : 0) +
          (B.rules.elevation && elevAt(h, B) >= 2 ? W.highGround : 0) +
          (B.rules.command && outOfCommand(u, h, B) ? -W.commandAvoid : 0);
    let score =
      atk * S.atk - threatAt(u, h) * riskW * W.threatMoving - approachDist(u, h) * aw + cover * S.cover + realism + rng(B) * W.jitter;
    if (T.captures && capturable(h, p.id, B)) {
      const site = captureSite(h, B);
      score +=
        (site.capPid === p.id ? W.finishCapture : site.kind ? W.captureStructure : W.captureCity) +
        (B.rules.vp ? W.vpCity : 0) +
        (B.rules.capitalLoss && isEnemyCapital(h) ? W.captureCapital : 0);
    }
    // Bombard an enemy structure from here (used when there is no unit to shoot)
    let satk = 0,
      stgt = null;
    if (u.ammo > 0 && effOf(T).land)
      for (const es of enemyStructs) {
        if (!inRange(u.type, h, es, B)) continue;
        const d = structDamage(u, es.s, undefined, B),
          v = STRUCTS[es.s.kind].value,
          sc = v * Math.min(1, d / es.s.hp) + (d >= es.s.hp ? v : 0);
        if (sc > satk) {
          satk = sc;
          stgt = es;
        }
      }
    if (!tgt && stgt) score += satk * S.atk;
    if (broken(u, B)) score -= distOwn(h) * W.brokenRetreat; // broken: fall back toward supply
    if (feinting) score -= hexDist(h, feint.target) * W.feintPull; // the feint
    if (wantsHome) {
      // aircraft and ships go back to their own airfield or port to rearm and repair
      const dh = Math.min(...home.map(x => hexDist(x, h)));
      score -= dh * W.homeDistance;
      if (T.domain === 'air' ? dh === 0 : dh <= 1) score += W.homeArrive;
    } else if (lowSupply(u)) score -= distOwn(h) * (u.ammo === 0 ? W.resupplyEmpty : W.resupplyLow);
    {
      const ow = B.territory[key(h.c, h.r)];
      if (territoryGame && !isAir(u) && ow !== p.id && !grants(ow, p.id, 'territory', B)) score += W.paintGround + node.cost;
    } // painting more ground (not an ally's)
    if (attritionNow && !isAir(u) && !friendlyGround(B.territory[key(h.c, h.r)], p.id, B)) score -= W.attritionAvoid; // attrition: stay in supply
    score -= objCost(h);
    if (T.repairs && !stall) {
      // engineers stay behind the front line and close to friends (until a stalemate)
      const nh = nearest(h);
      if (nh < front + 1) score -= (front + 1 - nh) * W.engineerBehindFront;
      const fd = friendDist(h);
      if (fd > 2) score -= (fd - 2) * W.engineerNearFriends;
    }
    if (T.domain === 'air' && u.fuel != null && u.fuel - (node.cost + distOwn(h)) * (T.fuelRate || 1) - (T.upkeep ?? AIR_UPKEEP) < 0)
      score -= W.fuelReserve; // keep enough fuel to get home
    if (!best || score > best.score) best = { score, node, tgt, stgt: tgt ? null : stgt };
  }
  let holdScore =
    (B.rules.entrench ? (u.dug || 0) * W.stayDugIn : 0) + // don't throw away a dug-in position lightly
    (B.rules.supplyLines && T.domain === 'land' && !inSupply(B, u) ? -W.supplyAvoid : 0) +
    (lowSupply(u) && B.territory[key(u.c, u.r)] === p.id ? W.holdInSupply : 0) +
    (stall ? W.holdInStalemate : S.hold) -
    threatAt(u, u) * riskW * W.threatHolding -
    approachDist(u, u) * aw;
  holdScore -= objCost(u);
  if (broken(u, B)) holdScore -= distOwn(u) * W.brokenRetreat;
  if (feinting) holdScore -= hexDist(u, feint.target) * W.feintPull;
  if (attritionNow && !isAir(u) && !friendlyGround(B.territory[key(u.c, u.r)], p.id, B)) holdScore -= W.attritionAvoid;
  // Staying put pays the same "far from home" cost as moving, so units that need supplies don't just wait.
  if (wantsHome) {
    const dh = distHome(u);
    holdScore -= dh * W.homeDistance;
    if (T.domain === 'air' ? dh === 0 : dh <= 1) holdScore += W.homeArrive;
  } else if (lowSupply(u)) holdScore -= distOwn(u) * (u.ammo === 0 ? W.resupplyEmpty : W.resupplyLow);
  let final = { c: u.c, r: u.r };
  if (!best || (!best.tgt && holdScore > best.score)) orders[u.id] = { type: 'hold' };
  else if (best.node.cost === 0)
    orders[u.id] = best.tgt
      ? { type: 'fire', target: best.tgt.id }
      : best.stgt
        ? { type: 'fire', starget: { c: best.stgt.c, r: best.stgt.r } }
        : { type: 'hold' };
  else {
    const path = pathTo(best.node);
    if (B.rules.engage && best.tgt && T.domain !== 'air')
      orders[u.id] = { type: 'engage', target: best.tgt.id }; // aircraft keep a planned path so the fuel-home check holds
    else if (B.rules.engage && p.ai === 'aggressive' && !best.tgt) orders[u.id] = { type: 'amove', path };
    else
      orders[u.id] = Object.assign(
        { type: 'move', path, target: best.tgt ? best.tgt.id : null },
        best.stgt ? { starget: { c: best.stgt.c, r: best.stgt.r } } : {}
      );
    final = path[path.length - 1];
  }
  // Capture a city we're ending on; otherwise plant a forward flag far from home.
  const stays = final.c === u.c && final.r === u.r;
  if (T.captures && capturable(final, p.id, B)) {
    orders[u.id] = stays
      ? { type: 'capture' }
      : { type: 'move', path: pathTo(best.node), target: best.tgt ? best.tgt.id : null, capture: true };
  } else if (
    T.domain === 'land' &&
    ctx.flagsThisTurn < (territoryGame ? 2 : 1) &&
    !(best && best.tgt) &&
    canFlagAt(final, B) &&
    B.territory[key(final.c, final.r)] !== p.id &&
    distOwn(final) >= 2
  ) {
    const o = orders[u.id];
    if (o.type === 'move' || o.type === 'amove') {
      o.flag = true;
      ctx.flagsThisTurn++;
    } else if (o.type === 'hold') {
      orders[u.id] = { type: 'flag' };
      ctx.flagsThisTurn++;
    }
  }
  // Engineers with nothing to repair lay road wherever they stop.
  if (T.builds && !(best && best.tgt) && canRoadAt(final, B)) {
    const o = orders[u.id];
    if (o.type === 'move' || o.type === 'amove') {
      if (!o.flag) o.road = true;
    } else if (o.type === 'hold') orders[u.id] = { type: 'road' };
  }
  reserved.add(lkey(u, final.c, final.r));
}

// Multi-source travel cost from every enemy position, over terrain this domain can cross.
function distField(dom, sources, B = appState.battle) {
  const def = B.mapDef,
    dist = new Map(),
    open = heapOf(n => n.d);
  const passCost = (c, r) => {
    const v = MOVE_COST[dom][tileAt(c, r, B).t];
    return v != null ? v : dom === 'land' && bridgeAt(c, r, B) ? 1 : null;
  };
  for (const e of sources) {
    if (passCost(e.c, e.r) == null) continue;
    const k = key(e.c, e.r);
    if (!dist.has(k)) {
      dist.set(k, 0);
      open.push({ c: e.c, r: e.r, d: 0 });
    }
  }
  while (open.length) {
    const cur = open.shift();
    if (cur.d > dist.get(key(cur.c, cur.r))) continue;
    for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
      const cost = passCost(n.c, n.r);
      if (cost == null) continue;
      const k = key(n.c, n.r),
        nd = cur.d + cost;
      if (!dist.has(k) || dist.get(k) > nd) {
        dist.set(k, nd);
        open.push({ c: n.c, r: n.r, d: nd });
      }
    }
  }
  return dist;
}

// APC AI: drive the infantry toward the front (or an enemy-held city) and drop it off within a few hexes.
function planAPC(u, reach, nearest, pid, B = appState.battle) {
  const cityGoal = h => {
    let best = Infinity;
    for (const k of Object.keys(B.cities || {})) {
      if (B.cities[k].owner != null && !isEnemy(B.cities[k].owner, pid, B)) continue;
      const [c, r] = unkey(k);
      best = Math.min(best, hexDist({ c, r }, h));
    }
    return best;
  };
  const goal = h => Math.min(nearest(h), cityGoal(h));
  const ends = [...reach.values()].filter(n => n.end);
  // Close enough already: unload toward the goal
  if (goal(u) <= 4) {
    const spot = landingSpots(u, B).sort((a, b) => goal(a) - goal(b))[0];
    return spot ? { type: 'unload', unload: { c: spot.c, r: spot.r } } : null;
  }
  const n = ends.filter(n => nearest(n) >= 2).sort((a, b) => goal(a) - goal(b) || a.cost - b.cost)[0];
  if (!n || n.cost === 0) return null;
  const spot = goal(n) <= 4 ? landingSpots(n, B).sort((a, b) => goal(a) - goal(b))[0] : null;
  const o = { type: 'move', path: pathTo(n), target: null };
  if (spot) o.unload = { c: spot.c, r: spot.r };
  return o;
}

// Engineer AI: fix the most damaged friend in reach (below 80% health), adjacent first.
function planEngineer(u, reach, mine, B = appState.battle) {
  const hurt = mine.filter(x => x !== u && !x.in && x.hp <= x.maxHp * 0.8).sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp);
  if (!hurt.length) return planBuild(u, reach, mine, B);
  const adj = hurt.find(x => hexDist(x, u) === 1);
  if (adj) return { type: 'repair', mend: adj.id };
  const ends = [...reach.values()].filter(n => n.end && n.cost > 0);
  for (const x of hurt) {
    const n = ends.filter(n => hexDist(n, x) === 1).sort((a, b) => a.cost - b.cost)[0];
    if (n) return { type: 'move', path: pathTo(n), target: null, repair: x.id };
  }
  return planBuild(u, reach, mine, B);
}
// Engineer AI, when nobody needs repairs: finish our own scaffold if one is in reach, otherwise start the
// structure the army lacks most (airfield if it has aircraft, port if it has ships, then a depot, then
// fortifications near the front) on our own ground, away from the enemy.
function planBuild(u, reach, mine, B = appState.battle) {
  const pid = u.pid,
    def = B.mapDef;
  // No building during a stalemate, or when the engineer is all that's left to fight with: go fight instead.
  if ((B.quiet || 0) >= STALL_TURNS || !mine.some(x => x !== u && !UNIT_TYPES[x.type].repairs && fighting(x))) return null;
  const enemies = aliveUnits(B).filter(e => isEnemy(e.pid, pid, B));
  const near = h => enemies.reduce((m, e) => Math.min(m, hexDist(e, h)), Infinity);
  const ends = [...reach.values()].filter(n => n.end);
  const order = (n, kind) =>
    n.cost === 0
      ? { type: 'build', kind, at: { c: n.c, r: n.r } }
      : { type: 'move', path: pathTo(n), target: null, build: { kind, at: { c: n.c, r: n.r } } };
  for (const n of ends.sort((a, b) => a.cost - b.cost)) {
    const s = structAt(n.c, n.r, B);
    if (s && s.build && s.build.pid === pid && s.kind !== 'bridge') return order(n, s.kind);
  }
  const has = kind => Object.values(B.structs).some(s => s.kind === kind && (s.build ? s.build.pid : s.owner) === pid);
  const forts = Object.values(B.structs).filter(s => s.kind === 'fort' && (s.build ? s.build.pid : s.owner) === pid).length;
  const front = near(u);
  let kind = null;
  if (mine.some(x => UNIT_TYPES[x.type].domain === 'air') && !has('airfield')) kind = 'airfield';
  else if (mine.some(x => UNIT_TYPES[x.type].domain === 'sea') && !has('port')) kind = 'port';
  else if (!has('depot')) kind = 'depot';
  else if (
    B.rules.missiles &&
    Object.values(B.structs).filter(x => x.kind === 'silo' && (x.build ? x.build.pid : x.owner) === pid).length < 2 &&
    (!(B.rules.income || B.rules.production) || (B.funds[pid] || 0) >= REAL.SILO_COST)
  )
    kind = 'silo'; // missiles: up to two silos
  else if (front <= 6 && forts < 2) kind = 'fort';
  if (!kind) return null;
  const ownish = h => B.territory[key(h.c, h.r)] === pid || supplyPoints(B).some(sp => sp.pid === pid && hexDist(sp, h) <= 2);
  const cands = ends.filter(
    n => canBuildAt(kind, n, pid, B) && ownish(n) && (kind === 'fort' ? near(n) <= 4 && near(n) >= 2 : near(n) >= 4)
  );
  const n = cands.sort((a, b) => a.cost + (kind === 'fort' ? near(a) : 0) - (b.cost + (kind === 'fort' ? near(b) : 0)))[0];
  return n ? order(n, kind) : null;
}

function landComponents(B = appState.battle) {
  const def = B.mapDef,
    comp = new Map();
  let id = 0;
  for (let r = 0; r < def.H; r++)
    for (let c = 0; c < def.W; c++) {
      const k = key(c, r);
      if (comp.has(k) || !landPassAt(c, r, B)) continue;
      comp.set(k, ++id);
      const q = [{ c, r }];
      while (q.length) {
        const cur = q.shift();
        for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
          const nk = key(n.c, n.r);
          if (!comp.has(nk) && landPassAt(n.c, n.r, B)) {
            comp.set(nk, id);
            q.push(n);
          }
        }
      }
    }
  return comp;
}

// Loaded: sail to a beach on an enemy-held landmass and unload. Empty: go pick up a stranded unit. Otherwise act like a normal ship.
function planTransport(u, reach, ctx, B = appState.battle) {
  const ends = [...reach.values()].filter(n => n.end);
  if (u.cargo) {
    let best = null;
    for (const n of ends)
      for (const h of landingSpots(n, B)) {
        const onEnemyLand = !ctx.enemyLand.length || ctx.enemyComps.has(ctx.comp.get(key(h.c, h.r)));
        if (!onEnemyLand) continue;
        const sc = -ctx.nearest(h) - n.cost * 0.1;
        if (!best || sc > best.sc) best = { sc, n, h };
      }
    if (best)
      return best.n.cost === 0
        ? { type: 'unload', unload: { c: best.h.c, r: best.h.r } }
        : { type: 'move', path: pathTo(best.n), target: null, unload: { c: best.h.c, r: best.h.r } };
    const toward = ctx.enemyLand.length ? ctx.enemyLand : null;
    const goal = h => (toward ? Math.min(...toward.map(e => hexDist(e, h))) : ctx.nearest(h));
    const n = ends.sort((a, b) => goal(a) - goal(b))[0];
    return n && n.cost > 0 ? { type: 'move', path: pathTo(n), target: null } : { type: 'hold' };
  }
  const waiting = ctx.stranded.filter(x => !x.in);
  if (!waiting.length) return null;
  const n = ends.sort(
    (a, b) =>
      Math.min(...waiting.map(x => Math.max(0, hexDist(x, a) - 1))) * 10 +
      a.cost * 0.1 -
      (Math.min(...waiting.map(x => Math.max(0, hexDist(x, b) - 1))) * 10 + b.cost * 0.1)
  )[0];
  return n && n.cost > 0 ? { type: 'move', path: pathTo(n), target: null } : { type: 'hold' };
}

// Orders for every AI army. humanAI: strategy to play the human army with (headless tests), or null to skip it.
function planAllAI(humanAI, B = appState.battle) {
  const out = {};
  for (const p of B.players) {
    if (!allAlive(B).some(u => u.pid === p.id)) continue;
    const ai = p.ai || humanAI;
    if (ai) Object.assign(out, planAI(Object.assign({}, p, { ai }), B));
  }
  return out;
}

// Mines (rule): engineers and destroyers near the enemy sometimes lay one where they stand.
function planMines(ctx) {
  const { B, mine, orders, nearest } = ctx;
  if (!B.rules.mines) return;
  for (const u of mine) {
    if (orders[u.id] || !canLayMine(u, B) || nearest(u) > 5) continue;
    if (rng(B) < AI_WEIGHTS.mineChance) orders[u.id] = { type: 'mine' };
  }
}

// Information operations (rule): rifle squads near the enemy sometimes broadcast instead of fighting.
function planBroadcasts(ctx) {
  const { B, mine, orders, nearest } = ctx;
  if (!B.rules.infoOps || !(B.rules.morale || (B.rules.fog && B.rules.intelFade))) return;
  for (const u of mine)
    if (!orders[u.id] && canBroadcast(u, B) && nearest(u) <= REAL.BROADCAST_RANGE && rng(B) < AI_WEIGHTS.broadcastChance)
      orders[u.id] = { type: 'broadcast' };
}
// Ammunition types (rule): load armor-piercing if the nearest enemy in sight is armored, otherwise high-explosive.
function chooseAmmo(ctx) {
  const { B, mine, orders, enemies } = ctx;
  if (!B.rules.ammo) return;
  for (const u of mine) {
    if (!orders[u.id] || !usesAmmoTypes(UNIT_TYPES[u.type]) || !enemies.length) continue;
    const e = enemies.reduce((a, b) => (hexDist(a, u) <= hexDist(b, u) ? a : b));
    orders[u.id] = Object.assign({}, orders[u.id], { ammo: armoredTarget(UNIT_TYPES[e.type]) ? 'ap' : 'he' });
  }
}

// Missiles (rule): launch each ready silo at the most valuable target in sight and range: warships, artillery,
// structures and clusters first, never where the splash would catch our own side.
function planMissiles(ctx) {
  const { B, p, orders } = ctx;
  if (!B.rules.missiles) return;
  const value = u => ({ battleship: 60, carrier: 60, ship: 40, arty: 35, tank: 25, sub: 30, lst: 25 })[u.type] || 12;
  for (const s of ownSilos(B, p.id)) {
    if (!siloReady(B, s)) continue;
    let best = null,
      bs = AI_WEIGHTS.strikeMin;
    const cands = new Map();
    for (const e of aliveUnits(B)) if (isEnemy(e.pid, p.id, B) && canSee(p.id, e, B)) cands.set(key(e.c, e.r), { c: e.c, r: e.r });
    for (const [k, x] of Object.entries(B.structs)) if (x.owner != null && isEnemy(x.owner, p.id, B)) cands.set(k, keyHex(k));
    for (const h of cands.values()) {
      if (!strikeTargetOk(B, p.id, s.k, h)) continue;
      if (aliveUnits(B).some(u => !isEnemy(u.pid, p.id, B) && hexDist(u, h) <= 1)) continue; // no friendly fire
      let sc = 0;
      for (const u of aliveUnits(B))
        if (isEnemy(u.pid, p.id, B)) sc += u.c === h.c && u.r === h.r ? value(u) : hexDist(u, h) === 1 ? value(u) / 3 : 0;
      const st = B.structs[key(h.c, h.r)];
      if (st && st.owner != null && isEnemy(st.owner, p.id, B)) sc += STRUCTS[st.kind].value + (st.kind === 'silo' ? 30 : 0);
      if (sc > bs) {
        bs = sc;
        best = h;
      }
    }
    if (best) orders['strike:' + s.k] = { type: 'strike', target: { c: best.c, r: best.r } };
  }
}
// City development (rule): with spare funds, invest in one city a turn: a threatened city for its defense,
// otherwise a rear city for its income.
function planInvest(ctx) {
  const { B, p, orders, nearest } = ctx;
  if (!B.rules.cityDev || !B.rules.income) return;
  const mineC = Object.keys(B.cities).filter(k => investOk(B, p.id, k));
  if (!mineC.length || (B.funds[p.id] || 0) < 10 + Math.min(...mineC.map(k => REAL.CITY_LEVEL_COST[cityLevel(B.cities[k]) + 1]))) return;
  const threatened = mineC.filter(k => nearest(keyHex(k)) <= 6);
  const pick = (threatened.length ? threatened : mineC).sort((a, b) => nearest(keyHex(b)) - nearest(keyHex(a)))[0];
  orders['invest:' + pick] = { type: 'invest' };
}
