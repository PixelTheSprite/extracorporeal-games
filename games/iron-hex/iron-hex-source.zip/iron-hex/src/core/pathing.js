// Movement range, pursuit paths, targeting and damage.
// ---------- Pathfinding ----------
function reachable(u, isReserved, B = appState.battle) {
  const T = UNIT_TYPES[u.type],
    air = T.domain === 'air',
    def = B.mapDef,
    zoc = B.rules.zoc;
  const maxMove = Math.min(moveOf(u, B), u.fuel == null ? Infinity : u.fuel / (T.fuelRate || 1)); // can't spend fuel you don't have
  const startNode = { c: u.c, r: u.r, cost: 0, prev: null };
  const dist = new Map([[key(u.c, u.r), startNode]]),
    open = heapOf(n => n.cost, grounded(u, B) || suppressed(u, B) ? [] : [startNode]); // storms ground aircraft; suppressed units hold
  while (open.length) {
    const cur = open.shift();
    if (zoc && cur !== startNode && inZOC(u, cur, B)) continue; // can end here, cannot pass through
    for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
      const cost = costAt(T, n.c, n.r, u.pid, B);
      if (cost == null) continue;
      const nc = cur.cost + cost;
      if (nc > maxMove) continue;
      const occ = unitAtLayer(n.c, n.r, air, B);
      if (occ && occ.pid !== u.pid && !grants(occ.pid, u.pid, 'passage', B)) continue;
      const k = key(n.c, n.r),
        ex = dist.get(k);
      if (!ex || ex.cost > nc) {
        const node = { c: n.c, r: n.r, cost: nc, prev: cur };
        dist.set(k, node);
        open.push(node);
      }
    }
  }
  for (const node of dist.values()) {
    if (node === startNode) {
      node.end = true;
      continue;
    }
    node.end = !isReserved((air ? 'A' : 'S') + key(node.c, node.r));
  }
  return dist;
}

const pathTo = node => {
  const p = [];
  for (let n = node; n; n = n.prev) p.unshift({ c: n.c, r: n.r });
  return p;
};

// First step of the cheapest route to any hex from which u can hit t (used by Engage each tick).
function stepToward(u, t, B = appState.battle) {
  const T = UNIT_TYPES[u.type],
    air = isAir(u),
    def = B.mapDef;
  const start = { c: u.c, r: u.r, cost: 0, prev: null };
  const dist = new Map([[key(u.c, u.r), start]]),
    open = heapOf(n => n.cost, [start]);
  while (open.length) {
    const cur = open.shift();
    if (cur !== start && inRange(u.type, cur, t, B)) {
      let n = cur;
      while (n.prev && n.prev !== start) n = n.prev;
      return { c: n.c, r: n.r };
    }
    if (cur.cost > 60) break;
    for (const n of neighborsRaw(cur.c, cur.r, def.W, def.H)) {
      const cost = costAt(T, n.c, n.r, u.pid, B);
      if (cost == null) continue;
      const occ = unitAtLayer(n.c, n.r, air, B);
      if (occ && occ.pid !== u.pid && !grants(occ.pid, u.pid, 'passage', B)) continue;
      const k = key(n.c, n.r),
        nc = cur.cost + cost,
        ex = dist.get(k);
      if (!ex || ex.cost > nc) {
        const node = { c: n.c, r: n.r, cost: nc, prev: cur };
        dist.set(k, node);
        open.push(node);
      }
    }
  }
  return null;
}

function bestTargetInRange(u, B = appState.battle) {
  if (broken(u, B) || grounded(u, B) || (UNIT_TYPES[u.type].setup && movedThisTurn(u, B))) return null;
  let best = null,
    bs = -1;
  for (const e of aliveUnits(B)) {
    if (!isEnemy(e.pid, u.pid, B) || !canHit(u, e, B) || !inRange(u.type, u, e, B) || !canTarget(u, e, B)) continue;
    const d = expDmg(u, e, e, false, B),
      sc = d + (d >= e.hp ? 30 : 0);
    if (sc > bs) {
      bs = sc;
      best = e;
    }
  }
  return best;
}

const engageList = (u, B = appState.battle) =>
  u.ammo > 0 && !broken(u, B) && !grounded(u, B)
    ? aliveUnits(B).filter(e => isEnemy(e.pid, u.pid, B) && canHit(u, e, B) && canTarget(u, e, B))
    : [];

const effOf = A => A.eff || EFF[A.domain];

// Submarines (with their rule on) can only be attacked by anti-submarine ships.
const canHit = (a, t, B = appState.battle) =>
  effOf(UNIT_TYPES[a.type])[UNIT_TYPES[t.type].domain] > 0 && !(isSub(t, B) && !UNIT_TYPES[a.type].asw);
// Artillery fires at what friendly spotters see; everyone else at what their side can see.
const canTarget = (u, e, B = appState.battle) => (UNIT_TYPES[u.type].indirect ? spotted(u.pid, e, B) : canSee(u.pid, e, B));

// At night (weather rule) long-range weapons lose 1 hex of range.
const inRange = (type, from, to, B = appState.battle) => {
  const d = hexDist(from, to),
    rg = UNIT_TYPES[type].range,
    mx = (rg[1] >= 2 && cond(B).night ? rg[1] - 1 : rg[1]) + elevationRange(type, from, to, B);
  return d >= rg[0] && d <= Math.max(rg[0], mx);
};

// pos: where the target stands (defaults to its current hex); a fortification there cuts ground damage.
function calcDamage(att, tgt, tgtTerrain, tgtHold, rand = 1, pos = tgt, B = appState.battle) {
  const A = UNIT_TYPES[att.type],
    T = UNIT_TYPES[tgt.type];
  const eff = effOf(A)[T.domain] * ((A.bonusVs && A.bonusVs[tgt.type]) || 1);
  if (!eff) return 0;
  const base = 10 + A.stats.firepower * 4;
  const hpF = 0.5 + (0.5 * att.hp) / att.maxHp;
  const armor = 1 - T.stats.armor * 0.06;
  const fort = builtAt(pos.c, pos.r, B);
  const cover = T.domain === 'land' ? (1 - terrainDef(T, tgtTerrain, B)) * (fort && fort.kind === 'fort' ? FORT_COVER : 1) : 1;
  const vet = (1 + VET_DAMAGE * (att.vet || 0)) * (shaken(att, B) ? 0.8 : 1); // veterans hit harder; shaken units hit softer
  return Math.max(
    1,
    Math.round(base * eff * hpF * armor * cover * (tgtHold ? 0.7 : 1) * vet * realismDamage(att, tgt, pos, B) * cityDefense(pos, B) * rand)
  );
}

const evadeOf = (u, B = appState.battle) => {
  const c = cond(B),
    T = UNIT_TYPES[u.type];
  return (
    Math.max(
      0,
      T.evade +
        VET_EVADE * (u.vet || 0) +
        (c.w === 'rain' ? 8 : 0) +
        (c.w === 'fog' && T.foot ? 15 : 0) -
        (shaken(u, B) ? 5 : 0) +
        airSupEvade(u, B)
    ) / 100
  );
};
const expDmg = (a, t, at, hold, B = appState.battle) => calcDamage(a, t, tileAt(at.c, at.r, B).t, hold, 1, at, B) * (1 - evadeOf(t, B));

function targetsFrom(u, from, B = appState.battle) {
  if (u.ammo <= 0 || broken(u, B) || grounded(u, B) || cannotFireAfterMoving(u, from, B)) return []; // artillery can't move and fire
  return aliveUnits(B).filter(e => isEnemy(e.pid, u.pid, B) && canHit(u, e, B) && inRange(u.type, from, e, B) && canTarget(u, e, B));
}

function humanReserved(u, B = appState.battle) {
  const set = new Set();
  for (const o of aliveUnits(B)) {
    if (o.pid !== u.pid || o.id === u.id) continue;
    const ord = B.orders[o.id];
    if (ord && ord.type === 'move') {
      const d = ord.path[ord.path.length - 1];
      set.add(lkey(o, d.c, d.r));
    } else set.add(lkey(o, o.c, o.r));
  }
  return k => set.has(k);
}
