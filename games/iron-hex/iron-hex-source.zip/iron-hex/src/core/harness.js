// Headless battles and the regression suites. Shared by tests/run.mjs (Node) and the in-game Diagnostics screen.
// A headless battle swaps in NullView and its own settings, plays AI against AI to the end, then restores
// whatever battle and settings were active before.
const RULE_KEYS = ['zoc', 'realtime', 'engage', 'terrRadius', 'terrPaint', 'terrSpread'],
  ENDGAME_KEYS = ['exhaust', 'attrition'];
const P11_ROSTERS = {
  artillery: { tank: 2, inf: 2, eng: 1, arty: 2 },
  subs: { tank: 1, inf: 2, ship: 1, sub: 2, lst: 1 },
  carriers: { tank: 1, inf: 2, plane: 2, carrier: 1, ship: 1, lst: 1 },
  mines: { tank: 2, inf: 2, eng: 2, ship: 1, lst: 1 },
};
const P11_KEYS = [
  'supplyLines',
  'entrench',
  'suppression',
  'facing',
  'urban',
  'elevation',
  'surrender',
  'command',
  'friction',
  'ew',
  'airSup',
  'aaUmbrella',
  'artillery',
  'subs',
  'mines',
  'carriers',
  'rail',
  'seasons',
  'reinforce',
  'vp',
  'infoOps',
  'ammo',
];
const P7_KEYS = ['fog', 'intelFade', 'decoys', 'aiDeception', 'income', 'production', 'capitalLoss', 'weather', 'morale'];
const RULES_ON = Object.fromEntries(
  RULE_KEYS.concat(ENDGAME_KEYS)
    .map(k => [k, true])
    .concat(P7_KEYS.map(k => [k, false]))
);
const RULES_OFF = Object.fromEntries(RULE_KEYS.concat(ENDGAME_KEYS, P7_KEYS, P11_KEYS, ['missiles', 'cityDev']).map(k => [k, false]));
const P12_KEYS = ['missiles', 'cityDev'];
const RULES_ALL = Object.fromEntries(RULE_KEYS.concat(ENDGAME_KEYS, P7_KEYS, P11_KEYS, P12_KEYS).map(k => [k, true]));
const FULL_ROSTER = Object.fromEntries(BASE_TYPES.map(t => [t, 1])); // the original twelve (rule-gated units have their own cases)
const DESTROY = { mode: 'destruction', pct: 60, hold: 3 },
  HOLD60 = { mode: 'territory', pct: 60, hold: 3 };

// Compact fingerprint of everything that affects the rest of the battle.
function stateHash(B) {
  const units = everyUnit(B).map(u => [
    u.id,
    u.type,
    u.pid,
    u.c,
    u.r,
    u.hp,
    u.ammo,
    u.fuel == null ? null : Math.round(u.fuel * 1000),
    u.in || 0,
    u.cargo || 0,
    u.dug || 0,
    u.supp || 0,
    u.cut || 0,
    u.face || 0,
  ]);
  const terr = Object.keys(B.territory || {})
    .sort()
    .map(k => k + '=' + B.territory[k]);
  return hashString(
    JSON.stringify([
      B.turn,
      B.rngState,
      units,
      terr,
      B.flags,
      B.cities,
      Object.keys(B.roads || {}).sort(),
      B.holds,
      B.quiet,
      B.structs,
      B.stats,
    ])
  );
}
// Turns the current battle's save into the version-1 shape (no seed, rules, logistics or fuel) for migration tests.
function toV1Save() {
  const d = clone(snapshot()),
    b = d.battle;
  d.version = 1;
  for (const k of ['seed', 'rngState', 'rules', 'victory', 'holds', 'quiet', 'territory', 'flags', 'cities', 'roads', 'structs', 'stats'])
    delete b[k];
  for (const u of b.units) {
    delete u.fuel;
    delete u.maxFuel;
  }
  return d;
}
// cfg: { label, seed, settings:{...overrides of defaultSettings()}, humanAI, roundTripAt, migrateFromV1 }
async function runHeadlessBattle(cfg) {
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, ai: R.aiOrders, view: VIEW };
  VIEW = NullView;
  const t0 = Date.now();
  let res;
  try {
    appState.settings = Object.assign(defaultSettings(), clone(cfg.settings || {}));
    newBattle(cfg.seed);
    let out = { end: false },
      migrated = null;
    while (!out.end) {
      const B = appState.battle;
      if (cfg.migrateFromV1 && B.turn === 1 && migrated == null) {
        migrated = applySave(toV1Save());
        if (!migrated) throw new Error('version 1 save was rejected');
        R.map = buildMap(appState.battle.mapDef);
        ensureLogistics(appState.battle);
      }
      if (cfg.roundTripAt && B.turn === cfg.roundTripAt && !B._reloaded) {
        if (!applySave(clone(snapshot()))) throw new Error('save was rejected on reload');
        R.map = buildMap(appState.battle.mapDef);
        ensureLogistics(appState.battle);
        appState.battle._reloaded = true;
      }
      out = await simulateTurn(planAllAI(cfg.humanAI || 'balanced'));
    }
    const B = appState.battle,
      win = out.winner !== undefined ? out.winner : pickWinner(out.remaining);
    res = {
      ok: true,
      reason: out.reason,
      turns: B.turn,
      winner: win ? win.name : 'none',
      hash: stateHash(B),
      version: SAVE_VERSION,
      units: B.units.length,
      stats: Object.assign({}, B.stats),
      ms: Date.now() - t0,
    };
  } catch (e) {
    res = {
      ok: false,
      error: String((e && e.stack) || e)
        .split('\n')
        .slice(0, 3)
        .join(' | '),
      ms: Date.now() - t0,
    };
  } finally {
    appState.battle = saved.battle;
    appState.settings = saved.settings;
    R.map = saved.map;
    R.aiOrders = saved.ai;
    VIEW = saved.view;
  }
  return res;
}
// Unit Editor fixture: a canned lookup answer (what Claude would return), parsed into a custom unit.
const LOOKUP_FIXTURE = {
  found: true,
  name: 'T-34-85',
  short: 'T-34',
  role: 'Medium tank',
  domain: 'land',
  era: 'WWII',
  country: 'Soviet Union',
  stats: {
    speed: { value: 55, unit: 'km/h', note: 'road speed' },
    maneuver: { value: 16, unit: 'hp/tonne' },
    armor: { value: 90, unit: 'mm', note: 'turret front' },
    firepower: { value: 120, unit: 'mm', note: '85 mm ZiS-S-53' },
  },
  game: { range: [1, 2], ammo: 6, fuel: 24, abilities: [], eff: { land: 1, sea: 0.6, air: 0 } },
  sources: ['Zaloga, T-34-85 Medium Tank (1996)'],
  confidence: 'high',
};
const FIXTURE_ART = [
  '......kkkkk.....',
  '.....kttlttk....',
  '.....ktttttkkkkk',
  '..kkkkkkkkkkkkk.',
  '.kttttttttttttk.',
  'kddddddddddddddk',
  'kwgwgwgwgwgwgwwk',
  '..kkkkkkkkkkkk..',
];
function fixtureUnit() {
  const d = parseLookup('```json\n' + JSON.stringify(LOOKUP_FIXTURE) + '\n```');
  d.id = 'u_t34fixture';
  d.art = FIXTURE_ART;
  return unitFromDraft(d);
}
// Named suites of battle setups.
// Each case's seed comes from its label (FNV-1a hash), so adding or reordering cases never changes the others.
function seedFor(label) {
  let h = 2166136261;
  for (let i = 0; i < label.length; i++) h = Math.imul(h ^ label.charCodeAt(i), 16777619) >>> 0;
  return 1000 + (h % 900000);
}
function suiteCases(name) {
  const cases = [];
  const add = (label, settings, extra = {}) => cases.push(Object.assign({ label, seed: seedFor(label), settings }, extra));
  const extras = () => {
    add('Territory victory, 60% for 3 turns', { rules: RULES_ON, victory: HOLD60 });
    add('Island Hop, every unit type', { rules: RULES_ON, victory: DESTROY, mapId: 'islands', roster: FULL_ROSTER });
    add(
      'Defensive vs defensive',
      { rules: RULES_ON, victory: DESTROY, strategies: ['player', 'defensive', 'defensive', 'defensive'] },
      { humanAI: 'defensive' }
    );
    add(
      'Defensive vs defensive, classic rules',
      { rules: RULES_OFF, victory: DESTROY, strategies: ['player', 'defensive', 'defensive', 'defensive'] },
      { humanAI: 'defensive' }
    );
    add('4 armies, random map, every unit type', {
      rules: RULES_ON,
      victory: DESTROY,
      armies: 4,
      mapId: 'random',
      randomSeed: 4242,
      roster: FULL_ROSTER,
    });
    const stDef = genMap('strait', 1942, 'Sandstorm Strait');
    add(
      'Infrastructure layout, every unit type',
      { rules: RULES_ON, victory: DESTROY, roster: FULL_ROSTER, layout: { mapId: 'strait', structs: autoLayout(stDef, 2) } },
      { infra: true }
    );
    add('Real map: Donbas', { rules: RULES_ON, victory: DESTROY, mapId: 'real-donbas' });
    add('Real map: Taiwan Strait, every unit type', {
      rules: RULES_ON,
      victory: DESTROY,
      mapId: 'real-taiwan',
      roster: FULL_ROSTER,
      playSide: 1,
    });
    add(
      '2 vs 2, random map',
      { rules: RULES_ON, victory: DESTROY, armies: 4, mapId: 'random', randomSeed: 5150, teams: [0, 0, 1, 1] },
      { teamCheck: true }
    );
    add(
      '2 vs 2, Suwałki Gap alliances',
      { rules: RULES_ON, victory: DESTROY, armies: 4, mapId: 'real-suwalki', teams: [0, 1, 0, 1] },
      { teamCheck: true }
    );
    add(
      '2 vs 2, territory victory, you grant allies nothing',
      {
        rules: RULES_ON,
        victory: HOLD60,
        armies: 4,
        mapId: 'random',
        randomSeed: 6161,
        teams: [0, 1, 1, 0],
        grants: { territory: false, resupply: false, passage: false },
      },
      { teamCheck: true }
    );
    add(
      'Infrastructure layout, classic rules',
      { rules: RULES_OFF, victory: DESTROY, roster: FULL_ROSTER, layout: { mapId: 'strait', structs: autoLayout(stDef, 2) } },
      { infra: true }
    );
  };
  // The first case is also used for the determinism, save round-trip and migration checks, so it turns everything on.
  add('Everything on', { rules: RULES_ALL, victory: DESTROY }, { p7: true });
  // Realism rules (Phase 11), each on top of the core rules, plus all of them together.
  const p11 = () => {
    for (const k of P11_KEYS)
      add(
        `Core rules + ${RULES[k].label}`,
        {
          rules: Object.assign(
            {},
            RULES_ON,
            { [k]: true },
            k === 'surrender' ? { supplyLines: true, morale: true } : k === 'infoOps' ? { morale: true } : {}
          ),
          victory: DESTROY,
        },
        { real: true }
      );
    add(
      'All realism rules',
      { rules: Object.assign({}, RULES_ON, Object.fromEntries(P11_KEYS.map(k => [k, true]))), victory: DESTROY },
      { real: true }
    );
    add(
      'All realism rules, territory, every unit type',
      { rules: Object.assign({}, RULES_ON, Object.fromEntries(P11_KEYS.map(k => [k, true]))), victory: HOLD60, roster: FULL_ROSTER },
      { real: true }
    );
  };
  // Missiles and city development (Phase 12).
  const p12 = () => {
    const eng = { tank: 2, inf: 2, eng: 2, aa: 1, ship: 1, battleship: 1, lst: 1 };
    add(
      'Core rules + Missile silos',
      { rules: Object.assign({}, RULES_ON, { missiles: true }), victory: DESTROY, roster: eng },
      { p12: true }
    );
    add(
      'Core rules + Missile silos, economy',
      { rules: Object.assign({}, RULES_ON, { missiles: true, income: true, production: true }), victory: DESTROY, roster: eng },
      { p12: true }
    );
    add(
      'Core rules + City development',
      { rules: Object.assign({}, RULES_ON, { cityDev: true, income: true, production: true }), victory: DESTROY },
      { p12: true }
    );
    add(
      'Missiles and city development together',
      {
        rules: Object.assign({}, RULES_ON, { missiles: true, cityDev: true, income: true, production: true }),
        victory: DESTROY,
        roster: eng,
      },
      { p12: true }
    );
  };
  const p7 = () => {
    for (const k of P7_KEYS)
      add(
        `Core rules + ${RULES[k].label}`,
        {
          rules: Object.assign(
            {},
            RULES_ON,
            { [k]: true },
            ['intelFade', 'decoys', 'aiDeception'].includes(k) ? { fog: true, decoys: k === 'aiDeception' ? true : k === 'decoys' } : {}
          ),
          victory: DESTROY,
        },
        { p7: true }
      );
    add(
      'Everything on, 2 vs 2',
      { rules: RULES_ALL, victory: DESTROY, armies: 4, mapId: 'random', randomSeed: 7171, teams: [0, 0, 1, 1] },
      { p7: true, teamCheck: true }
    );
    add('Everything on, territory victory, every unit type', { rules: RULES_ALL, victory: HOLD60, roster: FULL_ROSTER }, { p7: true });
  };
  if (name === 'quick') {
    p7();
    p11();
    p12();
    add('All rules on', { rules: RULES_ON, victory: DESTROY });
    add('All rules off', { rules: RULES_OFF, victory: DESTROY });
    for (const k of RULE_KEYS.concat(ENDGAME_KEYS))
      add(`Only ${RULES[k].label}`, { rules: Object.assign({}, RULES_OFF, { [k]: true }), victory: DESTROY });
    extras();
  } else {
    p7();
    p11();
    p12();
    // Every real-world map (all of its sides), and a large generated custom map
    for (const m of REAL_MAPS)
      add(`Real map: ${m.name}, ${m.spawns.length} sides`, {
        rules: RULES_ON,
        victory: DESTROY,
        mapId: m.id,
        armies: m.spawns.length,
        roster: FULL_ROSTER,
      });
    const big = genMap('custom', 77, 'Huge custom', { W: 40, H: 30, water: 40, mountains: 30, forest: 40, desert: 20 });
    big.id = 'custom-test';
    add('Custom 40 × 30 map, 4 armies', { rules: RULES_ON, victory: DESTROY, mapId: big.id, customMap: big, armies: 4 });
    // Every combination of the six rule toggles, under both victory conditions (128 battles).
    // ... and the two endgame rules cycle through all four on/off combinations across these 128 battles.
    for (let m = 0; m < 64; m++) {
      for (const [vi, victory] of [
        [0, DESTROY],
        [1, HOLD60],
      ]) {
        const e = (m * 2 + vi) % 4;
        const rules = Object.assign(Object.fromEntries(RULE_KEYS.map((k, i) => [k, !!(m & (1 << i))])), {
          exhaust: !!(e & 1),
          attrition: !!(e & 2),
        });
        const on =
          RULE_KEYS.concat(ENDGAME_KEYS)
            .filter(k => rules[k])
            .map(k => RULES[k].short)
            .join(', ') || 'no rules';
        add(`${on} | ${vi ? 'territory 60%' : 'destruction'}`, { rules, victory });
      }
    }
    extras();
  }
  return cases;
}
// Runs a suite and returns rows of { label, status:'pass'|'warn'|'fail', detail, ms }.
// A battle that reaches the turn limit is a warning (a likely stalemate), not a failure.
async function runSuite(name, onProgress = () => {}, shouldStop = () => false) {
  const cases = suiteCases(name),
    rows = [],
    total = cases.length + 15;
  let done = 0;
  // onProgress may return a promise (the browser uses it to yield a frame so the page stays responsive).
  const push = async row => {
    rows.push(row);
    await onProgress(++done / total, row);
  };
  const problems = validateAll();
  await push({
    label: 'Data validation (unit types and maps)',
    status: problems.length ? 'fail' : 'pass',
    detail: problems.length
      ? problems.join('; ')
      : `${Object.keys(UNIT_TYPES).length} unit types, ${MAP_PRESETS.length} generated and ${REAL_MAPS.length} real-world maps`,
    ms: 0,
  });
  for (const c of cases) {
    if (shouldStop()) return rows;
    const r = await runHeadlessBattle(c);
    const ffBad = r.ok && c.teamCheck && r.stats.friendlyFire;
    await push({
      label: c.label,
      ms: r.ms,
      status: !r.ok || ffBad ? 'fail' : r.reason === 'timeout' ? 'warn' : 'pass',
      detail: r.ok
        ? `${r.winner} won by ${r.reason === 'timeout' ? 'turn limit' : r.reason} on turn ${r.turns}` +
          (c.infra || r.stats.built
            ? `; structures built ${r.stats.built}, captured ${r.stats.captured}, destroyed ${r.stats.destroyed}, airfield landings ${r.stats.landings}, port calls ${r.stats.portCalls}`
            : '') +
          (c.teamCheck ? `; allies hit each other ${r.stats.friendlyFire || 0} times` : '') +
          (c.real
            ? `; surrendered ${r.stats.surrendered || 0}, friction ${r.stats.friction || 0}, mines laid ${r.stats.minesLaid || 0} hit ${r.stats.minesHit || 0}, reinforced ${r.stats.reinforced || 0}, broadcasts ${r.stats.broadcasts || 0}`
            : '') +
          (c.p7
            ? `; produced ${r.stats.produced || 0}, decoys ${r.stats.decoys || 0} (${r.stats.decoysExposed || 0} exposed), feints ${r.stats.feints || 0}, storms ${r.stats.storms || 0}, units broken ${r.stats.broken || 0}`
            : '')
        : r.error,
    });
    if (r.ok) c.result = r;
  }
  if (shouldStop()) return rows;
  await checkUnitEditor(push);
  await checkCampaign(push);
  await checkLooksAndRecords(rows, push);
  await checkTurnLimitGate(cases, push);
  await checkMultiTurnOrders(push);
  await checkReplay(push);
  // Infrastructure gate: across the battles, the AI must build, land on airfields and put in at ports.
  const sum = k => cases.reduce((s, c) => s + (c.result ? c.result.stats[k] : 0), 0);
  const used = {
    built: sum('built'),
    landings: sum('landings'),
    portCalls: sum('portCalls'),
    captured: sum('captured'),
    destroyed: sum('destroyed'),
  };
  await push({
    label: 'AI uses infrastructure',
    ms: 0,
    status: used.built && used.landings && used.portCalls ? 'pass' : 'fail',
    detail: `${used.built} structures built, ${used.landings} airfield landings, ${used.portCalls} port calls, ${used.captured} captured, ${used.destroyed} destroyed across ${cases.length} battles`,
  });
  const c0 = cases[0],
    first = c0.result || (await runHeadlessBattle(c0)),
    again = await runHeadlessBattle(c0);
  await push({
    label: 'Determinism: same seed twice',
    ms: again.ms,
    status: first.ok && again.ok && first.hash === again.hash ? 'pass' : 'fail',
    detail: first.ok && again.ok ? `state ${first.hash} vs ${again.hash}` : again.error || first.error,
  });
  const rt = await runHeadlessBattle(Object.assign({}, c0, { roundTripAt: 5 }));
  await push({
    label: 'Save and reload at turn 5 gives the same battle',
    ms: rt.ms,
    status: rt.ok && rt.hash === first.hash ? 'pass' : 'fail',
    detail: rt.ok ? `state ${rt.hash} vs ${first.hash}` : rt.error,
  });
  const mg = await runHeadlessBattle(Object.assign({}, c0, { migrateFromV1: true }));
  await push({
    label: 'Version 1 save upgrades and plays to the end',
    ms: mg.ok ? mg.ms : 0,
    status: mg.ok ? 'pass' : 'fail',
    detail: mg.ok ? `upgraded to version ${mg.version}; ${mg.winner} won on turn ${mg.turns}` : mg.error,
  });
  return rows;
}
// Unit Editor: a lookup answer becomes a valid unit; it fights; a save carrying it reloads where it was never installed.
async function checkUnitEditor(push) {
  const T = fixtureUnit(),
    probs = registerCustomUnit(T);
  await push({
    label: 'Unit Editor: lookup answer becomes a valid unit',
    ms: 0,
    status: probs.length ? 'fail' : 'pass',
    detail: probs.length
      ? probs.join('; ')
      : `${T.name}: speed ${T.stats.speed}, maneuver ${T.stats.maneuver}, armor ${T.stats.armor}, firepower ${T.stats.firepower}; move ${T.move}, HP ${T.hp}`,
  });
  if (!probs.length) {
    const cb = await runHeadlessBattle({
      label: 'custom',
      seed: 4321,
      settings: { rules: RULES_ON, victory: DESTROY, roster: { u_t34fixture: 2, tank: 1, inf: 2, plane: 1, ship: 1 } },
    });
    let reload = 'not run';
    if (cb.ok) {
      // fresh-browser check: snapshot a battle with the unit, forget the unit, then load the save
      const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
      VIEW = NullView;
      appState.settings = Object.assign(defaultSettings(), { roster: { u_t34fixture: 1, tank: 1 } });
      newBattle(99);
      const snap = clone(snapshot());
      unregisterCustomUnit('u_t34fixture');
      reload = applySave(snap) && UNIT_TYPES.u_t34fixture ? 'ok' : 'failed';
      appState.battle = saved.battle;
      appState.settings = saved.settings;
      R.map = saved.map;
      VIEW = saved.view;
    }
    await push({
      label: 'Unit Editor: custom unit fights and survives save/load',
      ms: cb.ms || 0,
      status: cb.ok && reload === 'ok' ? 'pass' : 'fail',
      detail: cb.ok ? `${cb.winner} won by ${cb.reason} on turn ${cb.turns}; reload in a fresh browser ${reload}` : cb.error,
    });
  }
  unregisterCustomUnit('u_t34fixture');
  // Security: a custom unit id that could break out of page markup is refused, and so is a save carrying one.
  const evil = Object.assign(fixtureUnit(), { id: 'u_x" onmouseover="alert(1)' });
  const refused = registerCustomUnit(evil).length > 0 && !UNIT_TYPES[evil.id];
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  VIEW = NullView;
  appState.settings = defaultSettings();
  newBattle(5);
  const snap = clone(snapshot());
  snap.battle.customTypes = { [evil.id]: evil };
  const saveRefused = !applySave(snap);
  appState.battle = saved.battle;
  appState.settings = saved.settings;
  R.map = saved.map;
  VIEW = saved.view;
  await push({
    label: 'Security: unsafe custom unit ids are refused',
    ms: 0,
    status: refused && saveRefused ? 'pass' : 'fail',
    detail: `registering: ${refused ? 'refused' : 'ACCEPTED'}; loading a save that carries one: ${saveRefused ? 'refused' : 'ACCEPTED'}`,
  });
}
// Campaign: every mission plays to a decision, and the whole campaign plays through with carried-over veterans.
async function checkCampaign(push) {
  const t0 = Date.now(),
    saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  VIEW = NullView;
  appState.settings = defaultSettings();
  const play = async () => {
    let out = { end: false };
    while (!out.end) out = await simulateTurn(planAllAI('balanced'));
    return out;
  };
  try {
    const results = [];
    // every mission of every built-in campaign (the Iron Coast first, so its seeds never move)
    for (const C of BUILTIN_CAMPAIGNS)
      for (const id of Object.keys(C.missions)) {
        const st = newCampaignState(C);
        st.mission = id;
        newMissionBattle(st, C, 500 + results.length);
        const out = await play();
        results.push(
          `${C.missions[id].title}: ${out.reason === 'objective' ? 'won' : out.reason === 'destruction' ? (out.remaining[0] && out.remaining[0].id === 0 ? 'won' : 'lost') : 'lost'} on turn ${appState.battle.turn}`
        );
      }
    await push({ label: 'Campaign: every mission plays to a decision', ms: Date.now() - t0, status: 'pass', detail: results.join('; ') });
    const bad = BUILTIN_CAMPAIGNS.flatMap(c => validateCampaign(c).map(x => c.name + ': ' + x));
    await push({
      label: 'Campaigns: built-in definitions are valid',
      ms: 0,
      status: bad.length ? 'fail' : 'pass',
      detail: bad.join('; ') || BUILTIN_CAMPAIGNS.map(c => `${c.name}, ${campaignLength(c)} missions per path`).join('; '),
    });
    // whole campaign, retrying lost missions up to 3 times each
    let st = newCampaignState(),
      played = [],
      tries = 0,
      promoted = 0;
    while (!st.done && tries < 12) {
      tries++;
      newMissionBattle(st, CAMPAIGN, 900 + tries);
      const out = await play(),
        B = appState.battle;
      const won = out.winner ? out.winner.id === 0 : out.remaining.length === 1 && out.remaining[0].id === 0;
      const res = campaignAfterMission(st, B, won);
      played.push(`${CAMPAIGN.missions[st.mission].title} ${won ? 'won' : 'lost'}`);
      promoted += res.promotions.length;
      st = res.state;
      if (!st.roster.length) break;
    }
    const vets = st.roster.filter(u => u.xp > 0).length;
    await push({
      label: 'Campaign: plays through with veterans carried over',
      ms: Date.now() - t0,
      status: st.done && played.length >= 3 && vets ? 'pass' : played.length >= 3 ? 'warn' : 'fail',
      detail: `${played.join(' → ')}; ${st.roster.length} units left, ${vets} with experience, ${promoted} promotions`,
    });
  } catch (e) {
    await push({
      label: 'Campaign: missions',
      ms: Date.now() - t0,
      status: 'fail',
      detail: String((e && e.stack) || e)
        .split('\n')
        .slice(0, 2)
        .join(' | '),
    });
  } finally {
    appState.battle = saved.battle;
    appState.settings = saved.settings;
    R.map = saved.map;
    VIEW = saved.view;
  }
}
// Looks and records: every medieval sprite is valid; unlocks follow the ladder; records summarize.
async function checkLooksAndRecords(rows, push) {
  const p = [];
  for (const [t, rows] of Object.entries(SKIN_ART.medieval)) {
    if (!UNIT_TYPES[t]) p.push(`medieval look for unknown unit ${t}`);
    p.push(...validateArt(rows).map(x => `${t} ${x}`));
  }
  for (const t of BASE_TYPES) if (!SKIN_ART.medieval[t] || !SKIN_NAMES.medieval[t]) p.push(`no medieval look for ${t}`);
  const prof = { units: { tank: { battles: 3, kills: 12, wins: 1, special: 0 }, inf: { battles: 2, kills: 0, wins: 0, special: 0 } } };
  const ok = unlockedPeriods(prof, 'tank').join() === 'modern,medieval,ancient' && unlockedPeriods(prof, 'inf').join() === 'modern';
  const sum = summarizeRecords([
    { at: '1', result: 'win', turns: 20, mapName: 'A', opponents: ['balanced'] },
    { at: '2', result: 'win', turns: 12, mapName: 'B', opponents: ['aggressive'] },
    { at: '3', result: 'loss', turns: 30, mapName: 'A', opponents: ['balanced'] },
  ]);
  const recOk =
    sum.wins === 2 && sum.losses === 1 && sum.fastestWin.turns === 12 && sum.bestStreak === 2 && sum.streak === 0 && sum.byMap.A.w === 1;
  await push({
    label: 'Looks and records: sprites, unlock ladder, leaderboard summary',
    ms: 0,
    status: !p.length && ok && recOk ? 'pass' : 'fail',
    detail: p.length
      ? p.join('; ')
      : `${Object.keys(SKIN_ART.medieval).length} medieval sprites valid; unlocks ${ok ? 'follow the ladder' : 'WRONG'}; summary ${recOk ? 'correct' : 'WRONG'}`,
  });
}
// Phase 6 gate: fewer than 1 in 20 battles reach the turn limit.
async function checkTurnLimitGate(cases, push) {
  const done = cases.filter(c => c.result),
    to = done.filter(c => c.result.reason === 'timeout').length,
    ex = done.filter(c => c.result.reason === 'exhaustion').length;
  await push({
    label: 'Battles reaching the turn limit',
    ms: 0,
    status: to * 20 < done.length ? 'pass' : 'warn',
    detail: `${to} of ${done.length} (${Math.round((100 * to) / Math.max(1, done.length))}%); ${ex} ended by supply exhaustion`,
  });
}
// Multi-turn orders: a far-off move gets there over several turns; Overwatch stands until changed.
// Replays: play a full battle with every rule on, then replay it from its opening state; the final state must match.
async function checkReplay(push) {
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  let ok = false,
    detail = '';
  try {
    VIEW = NullView;
    appState.settings = defaultSettings();
    Object.assign(appState.settings.rules, RULES_ALL, { vp: false }); // every rule but victory points, whose war weariness ends battles early
    newBattle(seedFor('replay check'));
    let out = { end: false };
    while (!out.end) out = await simulateTurn(planAllAI('balanced'));
    const B = appState.battle,
      want = stateHash(B),
      rep = replayOf(B),
      turns = rep.log.length;
    const size = JSON.stringify(rep).length;
    if (!loadReplayStart(rep)) throw new Error('replay start would not load');
    let o = { end: false };
    for (let i = 0; i < turns && !o.end; i++) o = await replayTurn(rep, i);
    const got = stateHash(appState.battle);
    ok = got === want;
    detail = `${turns} turns replayed; final state ${got} vs ${want}; replay ${Math.round(size / 1024)} KB`;
  } catch (e) {
    detail = String((e && e.message) || e);
  }
  appState.battle = saved.battle;
  appState.settings = saved.settings;
  R.map = saved.map;
  VIEW = saved.view;
  await push({ label: 'Replay reproduces the battle exactly', ms: 0, status: ok ? 'pass' : 'fail', detail });
}
async function checkMultiTurnOrders(push) {
  const saved = { battle: appState.battle, settings: appState.settings, map: R.map, view: VIEW };
  VIEW = NullView;
  appState.settings = defaultSettings();
  newBattle(321);
  let detail = '',
    ok = false;
  try {
    const B = appState.battle,
      u = B.units.find(x => x.pid === 0 && x.type === 'tank'),
      f = travelField(u, 4);
    const far = [...f.values()].filter(n => n.turns === 3).sort((a, b) => a.cost - b.cost)[0];
    const hold = B.units.find(x => x.pid === 0 && x.type === 'inf');
    noteStanding(B, u, { type: 'move', multi: { dest: { c: far.c, r: far.r } } });
    noteStanding(B, hold, { type: 'hold' });
    let turns = 0,
      arrived = false,
      held = true;
    while (turns < 8 && !arrived) {
      B.orders = {};
      const notes = applyStanding(B);
      if (notes.some(n => n.includes('arrived'))) {
        arrived = true;
        break;
      }
      if (!B.orders[hold.id] || B.orders[hold.id].type !== 'hold') held = false;
      const ai = planAllAI(null);
      Object.assign(ai, B.orders);
      const out = await simulateTurn(ai);
      turns++;
      if (out.end) break;
    }
    ok = arrived && held && turns >= 2;
    detail = `a hex about 3 turns away reached in ${turns} turns${arrived ? '' : ' (not reached)'}; Overwatch ${held ? 'stood every turn' : 'was lost'}`;
  } catch (e) {
    detail = String((e && e.message) || e);
  }
  appState.battle = saved.battle;
  appState.settings = saved.settings;
  R.map = saved.map;
  VIEW = saved.view;
  await push({ label: 'Multi-turn move and standing Overwatch', ms: 0, status: ok ? 'pass' : 'fail', detail });
}
