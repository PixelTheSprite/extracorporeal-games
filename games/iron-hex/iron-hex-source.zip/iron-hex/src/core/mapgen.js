// Seeded map generation and land-route guarantees between spawns.
// ---------- Map generation ----------
function makeNoise(seed) {
  const R = mulberry32(seed),
    v = new Float32Array(256 * 256);
  for (let i = 0; i < v.length; i++) v[i] = R();
  const at = (i, j) => v[((j & 255) << 8) + (i & 255)];
  const sm = t => t * t * (3 - 2 * t);
  const base = (x, y) => {
    const i = Math.floor(x),
      j = Math.floor(y),
      fx = sm(x - i),
      fy = sm(y - j);
    return lerp(lerp(at(i, j), at(i + 1, j), fx), lerp(at(i, j + 1), at(i + 1, j + 1), fx), fy);
  };
  return (x, y) => base(x, y) * 0.6 + base(x * 2 + 17, y * 2 + 9) * 0.28 + base(x * 4 + 5, y * 4 + 31) * 0.12;
}

const MAP_PRESETS = [
  {
    id: 'strait',
    name: 'Sandstorm Strait',
    kind: 'strait',
    seed: 1942,
    blurb: 'Green highlands to the north, open desert to the south, a narrow strait between.',
  },
  { id: 'islands', name: 'Island Hop', kind: 'islands', seed: 77, blurb: 'Scattered islands. Ships and planes carry the fight.' },
  { id: 'random', name: 'Random front', kind: 'continent', seed: null, blurb: 'A fresh battlefield from a random seed.' },
];

// opts (custom maps from the Map Editor): { W, H, water, mountains, forest, desert } with sliders 0–100.
function genMap(kind, seed, name, opts = {}) {
  const W = opts.W || 26,
    H = opts.H || 18;
  if (kind === 'custom') return genCustom(W, H, seed, name, opts);
  const rnd = mulberry32(seed),
    n1 = makeNoise(seed),
    n2 = makeNoise(seed + 991);
  const g = [];
  const mid = (H - 1) / 2;
  const land = (h, m, desert) => {
    if (desert) return h > 0.71 ? 'm' : h > 0.62 ? 'h' : m > 0.66 ? 'f' : m < 0.36 ? 'p' : 's';
    return h > 0.71 ? 'm' : h > 0.62 ? 'h' : m > 0.55 ? 'f' : 'p';
  };
  for (let r = 0; r < H; r++) {
    const row = [];
    for (let c = 0; c < W; c++) {
      const edge = Math.min(c, r, W - 1 - c, H - 1 - r);
      const { x, y } = toWorld(c, r);
      const h = n1(x * 0.16, y * 0.16),
        m = n2(x * 0.28, y * 0.28);
      let t;
      if (edge === 0) t = '~';
      else if (edge === 1) t = h < 0.55 ? 'w' : 's';
      else if (kind === 'strait') {
        const d = Math.abs(r - mid);
        if (d <= 0.5) t = c >= 12 && c <= 13 ? (r < mid ? 'h' : 's') : c === 4 || c === W - 5 ? 's' : c > 5 && c < W - 6 ? '~' : 'w';
        else if (d <= 1.5) t = h < 0.42 ? 'w' : h < 0.56 ? 's' : land(h, m, r > mid);
        else t = land(h, m, r > mid);
      } else if (kind === 'islands') {
        const hh = h + (m - 0.5) * 0.25;
        t = hh < 0.46 ? '~' : hh < 0.52 ? 'w' : hh < 0.55 ? 's' : land(h + 0.04, m, false);
      } else {
        t = h < 0.36 ? '~' : h < 0.42 ? 'w' : h < 0.45 ? 's' : land(h, m, y / (H * 1.5) > 0.55);
      }
      row.push(t);
    }
    g.push(row);
  }
  // scatter a few cities on open land
  let placed = 0,
    tries = 0;
  while (placed < 4 && tries++ < 400) {
    const c = 3 + Math.floor(rnd() * (W - 6)),
      r = 3 + Math.floor(rnd() * (H - 6));
    if ('ps'.includes(g[r][c])) {
      g[r][c] = 'c';
      placed++;
    }
  }
  // spawns: NW, SE, NE, SW — force usable land around each
  const spawns = [
    [2, 2],
    [W - 3, H - 3],
    [W - 3, 2],
    [2, H - 3],
  ].map(([c, r]) => ({ c, r }));
  for (const s of spawns) {
    g[s.r][s.c] = 'c';
    for (const nb of neighborsRaw(s.c, s.r, W, H)) {
      const edge = Math.min(nb.c, nb.r, W - 1 - nb.c, H - 1 - nb.r);
      if (edge >= 2 && !'psf'.includes(g[nb.r][nb.c])) g[nb.r][nb.c] = 'p';
    }
  }
  if (kind !== 'islands') connectSpawns(g, spawns, W, H);
  return { name, kind, seed, W, H, rows: g.map(r => r.join('')), spawns };
}

// Tanks need a land route to every enemy: if two spawns are cut off, carve a sandbar along the hex line between them.
function connectSpawns(g, spawns, W, H) {
  const landPass = t => MOVE_COST.land[t] != null;
  const reach = from => {
    const seen = new Set([key(from.c, from.r)]),
      q = [from];
    while (q.length) {
      const cur = q.shift();
      for (const n of neighborsRaw(cur.c, cur.r, W, H)) {
        const k = key(n.c, n.r);
        if (!seen.has(k) && landPass(g[n.r][n.c])) {
          seen.add(k);
          q.push(n);
        }
      }
    }
    return seen;
  };
  const toCube = h => {
    const a = offToAxial(h.c, h.r);
    return { x: a.q, z: a.r, y: -a.q - a.r };
  };
  const fromCube = (x, y, z) => {
    let rx = Math.round(x),
      ry = Math.round(y),
      rz = Math.round(z);
    const dx = Math.abs(rx - x),
      dy = Math.abs(ry - y),
      dz = Math.abs(rz - z);
    if (dx > dy && dx > dz) rx = -ry - rz;
    else if (dy > dz) ry = -rx - rz;
    else rz = -rx - ry;
    return { c: rx + (rz - (rz & 1)) / 2, r: rz };
  };
  for (const [i, j] of [
    [0, 1],
    [2, 3],
    [0, 2],
    [1, 3],
  ]) {
    const A = spawns[i],
      Bs = spawns[j];
    if (reach(A).has(key(Bs.c, Bs.r))) continue;
    const a = toCube(A),
      b = toCube(Bs),
      N = hexDist(A, Bs);
    for (let k = 0; k <= N; k++) {
      const t = k / N,
        h = fromCube(lerp(a.x, b.x, t) + 1e-6, lerp(a.y, b.y, t) + 1e-6, lerp(a.z, b.z, t) - 2e-6);
      if (h.c < 1 || h.r < 1 || h.c > W - 2 || h.r > H - 2) continue;
      if (!landPass(g[h.r][h.c])) g[h.r][h.c] = 's';
    }
  }
}

// Map Editor generator: same noise as the presets, shaped by four sliders (0–100).
function genCustom(W, H, seed, name, o) {
  const rnd = mulberry32(seed),
    n1 = makeNoise(seed),
    n2 = makeNoise(seed + 991);
  const water = o.water ?? 35,
    mtn = o.mountains ?? 30,
    forest = o.forest ?? 35,
    desert = o.desert ?? 20;
  const sea = 0.28 + water * 0.0035; // noise below this is water
  const mLine = 0.78 - mtn * 0.0022,
    hLine = mLine - 0.06 - mtn * 0.0006;
  const fLine = 0.72 - forest * 0.0035,
    scale = (0.16 * 26) / Math.max(W, 26);
  const g = [];
  for (let r = 0; r < H; r++) {
    const row = [];
    for (let c = 0; c < W; c++) {
      const edge = Math.min(c, r, W - 1 - c, H - 1 - r),
        { x, y } = toWorld(c, r);
      const h = n1(x * scale, y * scale),
        m = n2(x * scale * 1.7, y * scale * 1.7);
      let t;
      if (water > 5 && edge === 0) t = '~';
      else if (h < sea - 0.05) t = '~';
      else if (h < sea) t = 'w';
      else if (h < sea + 0.025) t = 's';
      else if (h > mLine) t = 'm';
      else if (h > hLine) t = 'h';
      else if (m > fLine) t = 'f';
      else t = y / (H * 1.5) > 1 - desert / 100 ? 's' : 'p';
      row.push(t);
    }
    g.push(row);
  }
  let placed = 0,
    tries = 0;
  const want = Math.max(2, Math.round((W * H) / 110));
  while (placed < want && tries++ < 800) {
    const c = 2 + Math.floor(rnd() * (W - 4)),
      r = 2 + Math.floor(rnd() * (H - 4));
    if ('ps'.includes(g[r][c])) {
      g[r][c] = 'c';
      placed++;
    }
  }
  const spawns = [
    [2, 2],
    [W - 3, H - 3],
    [W - 3, 2],
    [2, H - 3],
  ].map(([c, r]) => ({ c, r }));
  for (const sp of spawns) {
    g[sp.r][sp.c] = 'c';
    for (const nb of neighborsRaw(sp.c, sp.r, W, H)) if (!'psf'.includes(g[nb.r][nb.c])) g[nb.r][nb.c] = 'p';
  }
  if (water < 70) connectSpawns(g, spawns, W, H);
  return { name, kind: 'custom', seed, W, H, rows: g.map(r => r.join('')), spawns, roads: [] };
}
// Any map by id: a generated preset, a real-world map, or the custom map carried in the settings.
function mapDefFor(id, S = appState.settings) {
  const preset = MAP_PRESETS.find(p => p.id === id);
  if (preset) return genMap(preset.kind, preset.seed ?? S.randomSeed, preset.name);
  const real = REAL_MAPS.find(m => m.id === id);
  if (real) return clone(real);
  if (S.customMap && S.customMap.id === id) return clone(S.customMap);
  return genMap(MAP_PRESETS[0].kind, MAP_PRESETS[0].seed, MAP_PRESETS[0].name);
}
const mapName = (id, S = appState.settings) =>
  (
    MAP_PRESETS.find(p => p.id === id) ||
    REAL_MAPS.find(m => m.id === id) ||
    (S.customMap && S.customMap.id === id ? S.customMap : null) || { name: id }
  ).name;
