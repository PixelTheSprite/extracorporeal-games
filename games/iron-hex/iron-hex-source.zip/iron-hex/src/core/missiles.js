// Phase 12: missile silos (rule 'missiles') and city development (rule 'cityDev').
// Starting values live in REAL so the A/B harness can sweep them; see tools/ab and the Phase 12 report.
Object.assign(REAL, {
  SILO_COST: 15, // funds to start a silo when the economy is on (otherwise only build time limits them)
  MISSILE_CHARGE: 5,
  MISSILE_CHARGE_MIN: 2,
  MISSILE_CITIES_PER_TURN: 2, // turns to charge; each 2 cities held saves a turn
  MISSILE_RANGE: 10,
  MISSILE_DMG: 60,
  MISSILE_SPLASH: 20,
  MISSILE_INTERCEPT: 0.4,
  MISSILE_INTERCEPT_MAX: 0.8,
  MISSILE_INTERCEPT_RANGE: 2,
  MISSILE_TARGET_GUARDS: true, // can units on the struck hex itself intercept? (A/B: false keeps warships from shielding themselves)
  CITY_LEVEL_COST: [0, 0, 20, 35],
  CITY_INVEST_TURNS: 3, // level 2 costs 20, level 3 costs 35; 3 turns each
  CITY_INCOME_PER_LEVEL: 2,
  CITY_DEF_PER_LEVEL: 0.1,
  CITY_HEAL_PER_LEVEL: 0.05,
  CITY_CHARGE_RANGE: 6,
});

// ---- missile silos ----
const ownSilos = (B, pid) =>
  Object.entries(B.structs || {})
    .filter(([, s]) => s.kind === 'silo' && !s.build && s.owner === pid)
    .map(([k, s]) => Object.assign({ k }, s));
function chargeNeeded(B, pid, at) {
  const cities = Object.values(B.cities || {}).filter(c => c.owner === pid).length;
  let n = REAL.MISSILE_CHARGE - Math.floor(cities / REAL.MISSILE_CITIES_PER_TURN);
  // City development: a level-3 city of yours near the silo speeds it up
  if (
    B.rules.cityDev &&
    Object.entries(B.cities || {}).some(
      ([k, c]) => c.owner === pid && (c.level || 1) >= 3 && hexDist(at, keyHex(k)) <= REAL.CITY_CHARGE_RANGE
    )
  )
    n -= 1;
  return Math.max(REAL.MISSILE_CHARGE_MIN, n);
}
const keyHex = k => {
  const [c, r] = unkey(k);
  return { c, r };
};
const siloReady = (B, s) => !!s && s.kind === 'silo' && !s.build && (s.charge || 0) >= chargeNeeded(B, s.owner, keyHex(s.k || ''));
// End of turn: built silos charge.
function logMissiles(B) {
  if (!B.rules.missiles) return false;
  let ev = false;
  for (const [k, s] of Object.entries(B.structs || {})) {
    if (s.kind !== 'silo' || s.build || s.owner == null) continue;
    const need = chargeNeeded(B, s.owner, keyHex(k)),
      was = s.charge || 0;
    s.charge = Math.min(need, was + 1);
    if (was < need && s.charge >= need) {
      const t = tileAt(...unkey(k));
      floatText({ px: t.wx, py: t.wy, pz: t.z, type: 'inf' }, 'Missile ready', '#ffb03a');
      ev = true;
    }
  }
  return ev;
}
// Can this hex be targeted by army pid's silo at siloKey?
function strikeTargetOk(B, pid, siloKey, h) {
  const s = B.structs[siloKey];
  if (!s || s.kind !== 'silo' || s.owner !== pid || !siloReady(B, Object.assign({ k: siloKey }, s))) return false;
  if (hexDist(keyHex(siloKey), h) > REAL.MISSILE_RANGE) return false;
  if (fogOn(B)) {
    if (!B.vis) computeVision(B);
    const v = B.vis[teamOf(pid, B)];
    return !!v && v.has(key(h.c, h.r));
  }
  return true;
}
// Missile launches are army actions keyed by silo: orders['strike:<c,r>'] = { type: 'strike', target: {c, r} }.
async function fireMissiles(B, orders) {
  if (!B.rules.missiles) return;
  for (const [k, o] of Object.entries(orders)) {
    if (!k.startsWith('strike:') || !o || o.type !== 'strike' || !o.target) continue;
    const sk = k.slice(7),
      s = B.structs[sk];
    if (!s || !strikeTargetOk(B, s.owner, sk, o.target)) continue;
    const pid = s.owner,
      at = o.target;
    s.charge = 0;
    B.stats.missiles = (B.stats.missiles || 0) + 1;
    if (B.stats.firstStrike == null) B.stats.firstStrike = pid;
    // interception: each of the target side's anti-aircraft units and warships near the target has a chance
    const guards = aliveUnits(B).filter(
      u =>
        isEnemy(u.pid, pid, B) &&
        (isAAUnit(UNIT_TYPES[u.type]) || UNIT_TYPES[u.type].domain === 'sea') &&
        hexDist(u, at) <= REAL.MISSILE_INTERCEPT_RANGE &&
        (REAL.MISSILE_TARGET_GUARDS || !(u.c === at.c && u.r === at.r)) // units on the struck hex itself, unless the flag allows
    ).length;
    const p = Math.min(REAL.MISSILE_INTERCEPT_MAX, REAL.MISSILE_INTERCEPT * guards);
    await VIEW.missile(keyHex(sk), at);
    if (guards && rng(B) < p) {
      B.stats.intercepted = (B.stats.intercepted || 0) + 1;
      const t = tileAt(at.c, at.r, B);
      floatText({ px: t.wx, py: t.wy, pz: t.z, type: 'inf' }, 'Intercepted', '#9fe86a');
      continue;
    }
    let dealt = 0,
      highValue = false;
    const hit = (u, dmg) => {
      const d = Math.min(
        u.hp,
        Math.round(dmg * (UNIT_TYPES[u.type].domain === 'land' ? 1 - terrainDef(UNIT_TYPES[u.type], tileAt(u.c, u.r, B).t, B) * 0.5 : 1))
      );
      u.hp -= d;
      dealt += d;
      floatText(u, `-${d}`, '#ff6a4a');
      if (u.hp <= 0 && u.cargo) {
        const cg = unitById(u.cargo, B);
        if (cg) cg.hp = 0;
      }
    };
    const onTarget = aliveUnits(B).filter(u => u.c === at.c && u.r === at.r);
    for (const u of onTarget) {
      hit(u, REAL.MISSILE_DMG);
      if (['battleship', 'ship', 'carrier', 'arty'].includes(u.type)) highValue = true;
    }
    const near = aliveUnits(B).filter(u => hexDist(u, at) === 1);
    for (const u of near) hit(u, REAL.MISSILE_SPLASH);
    if (onTarget.length + near.filter(u => isEnemy(u.pid, pid, B)).length >= 3) highValue = true; // a cluster
    const st = B.structs[key(at.c, at.r)];
    if (st) {
      st.hp -= REAL.MISSILE_DMG;
      dealt += REAL.MISSILE_DMG;
      highValue = true;
      if (st.hp <= 0) destroyStructAt(B, at.c, at.r);
    }
    B.stats.missileDmg = (B.stats.missileDmg || 0) + dealt;
    if (highValue) B.stats.missileHighValue = (B.stats.missileHighValue || 0) + 1;
    VIEW.shake(8);
    VIEW.cards();
    VIEW.hud();
  }
}

// ---- city development ----
const cityLevel = c => (c && c.level) || 1;
// Investments are army actions keyed by city: orders['invest:<c,r>'] = { type: 'invest' }. Paid when ordered.
function investOk(B, pid, ck) {
  const c = B.cities[ck];
  if (!B.rules.cityDev || !B.rules.income || !c || c.owner !== pid || c.investing || cityLevel(c) >= 3) return false;
  return (B.funds[pid] || 0) >= REAL.CITY_LEVEL_COST[cityLevel(c) + 1];
}
function applyInvestments(B, orders) {
  if (!B.rules.cityDev) return;
  for (const [k, o] of Object.entries(orders)) {
    if (!k.startsWith('invest:') || !o || o.type !== 'invest') continue;
    const ck = k.slice(7),
      c = B.cities[ck];
    if (!c || !investOk(B, c.owner, ck)) continue;
    const to = cityLevel(c) + 1;
    B.funds[c.owner] -= REAL.CITY_LEVEL_COST[to];
    c.investing = { to, turns: REAL.CITY_INVEST_TURNS };
    B.stats.invested = (B.stats.invested || 0) + REAL.CITY_LEVEL_COST[to];
  }
}
// End of turn: investments progress; developed cities heal the units in them.
function logCityDev(B) {
  if (!B.rules.cityDev) return false;
  let ev = false;
  for (const [k, c] of Object.entries(B.cities || {})) {
    const h = keyHex(k),
      t = tileAt(h.c, h.r, B);
    if (c.investing && --c.investing.turns <= 0) {
      c.level = c.investing.to;
      c.investing = null;
      B.stats.cityLevels = (B.stats.cityLevels || 0) + 1;
      floatText({ px: t.wx, py: t.wy, pz: t.z, type: 'inf' }, `City level ${c.level}`, '#9fe86a');
      ev = true;
    }
    const lvl = cityLevel(c);
    if (lvl > 1 && c.owner != null)
      for (const u of aliveUnits(B))
        if (u.c === h.c && u.r === h.r && friendOf(u.pid, c.owner, B) && u.hp < u.maxHp)
          u.hp = Math.min(u.maxHp, u.hp + Math.ceil(u.maxHp * REAL.CITY_HEAL_PER_LEVEL * (lvl - 1)));
  }
  return ev;
}
// A captured city loses a level and any investment in progress.
function cityCaptured(B, c) {
  if (!B.rules.cityDev) return;
  c.level = Math.max(1, cityLevel(c) - 1);
  c.investing = null;
}
const cityIncome = (B, pid) =>
  B.rules.cityDev
    ? Object.values(B.cities || {})
        .filter(c => c.owner === pid)
        .reduce((s, c) => s + REAL.CITY_INCOME_PER_LEVEL * (cityLevel(c) - 1), 0)
    : 0;
// Units in a developed city take less damage.
function cityDefense(pos, B = appState.battle) {
  if (!B || !B.rules.cityDev) return 1;
  const c = B.cities && B.cities[key(pos.c, pos.r)];
  return c ? 1 - REAL.CITY_DEF_PER_LEVEL * (cityLevel(c) - 1) : 1;
}
// Extra purchases per turn: one for each level-3 city (Mid-battle production).
const extraBuys = (B, pid) =>
  B.rules.cityDev ? Object.values(B.cities || {}).filter(c => c.owner === pid && cityLevel(c) >= 3).length : 0;
