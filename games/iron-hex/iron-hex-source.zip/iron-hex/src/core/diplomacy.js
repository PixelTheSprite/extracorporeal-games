// Teams and diplomacy. Every army has a team (B.teams[pid]); armies on the same team are allies:
// they never fight, and they win together. Allies can also grant each other three things, each one-sided
// (A granting B does not make B grant A), stored as B.diplo[giver][receiver] = { territory, resupply, passage }:
//   territory  the giver's ground counts as friendly for the receiver: the receiver doesn't paint over it,
//              and where their supply rings overlap the hex goes to the giver instead of turning neutral
//   resupply   the receiver's units resupply in the giver's territory and at the giver's airfields, ports and depots
//   passage    the receiver's units can move through hexes the giver's units occupy
// With no teams set (free-for-all), every other army is an enemy and nothing here changes the rules.
const GRANTS = {
  territory: {
    label: 'Share territory',
    desc: 'They won’t paint over your ground, and overlapping supply rings stay yours instead of turning neutral.',
  },
  resupply: { label: 'Resupply', desc: 'Their units refuel and rearm in your territory and at your airfields, ports and depots.' },
  passage: { label: 'Passage', desc: 'Their units can move through hexes your units occupy.' },
};
const teamOf = (pid, B = appState.battle) => {
  const t = B && B.teams;
  return t && t[pid] != null ? t[pid] : pid;
};
const isAlly = (a, b, B = appState.battle) => a !== b && teamOf(a, B) === teamOf(b, B);
const isEnemy = (a, b, B = appState.battle) => a !== b && teamOf(a, B) !== teamOf(b, B);
// Does `giver` grant `kind` to `receiver`? Allies grant everything unless the giver has switched it off.
function grants(giver, receiver, kind, B = appState.battle) {
  if (giver == null || receiver == null || !isAlly(giver, receiver, B)) return false;
  const d = B.diplo,
    g = d && d[giver] && d[giver][receiver];
  return !g || g[kind] !== false;
}
// Armies whose ground and bases resupply this army: itself, plus allies that grant it resupply.
const suppliersOf = (pid, B = appState.battle) => B.players.map(p => p.id).filter(o => o === pid || grants(o, pid, 'resupply', B));
const friendlyGround = (owner, pid, B = appState.battle) => owner === pid || grants(owner, pid, 'resupply', B);
// Victory helpers: a team is out when none of its armies can still fight.
const teamsIn = (players, B = appState.battle) => [...new Set(players.map(p => teamOf(p.id, B)))];
const teamShare = (B, team) => B.players.filter(p => teamOf(p.id, B) === team).reduce((s, p) => s + territoryShare(B, p.id), 0);
// Endgame score (supply exhaustion and turn-limit tiebreaks): remaining unit HP, 10 per hex of territory,
// 50 per city or capturable structure held.
function teamScore(B, team) {
  const pids = B.players.filter(p => teamOf(p.id, B) === team).map(p => p.id);
  const hp = allAlive(B)
    .filter(u => pids.includes(u.pid))
    .reduce((s, u) => s + u.hp, 0);
  const hexes = Object.values(B.territory || {}).filter(v => pids.includes(v)).length;
  const sites = Object.values(B.cities || {})
    .concat(Object.values(B.structs || {}).filter(s => !s.build && STRUCTS[s.kind].capture))
    .filter(s => pids.includes(s.owner)).length;
  return Math.round(hp + 10 * hexes + 50 * sites);
}
