// Weather and time of day (rule 'weather') and morale (rule 'morale').
// Weather comes in 3-turn spells with a 2-spell forecast; every 8 turns are 6 of day and 2 of night.
const WEATHER = {
  clear: { name: 'Clear', icon: '☀', desc: 'No effects.' },
  rain: { name: 'Rain', icon: '🌧', desc: 'Every unit is 8 points harder to hit.' },
  fog: { name: 'Fog', icon: '🌫', desc: 'Sight −1 (aircraft −2); soldiers on foot are 15 points harder to hit.' },
  storm: { name: 'Storm', icon: '⛈', desc: 'Aircraft are grounded: they can’t move or fire, and burn no fuel.' },
};
const DAY_LEN = 6,
  NIGHT_LEN = 2,
  WEATHER_SPELL = 3;
const isNight = turn => (turn - 1) % (DAY_LEN + NIGHT_LEN) >= DAY_LEN;
function rollWeather(B = appState.battle) {
  const x = rng(B);
  return x < 0.5 ? 'clear' : x < 0.75 ? 'rain' : x < 0.9 ? 'fog' : 'storm';
}
function initWeather(B) {
  B.weather = { now: 'clear', forecast: [rollWeather(B), rollWeather(B)] };
}
// Called as a turn ends: a new spell starts every WEATHER_SPELL turns.
function advanceWeather(B) {
  if (!B.weather || B.turn % WEATHER_SPELL) return;
  B.weather.now = B.weather.forecast.shift();
  B.weather.forecast.push(rollWeather(B));
  if (B.weather.now === 'storm') B.stats.storms = (B.stats.storms || 0) + 1;
}
// Current conditions: { w: weather, night }. With the rule off, always a clear day.
const cond = (B = appState.battle) => {
  return B && B.rules && B.rules.weather && B.weather ? { w: B.weather.now, night: isNight(B.turn) } : { w: 'clear', night: false };
};
const grounded = (u, B = appState.battle) => isAir(u) && cond(B).w === 'storm';

// ---- Morale ----
// 0–100. Starts at 60 (+10 per veteran rank). At each turn's end: damage taken lowers it (60 × the share of
// max HP lost), so does friends falling within 2 hexes (−15 each) and being isolated (−8); being near
// two or more friends (+3), on friendly ground (+3) and each kill (+8) raise it.
// Shaken (below 40): deals 20% less damage and is 5 points easier to hit. Broken (below 20): can't fire, and
// the AI pulls it back toward supply. A broken unit rallies once it climbs back to 20.
const MORALE_START = 60,
  SHAKEN = 40,
  BROKEN = 20;
const moraleOn = (B = appState.battle) => {
  return !!(B && B.rules && B.rules.morale);
};
const shaken = (u, B = appState.battle) => moraleOn(B) && u.morale != null && u.morale < SHAKEN;
const broken = (u, B = appState.battle) => moraleOn(B) && u.morale != null && u.morale < BROKEN;
const moraleState = (u, B = appState.battle) =>
  !moraleOn(B) || u.morale == null ? null : u.morale < BROKEN ? 'Broken' : u.morale < SHAKEN ? 'Shaken' : 'Steady';
function initMorale(B) {
  for (const u of B.units) if (u.morale == null) u.morale = Math.min(100, MORALE_START + 10 * (u.vet || 0));
}
function updateMorale(B) {
  const near = (u, o) => (o.pid === u.pid || isAlly(o.pid, u.pid, B)) && hexDist(o, u) <= 2;
  for (const u of aliveUnits(B)) {
    if (u.morale == null) u.morale = MORALE_START;
    const before = moraleState(u, B);
    let m = u.morale;
    const lost = Math.max(0, (u.hp0 ?? u.hp) - u.hp);
    if (lost) m -= Math.round((60 * lost) / u.maxHp);
    if (!u.in) {
      const friends = aliveUnits(B).filter(o => o !== u && !o.in && near(u, o)).length;
      m += friends >= 2 ? 3 : friends === 0 ? -8 : 0;
      if (friendlyGround(B.territory[key(u.c, u.r)], u.pid, B)) m += 3;
      m -= 15 * B.units.filter(o => o.hp <= 0 && (o.hp0 || 0) > 0 && near(u, o)).length;
    } else m += 5; // sheltered aboard a transport
    m += 8 * (u.kills0 || 0);
    u.morale = clamp(Math.round(m), 0, 100);
    const after = moraleState(u, B);
    if (after !== before) {
      if (after === 'Broken') {
        floatText(u, 'Broken!', '#ff6a4a');
        B.stats.broken = (B.stats.broken || 0) + 1;
      } else if (after === 'Shaken' && before === 'Steady') floatText(u, 'Shaken', '#ffb03a');
      else floatText(u, 'Rallied', '#9fe86a');
    }
  }
}
