// Schema checks for unit types and maps. Run at startup, on every loaded save, and by the test suites.
// The Unit Editor and Map Editor should run these before saving anything they create.
const STAT_KEYS = ['speed', 'maneuver', 'armor', 'firepower'];
const DOMAINS = ['land', 'sea', 'air'];

function validateUnitType(id, T) {
  const p = [],
    is = (cond, msg) => {
      if (!cond) p.push(`${id}: ${msg}`);
    };
  for (const k of ['id', 'short', 'name', 'role', 'domain', 'source']) is(T[k], `missing "${k}"`);
  is(T.id === id, `id "${T.id}" doesn't match its key`);
  // Custom unit ids end up in page markup: only u_ followed by lowercase letters, digits and underscores.
  if (T.custom)
    is(
      typeof id === 'string' && SAFE_UNIT_ID.test(id),
      `custom unit id must look like u_name_123 (lowercase letters, digits, underscores)`
    );
  is(DOMAINS.includes(T.domain), `unknown domain "${T.domain}"`);
  is(TYPE_ORDER.includes(id), 'not listed in TYPE_ORDER');
  for (const k of STAT_KEYS) {
    const v = T.stats && T.stats[k];
    is(Number.isInteger(v) && v >= 0 && v <= 10, `stat ${k} must be a whole number 0–10 (got ${v})`);
  }
  is(
    Array.isArray(T.range) && T.range.length === 2 && T.range[0] >= 0 && T.range[0] <= T.range[1],
    'range must be [min, max] with 0 ≤ min ≤ max'
  );
  is(Number.isInteger(T.ammo) && T.ammo > 0, 'ammo must be a positive whole number');
  is(T.fuel == null || T.fuel > 0, 'fuel must be positive when set');
  is(Array.isArray(T.norm) && T.norm.length === 4, 'needs 4 normalization rows (speed, maneuverability, armor, firepower)');
  if (Array.isArray(T.norm))
    T.norm.forEach((row, i) => {
      is(Array.isArray(row) && row.length === 4, `normalization row ${i + 1} needs [stat, real value, scale, score]`);
      if (row && T.stats)
        is(
          row[3] === T.stats[STAT_KEYS[i]],
          `normalization row "${row[0]}" scores ${row[3]} but stats.${STAT_KEYS[i]} is ${T.stats[STAT_KEYS[i]]}`
        );
    });
  if (T.eff) for (const d of Object.keys(T.eff)) is(DOMAINS.includes(d), `eff has unknown domain "${d}"`);
  if (T.bonusVs) for (const k of Object.keys(T.bonusVs)) is(UNIT_TYPES[k], `bonusVs names unknown unit "${k}"`);
  if (Array.isArray(T.carryKinds)) for (const k of T.carryKinds) is(UNIT_TYPES[k], `carryKinds names unknown unit "${k}"`);
  else if (T.carryKinds != null) is(T.carryKinds === 'foot', 'carryKinds must be a list of unit ids or "foot"');
  return p;
}
const MAP_MIN = { W: 12, H: 10 },
  MAP_MAX = { W: 40, H: 30 };
function validateMapDef(def) {
  const p = [];
  if (!def || !Array.isArray(def.rows)) return ['map: missing terrain rows'];
  if (!(def.W >= MAP_MIN.W && def.W <= MAP_MAX.W && def.H >= MAP_MIN.H && def.H <= MAP_MAX.H))
    p.push(`map: size ${def.W} × ${def.H} is outside ${MAP_MIN.W}–${MAP_MAX.W} × ${MAP_MIN.H}–${MAP_MAX.H}`);
  if (!Array.isArray(def.spawns) || def.spawns.length < 2) p.push('map: needs at least 2 spawn points');
  if (def.spawns && def.spawns.length > 4) p.push('map: at most 4 spawn points');
  if (def.spawns && new Set(def.spawns.map(s => s.c + ',' + s.r)).size !== def.spawns.length) p.push('map: two spawn points share a hex');
  if (def.sides && def.sides.length !== (def.spawns || []).length) p.push('map: needs one side name per spawn point');
  for (const k of def.roads || []) {
    const [c, r] = unkey(k);
    if (!(def.rows[r] && def.rows[r][c]) || TERRAIN[def.rows[r][c]].water) {
      p.push(`map: road at ${k} is not on land`);
      break;
    }
  }
  if (def.rows.length !== def.H) p.push(`map: ${def.rows.length} rows but H is ${def.H}`);
  def.rows.forEach((row, r) => {
    if (row.length !== def.W) p.push(`map: row ${r} has ${row.length} hexes but W is ${def.W}`);
    for (const ch of row)
      if (!TERRAIN[ch]) {
        p.push(`map: unknown terrain "${ch}" in row ${r}`);
        break;
      }
  });
  (def.spawns || []).forEach((sp, i) => {
    if (sp.c < 0 || sp.r < 0 || sp.c >= def.W || sp.r >= def.H) p.push(`map: spawn ${i + 1} is off the map`);
    else if (TERRAIN[def.rows[sp.r][sp.c]].water) p.push(`map: spawn ${i + 1} is on water`);
  });
  return p;
}
// Every unit type plus every map preset (random maps checked with a fixed seed).
function validateAll() {
  const p = [];
  for (const [id, T] of Object.entries(UNIT_TYPES)) p.push(...validateUnitType(id, T));
  for (const m of MAP_PRESETS) {
    const def = genMap(m.kind, m.seed ?? 12345, m.name);
    p.push(...validateMapDef(def).map(x => `${m.name} ${x}`));
    p.push(...validateLayout({ structs: autoLayout(def, 4) }, def).map(x => `${m.name} auto ${x}`));
  }
  for (const m of REAL_MAPS) {
    p.push(...validateMapDef(m).map(x => `${m.name} ${x}`));
    p.push(...validateLayout({ structs: autoLayout(m, m.spawns.length) }, m).map(x => `${m.name} auto ${x}`));
  }
  for (const [k, S] of Object.entries(STRUCTS)) {
    if (!STRUCT_ORDER.includes(k)) p.push(`structure ${k}: not in STRUCT_ORDER`);
    if (!(Number.isInteger(S.turns) && S.turns >= 1 && S.turns <= 4)) p.push(`structure ${k}: build time must be 1–4 turns`);
    if (!(S.hp > 0) || !(S.armor >= 0 && S.armor <= 10)) p.push(`structure ${k}: bad hp or armor`);
  }
  return p;
}
