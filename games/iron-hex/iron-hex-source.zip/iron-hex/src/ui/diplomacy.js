// Diplomacy: teams before a battle (Diplomacy screen, from Quick battle), and during a battle what you grant
// each ally (the 🤝 Allies button). Grants are one-sided: switching one off changes only what you give.
const TEAM_NAMES = ['Team 1', 'Team 2', 'Team 3', 'Team 4'];
// Sides on the current Quick battle setup, in army order (your side first), with the map's default teams.
function prepSides() {
  const S = appState.settings,
    maps = prepMaps(),
    cur = maps.find(m => m.id === S.mapId) || maps[0],
    def = cur.def();
  const order = [...def.spawns.keys()],
    ps = def.sides ? S.playSide || 0 : 0;
  if (ps) {
    order.splice(order.indexOf(ps), 1);
    order.unshift(ps);
  }
  const names = order.map((i, slot) => (def.sides ? def.sides[i].name : ARMIES[slot].name)).slice(0, S.armies);
  const teams = order.map((i, slot) => (def.teams ? def.teams[i] : slot)).slice(0, S.armies);
  return { names, defaults: teams, key: `${S.mapId}|${ps}|${S.armies}` };
}
// Keeps S.teams in step with the setup: a new map, side or army count resets to that map's default teams.
function syncTeams() {
  const S = appState.settings,
    sides = prepSides();
  if (S.teamsFor !== sides.key || !Array.isArray(S.teams) || S.teams.length < S.armies) {
    S.teams = sides.defaults.slice();
    S.teamsFor = sides.key;
  }
  return sides;
}
const teamSummary = (names, teams) => {
  const groups = [...new Set(teams)].map(t => names.filter((_, i) => teams[i] === t));
  return groups.every(g => g.length === 1) ? 'Free-for-all: every army fights every other.' : groups.map(g => g.join(' + ')).join('  vs  ');
};
function renderDiplomacy() {
  const S = appState.settings,
    sides = syncTeams(),
    teams = S.teams.slice(0, S.armies);
  S.grants = S.grants || { territory: true, resupply: true, passage: true };
  $('#dp-teams').innerHTML = sides.names
    .map(
      (
        n,
        i
      ) => `<div class="team-row"><span class="sw" style="background:${ARMIES[i].color};width:22px;height:22px;border:3px solid var(--ink)"></span>
    <span><b>${escapeHtml(n)}</b>${i === 0 ? ' (you)' : ''}</span>
    <span class="seg" role="radiogroup" aria-label="Team for ${escapeHtml(n)}">${TEAM_NAMES.slice(0, S.armies)
      .map(
        (t, j) =>
          `<button class="btn sm alt" role="radio" aria-checked="${teams[i] === j}" aria-pressed="${teams[i] === j}" data-dp-team="${i}:${j}">${t}</button>`
      )
      .join('')}</span></div>`
    )
    .join('');
  $('#dp-summary').textContent = teamSummary(sides.names, teams);
  $('#dp-presets').innerHTML =
    `<button class="btn sm alt" data-dp-preset="ffa">Free-for-all</button>${S.armies === 4 ? '<button class="btn sm alt" data-dp-preset="2v2">2 vs 2 (you + army 2)</button>' : ''}${sides.defaults.some((t, i) => t !== i) ? '<button class="btn sm alt" data-dp-preset="map">Map’s alliances</button>' : ''}`;
  $('#dp-grants').innerHTML = Object.entries(GRANTS)
    .map(
      ([k, g]) => `<div class="pick-row grant-row"><span><b>${g.label}</b><small>${g.desc}</small></span>
    <button class="btn sm alt" data-dp-grant="${escapeHtml(k)}" aria-pressed="${S.grants[k] !== false}" aria-label="${g.label}">${S.grants[k] !== false ? 'On' : 'Off'}</button></div>`
    )
    .join('');
}
$('#scr-diplomacy').addEventListener('click', e => {
  const S = appState.settings;
  const t = e.target.closest('[data-dp-team]');
  if (t) {
    const [i, j] = t.dataset.dpTeam.split(':').map(Number),
      next = S.teams.slice();
    next[i] = j;
    if (new Set(next.slice(0, S.armies)).size < 2) {
      $('#dp-status').textContent = 'At least two teams are needed: someone has to be the enemy.';
      return;
    }
    S.teams = next;
    $('#dp-status').textContent = '';
    SFX.play('click');
    renderDiplomacy();
    return;
  }
  const pr = e.target.closest('[data-dp-preset]');
  if (pr) {
    const k = pr.dataset.dpPreset;
    S.teams = k === 'ffa' ? [0, 1, 2, 3] : k === '2v2' ? [0, 0, 1, 1] : prepSides().defaults.slice();
    $('#dp-status').textContent = '';
    SFX.play('click');
    renderDiplomacy();
    return;
  }
  const g = e.target.closest('[data-dp-grant]');
  if (g) {
    S.grants[g.dataset.dpGrant] = S.grants[g.dataset.dpGrant] === false;
    SFX.play('click');
    renderDiplomacy();
  }
});
// In battle: your grants to each ally (change any time; they apply from the next turn's resolution).
function openDiploDialog() {
  const B = appState.battle;
  if (!B) return;
  const allies = B.players.filter(p => isAlly(me(), p.id));
  const row = (p, mine) =>
    `<tr><td>${escapeHtml(mine ? 'You → ' + p.name : p.name + ' → you')}</td>${Object.keys(GRANTS)
      .map(k =>
        mine
          ? `<td><button class="btn sm alt" data-dg="${p.id}:${k}" aria-pressed="${grants(me(), p.id, k)}" aria-label="${GRANTS[k].label} for ${escapeHtml(p.name)}">${grants(me(), p.id, k) ? 'On' : 'Off'}</button></td>`
          : `<td>${grants(p.id, me(), k) ? 'Yes' : 'No'}</td>`
      )
      .join('')}</tr>`;
  showDialog(`<div class="panel" role="dialog" aria-modal="true" aria-labelledby="dg-title"><h2 id="dg-title">Diplomacy</h2>
    <p>${escapeHtml(
      teamSummary(
        B.players.map(p => p.name),
        B.players.map(p => teamOf(p.id))
      )
    )}</p>
    ${
      allies.length
        ? `<div class="tbl-wrap"><table class="tbl grant-tbl"><thead><tr><th></th>${Object.values(GRANTS)
            .map(g => `<th>${g.label}</th>`)
            .join('')}</tr></thead><tbody>${allies.map(p => row(p, true) + row(p, false)).join('')}</tbody></table></div>
      <ul class="uc-list">${Object.values(GRANTS)
        .map(g => `<li><b>${g.label}:</b> ${g.desc}</li>`)
        .join('')}</ul>
      <p class="src">Allies never fight each other and win together. You can switch what you grant at any time; it takes effect from the next turn. AI allies grant you everything.</p>`
        : '<p class="src">You have no allies in this battle. Set teams on the Diplomacy screen before a Quick battle.</p>'
    }
    <div class="row-end"><span></span><button class="btn" id="dg-close">Close</button></div></div>`);
  $('#dg-close').focus();
  $('#modal')
    .querySelectorAll('[data-dg]')
    .forEach(
      b =>
        (b.onclick = () => {
          const [pid, k] = b.dataset.dg.split(':'),
            d = (B.diplo[me()] = B.diplo[me()] || {}),
            g = (d[pid] = d[pid] || { territory: true, resupply: true, passage: true });
          g[k] = !grants(me(), +pid, k);
          SFX.play('click');
          openDiploDialog();
        })
    );
  $('#dg-close').onclick = () => closeModal();
}
