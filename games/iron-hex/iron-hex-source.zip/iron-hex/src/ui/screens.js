// ---------- Screens ----------

function go(id, opt = {}) {
  SFX.init();
  closeMenu();
  closeModal();
  ensureCustomSprites();
  if (appState.screen === 'multi' && id !== 'multi') leaveMulti();
  $$('.screen').forEach(s => (s.hidden = s.id !== 'scr-' + id));
  setMusicScene(id === 'battle' ? 'battle' : 'menu');
  if (id === 'select') {
    markTutorial();
    renderHQMenu();
  }
  appState.screen = id;
  if (id === 'prep') renderPrep();
  if (id === 'diag') renderDiag();
  if (id === 'infra') renderInfra();
  if (id === 'mapedit') renderMapEdit();
  if (id === 'unitedit') renderUnitEdit();
  if (id === 'campaign') renderCampaign();
  if (id === 'multi') renderMulti();
  if (id === 'replays') renderReplays();
  if (id === 'campedit') renderCampEdit();
  if (id === 'diplomacy') renderDiplomacy();
  if (id === 'leaderboard') {
    renderLeaderboard();
    renderBalanceData();
  }
  if (id === 'gallery') renderGallery();
  if (id === 'library') renderLibrary();
  if (id === 'settings') renderSettings();
  if (id === 'battle')
    requestAnimationFrame(() => {
      resizeCanvas();
    });
  const first = document.querySelector('#scr-' + id + ' button');
  if (first && id !== 'battle') first.focus({ preventScroll: true });
}

document.addEventListener('click', e => {
  const g = e.target.closest('[data-go]');
  if (g) {
    SFX.init();
    SFX.play('click');
    go(g.dataset.go);
    return;
  }
});

$('#btn-quit').addEventListener('click', () => {
  try {
    window.close();
  } catch (e) {}
  go('quit');
});

// ---------- Title animation ----------
const titleScene = { c: null, x: null };

function drawTitle(now) {
  const c = $('#title-bg');
  const W = 320,
    Hh = clamp(Math.round((320 * innerHeight) / Math.max(1, innerWidth)), 180, 640);
  if (c.width !== W || c.height !== Hh) {
    c.width = W;
    c.height = Hh;
  }
  const x = c.getContext('2d');
  x.imageSmoothingEnabled = false;
  const bands = ['#2e2350', '#4a2d5e', '#7a3c62', '#b0505a', '#e0785a', '#f2a060', '#f8c878'];
  const hz = Math.round(Hh * 0.62);
  bands.forEach((col, i) => {
    x.fillStyle = col;
    x.fillRect(0, Math.round((i * hz) / bands.length), W, Math.ceil(hz / bands.length) + 1);
  });
  x.fillStyle = '#ffe8a0';
  x.beginPath();
  x.arc(W * 0.72, hz - 6, 26, Math.PI, 0);
  x.fill();
  const t = now / 1000;
  // far mesas
  x.fillStyle = '#6a3448';
  for (let i = -1; i < 6; i++) {
    const bx = ((((i * 90 - t * 6) % 450) + 450) % 450) - 90;
    x.fillRect(Math.round(bx), hz - 22, 50, 22);
    x.fillRect(Math.round(bx) + 8, hz - 30, 30, 8);
  }
  // dunes
  x.fillStyle = '#c0763e';
  for (let px = 0; px < W; px += 2) {
    const y = hz + 6 + Math.sin((px + t * 14) / 22) * 4;
    x.fillRect(px, Math.round(y), 2, Hh);
  }
  x.fillStyle = '#e0a860';
  x.fillRect(0, hz + 22, W, Hh);
  x.fillStyle = '#c88c48';
  for (let i = 0; i < 40; i++) {
    const px = (((i * 37 - t * 40) % W) + W) % W;
    x.fillRect(Math.round(px), hz + 26 + ((i * 13) % Math.max(8, Hh - hz - 30)), 4, 1);
  }
  // units
  const ground = hz + 34;
  [0, 1].forEach(i => {
    const tx = ((t * 26 + i * 90) % (W + 60)) - 30;
    const bob = Math.floor(t * 8 + i) % 2;
    drawSprite(x, SPR.tank[i === 0 ? 0 : 2], tx, ground + bob + i * 10, 2, false);
  });
  const px = W + 40 - ((t * 60) % (W + 80));
  drawSprite(x, SPR.plane[1], px, 40 + Math.sin(t * 2) * 4, 2, true);
}

$('#btn-tutorial').addEventListener('click', () => {
  SFX.init();
  SFX.play('select');
  startTutorial();
});
// First time on Command HQ: point new players at the tutorial.
function markTutorial() {
  $('#btn-tutorial').classList.toggle('suggest', !appState.prefs.tutorialDone);
}

// ---- Command HQ: Play, Editors and Extras are accordions (several may be open; remembered per device) ----
function renderHQMenu() {
  const open = appState.prefs.hqOpen || {};
  for (const h of $$('#scr-select [data-hq]')) {
    const on = !!open[h.dataset.hq];
    h.setAttribute('aria-expanded', String(on));
    $('#' + h.getAttribute('aria-controls')).hidden = !on;
  }
}
$('#scr-select').addEventListener('click', e => {
  const h = e.target.closest('[data-hq]');
  if (!h) return;
  const open = (appState.prefs.hqOpen = appState.prefs.hqOpen || {});
  open[h.dataset.hq] = !open[h.dataset.hq];
  savePrefs();
  SFX.init();
  SFX.play('click');
  renderHQMenu();
});
