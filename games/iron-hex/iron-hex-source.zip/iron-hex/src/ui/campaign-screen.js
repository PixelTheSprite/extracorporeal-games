// Campaign: the objective chip and map marker in battle, and the Campaign screen.
// ---- Objective display in battle -------------------------------------------
function objectiveLabel(B) {
  const o = B.objective;
  if (!o) return '';
  const prog = o.type === 'capture' ? ` (held ${o.progress}/${o.hold})` : o.type === 'survive' ? ` (turn ${B.turn}/${o.turns})` : '';
  return `${o.text}${prog} · ${B.turnLimit} turns`;
}
function drawObjective(P, now) {
  const B = appState.battle,
    o = B && B.objective;
  if (!o || !o.target) return;
  const t = tileAt(o.target.c, o.target.r),
    p = P(t.wx, t.wy, t.z);
  if (!p) return;
  const ctx = R.ctx,
    r = Math.max(6, p.s * (0.9 + 0.12 * Math.sin(now / 250)));
  ctx.strokeStyle = '#ffe04a';
  ctx.lineWidth = 2;
  ctx.setLineDash([4, 3]);
  ctx.beginPath();
  ctx.ellipse(p.x, p.y, r, r * (appState.prefs.view === 'top' ? 1 : 0.55), 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.lineWidth = 1;
  drawText(ctx, '★', p.x, p.y - r * 0.6 - 6, '#ffe04a');
  if (o.type === 'escort') {
    const u = unitById(o.unitId);
    if (u && u.hp > 0 && !u.in) {
      const q = P(u.px, u.py, u.pz);
      if (q) drawText(ctx, '★', q.x, q.y - q.s * 1.4 - 10, '#ffe04a');
    }
  }
}

// ---- Campaign screen --------------------------------------------------------
const OBJ_TEXT = {
  capture: o => `Capture the central town and hold it for ${o.hold} turns`,
  destroyStruct: o => `Destroy or capture the enemy ${STRUCTS[o.kind].name.toLowerCase()}`,
  survive: o => `Survive for ${o.turns} turns`,
  escort: o => `Bring ${o.unitName} within 2 hexes of the enemy capital`,
};
let campConfirm = false;
function renderCampaign() {
  const C = campaignById(activeCampaignId()),
    st = loadCampaign(C.id),
    el = $('#camp-body');
  renderCampaignPicker(C);
  const rosterTbl =
    roster => `<div class="tbl-wrap"><table class="tbl camp-roster"><thead><tr><th></th><th>Unit</th><th>Type</th><th>Rank</th><th>Experience</th></tr></thead><tbody>${roster
      .map(u => {
        const rk = rankFor(u.xp),
          nx = VET_XP[rk + 1];
        return `<tr><td><canvas class="px" width="24" height="16" data-spr-type="${escapeHtml(u.type)}" data-spr-pid="0"></canvas></td><td>${escapeHtml(u.name)}</td><td>${escapeHtml(UNIT_TYPES[u.type] ? UNIT_TYPES[u.type].short : u.type)}</td><td>${'★'.repeat(rk) || '·'} ${RANK_NAME[rk]}</td><td>${u.xp}${nx != null ? ` / ${nx}` : ''}</td></tr>`;
      })
      .join('')}</tbody></table></div>
    <p class="src">Experience: 1 per mission survived, 2 per enemy destroyed. Each rank adds 5% damage and 3 points of evasion. Fallen units are gone for good; after each victory, replacements top the force up to ${MIN_FORCE}.</p>`;
  if (!st) {
    el.innerHTML = `<div class="panel prep-sec"><h2>${escapeHtml(C.name)}</h2><p>${escapeHtml(C.intro)}</p><h2>Your task force</h2>${rosterTbl(newCampaignState(C).roster)}
      <div class="row-end"><button class="btn" id="btn-camp-start">Start campaign</button></div></div>`;
  } else if (st.done) {
    el.innerHTML = `<div class="panel prep-sec"><h2 class="end-title">Campaign complete!</h2><p>${escapeHtml(C.name)}: ${st.history.filter(h => h.won).length} missions won, ${st.history.filter(h => !h.won).length} attempts lost.</p>
      <h2>Survivors</h2>${rosterTbl(st.roster)}<h2>History</h2>${campHistory(st)}<div class="row-end"><button class="btn alt" id="btn-camp-restart">Start over</button></div></div>`;
  } else {
    const m = C.missions[st.mission],
      won = st.history.filter(h => h.won).length;
    el.innerHTML = `<div class="infra-grid"><div class="panel prep-sec">
        <h2>Mission ${won + 1} of ${campaignLength(C)}: ${escapeHtml(m.title)}</h2>
        <canvas class="px camp-map" width="300" height="200" id="camp-map"></canvas>
        <p>${escapeHtml(m.brief)}</p>
        <div class="derived"><span>Objective: ${escapeHtml(OBJ_TEXT[m.objective.type](m.objective))}</span><span>Turn limit ${m.turnLimit}</span><span>Enemy: ${escapeHtml(STRATS[m.enemy.strategy].label)} AI</span><span>Enemy forces: ${escapeHtml(
          rosterList(m.enemy.roster)
            .map(r => UNIT_TYPES[r[0]].short)
            .join(', ')
        )}</span></div>
        ${m.branchNote ? `<p class="src">${escapeHtml(m.branchNote)}</p>` : ''}
        <div class="row-end"><button class="btn alt" id="btn-camp-restart">${campConfirm ? 'Click again to start over' : 'Start over'}</button><button class="btn" id="btn-camp-go">Start mission</button></div>
      </div><div class="panel prep-sec"><h2>Your task force</h2>${rosterTbl(st.roster)}<h2>History</h2>${campHistory(st)}</div></div>`;
    drawMapPreview($('#camp-map'), missionMapDef(m), 2);
  }
  paintSprites(el);
}
const campHistory = st =>
  st.history.length
    ? `<ul class="uc-list">${st.history.map(h => `<li>${escapeHtml(h.title)}: ${h.won ? 'won' : 'lost'} on turn ${h.turns}</li>`).join('')}</ul>`
    : '<p class="src">No missions yet.</p>';
function startMission() {
  const C = campaignById(activeCampaignId()),
    st = loadCampaign(C.id);
  if (!st || st.done) return;
  refreshUnlocks();
  newMissionBattle(st, C);
  enterBattle(`Mission: ${C.missions[st.mission].title}`);
}
$('#scr-campaign').addEventListener('click', e => {
  if (e.target.closest('#btn-camp-start')) {
    saveCampaign(newCampaignState(campaignById(activeCampaignId())));
    SFX.play('select');
    renderCampaign();
    return;
  }
  if (e.target.closest('#btn-camp-go')) {
    SFX.play('select');
    startMission();
    return;
  }
  if (e.target.closest('#btn-camp-restart')) {
    if (!campConfirm && loadCampaign() && !loadCampaign().done) {
      campConfirm = true;
      renderCampaign();
      setTimeout(() => {
        campConfirm = false;
      }, 4000);
      return;
    }
    campConfirm = false;
    saveCampaign(newCampaignState(campaignById(activeCampaignId())));
    SFX.play('click');
    renderCampaign();
  }
});

// Which campaign: the built-in ones and your own, each with its progress.
function renderCampaignPicker(C) {
  $('#camp-pick').innerHTML = String(
    html`${allCampaigns().map(c => {
      const st = loadCampaign(c.id),
        mine = !BUILTIN_CAMPAIGNS.includes(c);
      const status = !st
        ? 'not started'
        : st.done
          ? 'complete'
          : `mission ${st.history.filter(h => h.won).length + 1} of ${campaignLength(c)}`;
      return html`<button class="btn alt" role="radio" aria-checked="${c.id === C.id}" aria-pressed="${c.id === C.id}" data-camp="${c.id}">
        ${c.name}<small> · ${mine ? 'yours · ' : ''}${status}</small>
      </button>`;
    })}`
  );
}
$('#camp-pick').addEventListener('click', e => {
  const b = e.target.closest('[data-camp]');
  if (!b) return;
  appState.prefs.campaignId = b.dataset.camp;
  savePrefs();
  campConfirm = false;
  SFX.play('click');
  renderCampaign();
});
