// The Campaign Editor: make your own campaigns (or copies of the built-in ones) and play them on the Campaign
// screen. A campaign is plain data (see validateCampaign in core/campaign.js), saved in this browser and
// exportable as a file. Text and number fields update the draft as you type; structural changes re-render.
const ce = { def: null, msg: '' };
const CE_RULES = ['weather', 'fog', 'morale', 'realtime']; // rules a mission can switch on or off
const ceNewId = () => 'c-' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36);
function ceBlankMission(n) {
  return {
    title: 'Mission ' + n,
    brief: '',
    map: { seed: Math.floor(Math.random() * 1e6), W: 26, H: 18, water: 35, mountains: 25, forest: 30, desert: 10, name: 'Mission ' + n },
    objective: { type: 'capture', hold: 2 },
    turnLimit: 30,
    enemy: { strategy: 'balanced', roster: { tank: 1, inf: 2, at: 1 } },
    reinforcements: [],
    next: null,
  };
}
function ceBlank() {
  return {
    id: ceNewId(),
    name: 'My campaign',
    intro: '',
    start: 'm1',
    roster: [
      ['tank', 'Sherman "First"'],
      ['inf', '1st Rifles'],
      ['inf', '2nd Rifles'],
      ['eng', 'Sapper'],
    ],
    missions: { m1: ceBlankMission(1) },
  };
}
const ceSave = list => store.set(LS_CUSTOM_CAMPAIGNS, list);

// ---- list of your campaigns ----
function renderCampEdit() {
  const list = customCampaignDrafts();
  $('#ce-list').innerHTML = list.length
    ? String(
        html`${list.map(c => {
          const probs = validateCampaign(c);
          return html`<div class="layout-row">
            <span
              ><b>${c.name}</b
              ><small
                >${Object.keys(c.missions || {}).length} missions ·
                ${probs.length ? 'needs fixes before it can be played' : 'ready to play'}</small
              ></span
            >
            <span class="row-btns"
              ><button class="btn sm" data-ce-edit="${c.id}">Edit</button><button class="btn sm alt" data-ce-export="${c.id}">Export</button
              ><button class="btn sm red" data-ce-del="${c.id}">${ce.confirmDel === c.id ? 'Delete?' : '✕'}</button></span
            >
          </div>`;
        })}`
      )
    : '<p class="src">No campaigns of your own yet.</p>';
  $('#ce-status').textContent = ce.msg || '';
  renderCeForm();
}

// ---- the editor form ----
function renderCeForm() {
  const d = ce.def,
    el = $('#ce-form');
  if (!d) {
    el.innerHTML = '<p class="src">Create a campaign, copy a built-in one, or edit one of yours.</p>';
    return;
  }
  const ids = Object.keys(d.missions);
  // keep whichever missions are open across re-renders, so you never lose your place
  const openNow = new Set([...el.querySelectorAll('details[open]')].map(x => x.dataset.ceMission));
  const types = TYPE_ORDER.map(t => [t, UNIT_TYPES[t].name]);
  const typeSel = (path, v) =>
    html`<select data-ce="${path}">
      ${types.map(([t, n]) => html`<option value="${t}" ${t === v ? 'selected' : ''}>${n}</option>`)}
    </select>`;
  const unitNames = [...new Set(d.roster.map(r => r[1]).concat(ids.flatMap(id => (d.missions[id].reinforcements || []).map(r => r[1]))))];
  const nextSel = (id, m) => {
    const n = m.next,
      mode = n && typeof n === 'object' ? 'branch' : n ? 'to:' + n : 'end';
    return html`<label class="field"
        >After this mission
        <select data-ce-next="${id}">
          <option value="end" ${mode === 'end' ? 'selected' : ''}>The campaign ends</option>
          ${ids.filter(x => x !== id).map(x => html`<option value="to:${x}" ${mode === 'to:' + x ? 'selected' : ''}>Go to: ${d.missions[x].title}</option>`)}
          <option value="branch" ${mode === 'branch' ? 'selected' : ''}>Branch on how fast you win</option>
        </select></label
      >
      ${
        mode === 'branch'
          ? html`<div class="ce-grid">
              <label class="field"
                >Fast if won within
                <input type="number" min="1" max="80" data-ce="missions.${id}.next.within" value="${n.within}" /> turns</label
              >
              <label class="field"
                >Fast:
                <select data-ce="missions.${id}.next.fast">
                  ${ids.filter(x => x !== id).map(x => html`<option value="${x}" ${x === n.fast ? 'selected' : ''}>${d.missions[x].title}</option>`)}
                </select></label
              >
              <label class="field"
                >Slower:
                <select data-ce="missions.${id}.next.slow">
                  ${ids.filter(x => x !== id).map(x => html`<option value="${x}" ${x === n.slow ? 'selected' : ''}>${d.missions[x].title}</option>`)}
                </select></label
              >
            </div>`
          : ''
      }`;
  };
  const objFields = (id, o) => {
    const p = `missions.${id}.objective`;
    return html`<label class="field"
        >Objective
        <select data-ce-obj="${id}">
          ${OBJECTIVE_TYPES.map(t => html`<option value="${t}" ${t === o.type ? 'selected' : ''}>${{ capture: 'Capture the central town', destroyStruct: 'Destroy or capture a structure', survive: 'Survive', escort: 'Escort a unit to the enemy capital' }[t]}</option>`)}
        </select></label
      >
      ${o.type === 'capture' ? html`<label class="field">Hold it for <input type="number" min="1" max="6" data-ce="${p}.hold" value="${o.hold}" /> turns</label>` : ''}
      ${
        o.type === 'destroyStruct'
          ? html`<label class="field"
              >Structure
              <select data-ce="${p}.kind">
                ${Object.keys(STRUCTS).map(k => html`<option value="${k}" ${k === o.kind ? 'selected' : ''}>${STRUCTS[k].name}</option>`)}
              </select></label
            >`
          : ''
      }
      ${o.type === 'survive' ? html`<label class="field">For <input type="number" min="3" max="40" data-ce="${p}.turns" value="${o.turns}" /> turns</label>` : ''}
      ${
        o.type === 'escort'
          ? html`<label class="field"
              >Unit to escort
              <select data-ce="${p}.unitName">
                ${unitNames.map(n => html`<option ${n === o.unitName ? 'selected' : ''}>${n}</option>`)}
              </select></label
            >`
          : ''
      }`;
  };
  el.innerHTML = String(
    html` <label class="field">Name <input type="text" maxlength="60" data-ce="name" value="${d.name}" /></label>
      <label class="field">Introduction <textarea rows="3" maxlength="600" data-ce="intro">${d.intro}</textarea></label>
      <h3 class="rule-group">Starting force (carries experience from mission to mission)</h3>
      ${d.roster.map((r, i) => html`<div class="ce-row">${typeSel(`roster.${i}.0`, r[0])}<input type="text" maxlength="40" data-ce="roster.${i}.1" value="${r[1]}" aria-label="Unit name" /><button class="btn sm red" data-ce-act="delunit:${i}" aria-label="Remove ${r[1]}">✕</button></div>`)}
      <button class="btn sm alt" data-ce-act="addunit">+ Unit</button>
      <h3 class="rule-group">Missions (the campaign starts with the first)</h3>
      ${ids.map((id, i) => {
        const m = d.missions[id],
          P = `missions.${id}`;
        return html`<details
          class="panel ce-mission"
          ${openNow.has(id) || ce.open === id || (i === 0 && !openNow.size) ? 'open' : ''}
          data-ce-mission="${id}"
        >
          <summary>${i + 1}. ${m.title}</summary>
          <label class="field">Title <input type="text" maxlength="60" data-ce="${P}.title" value="${m.title}" /></label>
          <label class="field">Briefing <textarea rows="2" maxlength="600" data-ce="${P}.brief">${m.brief}</textarea></label>
          <div class="ce-grid">
            <canvas class="px camp-map" width="240" height="160" data-ce-map="${id}" aria-label="Map preview"></canvas>
            <div>
              <label class="field"
                >Map seed <input type="number" min="0" max="999999999" data-ce="${P}.map.seed" value="${m.map.seed}"
              /></label>
              ${['W', 'H', 'water', 'mountains', 'forest', 'desert'].map(k => html`<label class="field">${{ W: 'Width', H: 'Height', water: 'Water %', mountains: 'Mountains %', forest: 'Forest %', desert: 'Desert %' }[k]} <input type="number" data-ce="${P}.map.${k}" value="${m.map[k]}" min="${k === 'W' ? 12 : k === 'H' ? 10 : 0}" max="${k === 'W' ? 40 : k === 'H' ? 30 : 100}" /></label>`)}
              <button class="btn sm alt" data-ce-act="reroll:${id}">New map</button>
            </div>
          </div>
          ${objFields(id, m.objective)}
          <label class="field">Turn limit <input type="number" min="5" max="80" data-ce="${P}.turnLimit" value="${m.turnLimit}" /></label>
          <label class="field"
            >Enemy strategy
            <select data-ce="${P}.enemy.strategy">
              ${Object.keys(STRATS).map(k => html`<option value="${k}" ${k === m.enemy.strategy ? 'selected' : ''}>${STRATS[k].label}</option>`)}
            </select></label
          >
          <div class="ce-roster">
            ${TYPE_ORDER.map(t => html`<label class="field">${UNIT_TYPES[t].short} <input type="number" min="0" max="6" data-ce="${P}.enemy.roster.${t}" value="${m.enemy.roster[t] || 0}" /></label>`)}
          </div>
          <h4>Reinforcements that join after this mission</h4>
          ${(m.reinforcements || []).map((r, j) => html`<div class="ce-row">${typeSel(`${P}.reinforcements.${j}.0`, r[0])}<input type="text" maxlength="40" data-ce="${P}.reinforcements.${j}.1" value="${r[1]}" aria-label="Reinforcement name" /><button class="btn sm red" data-ce-act="delref:${id}:${j}" aria-label="Remove">✕</button></div>`)}
          <button class="btn sm alt" data-ce-act="addref:${id}">+ Reinforcement</button>
          <h4>Rules for this mission</h4>
          <div class="ce-rules">
            ${CE_RULES.map(k => html`<label><input type="checkbox" data-ce-rule="${id}:${k}" ${((m.rules || {})[k] ?? appState.settings.rules[k]) ? 'checked' : ''} /> ${RULES[k].label}</label>`)}
          </div>
          ${nextSel(id, m)}
          <div class="row-end">
            <button class="btn sm alt" data-ce-act="test:${id}">▶ Test play</button
            ><button class="btn sm alt" data-ce-act="up:${id}" ${i === 0 ? 'disabled' : ''}>Move up</button
            ><button class="btn sm red" data-ce-act="delm:${id}" ${ids.length < 2 ? 'disabled' : ''}>Delete mission</button>
          </div>
        </details>`;
      })}
      <button class="btn sm alt" data-ce-act="addm">+ Mission</button>
      <div class="ce-problems" id="ce-problems" role="status"></div>
      <div class="row-end">
        <button class="btn alt" data-ce-act="close">Close</button><button class="btn" data-ce-act="save">Save campaign</button>
      </div>`
  );
  for (const c of el.querySelectorAll('[data-ce-map]')) drawMapPreview(c, missionMapDef(d.missions[c.dataset.ceMap]), 2);
  ceShowProblems();
}
function ceShowProblems() {
  const p = validateCampaign(ce.def);
  $('#ce-problems').innerHTML = p.length
    ? String(
        html`<b>To fix before it can be played:</b>
          <ul class="uc-list">
            ${p.map(x => html`<li>${x}</li>`)}
          </ul>`
      )
    : '<b>Ready to play.</b>';
}
// set a value at a dotted path ("missions.m1.map.W") in the draft
function ceSet(path, v) {
  const keys = path.split('.');
  let o = ce.def;
  for (const k of keys.slice(0, -1)) o = o[k];
  o[keys[keys.length - 1]] = v;
}
$('#ce-form').addEventListener('input', e => {
  const t = e.target,
    path = t.dataset.ce;
  if (!path || !ce.def) return;
  const v = t.type === 'number' ? (t.value === '' ? 0 : Math.round(+t.value)) : t.value;
  ceSet(path, v);
  if (/\.map\.|\.enemy\.roster\./.test(path)) {
    const r = path.split('.');
    if (r[0] === 'missions' && r[2] === 'enemy') {
      const ro = ce.def.missions[r[1]].enemy.roster;
      if (!ro[r[4]]) delete ro[r[4]];
    }
    const c = $(`[data-ce-map="${path.split('.')[1]}"]`);
    if (c && /\.map\./.test(path)) drawMapPreview(c, missionMapDef(ce.def.missions[path.split('.')[1]]), 2);
  }
  if (/\.title$/.test(path) && path.startsWith('missions.')) {
    const s = t.closest('details').querySelector('summary');
    if (s) s.textContent = s.textContent.replace(/^(\d+\. ).*/, '$1' + v);
  }
  ceShowProblems();
});
$('#ce-form').addEventListener('change', e => {
  const t = e.target,
    d = ce.def;
  if (!d) return;
  if (t.dataset.ceObj) {
    const id = t.dataset.ceObj,
      ty = t.value;
    d.missions[id].objective =
      ty === 'capture'
        ? { type: ty, hold: 2 }
        : ty === 'destroyStruct'
          ? { type: ty, kind: 'airfield' }
          : ty === 'survive'
            ? { type: ty, turns: 10 }
            : { type: ty, unitName: d.roster[0][1] };
    if (ty === 'destroyStruct') {
      const m = d.missions[id];
      m.layout = m.layout || {};
      m.layout.enemy = [...new Set([...(m.layout.enemy || []), 'airfield'])];
    }
    ce.open = id;
    return renderCeForm();
  }
  if (t.dataset.ceNext) {
    const id = t.dataset.ceNext,
      v = t.value,
      others = Object.keys(d.missions).filter(x => x !== id);
    d.missions[id].next =
      v === 'end' ? null : v === 'branch' ? { within: 16, fast: others[0], slow: others[others.length - 1] } : v.slice(3);
    ce.open = id;
    return renderCeForm();
  }
  if (t.dataset.ceRule) {
    const [id, k] = t.dataset.ceRule.split(':'),
      m = d.missions[id];
    m.rules = Object.assign({}, m.rules || {}, { [k]: t.checked });
    return ceShowProblems();
  }
  if (t.dataset.ce && t.tagName === 'SELECT') {
    ceSet(t.dataset.ce, t.value);
    ceShowProblems();
  }
});
$('#scr-campedit').addEventListener('click', async e => {
  const b = e.target.closest('[data-ce-act],[data-ce-edit],[data-ce-export],[data-ce-del],[data-ce-new]');
  if (!b) return;
  const d = ce.def,
    list = customCampaignDrafts(),
    say = t => {
      ce.msg = t;
      $('#ce-status').textContent = t;
    };
  if (b.dataset.ceNew) {
    const src =
      b.dataset.ceNew === 'blank'
        ? ceBlank()
        : Object.assign(clone(BUILTIN_CAMPAIGNS.find(c => c.id === b.dataset.ceNew)), { id: ceNewId() });
    if (b.dataset.ceNew !== 'blank') src.name = src.name + ' (my copy)';
    ce.def = src;
    ce.open = null;
    say('');
    return renderCampEdit();
  }
  if (b.dataset.ceEdit) {
    ce.def = clone(list.find(c => c.id === b.dataset.ceEdit));
    ce.open = null;
    say('');
    return renderCampEdit();
  }
  if (b.dataset.ceExport) {
    const c = list.find(x => x.id === b.dataset.ceExport);
    return say(
      await ueDownload(
        `campaign-${c.name.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.json`,
        JSON.stringify({ app: 'iron-hex-campaign', version: 1, campaign: c })
      )
    );
  }
  if (b.dataset.ceDel) {
    if (ce.confirmDel !== b.dataset.ceDel) {
      ce.confirmDel = b.dataset.ceDel;
      return renderCampEdit();
    }
    ce.confirmDel = null;
    ceSave(list.filter(c => c.id !== b.dataset.ceDel));
    if (d && d.id === b.dataset.ceDel) ce.def = null;
    say('Deleted.');
    return renderCampEdit();
  }
  const [act, id, j] = b.dataset.ceAct.split(':');
  const ids = d ? Object.keys(d.missions) : [];
  if (act === 'addunit') d.roster.push(['inf', 'New unit']);
  else if (act === 'delunit') d.roster.splice(+id, 1);
  else if (act === 'addref') {
    (d.missions[id].reinforcements = d.missions[id].reinforcements || []).push(['inf', 'New unit']);
    ce.open = id;
  } else if (act === 'delref') {
    d.missions[id].reinforcements.splice(+j, 1);
    ce.open = id;
  } else if (act === 'reroll') {
    d.missions[id].map.seed = Math.floor(Math.random() * 1e6);
    ce.open = id;
  } else if (act === 'addm') {
    let n = ids.length + 1;
    while (d.missions['m' + n]) n++;
    const nid = 'm' + n,
      last = ids[ids.length - 1];
    d.missions[nid] = ceBlankMission(ids.length + 1);
    if (last && d.missions[last].next == null) d.missions[last].next = nid; // chain it after the last mission
    ce.open = nid;
  } else if (act === 'delm') {
    delete d.missions[id];
    for (const m of Object.values(d.missions)) {
      if (m.next === id) m.next = null;
      if (m.next && typeof m.next === 'object' && (m.next.fast === id || m.next.slow === id)) m.next = null;
    }
    if (d.start === id) d.start = Object.keys(d.missions)[0];
  } else if (act === 'up') {
    const k = ids.indexOf(id),
      order = ids.slice();
    [order[k - 1], order[k]] = [order[k], order[k - 1]];
    const ms = {};
    for (const x of order) ms[x] = d.missions[x];
    d.missions = ms;
    d.start = order[0];
    ce.open = id;
  } else if (act === 'test') {
    const probs = validateCampaign(d);
    if (probs.length) return say('Fix the problems listed below before test playing.');
    const st = newCampaignState(d);
    st.mission = id;
    refreshUnlocks();
    newMissionBattle(st, d);
    appState.battle.campaign.test = true;
    return enterBattle(`Test: ${d.missions[id].title}`);
  } else if (act === 'save') {
    const i = list.findIndex(c => c.id === d.id);
    if (i >= 0) list[i] = clone(d);
    else list.unshift(clone(d));
    ceSave(list);
    const probs = validateCampaign(d);
    say(probs.length ? 'Saved as a draft: fix the problems listed to play it.' : 'Saved. Play it from the Campaign screen.');
    return renderCampEdit();
  } else if (act === 'close') {
    ce.def = null;
    say('');
    return renderCampEdit();
  }
  renderCeForm();
});
$('#ce-import').addEventListener('change', async e => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  const say = t => {
    ce.msg = t;
    $('#ce-status').textContent = t;
  };
  if (tooBig(f)) return say('That file is too large to be a campaign (over 5 MB).');
  try {
    const data = JSON.parse(await f.text());
    if (data.app !== 'iron-hex-campaign' || !data.campaign) throw 0;
    const c = Object.assign(data.campaign, { id: ceNewId() }); // a fresh id, so it never replaces another campaign
    const list = customCampaignDrafts();
    list.unshift(c);
    ceSave(list);
    ce.def = clone(c);
    say(validateCampaign(c).length ? 'Imported as a draft: it needs fixes before it can be played.' : 'Imported.');
    renderCampEdit();
  } catch (err) {
    say('That file isn’t an Iron Hex campaign.');
  }
  e.target.value = '';
});
