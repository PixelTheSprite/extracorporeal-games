// ---------- Views ----------
function setView(v, silent) {
  appState.prefs.view = v;
  $$('[data-view]').forEach(b => b.setAttribute('aria-pressed', b.dataset.view === v));
  $('#btn-rotl').disabled = $('#btn-rotr').disabled = v === 'top';
  if (R.cvs) {
    const def = appState.battle.mapDef;
    if (v === 'top') {
      R.cam.zoom = clamp(Math.min(R.cvs.width / (def.W * SQ3 + 1), R.cvs.height / (def.H * 1.5 + 1)), 5, 30);
      R.cam.x = (def.W * SQ3) / 2;
      R.cam.y = (def.H - 1) * 0.75;
    } else {
      const mine = aliveUnits().filter(u => u.pid === me());
      const f = R.sel && R.sel.hp > 0 ? R.sel : mine[0];
      if (f) {
        R.cam.x = f.px ?? tileAt(f.c, f.r).wx;
        R.cam.y = f.py ?? tileAt(f.c, f.r).wy;
      }
    }
    if (v === 'iso') R.cam.zoom = clamp(Math.min(R.cvs.width / 30, 16), 8, 30);
    if (v === 'ground') R.cam.zoom = clamp(R.cvs.height / 20, 7, 16);
    if (v === 'ground') {
      // face the middle of the battlefield from the focused unit
      const cx = (def.W * SQ3) / 2,
        cy = (def.H - 1) * 0.75;
      const a = Math.atan2(-(cx - R.cam.x), -(cy - R.cam.y));
      let target = Math.round(a / (Math.PI / 4)) * (Math.PI / 4);
      while (target - R.cam.angle > Math.PI) target -= Math.PI * 2;
      while (target - R.cam.angle < -Math.PI) target += Math.PI * 2;
      R.cam.angleT = target;
    }
  }
  savePrefs();
  if (!silent) SFX.play('click');
  setTimeout(() => positionMenu(menuAnchor()), 0);
}

function rotate(d) {
  if (appState.prefs.view === 'top') return;
  R.cam.angleT += (d * Math.PI) / 4;
  SFX.play('click');
}

$$('[data-view]').forEach(b => b.addEventListener('click', () => setView(b.dataset.view)));

$('#btn-rotl').addEventListener('click', () => rotate(-1));

$('#btn-rotr').addEventListener('click', () => rotate(1));

$('#btn-zin').addEventListener('click', () => zoomBy(1.15));

$('#btn-zout').addEventListener('click', () => zoomBy(1 / 1.15));

function makeProj() {
  const c = R.cam,
    cw = R.cvs.width,
    ch = R.cvs.height,
    Z = c.zoom,
    v = appState.prefs.view;
  if (v === 'top') return (x, y) => ({ x: (x - c.x) * Z + cw / 2, y: (y - c.y) * Z + ch / 2, s: Z, d: y });
  const ca = Math.cos(c.angle),
    sa = Math.sin(c.angle);
  if (v === 'iso')
    return (x, y, z) => {
      const dx = x - c.x,
        dy = y - c.y,
        rx = dx * ca - dy * sa,
        ry = dx * sa + dy * ca;
      return { x: rx * Z + cw / 2, y: ry * Z * 0.55 + ch / 2 - z * Z * 0.9, s: Z, d: ry };
    };
  const F = Z * 9,
    D = 7,
    Hc = 3.4,
    hor = ch * 0.24;
  return (x, y, z) => {
    const dx = x - c.x,
      dy = y - c.y,
      rx = dx * ca - dy * sa,
      ry = dx * sa + dy * ca;
    const depth = D - ry;
    if (depth < 1.1) return null;
    return { x: cw / 2 + (rx * F) / depth, y: hor + ((Hc - z) * F) / depth, s: F / depth, d: -depth, depth };
  };
}
