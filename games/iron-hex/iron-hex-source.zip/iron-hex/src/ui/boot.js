// ---------- Main loop & boot ----------
function loop(now) {
  requestAnimationFrame(loop);
  if (appState.screen === 'start') drawTitle(now);
  else if (appState.screen === 'battle' && R.map && appState.battle) {
    runTweens(now);
    if (!needsFrame(now)) return; // nothing changing: skip the frame (phones and batteries thank us)
    R.lastFrame = now;
    render(now);
  }
}
// Full frame rate only while something changes: animations, effects, the camera, a turn resolving, the AI
// planning, or for a moment after any touch, click or key. Otherwise 8 frames a second keeps ambient motion.
function needsFrame(now) {
  const c = R.cam,
    sig = camSig() + (appState.prefs.view || '');
  const active =
    R.tweens.length ||
    R.fx.length ||
    R.shake > 0.3 ||
    R.busy ||
    R.planning ||
    Math.abs(c.angleT - c.angle) > 0.002 ||
    sig !== R.lastCamSig ||
    now < (R.activeUntil || 0) ||
    !R.lastFrame;
  R.lastCamSig = sig;
  return active || now - R.lastFrame >= 125;
}
const markActive = (ms = 700) => {
  R.activeUntil = performance.now() + ms;
};
for (const ev of ['pointerdown', 'pointermove', 'pointerup', 'wheel', 'keydown', 'touchstart', 'touchmove'])
  document.addEventListener(ev, () => markActive(), { passive: true, capture: true });

function boot() {
  VIEW = BrowserView;
  const problems = validateAll();
  if (problems.length) console.warn('Iron Hex data problems:\n' + problems.join('\n'));
  buildSprites();
  initMotionPref();
  loadPrefs();
  loadCustomUnitsAtBoot();
  migrateOldSave(); // a battle saved before save slots existed moves into a slot
  buildSkinSprites();
  if (appState.prefs.palette === 'colorblind') applyPalette();
  refreshUnlocks();
  R.cvs = $('#battle-canvas');
  R.ctx = R.cvs.getContext('2d');
  setupCanvasInput();
  requestAnimationFrame(loop);
  if (document.fonts && document.fonts.load) document.fonts.load('8px "Press Start 2P"').catch(() => {});
}

boot();
