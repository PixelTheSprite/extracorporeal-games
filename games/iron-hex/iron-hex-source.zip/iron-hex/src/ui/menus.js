// ---------- Selection & action menu ----------
function selectUnit(u) {
  SFX.play('select');
  R.sel = u;
  R.kc = { c: u.c, r: u.r };
  announce(describeUnit(u));
  R.mode = 'menu';
  R.reach = null;
  R.targets = null;
  R.pending = null;
  R.amove = false;
  renderCards();
  openUnitMenu(u, { c: u.c, r: u.r });
}

function clearSelection() {
  R.sel = null;
  R.mode = 'idle';
  R.reach = null;
  R.targets = null;
  R.pending = null;
  R.amove = false;
  R.unload = null;
  R.loadList = null;
  R.loadPath = null;
  R.repair = null;
  R.travel = null;
  R.bridge = null;
  R.starget = null;
  closeMenu();
  renderCards();
  updateHint();
}

function openUnitMenu(u, at) {
  const B = appState.battle;
  const reach = reachable(u, humanReserved(u));
  const canMove = [...reach.values()].some(n => n.end && n.cost > 0);
  const tg = targetsFrom(u, u),
    chase = engageList(u);
  const items = [['Move', 'move', !canMove]];
  if (B.rules.engage) items.push(['Attack-move', 'amove', !canMove || u.ammo <= 0]);
  items.push(['Fire', 'fire', !tg.length]);
  if (B.rules.engage) items.push(['Engage', 'engage', !chase.length]);
  const loadable = isTransport(u) && !u.cargo ? boardCandidates(u) : [];
  const spots = isTransport(u) && u.cargo ? landingSpots(u) : [];
  const ferries = UNIT_TYPES[u.type].domain === 'land' ? emptyTransportsNear(u) : [];
  if (isTransport(u)) items.push(u.cargo ? ['Unload', 'unload', !spots.length] : ['Load', 'load', !loadable.length]);
  if (ferries.length) items.push(['Board ' + ferries[0].name, 'board', false]);
  if (UNIT_TYPES[u.type].captures) items.push(['Capture', 'capture', !capturable(u, u.pid)]);
  if (UNIT_TYPES[u.type].domain === 'land') items.push(['Plant flag', 'flag', !canFlagAt(u)]);
  const mendList = UNIT_TYPES[u.type].repairs ? repairTargets(u, u) : [];
  if (UNIT_TYPES[u.type].repairs) items.push(['Repair', 'repair', !mendList.length]);
  if (UNIT_TYPES[u.type].builds) items.push(['Build road', 'road', !canRoadAt(u)]);
  if (UNIT_TYPES[u.type].builds) items.push(['Build…', 'build', !buildChoices(u, u).some(c => c.sites.length)]);
  if (canBroadcast(u)) items.push(['Broadcast', 'broadcast', false]);
  if (appState.battle.rules.ammo && usesAmmoTypes(UNIT_TYPES[u.type]))
    items.push([((R.ammoPick && R.ammoPick[u.id]) || u.ammoType || 'he') === 'ap' ? 'Load HE rounds' : 'Load AP rounds', 'ammo', false]);
  if (appState.battle.rules.mines && (UNIT_TYPES[u.type].builds || UNIT_TYPES[u.type].asw))
    items.push(['Lay mine', 'mine', !canLayMine(u)]);
  if (appState.battle.rules.rail && UNIT_TYPES[u.type].builds) items.push(['Blow bridge', 'demolish', !canDemolish(u)]);
  if (appState.battle.rules.fog && appState.battle.rules.decoys && UNIT_TYPES[u.type].foot)
    items.push(['Plant decoy', 'decoy', !canPlantDecoy(u)]);
  const bombs = bombardTargets(u, u);
  if (u.ammo > 0 && effOf(UNIT_TYPES[u.type]).land) items.push(['Bombard', 'bombard', !bombs.length]);
  items.push([B.rules.realtime ? 'Overwatch' : 'Hold', 'hold', false], ['Intel', 'intel', false]);
  if (B.orders[u.id]) items.push(['Clear order', 'clear', false]);
  items.push(['Cancel', 'cancel', false]);
  showMenu(`${u.name} ${u.hp}/${u.maxHp}`, items, at, act => {
    if (act === 'move' || act === 'amove') {
      R.mode = 'move';
      R.reach = reach;
      R.amove = act === 'amove';
      R.travel = act === 'move' && !grounded(u) ? travelField(u) : null;
      closeMenu();
    } else if (act === 'engage') {
      R.mode = 'target';
      R.targets = { from: null, list: chase, path: null, engage: true };
      closeMenu();
    } else if (act === 'fire') {
      R.mode = 'target';
      R.targets = { from: { c: u.c, r: u.r }, list: tg, path: null };
      closeMenu();
    } else if (act === 'hold') {
      setOrder(u, { type: 'hold' });
    } else if (act === 'unload') {
      R.mode = 'unload';
      R.unload = { list: spots, path: null };
      closeMenu();
    } else if (act === 'load') {
      if (loadable.length === 1) setPair(u, loadable[0]);
      else {
        R.mode = 'load';
        R.loadList = loadable;
        closeMenu();
      }
    } else if (act === 'board') {
      setPair(ferries[0], u);
    } else if (act === 'capture') {
      setOrder(u, { type: 'capture' });
    } else if (act === 'flag') {
      setOrder(u, { type: 'flag' });
    } else if (act === 'repair') {
      R.mode = 'repair';
      R.repair = { list: mendList, path: null };
      closeMenu();
    } else if (act === 'road') {
      setOrder(u, { type: 'road' });
    } else if (act === 'build') {
      openBuildMenu(u, { c: u.c, r: u.r }, null);
    } else if (act === 'ammo') {
      // switching rounds doesn't use up the unit's order: the choice rides along with whatever order it gets
      const cur = ((R.ammoPick && R.ammoPick[u.id]) || u.ammoType || 'he') === 'ap' ? 'he' : 'ap';
      (R.ammoPick = R.ammoPick || {})[u.id] = cur;
      const B = appState.battle;
      if (B.orders[u.id]) B.orders[u.id] = Object.assign({}, B.orders[u.id], { ammo: cur });
      SFX.play('click');
      closeMenu();
      R.sel = null;
      R.mode = 'idle';
      renderCards();
      updateHint();
    } else if (act === 'broadcast') {
      setOrder(u, { type: 'broadcast' });
    } else if (act === 'mine' || act === 'demolish') {
      setOrder(u, { type: act });
    } else if (act === 'decoy') {
      setOrder(u, { type: 'decoy' });
    } else if (act === 'bombard') {
      R.mode = 'starget';
      R.starget = { list: bombs, path: null };
      closeMenu();
    } else if (act === 'intel') {
      showIntel(u);
    } else if (act === 'clear') {
      unpair(u);
      delete B.orders[u.id];
      noteStanding(B, u, null);
      clearSelection();
      renderHud();
      updateDone();
    } else clearSelection();
    updateHint();
  });
}

function openDestMenu(u, node) {
  const path = pathTo(node),
    dest = path[path.length - 1];
  R.pending = { path };
  const tg = targetsFrom(u, dest);
  const spots = isTransport(u) && u.cargo ? landingSpots(dest) : [];
  const items = [['Fire', 'fire', !tg.length]];
  if (isTransport(u) && u.cargo) items.push(['Unload', 'unload', !spots.length]);
  const riders = isTransport(u) && !u.cargo ? aliveUnits().filter(o => o.pid === u.pid && canCarry(u, o) && hexDist(o, dest) === 1) : [];
  if (isTransport(u) && !u.cargo) items.push(['Load', 'load', !riders.length]);
  if (UNIT_TYPES[u.type].captures && capturable(dest, u.pid)) items.push(['Capture', 'capture', false]);
  if (UNIT_TYPES[u.type].domain === 'land') items.push(['Plant flag', 'flag', !canFlagAt(dest)]);
  const mendList = UNIT_TYPES[u.type].repairs ? repairTargets(u, dest) : [];
  if (UNIT_TYPES[u.type].repairs) items.push(['Repair', 'repair', !mendList.length]);
  if (UNIT_TYPES[u.type].builds) items.push(['Build road', 'road', !canRoadAt(dest)]);
  if (UNIT_TYPES[u.type].builds) items.push(['Build…', 'build', !buildChoices(u, dest).some(c => c.sites.length)]);
  const bombs = u.ammo > 0 && effOf(UNIT_TYPES[u.type]).land ? bombardTargets(u, dest) : null;
  if (bombs) items.push(['Bombard', 'bombard', !bombs.length]);
  items.push(['Wait', 'wait', false], ['Back', 'back', false]);
  showMenu('At destination', items, dest, act => {
    if (act === 'fire') {
      R.mode = 'target';
      R.targets = { from: dest, list: tg, path };
      closeMenu();
    } else if (act === 'unload') {
      R.mode = 'unload';
      R.unload = { list: spots, path };
      closeMenu();
    } else if (act === 'load') {
      if (riders.length === 1) setPair(u, riders[0], path);
      else {
        R.mode = 'load';
        R.loadList = riders;
        R.loadPath = path;
        closeMenu();
      }
    } else if (act === 'wait') setOrder(u, { type: 'move', path, target: null });
    else if (act === 'capture') setOrder(u, { type: 'move', path, target: null, capture: true });
    else if (act === 'flag') setOrder(u, { type: 'move', path, target: null, flag: true });
    else if (act === 'repair') {
      R.mode = 'repair';
      R.repair = { list: mendList, path };
      closeMenu();
    } else if (act === 'road') setOrder(u, { type: 'move', path, target: null, road: true });
    else if (act === 'build') openBuildMenu(u, dest, path);
    else if (act === 'bombard') {
      R.mode = 'starget';
      R.starget = { list: bombs, path };
      closeMenu();
    } else {
      R.pending = null;
      R.mode = 'move';
      closeMenu();
    }
    updateHint();
  });
}

function setOrder(u, o) {
  unpair(u);
  if (R.ammoPick && R.ammoPick[u.id] && !o.ammo) o = Object.assign({}, o, { ammo: R.ammoPick[u.id] }); // loaded rounds ride along
  appState.battle.orders[u.id] = o;
  noteStanding(appState.battle, u, o);
  SFX.play('order');
  clearSelection();
  renderHud();
  updateDone();
  updateHint();
}

// Loading pairs two orders: the transport's Load and the cargo's Board. Changing either one cancels both.
function unpair(u) {
  const O = appState.battle.orders,
    o = O[u.id];
  if (!o) return;
  if (o.type === 'board') {
    const t = O[o.transport];
    if (t && ((t.type === 'load' && t.cargo === u.id) || t.load === u.id)) delete O[o.transport];
  }
  const cid = o.type === 'load' ? o.cargo : o.load;
  if (cid) {
    const c = O[cid];
    if (c && c.type === 'board' && c.transport === u.id) delete O[cid];
  }
}

// path: the transport's route when it moves first and loads at the destination (Move + load).
function setPair(transport, cargo, path) {
  unpair(transport);
  unpair(cargo);
  const O = appState.battle.orders;
  O[transport.id] = path ? { type: 'move', path, target: null, load: cargo.id } : { type: 'load', cargo: cargo.id };
  O[cargo.id] = { type: 'board', transport: transport.id };
  SFX.play('order');
  clearSelection();
  renderHud();
  updateDone();
  updateHint();
}

function showMenu(title, items, at, cb) {
  const m = $('#action-menu');
  m.innerHTML =
    `<h3>${escapeHtml(title)}</h3>` +
    items
      .map(
        ([l, a, dis]) =>
          `<button class="btn sm ${a === 'cancel' || a === 'back' ? 'alt' : ''}" role="menuitem" data-act="${escapeHtml(a)}" ${dis ? 'disabled' : ''}>${l}</button>`
      )
      .join('');
  m.hidden = false;
  m.onclick = e => {
    const b = e.target.closest('[data-act]');
    if (b && !b.disabled) {
      SFX.play('click');
      cb(b.dataset.act);
    }
  };
  positionMenu(at);
  const first = m.querySelector('button:not(:disabled)');
  if (first) first.focus({ preventScroll: true });
}

function positionMenu(at) {
  const m = $('#action-menu');
  if (m.hidden || !at) return;
  const P = makeProj(),
    t = tileAt(at.c, at.r),
    p = P(t.wx, t.wy, t.z);
  const st = $('#stage').getBoundingClientRect();
  let x = p ? p.x * R.PX + 30 : st.width / 2,
    y = p ? p.y * R.PX - 60 : st.height / 3;
  const mw = m.offsetWidth,
    mh = m.offsetHeight;
  if (x + mw > st.width - 6) x = (p ? p.x * R.PX - 30 : x) - mw;
  x = clamp(x, 6, Math.max(6, st.width - mw - 6));
  y = clamp(y, 6, Math.max(6, st.height - mh - 6));
  m.style.left = x + 'px';
  m.style.top = y + 'px';
}

function closeMenu() {
  const m = $('#action-menu');
  if (m) {
    m.hidden = true;
    m.onclick = null;
  }
}

function closeModal() {
  const m = $('#modal');
  if (m) {
    m.hidden = true;
    m.innerHTML = '';
  }
}

// Intel markup shared by the battle popup (u = a live unit) and the Unit library (u = null).
function intelBody(type, pid, u, titleId) {
  const T = UNIT_TYPES[type],
    a = ARMIES[pid],
    eff = effOf(T);
  const statRow = (label, v) =>
    `<div class="statrow"><span>${label}</span><span class="pips" aria-hidden="true">${Array.from({ length: 10 }, (_, i) => `<i class="${i < v ? 'on' : ''}"></i>`).join('')}</span><b>${v}</b></div>`;
  const cargo = u && u.cargo ? unitById(u.cargo) : null;
  const perArmy = currentRoster()[type] || 0;
  const attacks =
    ['land', 'sea', 'air'].map(d => `<span>${DOMAIN_LABEL[d]} <b>${eff[d] ? '×' + eff[d].toFixed(1) : 'none'}</b></span>`).join('') +
    (T.bonusVs
      ? Object.entries(T.bonusVs)
          .map(([k, m]) => `<span>${escapeHtml(UNIT_TYPES[k].short)} <b>×${m} bonus</b></span>`)
          .join('')
      : '');
  return `<div class="intel-head"><canvas class="px" width="32" height="24" data-spr-type="${escapeHtml(type)}" data-spr-pid="${escapeHtml(pid)}"></canvas>
      <div><h2 id="${titleId}">${escapeHtml(u ? u.name : T.name)}</h2><p>${u ? `${escapeHtml(T.name)} ${escapeHtml(T.role.toLowerCase())}, ${escapeHtml(((appState.battle && appState.battle.players[u.pid]) || a).name)}` : `${escapeHtml(T.role)}, ${DOMAIN_LABEL[T.domain].toLowerCase()} unit`}</p></div></div>
    <div>${statRow('Speed', T.stats.speed)}${statRow('Maneuver', T.stats.maneuver)}${statRow('Armor', T.stats.armor)}${statRow('Firepower', T.stats.firepower)}</div>
    <div class="derived"><span>HP ${u ? u.hp + '/' : ''}${T.hp}</span><span>Move ${T.move}</span><span>Range ${T.range[0] === T.range[1] ? T.range[0] + (T.range[0] === 0 ? ' (directly below)' : '') : T.range[0] + '–' + T.range[1]}</span><span>Ammo ${u ? u.ammo + '/' : ''}${T.ammo}</span><span>Evasion ${T.evade}%</span>${T.carry ? `<span>Carries ${T.carry} ${T.carryKinds ? 'infantry-type' : 'land'} unit${cargo ? ': ' + escapeHtml(cargo.name) : ''}</span>` : ''}${T.fuel ? `<span>Fuel ${u ? Math.round(u.fuel) + '/' : ''}${T.fuel}${T.domain === 'air' ? ` (burns ${T.upkeep ?? AIR_UPKEEP}/turn aloft)` : ''}${T.fuelRate ? ` (${T.fuelRate} per hex)` : ''}</span>` : '<span>No fuel needed</span>'}${T.captures ? '<span>Captures cities</span>' : ''}${T.domain === 'land' ? '<span>Plants flags</span>' : ''}${T.repairs ? `<span>Repairs adjacent units (+${REPAIR_PCT * 100}% HP)</span>` : ''}${T.builds ? '<span>Builds roads</span>' : ''}${!u ? `<span>${perArmy ? perArmy + ' per army in your roster' : 'Not in your roster'}</span>` : ''}</div>
    <div class="derived matchup"><span>Damage vs:</span>${attacks}</div>
    <p class="src">${escapeHtml(T.source)} Each stat is normalized to 0–10 against the scale below${T.custom ? '' : '. The Unit editor does this lookup for any vehicle you name'}.</p>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Stat</th><th>Real-world value</th><th>Scale</th><th>0–10</th></tr></thead>
    <tbody>${T.norm.map(r => `<tr><td>${escapeHtml(r[0])}</td><td>${escapeHtml(r[1])}</td><td>${escapeHtml(r[2])}</td><td>${escapeHtml(r[3])}</td></tr>`).join('')}</tbody></table></div>`;
}

function paintSprites(root, size = 1) {
  root.querySelectorAll('[data-spr-type]').forEach(cv => {
    const x = cv.getContext('2d');
    x.imageSmoothingEnabled = false;
    x.clearRect(0, 0, cv.width, cv.height);
    const s = SPR[cv.dataset.sprType][+cv.dataset.sprPid];
    x.drawImage(s.n, Math.round((cv.width - s.w * size) / 2), Math.round((cv.height - s.h * size) / 2), s.w * size, s.h * size);
  });
}

function showIntel(u) {
  showDialog(`<div class="panel" role="dialog" aria-modal="true" aria-labelledby="intel-title">${intelBody(u.type, u.pid, u, 'intel-title')}
    <button class="btn" id="intel-close">Close</button></div>`);
  paintSprites($('#modal'));
  $('#intel-close').onclick = () => {
    closeModal();
    if (R.sel && R.sel.id === u.id && u.pid === me()) openUnitMenu(u, { c: u.c, r: u.r });
  };
  $('#intel-close').focus();
}

// What an engineer standing (or arriving) at `at` can build: land structures go on that hex, bridges on a
// shallow-water neighbor. Continuing your own unfinished structure is offered first.
function buildChoices(u, at) {
  const def = appState.battle.mapDef;
  return STRUCT_ORDER.filter(kind => structAllowed(kind, appState.battle.rules)).map(kind => {
    const sites =
      kind === 'bridge'
        ? neighborsRaw(at.c, at.r, def.W, def.H).filter(n => canBuildAt('bridge', n, u.pid))
        : canBuildAt(kind, at, u.pid)
          ? [{ c: at.c, r: at.r }]
          : [];
    const sc = sites.length === 1 ? structAt(sites[0].c, sites[0].r) : null;
    const S = STRUCTS[kind];
    const label =
      sc && sc.build ? `Continue ${S.name} ${sc.build.prog}/${sc.build.need}` : `${S.name} (${S.turns} turn${S.turns > 1 ? 's' : ''})`;
    return { kind, sites, label };
  });
}
function openBuildMenu(u, at, path) {
  const ch = buildChoices(u, at);
  showMenu('Build', ch.map(c => [c.label, 'b:' + c.kind, !c.sites.length]).concat([['Back', 'back', false]]), at, act => {
    if (act === 'back') {
      if (path) {
        R.mode = 'move';
        R.pending = null;
        closeMenu();
      } else openUnitMenu(u, { c: u.c, r: u.r });
      return;
    }
    const c = ch.find(x => 'b:' + x.kind === act);
    const order = site =>
      path ? { type: 'move', path, target: null, build: { kind: c.kind, at: site } } : { type: 'build', kind: c.kind, at: site };
    if (c.sites.length === 1) setOrder(u, order(c.sites[0]));
    else {
      R.mode = 'bridge';
      R.bridge = { list: c.sites, path, kind: c.kind };
      closeMenu();
    }
    updateHint();
  });
}
// Info card for a structure (tap one when no unit is selected).
function showStructInfo(t) {
  const s = structAt(t.c, t.r);
  if (!s) return;
  const S = STRUCTS[s.kind],
    pname = pid => (appState.battle.players[pid] || ARMIES[pid]).name,
    owner = s.build ? pname(s.build.pid) : s.owner == null ? 'Neutral' : pname(s.owner);
  showDialog(`<div class="panel" role="dialog" aria-modal="true" aria-labelledby="st-title">
    <div class="intel-head"><canvas class="px" width="32" height="24" id="st-spr"></canvas>
      <div><h2 id="st-title">${S.name}</h2><p>${s.build ? `Under construction by ${owner}: ${s.build.prog} of ${s.build.need} turns` : owner}</p></div></div>
    <div class="derived"><span>HP ${s.hp}/${s.maxHp}</span><span>Armor ${S.armor}</span><span>Builds in ${S.turns} turn${S.turns > 1 ? 's' : ''}</span>${S.capture ? '<span>Capturable</span>' : '<span>Destroy only</span>'}${S.supply ? '<span>Supply point</span>' : ''}${s.capPid != null ? `<span>Being captured ${s.prog}/${CAPTURE_TURNS}</span>` : ''}</div>
    <p>${S.desc}</p><button class="btn" id="st-close">Close</button></div>`);
  const cv = $('#st-spr'),
    x = cv.getContext('2d'),
    spr = STRUCT_SPR[s.kind];
  x.imageSmoothingEnabled = false;
  x.drawImage(spr.n, Math.round((32 - spr.w) / 2), Math.round((24 - spr.h) / 2));
  $('#st-close').onclick = () => closeModal();
  $('#st-close').focus();
}
