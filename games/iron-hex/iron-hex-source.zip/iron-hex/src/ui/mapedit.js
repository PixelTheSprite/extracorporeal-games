// Map Editor: paint terrain, roads and spawn points; generate from a seed; check and save maps.
// Saved maps live in this browser (localStorage) and show up in Quick battle and the Infrastructure editor.
const LS_MAPS = 'ironhex_maps';
// Maps from storage are validated (and their ids checked) before use; anything malformed is skipped.
const SAFE_ID = /^[a-z0-9_-]{1,60}$/i;
function loadMaps() {
  return storedList(LS_MAPS).filter(m => {
    try {
      return m && SAFE_ID.test(m.id || '') && !validateMapDef(m).length;
    } catch (e) {
      return false;
    }
  });
}
const storeMaps = list => store.set(LS_MAPS, list);
const MAP_SIZES = [
  ['Small', 20, 14],
  ['Medium', 26, 18],
  ['Large', 32, 22],
  ['Huge', 40, 30],
];
const PAINT = [
  ['~', 'Deep sea'],
  ['w', 'Shallows'],
  ['s', 'Sand'],
  ['p', 'Plains'],
  ['f', 'Forest'],
  ['h', 'Hills'],
  ['m', 'Mountains'],
  ['c', 'City'],
];
const mapEd = {
  def: null,
  tool: 'p',
  brush: 1,
  spawn: 0,
  undo: [],
  hover: null,
  painting: false,
  editingId: null,
  gen: { size: 1, seed: Math.floor(Math.random() * 1e6), water: 35, mountains: 30, forest: 35, desert: 20 },
};

const meRows = () => mapEd.def.rows.map(r => r.split(''));
function meSetRows(g) {
  mapEd.def.rows = g.map(r => r.join(''));
}
function mePush() {
  mapEd.undo.push(JSON.stringify({ rows: mapEd.def.rows, spawns: mapEd.def.spawns, roads: mapEd.def.roads }));
  if (mapEd.undo.length > 40) mapEd.undo.shift();
}
function meNew(kind) {
  const [, W, H] = MAP_SIZES[mapEd.gen.size],
    g = mapEd.gen;
  const name = ($('#me-name') && $('#me-name').value.trim()) || 'My map';
  mapEd.def =
    kind === 'blank'
      ? {
          name,
          kind: 'custom',
          W,
          H,
          rows: Array.from({ length: H }, (_, r) =>
            Array.from({ length: W }, (_, c) => (c === 0 || r === 0 || c === W - 1 || r === H - 1 ? '~' : 'p')).join('')
          ),
          spawns: [
            { c: 2, r: 2 },
            { c: W - 3, r: H - 3 },
          ],
          roads: [],
        }
      : genMap('custom', g.seed, name, { W, H, water: g.water, mountains: g.mountains, forest: g.forest, desert: g.desert });
  if (kind === 'blank') {
    const rows = meRows();
    for (const sp of mapEd.def.spawns) rows[sp.r][sp.c] = 'c';
    meSetRows(rows);
  }
  mapEd.def.roads = mapEd.def.roads || [];
  mapEd.undo = [];
  mapEd.editingId = null;
}
// Problems that block saving, and warnings worth knowing about.
function meCheck() {
  const d = mapEd.def,
    errors = validateMapDef(d),
    warnings = [];
  const rows = d.rows,
    land = (c, r) => !TERRAIN[rows[r][c]].water;
  const comp = sp => {
    const seen = new Set([sp.c + ',' + sp.r]),
      q = [sp];
    while (q.length) {
      const cur = q.pop();
      for (const n of neighborsRaw(cur.c, cur.r, d.W, d.H)) {
        const k = n.c + ',' + n.r;
        if (!seen.has(k) && land(n.c, n.r)) {
          seen.add(k);
          q.push(n);
        }
      }
    }
    return seen;
  };
  if (d.spawns.length >= 2 && !errors.length) {
    const c0 = comp(d.spawns[0]);
    if (d.spawns.some(s => !c0.has(s.c + ',' + s.r)))
      warnings.push(
        'Not every spawn point can reach the others by land. Tanks will need transports or bridges — or use “Carve land routes”.'
      );
  }
  const waterCount = rows
    .join('')
    .split('')
    .filter(t => TERRAIN[t].water).length;
  if (!waterCount) warnings.push('No water at all: ships and landing craft will not deploy.');
  return { errors, warnings };
}
function renderMapEdit() {
  if (!mapEd.def) meNew('generate');
  const d = mapEd.def,
    g = mapEd.gen;
  $('#me-size').innerHTML = MAP_SIZES.map(
    ([n, W, H], i) => `<option value="${i}" ${i === g.size ? 'selected' : ''}>${n} (${W} × ${H})</option>`
  ).join('');
  $('#me-seed').value = g.seed;
  for (const k of ['water', 'mountains', 'forest', 'desert']) {
    $(`#me-${k}`).value = g[k];
    $(`#me-${k}-v`).textContent = g[k];
  }
  let grp = '';
  $('#me-copy').innerHTML =
    '<option value="">Copy an existing map…</option>' +
    allMaps()
      .map(m => {
        const open = m.group !== grp ? `${grp ? '</optgroup>' : ''}<optgroup label="${m.group}">` : '';
        grp = m.group;
        return open + `<option value="${escapeHtml(m.id)}">${escapeHtml(m.name)}</option>`;
      })
      .join('') +
    '</optgroup>';
  $('#me-tools').innerHTML =
    PAINT.map(
      ([t, n]) =>
        `<button class="btn sm alt paint-btn" data-me-tool="${escapeHtml(t)}" aria-pressed="${mapEd.tool === t}"><i style="background:${TERRAIN[t].color}"></i>${n}</button>`
    ).join('') +
    `<button class="btn sm alt" data-me-tool="road" aria-pressed="${mapEd.tool === 'road'}">Road</button><button class="btn sm alt" data-me-tool="unroad" aria-pressed="${mapEd.tool === 'unroad'}">Remove road</button>`;
  $('#me-spawns').innerHTML =
    [0, 1, 2, 3]
      .map(
        i =>
          `<button class="btn sm alt owner-btn" data-me-spawn="${escapeHtml(i)}" aria-pressed="${mapEd.tool === 'spawn' && mapEd.spawn === i}" ${i > d.spawns.length ? 'disabled' : ''}><i style="background:${ARMIES[i].color}"></i>Spawn ${i + 1}</button>`
      )
      .join('') + `<button class="btn sm alt" data-me-tool="unspawn" aria-pressed="${mapEd.tool === 'unspawn'}">Remove spawn</button>`;
  $('#me-brush').innerHTML = [1, 2, 3]
    .map(
      b =>
        `<button class="btn sm alt" data-me-brush="${escapeHtml(b)}" aria-pressed="${mapEd.brush === b}">${b === 1 ? '1 hex' : b === 2 ? '7 hexes' : '19 hexes'}</button>`
    )
    .join('');
  $('#me-sides').innerHTML = d.spawns
    .map(
      (sp, i) =>
        `<label class="field side-field"><span><i style="background:${ARMIES[i].color}"></i>Side ${i + 1}</span><input data-me-side="${escapeHtml(i)}" type="text" maxlength="40" placeholder="${escapeHtml(ARMIES[i].name)}" value="${escapeHtml(d.sides && d.sides[i] ? d.sides[i].name : '')}"></label>`
    )
    .join('');
  $('#me-name').value = d.name || '';
  $('#me-info').textContent =
    `${d.W} × ${d.H} hexes · ${d.spawns.length} spawn point${d.spawns.length === 1 ? '' : 's'} · ${d.roads.length} road hexes`;
  $('#btn-me-undo').disabled = !mapEd.undo.length;
  meRenderCheck();
  meRenderList();
  drawMapEdit();
}
function meRenderCheck() {
  const { errors, warnings } = meCheck();
  $('#me-check').innerHTML =
    (errors.length
      ? errors.map(e => `<li class="bad">${escapeHtml(e.replace(/^map: /, ''))}</li>`).join('')
      : '<li class="ok">Ready to save.</li>') + warnings.map(w => `<li class="warn">${escapeHtml(w)}</li>`).join('');
  $('#btn-me-carve').hidden = !warnings.some(w => w.startsWith('Not every'));
}
function meRenderList() {
  const list = loadMaps();
  $('#me-list').innerHTML = list.length
    ? list
        .map(
          m => `<div class="layout-row"><span><b>${escapeHtml(m.name)}</b><small>${m.W} × ${m.H} · ${m.spawns.length} spawn points</small></span>
    <span class="row-btns"><button class="btn sm alt" data-me-edit="${escapeHtml(m.id)}">Edit</button><button class="btn sm" data-me-play="${escapeHtml(m.id)}">Play in Quick battle</button><button class="btn sm red" data-me-del="${escapeHtml(m.id)}" aria-label="Delete ${escapeHtml(m.name)}">✕</button></span></div>`
        )
        .join('')
    : '<p class="src">No saved maps yet.</p>';
}
function drawMapEdit() {
  const cv = $('#me-canvas'),
    x = cv.getContext('2d'),
    d = mapEd.def,
    G = infraGeom(cv, d);
  x.imageSmoothingEnabled = false;
  x.fillStyle = '#10213d';
  x.fillRect(0, 0, cv.width, cv.height);
  const hex = (c, r, fill, stroke) => {
    const p = G.at(c, r);
    x.beginPath();
    HEX_CORNERS.forEach(([a, b], i) => {
      const px = p.x + a * G.sz,
        py = p.y + b * G.sz;
      i ? x.lineTo(px, py) : x.moveTo(px, py);
    });
    x.closePath();
    if (fill) {
      x.fillStyle = fill;
      x.fill();
    }
    if (stroke) {
      x.strokeStyle = stroke;
      x.stroke();
    }
  };
  for (let r = 0; r < d.H; r++) for (let c = 0; c < d.W; c++) hex(c, r, TERRAIN[d.rows[r][c]].color, 'rgba(0,0,0,.18)');
  const roads = new Set(d.roads);
  x.strokeStyle = '#6a4a26';
  x.lineWidth = Math.max(2, G.sz * 0.35);
  x.lineCap = 'round';
  for (const k of roads) {
    const [c, r] = unkey(k),
      p = G.at(c, r);
    let linked = false;
    for (const n of neighborsRaw(c, r, d.W, d.H))
      if (roads.has(n.c + ',' + n.r)) {
        const q = G.at(n.c, n.r);
        x.beginPath();
        x.moveTo(p.x, p.y);
        x.lineTo((p.x + q.x) / 2, (p.y + q.y) / 2);
        x.stroke();
        linked = true;
      }
    if (!linked) {
      x.beginPath();
      x.arc(p.x, p.y, x.lineWidth / 2, 0, Math.PI * 2);
      x.fillStyle = '#6a4a26';
      x.fill();
    }
  }
  x.lineWidth = 1;
  x.lineCap = 'butt';
  for (let r = 0; r < d.H; r++)
    for (let c = 0; c < d.W; c++)
      if (d.rows[r][c] === 'c') {
        const p = G.at(c, r),
          s = Math.max(2, G.sz * 0.35);
        x.fillStyle = '#3a3028';
        x.fillRect(p.x - s, p.y - s * 0.6, s * 2, s * 1.2);
        x.fillStyle = '#d8cdb8';
        x.fillRect(p.x - s * 0.6, p.y - s * 0.3, s * 0.4, s * 0.6);
        x.fillRect(p.x + s * 0.2, p.y - s * 0.3, s * 0.4, s * 0.6);
      }
  d.spawns.forEach((s, i) => {
    const p = G.at(s.c, s.r),
      z = Math.max(6, G.sz * 0.7);
    x.fillStyle = '#1b140e';
    x.fillRect(p.x - z - 1, p.y - z - 1, z * 2 + 2, z * 2 + 2);
    x.fillStyle = ARMIES[i].color;
    x.fillRect(p.x - z, p.y - z, z * 2, z * 2);
    x.fillStyle = '#fff';
    x.font = `${Math.max(8, Math.round(z * 1.2))}px "Press Start 2P", monospace`;
    x.textAlign = 'center';
    x.textBaseline = 'middle';
    x.fillText(String(i + 1), p.x, p.y + 1);
  });
  if (mapEd.hover)
    for (let r = 0; r < d.H; r++)
      for (let c = 0; c < d.W; c++) if (hexDist({ c, r }, mapEd.hover) < meBrushSize()) hex(c, r, null, '#ffffff');
}
const meBrushSize = () => (['road', 'unroad', 'spawn', 'unspawn'].includes(mapEd.tool) ? 1 : mapEd.brush);
function meHexAt(e) {
  const cv = $('#me-canvas'),
    rc = cv.getBoundingClientRect(),
    d = mapEd.def,
    G = infraGeom(cv, d);
  const px = ((e.clientX - rc.left) * cv.width) / rc.width,
    py = ((e.clientY - rc.top) * cv.height) / rc.height;
  let best = null,
    bd = Infinity;
  for (let r = 0; r < d.H; r++)
    for (let c = 0; c < d.W; c++) {
      const p = G.at(c, r),
        dd = Math.hypot(p.x - px, p.y - py);
      if (dd < bd) {
        bd = dd;
        best = { c, r };
      }
    }
  return bd <= G.sz ? best : null;
}
function meApply(h) {
  const d = mapEd.def,
    rows = meRows(),
    k = h.c + ',' + h.r,
    spawnAt = d.spawns.findIndex(s => s.c === h.c && s.r === h.r);
  if (mapEd.tool === 'road' || mapEd.tool === 'unroad') {
    const set = new Set(d.roads);
    if (mapEd.tool === 'road') {
      if (TERRAIN[rows[h.r][h.c]].water) return 'Roads go on land.';
      set.add(k);
    } else set.delete(k);
    d.roads = [...set];
    return null;
  }
  if (mapEd.tool === 'spawn') {
    if (spawnAt >= 0 && spawnAt !== mapEd.spawn) return `Spawn ${spawnAt + 1} is already here.`;
    rows[h.r][h.c] = 'c';
    meSetRows(rows);
    const i = Math.min(mapEd.spawn, d.spawns.length);
    d.spawns[i] = { c: h.c, r: h.r };
    if (d.sides)
      while (d.sides.length < d.spawns.length)
        d.sides.push({ name: ARMIES[d.sides.length].name, short: ARMIES[d.sides.length].name.split(' ')[0] });
    mapEd.spawn = Math.min(3, d.spawns.length);
    return null;
  }
  if (mapEd.tool === 'unspawn') {
    if (spawnAt >= 0) {
      d.spawns.splice(spawnAt, 1);
      if (d.sides) d.sides.splice(spawnAt, 1);
    }
    return null;
  }
  // terrain brush; spawn points keep their city, and water washes roads away
  const set = new Set(d.roads);
  for (let r = 0; r < d.H; r++)
    for (let c = 0; c < d.W; c++) {
      if (hexDist({ c, r }, h) >= mapEd.brush) continue;
      if (d.spawns.some(s => s.c === c && s.r === r)) continue;
      rows[r][c] = mapEd.tool;
      if (TERRAIN[mapEd.tool].water) set.delete(c + ',' + r);
    }
  meSetRows(rows);
  d.roads = [...set];
  return null;
}
const meCanvas = $('#me-canvas');
meCanvas.addEventListener('pointerdown', e => {
  const h = meHexAt(e);
  if (!h) return;
  meCanvas.setPointerCapture(e.pointerId);
  mePush();
  mapEd.painting = true;
  const msg = meApply(h);
  $('#me-status').textContent = msg || '';
  SFX.play('click');
  renderMapEditLight();
});
meCanvas.addEventListener('pointermove', e => {
  const h = meHexAt(e);
  if (mapEd.painting && h && !['spawn', 'unspawn'].includes(mapEd.tool)) meApply(h);
  if ((h && h.c + ',' + h.r) !== (mapEd.hover && mapEd.hover.c + ',' + mapEd.hover.r) || mapEd.painting) {
    mapEd.hover = h;
    drawMapEdit();
  }
});
const meStop = () => {
  if (mapEd.painting) {
    mapEd.painting = false;
    renderMapEditLight();
  }
};
meCanvas.addEventListener('pointerup', meStop);
meCanvas.addEventListener('pointercancel', meStop);
meCanvas.addEventListener('pointerleave', () => {
  mapEd.hover = null;
  drawMapEdit();
});
// Cheaper refresh while painting (skips rebuilding the selects)
function renderMapEditLight() {
  const d = mapEd.def;
  $('#me-info').textContent =
    `${d.W} × ${d.H} hexes · ${d.spawns.length} spawn point${d.spawns.length === 1 ? '' : 's'} · ${d.roads.length} road hexes`;
  $('#btn-me-undo').disabled = !mapEd.undo.length;
  $$('[data-me-spawn]').forEach(b => {
    const i = +b.dataset.meSpawn;
    b.disabled = i > d.spawns.length;
    b.setAttribute('aria-pressed', mapEd.tool === 'spawn' && mapEd.spawn === i);
  });
  meRenderCheck();
  drawMapEdit();
}
$('#scr-mapedit').addEventListener('input', e => {
  const k = e.target.dataset.meSlider;
  if (k) {
    mapEd.gen[k] = +e.target.value;
    $(`#me-${k}-v`).textContent = e.target.value;
  }
});
$('#scr-mapedit').addEventListener('change', e => {
  if (e.target.id === 'me-size') mapEd.gen.size = +e.target.value;
  if (e.target.id === 'me-seed') mapEd.gen.seed = Math.max(0, Math.floor(+e.target.value || 0));
  if (e.target.id === 'me-name') mapEd.def.name = e.target.value.trim();
  if (e.target.dataset.meSide != null) {
    const d = mapEd.def,
      i = +e.target.dataset.meSide,
      v = e.target.value.trim();
    d.sides = d.sides || d.spawns.map((_, j) => ({ name: ARMIES[j].name, short: ARMIES[j].name.split(' ')[0] }));
    d.sides[i] = { name: v || ARMIES[i].name, short: (v || ARMIES[i].name).split(' ')[0] };
    if (d.sides.every((s, j) => s.name === ARMIES[j].name)) delete d.sides;
  }
  if (e.target.id === 'me-copy' && e.target.value) {
    const src = anyMapDef(e.target.value);
    mapEd.def = {
      name: src.name + ' (copy)',
      kind: 'custom',
      W: src.W,
      H: src.H,
      rows: src.rows.slice(),
      spawns: src.spawns.map(s => ({ c: s.c, r: s.r })),
      roads: (src.roads || []).slice(),
      sides: src.sides ? src.sides.map(s => ({ ...s })) : undefined,
    };
    if (!mapEd.def.sides) delete mapEd.def.sides;
    mapEd.undo = [];
    mapEd.editingId = null;
    $('#me-status').textContent = `Copied ${src.name}. Saving makes a new map; the original is unchanged.`;
    renderMapEdit();
  }
});
$('#scr-mapedit').addEventListener('click', e => {
  const t = e.target.closest('[data-me-tool]');
  if (t) {
    mapEd.tool = t.dataset.meTool;
    SFX.play('click');
    renderMapEdit();
    return;
  }
  const sp = e.target.closest('[data-me-spawn]');
  if (sp && !sp.disabled) {
    mapEd.tool = 'spawn';
    mapEd.spawn = +sp.dataset.meSpawn;
    SFX.play('click');
    renderMapEdit();
    return;
  }
  const br = e.target.closest('[data-me-brush]');
  if (br) {
    mapEd.brush = +br.dataset.meBrush;
    SFX.play('click');
    renderMapEdit();
    return;
  }
  if (e.target.closest('#btn-me-dice')) {
    mapEd.gen.seed = Math.floor(Math.random() * 1e6);
    $('#me-seed').value = mapEd.gen.seed;
    return;
  }
  if (e.target.closest('#btn-me-gen')) {
    mePush();
    const u = mapEd.undo;
    meNew('generate');
    mapEd.undo = u;
    $('#me-status').textContent = `Generated from seed ${mapEd.gen.seed}.`;
    renderMapEdit();
    return;
  }
  if (e.target.closest('#btn-me-blank')) {
    mePush();
    const u = mapEd.undo;
    meNew('blank');
    mapEd.undo = u;
    $('#me-status').textContent = 'Blank map: plains inside a ring of sea.';
    renderMapEdit();
    return;
  }
  if (e.target.closest('#btn-me-undo')) {
    const s = mapEd.undo.pop();
    if (s) {
      Object.assign(mapEd.def, JSON.parse(s));
      renderMapEdit();
    }
    return;
  }
  if (e.target.closest('#btn-me-carve')) {
    mePush();
    const g = meRows();
    connectSpawns(g, mapEd.def.spawns, mapEd.def.W, mapEd.def.H);
    meSetRows(g);
    $('#me-status').textContent = 'Carved sandbar routes between the spawn points.';
    renderMapEdit();
    return;
  }
  if (e.target.closest('#btn-me-save')) {
    const { errors } = meCheck();
    if (errors.length) {
      $('#me-status').textContent = 'Fix the problems listed under Check before saving.';
      return;
    }
    const d = mapEd.def;
    d.name = ($('#me-name').value || '').trim() || 'My map';
    const list = loadMaps();
    const existing = mapEd.editingId && list.find(m => m.id === mapEd.editingId);
    const saved = Object.assign(existing || { id: 'custom-' + Date.now().toString(36) }, clone(d), { kind: 'custom' });
    if (!existing) list.push(saved);
    mapEd.editingId = saved.id;
    $('#me-status').textContent = storeMaps(list) ? `Saved “${saved.name}”.` : 'Could not save: browser storage is unavailable.';
    meRenderList();
    return;
  }
  const ed = e.target.closest('[data-me-edit]'),
    pl = e.target.closest('[data-me-play]'),
    dl = e.target.closest('[data-me-del]');
  const id = (ed || pl || dl || {}).dataset;
  if (!id) return;
  const list = loadMaps(),
    m = list.find(x => x.id === (ed ? id.meEdit : pl ? id.mePlay : id.meDel));
  if (!m) return;
  if (ed) {
    mapEd.def = clone(m);
    mapEd.editingId = m.id;
    mapEd.undo = [];
    $('#me-status').textContent = `Editing “${m.name}”.`;
    renderMapEdit();
  } else if (pl) {
    const S = appState.settings;
    S.mapId = m.id;
    S.customMap = clone(m);
    S.playSide = 0;
    S.layout = null;
    SFX.play('select');
    go('prep');
  } else if (dl) {
    storeMaps(list.filter(x => x.id !== m.id));
    if (appState.settings.mapId === m.id) {
      appState.settings.mapId = 'strait';
      appState.settings.customMap = null;
    }
    if (mapEd.editingId === m.id) mapEd.editingId = null;
    $('#me-status').textContent = `Deleted “${m.name}”.`;
    meRenderList();
  }
});
