// ---------- Utils ----------
const $ = s => document.querySelector(s);

const $$ = s => [...document.querySelectorAll(s)];

// Shows the shared modal with this content (closing any open action menu). Callers wire up its buttons after.
function showDialog(html) {
  const m = $('#modal');
  m.innerHTML = html;
  m.hidden = false;
  closeMenu();
  return m;
}

// Escape-by-default HTML for new code: html`<b>${name}</b>` escapes every interpolated value; values that are
// themselves html`` results (or arrays of them) are kept as markup. Use it instead of hand-calling escapeHtml.
class SafeHTML {
  constructor(s) {
    this.s = s;
  }
  toString() {
    return this.s;
  }
}
function html(strings, ...vals) {
  const part = v => (v instanceof SafeHTML ? v.s : Array.isArray(v) ? v.map(part).join('') : v == null || v === false ? '' : escapeHtml(v));
  let out = strings[0];
  vals.forEach((v, i) => {
    out += part(v) + strings[i + 1];
  });
  return new SafeHTML(out);
}

// Imported files (saves, unit packs) larger than this are refused before they're read.
const MAX_IMPORT_BYTES = 5 * 1024 * 1024;
const tooBig = f => f.size > MAX_IMPORT_BYTES;
