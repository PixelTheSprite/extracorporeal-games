// ---------- Unit library ----------
function renderLibrary() {
  const L = appState.library;
  const order = t => {
    const i = TYPE_ORDER.indexOf(t.id);
    return i < 0 ? 99 : i;
  };
  // Grouped by where units fight: land, sea, then air (custom units join their own group).
  const item = T => `<button class="lib-item" data-lib="${escapeHtml(T.id)}" aria-current="${L.type === T.id}">
      <canvas class="px" width="28" height="21" data-spr-type="${escapeHtml(T.id)}" data-spr-pid="${escapeHtml(L.pid)}"></canvas>
      <span><b>${escapeHtml(T.name)}</b><small>${escapeHtml(T.role)}${T.custom ? ' · custom' : ''}${T.rule ? ' · needs the ' + escapeHtml(RULES[T.rule].label) + ' rule' : ''}</small></span></button>`;
  $('#lib-list').innerHTML = ['land', 'sea', 'air']
    .map(dom => {
      const units = Object.values(UNIT_TYPES)
        .filter(T => T.domain === dom)
        .sort((a, b) => order(a) - order(b));
      return units.length
        ? `<h3 class="lib-group" id="lib-g-${dom}">${{ land: 'Land', sea: 'Sea', air: 'Air' }[dom]}</h3><div role="group" aria-labelledby="lib-g-${dom}">${units.map(item).join('')}</div>`
        : '';
    })
    .join('');
  $('#lib-detail').innerHTML =
    `<div class="swatches" role="group" aria-label="Preview army colors"><span class="src">Army colors</span>${ARMIES.map((a, i) => `<button data-lib-pid="${escapeHtml(i)}" aria-pressed="${L.pid === i}" aria-label="${a.name}" title="${a.name}" style="background:${a.color}"></button>`).join('')}</div>
    ${intelBody(L.type, L.pid, null, 'lib-title')}${UNIT_TYPES[L.type].custom ? `<button class="btn sm alt" data-lib-edit="${escapeHtml(L.type)}" style="justify-self:start">Edit in Unit editor</button>` : ''}${looksHtml(L.type)}`;
  paintSprites($('#lib-list'));
  paintSprites($('#lib-detail'));
  paintLooks($('#lib-detail'));
}

$('#scr-library').addEventListener('click', e => {
  const L = appState.library;
  const it = e.target.closest('[data-lib]');
  if (it) {
    L.type = it.dataset.lib;
    SFX.play('click');
    renderLibrary();
    $(`[data-lib="${escapeHtml(L.type)}"]`).focus();
    if (innerWidth < 1025) $('#lib-detail').scrollIntoView({ behavior: 'smooth', block: 'start' });
    return;
  }
  const ed = e.target.closest('[data-lib-edit]');
  if (ed) {
    const T = loadUnits().find(x => x.id === ed.dataset.libEdit) || UNIT_TYPES[ed.dataset.libEdit];
    ue.draft = draftFromUnit(T, false);
    ue.status = `Editing ${T.name}.`;
    go('unitedit');
    return;
  }
  const sw = e.target.closest('[data-lib-pid]');
  if (sw) {
    L.pid = +sw.dataset.libPid;
    SFX.play('click');
    renderLibrary();
    $(`[data-lib-pid="${escapeHtml(L.pid)}"]`).focus();
  }
});
