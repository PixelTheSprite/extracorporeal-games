// How to play: opens automatically on your first battle, and any time from the ? button or the ? key.
const HELP_SECTIONS = [
  [
    'Goal',
    'Win by the victory condition set in Battle settings: destroy every enemy army, or hold a share of the map for several turns in a row. The Goal chip at the top shows which.',
  ],
  [
    'Give orders',
    'Tap a unit, or its card at the bottom, to open its menu. Move shows blue hexes you can reach; after moving you can still fire or use an action. Every unit needs an order before Done lights up. Tab jumps to the next unit without orders.',
  ],
  [
    'Everything happens at once',
    'When every army has given orders, all of them play out together in short steps. Enemies move too, so a target can slip out of range or run into you. With Real-time fire on, units shoot the moment an enemy comes into range.',
  ],
  [
    'Realism rules',
    'Optional, in Battle settings under Realism. Supply lines: ground units must trace friendly ground or roads to a held city or base, or they can’t rearm (Cut off). Entrenchment: holding still digs in (⛏, up to 30% less damage). Suppression: losing a quarter of HP in a turn pins a unit for a turn. Armor facing: hit vehicles from the side or rear. Urban combat: cities shelter infantry, not vehicles. Elevation: high ground hits harder, reaches and sees further. Surrender: a wrecked unit that is cut off or surrounded gives up. Command radius: far from your capital, depots, airfields and half-tracks, ground units move slower. Order friction: orders sometimes go wrong. Electronic warfare: drones jam nearby enemies. Air superiority: your fighters overhead help your units. AA umbrellas (tinted on the map) blunt air attacks. Artillery (a new unit) fires indirectly at what your units see, but not after moving. Submarines (new) hide from all but nearby units and are hunted by destroyers. Mines: engineers and destroyers lay them (Lay mine). Carriers (new) are airfields at sea. Railways: roads in your territory are fast; engineers can Blow bridge. Seasons: mud and snow slow movement off-road; winter freezes the shallows. Timed reinforcements arrive at your capital every 8 turns. Victory points: hold cities to score; heavy losses make an army sue for peace. Information operations: rifle squads Broadcast to shake nearby enemies. Ammunition types: load AP against armor, HE against soldiers. Missile silos (Strategic rules): engineers build them; when one is ready, 🚀 Launch and tap a visible hex in range. City development: invest in your cities from the 🏭 Build dialog.',
  ],
  [
    'Orders that last',
    'Overwatch (Hold) stays in place every turn until you give that unit another order. When moving, fainter rings show hexes 2, 3 and 4 turns away: pick one and the unit keeps going each turn until it arrives (yellow dots mark where each turn should end). A new order or Clear order cancels it.',
  ],
  [
    'Camera',
    'Top, Iso and Ground switch views (keys 1, 2, 3). Drag to pan, use the wheel or pinch to zoom, and Q / E or the arrow buttons to rotate.',
  ],
  [
    'Supply and territory',
    'Flags and captured cities are supply points. Units that end a turn in your territory get +2 ammo and a full fuel tank; ships also resupply next to one of your flags or cities. Planes burn fuel every turn and crash at zero. Rifle squads and bazooka teams capture a city by holding it for 2 turns.',
  ],
  [
    'Special units',
    'LSTs and half-tracks carry units: use Load, Board and Unload. Engineers repair a damaged neighbor and build roads that cut movement cost. Intel shows any unit’s stats and the real vehicle behind them.',
  ],
  [
    'Infrastructure',
    'Engineers can Build airfields, ports, depots and fortifications on the hex they stand on, and bridges onto shallow water next to them; bigger structures take 1 to 3 turns. Airfields, ports and depots are supply points that infantry can capture; any unit that can hit ground targets can Bombard a structure. Tap a structure for details. Pre-place structures in the Infrastructure editor.',
  ],
  [
    'Campaign and records',
    'The Campaign is three linked missions with objectives. Units that survive gain ranks (more damage and evasion) and carry over; fallen ones are gone. Every battle you finish is recorded in the Leaderboard, which can also post your totals to a shared board. Fielding a unit type in 3 battles unlocks its Medieval Europe look; choose looks in Battle settings.',
  ],
  [
    'Teams, endgame and saves',
    'The Diplomacy screen (from Quick battle) puts armies on teams; allies never fight and win together, and each one chooses what it grants its allies: shared territory, resupply and passage (🤝 Allies in battle). Battle settings has two optional endgame rules, Supply exhaustion and Attrition, that stop stalemates. Save, Load and New are in the battle toolbar: saves live in this browser and can be exported and imported as files.',
  ],
  [
    'Fog, economy and conditions',
    'Optional rules in Battle settings. Fog of war hides what your units can’t see and leaves last-known markers; Fading intel adds confidence to sightings; Decoys let soldiers plant a fake tank (Plant decoy); AI deception lets the AI do the same and feint. Three economy rules work separately: Income, Mid-battle production (buy a unit a turn with 🏭 Build), and Capital loss (lose your capital and you’re out). Weather and time of day bring rain, fog, storms that ground aircraft, and nights that cut sight and range. Morale shakes and breaks units that take a beating. The roster picker can also set a point budget.',
  ],
  [
    'Make it your own',
    'Battle settings sets the victory condition, each army’s starting roster, and every rule. The Unit editor turns a real vehicle into a new unit with your own pixel art; the Map editor and Infrastructure editor build battlefields. All of them are on Command HQ.',
  ],
];
function showHelp() {
  showDialog(`<div class="panel help" role="dialog" aria-modal="true" aria-labelledby="help-title">
    <h2 id="help-title">How to play</h2>
    ${HELP_SECTIONS.map(([h, p]) => `<section><h3>${h}</h3><p>${p}</p></section>`).join('')}
    <button class="btn" id="help-close">Got it</button></div>`);
  $('#help-close').onclick = () => closeModal();
  $('#help-close').focus();
  if (!appState.prefs.seenHelp) {
    appState.prefs.seenHelp = true;
    savePrefs();
  }
}
