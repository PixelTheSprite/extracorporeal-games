// Battle modes in the interface. Single-player resolves when you press Done. Hot-seat passes the device from
// player to player (a handoff screen hides the board between them), then resolves. Online submits your orders
// to the match and resolves (or animates someone else's resolution) when everyone is in.

// ---- Done ----
function onDone() {
  const B = appState.battle;
  if (battleMode(B) === 'hotseat') return hotseatNext();
  if (battleMode(B) === 'online') return onlineSubmit();
  resolveTurn();
}

// ---- Hot-seat ----
const humansAlive = B => B.players.filter(p => !p.ai && inFight(p.id)).map(p => p.id);
function startHotseatTurn(B) {
  R.seatQueue = humansAlive(B);
  if (!R.seatQueue.length) return;
  appState.me = R.seatQueue[0];
  showHandoff();
}
function hotseatNext() {
  const B = appState.battle;
  R.seatQueue = (R.seatQueue || []).filter(pid => pid !== me());
  if (!R.seatQueue.length) {
    appState.me = humansAlive(B)[0] ?? 0; // watch the resolution from the first player's side
    resolveTurn();
    return;
  }
  appState.me = R.seatQueue[0];
  clearSelection();
  showHandoff();
}
// An opaque screen between players, so nobody sees another's orders (or, with fog, their view).
function showHandoff() {
  const B = appState.battle,
    p = B.players[me()];
  const m = showDialog(
    html`<div class="panel handoff-panel" role="dialog" aria-modal="true" aria-labelledby="ho-title">
      <h2 id="ho-title"><span class="sw" style="background:${ARMIES[me()].color}"></span> ${p.name}</h2>
      <p>Turn ${B.turn}. Pass the device to the ${p.name} player. Everyone else, look away.</p>
      <div class="row-end"><span></span><button class="btn" id="ho-ready">Ready</button></div>
    </div>`
  );
  m.classList.add('handoff');
  $('#ho-ready').focus();
  $('#ho-ready').onclick = () => {
    m.classList.remove('handoff');
    closeModal();
    R.sightCache = null;
    renderHud();
    renderCards();
    updateDone();
    updateHint();
    banner(p.short || p.name);
  };
}

// ---- Online ----
// R.mp = { db, uid, mid, seat, turn, submitted:[], names:{}, unsub:[], timer, resolving }
async function enterOnlineMatch(db, uid, mid, seat) {
  const m = (await db.doc(`matches/${mid}`).get()).data();
  const state = await getBig(db, `matches/${mid}/data/state`);
  if (!m || !state || !applySave(state)) return false;
  leaveOnlineMatch();
  appState.me = seat;
  R.mp = {
    db,
    uid,
    mid,
    seat,
    turn: m.turn,
    status: m.status,
    deadlineHours: m.deadlineHours,
    turnStarted: m.turnStarted,
    submitted: [],
    names: {},
    unsub: [],
    timer: null,
    resolving: false,
  };
  await onlineNames(m);
  enterBattle(`${m.name}: you command ${appState.battle.players[seat].name}`);
  const mp = R.mp;
  mp.unsub.push(
    db.doc(`matches/${mid}`).onSnapshot(
      snap => snap.exists && onlineMatchChanged(snap.data()),
      () => {}
    )
  );
  mp.unsub.push(
    db.collection(`matches/${mid}/orders`).onSnapshot(
      q => onlineOrdersChanged(q),
      () => {}
    )
  );
  mp.timer = setInterval(() => onlineTryResolve(), 30000); // deadlines
  return true;
}
function leaveOnlineMatch() {
  if (!R.mp) return;
  for (const u of R.mp.unsub)
    try {
      u();
    } catch (e) {}
  clearInterval(R.mp.timer);
  R.mp = null;
  appState.me = 0;
}
async function onlineNames(m) {
  const claims = await seatClaims(R.mp.db, R.mp.mid, m.seats);
  R.mp.claims = claims;
  try {
    const user = await claude.use('user');
    const ids = claims.filter(Boolean);
    const ps = user && ids.length ? await user.profiles(ids) : {};
    claims.forEach((id, i) => {
      if (id) R.mp.names[i] = (ps[id] && ps[id].name) || 'Player';
    });
  } catch (e) {}
}
// Your orders for this turn go to the match; then wait for everyone (or resolve if you're last).
async function onlineSubmit() {
  const B = appState.battle,
    mp = R.mp;
  if (!mp || mp.resolving) return;
  const mine = {};
  for (const u of aliveUnits()) if (u.pid === me() && B.orders[u.id]) mine[u.id] = B.orders[u.id];
  for (const [k, o] of Object.entries(B.orders)) if (k.startsWith('strike:') || k.startsWith('invest:')) mine[k] = o; // army actions
  $('#btn-done').disabled = true;
  $('#btn-done').textContent = 'Sending…';
  try {
    await submitOrders(mp.db, mp.mid, mp.uid, mp.seat, mp.turn, {
      orders: mine,
      prod: (B.prodQueue || {})[me()] || [],
      grants: (B.diplo || {})[me()] || null,
    });
    mp.mySubmitted = mp.turn;
  } catch (e) {
    $('#hint').textContent = 'Couldn’t send your orders: ' + ((e && e.message) || 'try again.');
  }
  updateDone();
  onlineTryResolve();
}
function onlineOrdersChanged(q) {
  const mp = R.mp;
  if (!mp) return;
  mp.submitted = q.docs
    .map(d => d.id.split('_'))
    .filter(([t]) => +t === mp.turn)
    .map(([, s]) => +s);
  renderHud();
  onlineTryResolve();
}
// Any device may resolve; the turn's lease makes sure exactly one does. The resolver animates the turn here.
async function onlineTryResolve() {
  const mp = R.mp;
  if (!mp || mp.resolving || R.busy) return;
  mp.resolving = true;
  try {
    const turn = mp.turn;
    const res = await resolveMatchTurn(mp.db, mp.mid, mp.uid, async orders => {
      initUnitVisuals();
      R.busy = true;
      clearSelection();
      updateDone();
      renderHud();
      banner('Engage!');
      SFX.play('fanfare');
      await sleep(900);
      const out = await simulateTurn(orders);
      R.busy = false;
      return out;
    });
    if (res.resolved && R.mp === mp) {
      mp.turn = turn + 1;
      if (res.out.end) return onlineFinished(res.out);
      mp.turnStarted = Date.now();
      beginTurn();
    }
  } catch (e) {
    console.warn('resolve failed', e);
  } finally {
    mp.resolving = false;
  }
}
// Someone else resolved a turn: play it here from its log entry, then adopt the authoritative result.
async function onlineMatchChanged(m) {
  const mp = R.mp;
  if (!mp) return;
  mp.deadlineHours = m.deadlineHours;
  mp.turnStarted = m.turnStarted;
  mp.status = m.status;
  if (m.turn <= mp.turn && m.status !== 'finished') return renderHud();
  if (mp.resolving || R.busy) return; // our own resolution is finishing; it will move on by itself
  while (mp.turn < (m.status === 'finished' ? m.result.turns + 1 : m.turn)) {
    const d = await mp.db.doc(`matches/${mp.mid}/log/${mp.turn}`).get();
    if (!d.exists || R.mp !== mp) break;
    const entry = JSON.parse(d.data().entry),
      B = appState.battle;
    B.rngState = entry.rng;
    B.prodQueue = clone(entry.prod || {});
    B.diplo = clone(entry.diplo || {});
    B.feints = clone(entry.feints || {});
    R.busy = true;
    clearSelection();
    updateDone();
    banner('Engage!');
    await sleep(600);
    const out = await simulateTurn(clone(entry.orders));
    R.busy = false;
    mp.turn++;
    if (out.end) break;
  }
  // Adopt the authoritative state (identical in practice; this guards against any device drift).
  const state = await getBig(mp.db, `matches/${mp.mid}/data/state`);
  if (state && R.mp === mp && applySave(state)) {
    initUnitVisuals();
    mp.turn = appState.battle.turn;
  }
  if (m.status === 'finished')
    return onlineFinished({ end: true, remaining: appState.battle.players.filter(p => inFight(p.id)), reason: m.result.reason });
  beginTurn();
}
function onlineFinished(out) {
  if (R.ended) return;
  endBattle(out.remaining, out.reason, out);
}
// Done button text and state, online: waiting once you've submitted.
function onlineDoneState() {
  const mp = R.mp;
  if (!mp) return null;
  if (mp.mySubmitted === mp.turn) {
    const waiting = appState.battle.players
      .filter(p => !p.ai && inFight(p.id) && !mp.submitted.includes(p.id) && p.id !== me())
      .map(p => playerName(p.id));
    return { disabled: true, text: waiting.length ? `Waiting for ${waiting.join(', ')}` : 'Resolving…' };
  }
  return null;
}
