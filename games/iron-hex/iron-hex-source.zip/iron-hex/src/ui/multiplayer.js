// The Multiplayer screen: online matches (hosted game) and how to start hot-seat play.
// A match uses the current Quick battle setup (map, armies, rules, roster, teams); each seat is a person or an AI.
const mpUI = { db: null, uid: null, unsub: null, list: [], claims: {}, names: {} };
const MP_DEADLINES = [
  [0, 'No deadline'],
  [24, '24 hours'],
  [72, '72 hours'],
];

async function renderMulti() {
  const S = appState.settings,
    sides = syncTeams();
  $('#mp-seats').innerHTML = String(
    html`${sides.names.map(
      (n, i) =>
        html`<div class="pick-row grant-row">
          <span><b>${n}</b><small>${i === 0 ? 'You' : 'Seat ' + (i + 1)}</small></span> ${
            i === 0
              ? html`<span class="src">You</span>`
              : html`<select data-mp-seat="${i}" aria-label="Who plays ${n}">
                  <option value="human">A person (open seat)</option>
                  ${Object.keys(STRATS).map(k => html`<option value="${k}">AI, ${STRATS[k].label.toLowerCase()}</option>`)}
                </select>`
          }
        </div>`
    )}`
  );
  $('#mp-setup-sum').textContent =
    `${prepMaps().find(m => m.id === S.mapId)?.name || 'Map'} · ${S.armies} armies · ${teamSummary(sides.names, S.teams.slice(0, S.armies)).replace(/\.$/, '')}`;
  $('#mp-deadline').innerHTML = MP_DEADLINES.map(([h, t]) => `<option value="${h}">${t}</option>`).join('');
  const db = await sbInit().catch(() => null),
    uid = db && (await SB.user.id().catch(() => null));
  mpUI.db = db;
  mpUI.uid = uid;
  $('#mp-online').classList.toggle('off', !db || !uid);
  if (!db || !uid) {
    $('#mp-status').textContent =
      'Online matches work in the hosted game, for people with Contributor access to it (your organization or invited guests). Hot-seat works anywhere.';
    $('#mp-list').innerHTML = '';
    return;
  }
  $('#mp-status').textContent = '';
  if (!mpUI.unsub)
    mpUI.unsub = db.collection('matches').onSnapshot(
      q => {
        mpUI.list = q.docs.filter(d => d.exists && !d.id.includes('/')).map(d => Object.assign({ id: d.id }, d.data()));
        renderMatchList();
      },
      () => {}
    );
}
async function renderMatchList() {
  const { db, uid } = mpUI;
  const list = mpUI.list
    .filter(m => m.seats)
    .sort((a, b) => b.created - a.created)
    .slice(0, 20);
  for (const m of list) mpUI.claims[m.id] = await seatClaims(db, m.id, m.seats);
  const ids = [...new Set(list.flatMap(m => mpUI.claims[m.id]).filter(Boolean))];
  try {
    const user = await claude.use('user');
    if (user && ids.length) mpUI.names = await user.profiles(ids);
  } catch (e) {}
  const nm = id => (mpUI.names[id] && mpUI.names[id].name) || 'Someone';
  $('#mp-list').innerHTML = list.length
    ? String(
        html`${list.map(m => {
          const claims = mpUI.claims[m.id] || [],
            mine = claims.indexOf(uid),
            open = m.seats.map((s, i) => (s.human && !claims[i] ? i : -1)).filter(i => i >= 0);
          const who = m.seats.map((s, i) => (s.human ? (claims[i] ? nm(claims[i]) : 'open seat') : 'AI')).join(', ');
          const status =
            m.status === 'finished'
              ? 'finished'
              : m.status === 'open'
                ? `waiting for ${open.length} player${open.length === 1 ? '' : 's'}`
                : `turn ${m.turn}`;
          let btns = '';
          if (m.status === 'finished') btns = html`<button class="btn sm alt" data-mp-replay="${m.id}">Watch replay</button>`;
          else if (mine >= 0 && m.status === 'playing')
            btns = html`<button class="btn sm" data-mp-play="${m.id}" data-seat="${mine}">Play</button>`;
          else if (mine >= 0 && m.host === uid)
            btns = html`<button class="btn sm alt" data-mp-start="${m.id}">Start now, AI in empty seats</button>`;
          else if (mine < 0 && open.length)
            btns = html`<button class="btn sm" data-mp-join="${m.id}" data-seat="${open[0]}">
              Join as ${m.armies ? m.armies[open[0]] : 'seat ' + (open[0] + 1)}
            </button>`;
          return html`<div class="layout-row">
            <span
              ><b>${m.name}</b
              ><small>${m.mapName} · ${status} · ${who}${m.deadlineHours ? ` · ${m.deadlineHours} h per turn` : ''}</small></span
            ><span class="row-btns">${btns}</span>
          </div>`;
        })}`
      )
    : '<p class="src">No matches yet. Create one above.</p>';
}
async function createFromSetup() {
  const { db, uid } = mpUI,
    say = t => ($('#mp-status').textContent = t);
  if (!db || !uid) return;
  const S = appState.settings;
  const seats = Array.from({ length: S.armies }, (_, i) => {
    if (i === 0) return { human: true };
    const v = ($(`[data-mp-seat="${i}"]`) || {}).value || 'human';
    return v === 'human' ? { human: true } : { human: false, ai: v };
  });
  say('Creating…');
  try {
    const mid = await createMatch(db, uid, {
      name: $('#mp-name').value.trim() || 'Match',
      settings: clone(S),
      seats,
      deadlineHours: +$('#mp-deadline').value,
    });
    say(
      seats.some((s, i) => i && s.human)
        ? 'Created. Share this game with the other players; they’ll find the match here and join.'
        : 'Created.'
    );
    if (!seats.some((s, i) => i && s.human)) await enterOnlineMatch(db, uid, mid, 0);
  } catch (e) {
    say('Couldn’t create the match: ' + ((e && e.message) || 'try again.'));
  }
}
$('#scr-multi').addEventListener('click', async e => {
  const { db, uid } = mpUI,
    say = t => ($('#mp-status').textContent = t);
  if (e.target.closest('#mp-create')) return createFromSetup();
  const j = e.target.closest('[data-mp-join]'),
    p = e.target.closest('[data-mp-play]'),
    s = e.target.closest('[data-mp-start]'),
    r = e.target.closest('[data-mp-replay]');
  if (j) {
    const res = await claimSeat(db, j.dataset.mpJoin, uid, +j.dataset.seat);
    return res.ok ? say('You’re in. The match starts when every seat is filled.') : say(res.why);
  }
  if (p) {
    say('Loading…');
    if (!(await enterOnlineMatch(db, uid, p.dataset.mpPlay, +p.dataset.seat))) say('That match could not be loaded.');
    return;
  }
  if (s) {
    await startWithAI(db, s.dataset.mpStart, uid);
    return say('Started: empty seats are now AI armies.');
  }
  if (r) {
    say('Loading…');
    try {
      startReplay(await matchReplay(db, r.dataset.mpReplay));
    } catch (err) {
      say('That replay could not be loaded.');
    }
  }
});
// Stop listening when leaving the screen (the list is only needed while it's visible).
function leaveMulti() {
  if (mpUI.unsub) {
    mpUI.unsub();
    mpUI.unsub = null;
  }
}
