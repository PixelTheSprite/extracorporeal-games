// ---------- Rendering ----------
function resizeCanvas() {
  if (!R.cvs) return;
  const st = $('#stage').getBoundingClientRect();
  R.PX = st.width < 600 ? 2 : 3;
  R.cvs.width = Math.max(1, Math.ceil(st.width / R.PX));
  R.cvs.height = Math.max(1, Math.ceil(st.height / R.PX));
  R.ctx.imageSmoothingEnabled = false;
}

window.addEventListener('resize', () => {
  resizeCanvas();
  positionMenu(menuAnchor());
});

const HAZE = [196, 222, 236];

function col(rgb, mul, hz = 0) {
  const r = clamp(rgb[0] * mul, 0, 255),
    g = clamp(rgb[1] * mul, 0, 255),
    b = clamp(rgb[2] * mul, 0, 255);
  return `rgb(${Math.round(lerp(r, HAZE[0], hz))},${Math.round(lerp(g, HAZE[1], hz))},${Math.round(lerp(b, HAZE[2], hz))})`;
}

function drawBackground(now) {
  const ctx = R.ctx,
    cw = R.cvs.width,
    ch = R.cvs.height,
    v = appState.prefs.view;
  if (v !== 'ground') {
    ctx.fillStyle = '#1a3060';
    ctx.fillRect(0, 0, cw, ch);
    ctx.fillStyle = '#23407a';
    const off = Math.floor(now / 120) % 16;
    for (let y = 0; y < ch; y += 8) for (let x = ((y / 8) % 2) * 8 - off; x < cw; x += 16) ctx.fillRect(x, y, 5, 1);
    return;
  }
  const hor = Math.round(ch * 0.24);
  const bands = ['#4a8ed8', '#5ea0e0', '#74b2e6', '#8cc2ea', '#a8d2ee', '#c4def0'];
  const bh = Math.ceil(hor / bands.length);
  bands.forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.fillRect(0, i * bh, cw, bh + 1);
  });
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 5; i++) {
    const x = ((((i * 97 + now / 200 - R.cam.angle * 60) % (cw + 60)) + cw + 60) % (cw + 60)) - 40,
      y = 6 + ((i * 13) % Math.max(10, hor - 20));
    ctx.fillRect(Math.round(x), y, 22, 4);
    ctx.fillRect(Math.round(x) + 5, y - 3, 12, 3);
  }
  ctx.fillStyle = '#8fa4c0';
  for (let x = 0; x < cw; x += 3) {
    const h = 4 + Math.abs(Math.sin((x + R.cam.angle * 120) / 17)) * 7 + Math.abs(Math.sin((x + R.cam.angle * 120) / 7)) * 2;
    ctx.fillRect(x, hor - Math.round(h), 3, Math.round(h));
  }
  ctx.fillStyle = col(TERRAIN['~'].rgb, 1, 0.55);
  ctx.fillRect(0, hor, cw, ch - hor);
}

function render(now) {
  const ctx = R.ctx,
    v = appState.prefs.view;
  const c = R.cam;
  c.angle += (c.angleT - c.angle) * 0.18;
  if (Math.abs(c.angleT - c.angle) > 0.002) positionMenu(menuAnchor());
  ctx.save();
  if (R.shake > 0.3 && !reducedMotion()) {
    ctx.translate(Math.round((Math.random() - 0.5) * R.shake), Math.round((Math.random() - 0.5) * R.shake));
    R.shake *= 0.86;
  } else R.shake = 0;
  drawBackground(now);
  const P = makeProj();
  // Hex geometry is cached per camera position: re-projected only when the camera, view or canvas changes.
  const sig = camSig() + '|' + (appState.prefs.palette || 'standard'); // recolor cached tiles when the palette changes
  // While panning on the cached terrain, skip re-projecting every hex (done once the camera stops).
  const panning =
    R.prevFrameSig !== sig &&
    R.terrCanvas &&
    appState.prefs.view !== 'ground' &&
    R.terrShape ===
      `${appState.prefs.view}|${c.zoom}|${c.angle.toFixed(4)}|${ctx.canvas.width}|${ctx.canvas.height}|${appState.prefs.palette || ''}` &&
    !R.mode.startsWith('move');
  if (!panning && (R.tileSig !== sig || R.tileMap !== R.map)) {
    R.tileSig = sig;
    R.tileMap = R.map;
    R.tileOrder = R.map.list
      .map(t => tileGeom(t, P, sig))
      .filter(g => !g.hidden)
      .sort((a, b) => a.d - b.d);
  }
  const us = [];
  for (const u of appState.battle.units) {
    if (u.in || u.gone || (u.hp <= 0 && !(u.dispHp > 0)) || !drawnForYou(u)) continue;
    const p = P(u.px, u.py, u.pz);
    if (p) us.push({ d: p.d + 0.02 + (isAir(u) ? 0.05 : 0), u });
  }
  us.sort((a, b) => a.d - b.d);
  R.pick = R.tileOrder;
  R.boxes = [];
  R.labels = [];
  if (!R.terrFill) R.terrFill = ARMY_RGB().map(c => `rgba(${c[0]},${c[1]},${c[2]},.38)`);
  R.flagIdx = new Map((appState.battle.flags || []).map(f => [key(f.c, f.r), f]));
  const overlay = buildOverlay();
  // Terrain cache: while the camera is still, the hexes (with territory, fog, overlays, flags, cities and
  // structures) are drawn once into an offscreen canvas and copied each frame; units go on top. While the camera
  // moves, everything is drawn directly, units interleaved by depth as before.
  const B = appState.battle,
    camMoving = R.prevFrameSig !== sig;
  R.prevFrameSig = sig;
  // Panning in the top and tilted views is a pure shift: reuse the cached terrain at an offset until the camera stops.
  const c0 = R.cam,
    shape = `${appState.prefs.view}|${c0.zoom}|${c0.angle.toFixed(4)}|${ctx.canvas.width}|${ctx.canvas.height}|${appState.prefs.palette || ''}`;
  const o = P(0, 0, 0);
  const shiftOk =
    camMoving &&
    R.terrCanvas &&
    R.terrShape === shape &&
    appState.prefs.view !== 'ground' &&
    o &&
    R.terrOrigin &&
    !R.mode.startsWith('move');
  if (shiftOk) {
    ctx.drawImage(R.terrCanvas, Math.round(o.x - R.terrOrigin.x), Math.round(o.y - R.terrOrigin.y));
    R.labels = [];
    for (const x of us) drawUnit(x.u, P, now);
  } else if (camMoving) {
    let j = 0; // merge units into the depth-sorted tiles
    for (const g of R.tileOrder) {
      while (j < us.length && us[j].d < g.d) drawUnit(us[j++].u, P, now);
      drawTile(g, P, now, overlay);
    }
    while (j < us.length) drawUnit(us[j++].u, P, now);
  } else {
    let ok = '';
    for (const [k, v] of overlay) ok += k + v;
    const terrKey = [
      sig,
      ok,
      B.visKey || '',
      B.turn,
      R.worldVer || 0,
      R.flagIdx.size,
      Object.keys(B.territory || {}).length,
      (R.sel && !R.cacheSelOk) || '',
    ].join('|');
    const cv = ctx.canvas;
    if (!R.terrCanvas || R.terrKey !== terrKey || R.terrCanvas.width !== cv.width || R.terrCanvas.height !== cv.height) {
      R.terrCanvas = R.terrCanvas || document.createElement('canvas');
      R.terrCanvas.width = cv.width;
      R.terrCanvas.height = cv.height;
      const off = R.terrCanvas.getContext('2d');
      off.imageSmoothingEnabled = false;
      off.clearRect(0, 0, cv.width, cv.height);
      R.ctx = off;
      R.cacheDraw = true;
      R.labels = [];
      for (const g of R.tileOrder) drawTile(g, P, now, overlay);
      R.cacheLabels = R.labels.slice();
      R.cacheDraw = false;
      R.ctx = ctx;
      R.terrKey = terrKey;
      R.terrShape = shape;
      R.terrOrigin = P(0, 0, 0);
    }
    ctx.drawImage(R.terrCanvas, 0, 0);
    R.labels = (R.cacheLabels || []).slice();
    if (R.sel && Math.floor(now / 250) % 2 === 0) {
      // the selected hex blinks: drawn live, not cached
      const g = R.tileOrder.find(x => x.t.c === R.sel.c && x.t.r === R.sel.r);
      if (g) {
        ctx.strokeStyle = '#ffe04a';
        ctx.lineWidth = 2;
        tracePoly(ctx, g.pts);
        ctx.stroke();
        ctx.lineWidth = 1;
      }
    }
    for (const x of us) drawUnit(x.u, P, now);
  }
  drawOrders(P, now);
  drawSightings(P, now);
  drawOwnMines(P);
  drawObjective(P, now);
  drawEffects(P, now);
  drawCursor(ctx);
  for (const l of R.labels) {
    const q = P(l.x, l.y, l.z);
    if (q) drawText(ctx, l.text, q.x, q.y - 22, l.color);
  }
  ctx.restore();
  if (v === 'ground') {
    // vignette edge for depth
    ctx.fillStyle = 'rgba(0,0,0,.18)';
    ctx.fillRect(0, R.cvs.height - 2, R.cvs.width, 2);
  }
}

function buildOverlay() {
  const o = new Map();
  // AA umbrellas (realism rule): tint the hexes each visible anti-aircraft unit covers (blue yours, red the enemy's).
  if (appState.battle.rules.aaUmbrella && !R.replay) {
    const B = appState.battle;
    for (const a of aliveUnits()) {
      if (!isAAUnit(UNIT_TYPES[a.type]) || !drawnForYou(a)) continue;
      const col = isEnemy(me(), a.pid) ? 'rgba(255,80,80,.13)' : 'rgba(90,150,255,.12)';
      for (let r = a.r - REAL.UMBRELLA_RANGE; r <= a.r + REAL.UMBRELLA_RANGE; r++)
        for (let c = a.c - REAL.UMBRELLA_RANGE - 1; c <= a.c + REAL.UMBRELLA_RANGE + 1; c++)
          if (r >= 0 && c >= 0 && r < B.mapDef.H && c < B.mapDef.W && hexDist(a, { c, r }) <= REAL.UMBRELLA_RANGE && !o.has(key(c, r)))
            o.set(key(c, r), col);
    }
  }
  strikeOverlay(o); // missile targeting range and ordered launches
  if (R.mode === 'move' && R.travel) {
    const a = { 2: 0.32, 3: 0.17, 4: 0.07 };
    for (const n of R.travel.values()) if (n.turns >= 2 && a[n.turns]) o.set(key(n.c, n.r), `rgba(90,170,255,${a[n.turns]})`);
  }
  if (R.mode === 'move' && R.reach) for (const n of R.reach.values()) if (n.end && n.cost > 0) o.set(key(n.c, n.r), 'rgba(90,170,255,.45)');
  if (R.mode === 'dest' && R.pending) {
    const d = R.pending.path[R.pending.path.length - 1];
    o.set(key(d.c, d.r), 'rgba(90,170,255,.6)');
  }
  if (R.mode === 'target' && R.targets) for (const e of R.targets.list) o.set(key(e.c, e.r), 'rgba(255,70,40,.5)');
  if (R.mode === 'unload' && R.unload) for (const h of R.unload.list) o.set(key(h.c, h.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'load' && R.loadList) for (const e of R.loadList) o.set(key(e.c, e.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'repair' && R.repair) for (const e of R.repair.list) o.set(key(e.c, e.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'bridge' && R.bridge) for (const e of R.bridge.list) o.set(key(e.c, e.r), 'rgba(110,230,110,.55)');
  if (R.mode === 'starget' && R.starget) for (const e of R.starget.list) o.set(key(e.c, e.r), 'rgba(255,70,40,.5)');
  return o;
}

function tracePoly(ctx, pts) {
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.closePath();
}

const camSig = () => {
  const c = R.cam;
  return `${appState.prefs.view}|${c.x}|${c.y}|${c.zoom}|${c.angle.toFixed(4)}|${R.cvs.width}|${R.cvs.height}`;
};
// Projected geometry and colors for one hex at the current camera (cached on the tile until the camera changes).
function tileGeom(t, P, sig) {
  if (t.g && t.g.sig === sig) return t.g;
  const v = appState.prefs.view,
    T = TERRAIN[t.t];
  const g = (t.g = { sig, t, hidden: true });
  const pc = P(t.wx, t.wy, t.z);
  if (!pc) return g;
  const pts = [];
  for (let i = 0; i < 6; i++) {
    const p = P(t.wx + HEX_CORNERS[i][0], t.wy + HEX_CORNERS[i][1], t.z);
    if (!p) return g;
    pts.push(p);
  }
  const hz = v === 'ground' ? clamp((pc.depth - 9) / 24, 0, 0.65) : 0;
  Object.assign(g, {
    hidden: false,
    d: pc.d,
    s: pc.s,
    pts,
    fill: col(T.rgb, 1, hz),
    px: Math.max(1, Math.round(pc.s / 12)),
    alpha: hz > 0.05 ? 1 - hz * 0.6 : 1,
    waveFill: T.water ? col(T.rgb, 1.45, hz) : null,
    sides: [],
    specks: [],
    decor: [],
  });
  if (v !== 'top')
    for (let i = 0; i < 6; i++) {
      const n = t.edge[i],
        nz = n ? n.z : -0.5;
      if (nz >= t.z - 0.001) continue;
      const j = (i + 1) % 6;
      const lo1 = P(t.wx + HEX_CORNERS[i][0], t.wy + HEX_CORNERS[i][1], nz),
        lo2 = P(t.wx + HEX_CORNERS[j][0], t.wy + HEX_CORNERS[j][1], nz);
      if (!lo1 || !lo2) continue;
      g.sides.push({ q: [pts[i], pts[j], lo2, lo1], fill: col(T.rgb, 0.5 + 0.28 * Math.max(0, Math.cos((i * Math.PI) / 3 - 0.6)), hz) });
    }
  if (pc.s >= 7)
    for (const sp of t.speck) {
      const p = P(t.wx + sp.ox, t.wy + sp.oy, t.z);
      if (p) g.specks.push({ x: Math.round(p.x), y: Math.round(p.y), fill: col(T.rgb, sp.v, hz) });
    }
  for (const d of t.decor) {
    const p = P(t.wx + d.ox, t.wy + d.oy, t.z);
    if (!p) continue;
    const spr = DECOR[d.k];
    g.decor.push({ spr, x: p.x, y: p.y + (v === 'top' ? (spr.h * p.s) / 24 : 0), sc: (p.s / 12) * d.s });
  }
  const fp = P(t.wx + 0.35, t.wy + 0.15, t.z),
    cp = P(t.wx - 0.5, t.wy + 0.1, t.z);
  g.flagAt = fp && { x: fp.x, y: fp.y, sc: clamp(fp.s / 12, 0.5, 4) * 1.2 };
  g.cityAt = cp && { x: cp.x, y: cp.y, sc: clamp(cp.s / 12, 0.5, 4) };
  const mp = P(t.wx, t.wy + 0.3, t.z),
    op = P(t.wx + 0.55, t.wy + 0.25, t.z);
  g.mid = mp && { x: mp.x, y: mp.y, sc: clamp(mp.s / 12, 0.5, 4) };
  g.ownAt = op && { x: op.x, y: op.y, sc: clamp(op.s / 12, 0.5, 4) };
  return g;
}
function drawTile(g, P, now, overlay) {
  const ctx = R.ctx,
    t = g.t,
    T = TERRAIN[t.t],
    pts = g.pts,
    s = g.s,
    px = g.px,
    B = appState.battle,
    k = t.k;
  for (const sd of g.sides) {
    ctx.fillStyle = sd.fill;
    tracePoly(ctx, sd.q);
    ctx.fill();
  }
  ctx.fillStyle = g.fill;
  tracePoly(ctx, pts);
  ctx.fill();
  if (s >= 6)
    for (const sp of g.specks) {
      // level of detail: terrain specks only when hexes are big enough to show them
      ctx.fillStyle = sp.fill;
      ctx.fillRect(sp.x, sp.y, px, px);
    }
  if (T.water && s >= 7) {
    ctx.fillStyle = g.waveFill;
    for (let k2 = 0; k2 < 2; k2++) {
      const p = P(t.wx + Math.sin(now / 900 + t.wave + k2 * 2) * 0.3 + (k2 ? 0.25 : -0.3), t.wy + (k2 ? 0.3 : -0.25), t.z);
      if (p) ctx.fillRect(Math.round(p.x), Math.round(p.y), 3 * px, px);
    }
  }
  const TR = B.territory || {},
    own = TR[k];
  if (own != null) {
    ctx.fillStyle = R.terrFill[own];
    tracePoly(ctx, pts);
    ctx.fill();
  }
  const RD = B.roads;
  if (RD && RD[k] && s >= 5) {
    if (!g.road) {
      // road segment geometry, built the first time this hex shows a road at this camera
      g.road = {
        ctr: P(t.wx, t.wy, t.z),
        mids: [0, 1, 2, 3, 4, 5].map(i =>
          P(t.wx + (Math.cos((i * Math.PI) / 3) * SQ3) / 2, t.wy + (Math.sin((i * Math.PI) / 3) * SQ3) / 2, t.z)
        ),
        alt: [P(t.wx - 0.45, t.wy, t.z), P(t.wx + 0.45, t.wy, t.z)],
      };
    }
    const w = Math.max(2, Math.round(s / 5)),
      ends = [];
    for (let i = 0; i < 6; i++) {
      const n = t.edge[i];
      if (n && RD[n.k]) ends.push(g.road.mids[i]);
    }
    const segs = ends.length ? ends : g.road.alt,
      ctr = g.road.ctr;
    for (const [c2, lw] of [
      ['#5a4024', w + 2],
      ['#b8945a', w],
      ['#e2c890', Math.max(1, w / 3)],
    ]) {
      ctx.strokeStyle = c2;
      ctx.lineWidth = lw;
      ctx.lineCap = 'round';
      for (const e of segs)
        if (e && ctr) {
          ctx.beginPath();
          ctx.moveTo(ctr.x, ctr.y);
          ctx.lineTo(e.x, e.y);
          ctx.stroke();
        }
    }
    ctx.lineCap = 'butt';
    ctx.lineWidth = 1;
  }
  if (fogShade(k)) {
    ctx.fillStyle = 'rgba(8,10,24,.42)';
    tracePoly(ctx, pts);
    ctx.fill();
  }
  const ov = overlay.get(k);
  if (ov) {
    ctx.fillStyle = ov;
    tracePoly(ctx, pts);
    ctx.fill();
  }
  if (s >= 6) {
    ctx.strokeStyle = 'rgba(0,0,0,.22)';
    ctx.lineWidth = 1;
    tracePoly(ctx, pts);
    ctx.stroke();
  }
  if (own != null) {
    // border where territory changes hands
    ctx.strokeStyle = ARMIES[own].light;
    ctx.lineWidth = s >= 9 ? 2 : 1;
    for (let i = 0; i < 6; i++) {
      const n = t.edge[i];
      if (n && TR[n.k] === own) continue;
      const j = (i + 1) % 6;
      ctx.beginPath();
      ctx.moveTo(pts[i].x, pts[i].y);
      ctx.lineTo(pts[j].x, pts[j].y);
      ctx.stroke();
    }
    ctx.lineWidth = 1;
  }
  if (R.hover === t && !R.busy) {
    ctx.strokeStyle = 'rgba(255,255,255,.8)';
    tracePoly(ctx, pts);
    ctx.stroke();
  }
  if (!R.cacheDraw && R.sel && R.sel.c === t.c && R.sel.r === t.r && Math.floor(now / 250) % 2 === 0) {
    ctx.strokeStyle = '#ffe04a';
    ctx.lineWidth = 2;
    tracePoly(ctx, pts);
    ctx.stroke();
    ctx.lineWidth = 1;
  }
  if (g.alpha < 1) ctx.globalAlpha = g.alpha;
  for (const d of g.decor) drawSprite(ctx, d.spr, d.x, d.y, d.sc, false);
  ctx.globalAlpha = 1;
  const fl = R.flagIdx.get(k);
  if (fl && g.flagAt) drawSprite(ctx, FLAG_SPR[fl.pid], g.flagAt.x, g.flagAt.y, g.flagAt.sc, false);
  const so = B.structs && B.structs[k];
  if (so && g.mid) drawStruct(ctx, so, g, t);
  strategicLabels(t, B); // silo charge, city levels
  const city = B.cities && B.cities[k];
  if (city) {
    if (city.owner != null && g.cityAt) drawSprite(ctx, FLAG_SPR[city.owner], g.cityAt.x, g.cityAt.y, g.cityAt.sc, false);
    if (city.capPid != null)
      R.labels.push({ x: t.wx, y: t.wy, z: t.z, text: `${city.prog}/${CAPTURE_TURNS}`, color: ARMIES[city.capPid].light });
  }
}

function drawUnit(u, P, now) {
  const ctx = R.ctx,
    v = appState.prefs.view,
    air = isAir(u),
    T = UNIT_TYPES[u.type];
  const g = P(u.px, u.py, u.pz);
  if (!g) return;
  const sc = clamp(g.s / 12, 0.4, 7);
  let p = g,
    lift = 0;
  if (air) {
    if (v === 'top') lift = g.s * 0.55;
    else {
      p = P(u.px, u.py, u.pz + 1.2) || g;
    }
    ctx.fillStyle = 'rgba(0,0,0,.35)';
    ctx.beginPath();
    ctx.ellipse(g.x, g.y + (v === 'top' ? g.s * 0.3 : 0), 6 * sc, 2 * sc, 0, 0, Math.PI * 2);
    ctx.fill();
    lift += Math.round(Math.sin(now / 280 + u.id) * sc);
  }
  let yb = p.y - lift + (v === 'top' ? g.s * 0.45 : 0);
  if (T.domain === 'sea') yb += 1.5 * sc;
  const fp = P(u.px + (u.fx || 1) * 0.4, u.py + (u.fy || 0) * 0.4, u.pz);
  const flip = fp ? fp.x < g.x - 0.01 : false;
  const hit = now - (u.hitT || -1e9) < 140;
  const spr = spriteFor(u, hit);
  if (u.gone || (u.hp <= 0 && !(u.dispHp > 0))) return;
  const box = drawSprite(ctx, spr, p.x, yb, sc, flip);
  if (T.domain === 'sea') {
    ctx.fillStyle = 'rgba(255,255,255,.75)';
    const w = Math.round((spr.w * sc) / 2) + 1;
    ctx.fillRect(
      Math.round(p.x + (flip ? w - 2 * sc : -w)),
      Math.round(yb - 2 * sc),
      Math.max(2, Math.round(2 * sc)),
      Math.max(1, Math.round(sc))
    );
  }
  if (u.cargo && !hit) {
    const c = unitById(u.cargo);
    if (c) drawSprite(ctx, spriteFor(c), p.x + (flip ? -3 : 3) * sc, yb - 3.5 * sc, sc * 0.5, flip);
  }
  R.boxes.push({ u, ...box });
  // HP bar + team pip
  const bw = 14,
    bx = Math.round(p.x - bw / 2),
    by = Math.round(box.y0 - 5);
  ctx.fillStyle = '#1b140e';
  ctx.fillRect(bx - 1, by - 1, bw + 2, 4);
  const pct = (u.dispHp ?? u.hp) / u.maxHp;
  ctx.fillStyle = pct < 0.34 ? '#d23a22' : pct < 0.67 ? '#f5c518' : '#7cd84a';
  ctx.fillRect(bx, by, Math.max(1, Math.round(bw * pct)), 2);
  if (shapesOn())
    drawArmyShape(ctx, u.pid, bx - 5, by + 1); // shape markers (accessibility)
  else {
    ctx.fillStyle = ARMIES[u.pid].color;
    ctx.fillRect(bx - 4, by - 1, 3, 4);
  }
  if (R.sel && R.sel.id === u.id) {
    const ay = by - 6 - (Math.floor(now / 200) % 2);
    ctx.fillStyle = '#1b140e';
    ctx.fillRect(Math.round(p.x) - 3, ay - 1, 7, 4);
    ctx.fillStyle = '#ffe04a';
    ctx.fillRect(Math.round(p.x) - 2, ay, 5, 1);
    ctx.fillRect(Math.round(p.x) - 1, ay + 1, 3, 1);
    ctx.fillRect(Math.round(p.x), ay + 2, 1, 1);
  }
  const o = appState.battle.orders[u.id];
  if (u.pid === me() && o && !R.busy) {
    ctx.fillStyle = '#1b140e';
    ctx.fillRect(bx + bw + 2, by - 1, 5, 5);
    ctx.fillStyle = o.type === 'hold' ? '#a8d4ff' : '#7cd84a';
    ctx.fillRect(bx + bw + 3, by, 3, 3);
  }
}

function centerOf(c, r, lift = 0.05) {
  const t = tileAt(c, r);
  return [t.wx, t.wy, t.z + lift];
}

function drawOrders(P, now) {
  if (R.busy) return;
  const ctx = R.ctx,
    B = appState.battle;
  const line = (pts, color, dash) => {
    const q = pts.map(a => P(...a));
    if (q.some(x => !x)) return;
    ctx.strokeStyle = '#1b140e';
    ctx.lineWidth = 3;
    ctx.setLineDash([]);
    ctx.beginPath();
    q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.stroke();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.setLineDash(dash ? [3, 2] : []);
    ctx.lineDashOffset = -Math.floor(now / 80);
    ctx.stroke();
    ctx.setLineDash([]);
  };
  const cross = (x, y, z) => {
    const p = P(x, y, z);
    if (!p) return;
    ctx.strokeStyle = '#ff4a2a';
    ctx.lineWidth = 1;
    const r = 5 + (Math.floor(now / 200) % 2);
    ctx.strokeRect(Math.round(p.x - r), Math.round(p.y - r), r * 2, r * 2);
    ctx.fillStyle = '#ff4a2a';
    ctx.fillRect(Math.round(p.x) - 1, Math.round(p.y) - 1, 2, 2);
  };
  const drawOne = (u, o) => {
    let from = [u.px, u.py, u.pz + 0.05];
    if (o.path) {
      line(
        o.path.map(h => centerOf(h.c, h.r)),
        o.type === 'amove' ? '#ff9a2a' : '#ffe04a',
        true
      );
      const d = o.path[o.path.length - 1];
      from = centerOf(d.c, d.r);
    }
    if (o.multi && o.path) {
      // where each turn of a multi-turn move should end
      const T = UNIT_TYPES[u.type];
      let acc = 0,
        turn = 1;
      for (let i = 1; i < o.path.length; i++) {
        const c = costAt(T, o.path[i].c, o.path[i].r) || 1;
        if (acc + c > T.move * turn + 1e-9) {
          const h = o.path[i - 1],
            q = P(...centerOf(h.c, h.r));
          if (q && turn < o.multi.turns) {
            ctx.fillStyle = '#ffe04a';
            ctx.beginPath();
            ctx.arc(q.x, q.y, Math.max(3, q.s * 0.22), 0, Math.PI * 2);
            ctx.fill();
            drawText(ctx, String(turn), q.x, q.y - Math.max(6, q.s * 0.5), '#ffe04a');
          }
          turn++;
        }
        acc += c;
      }
    }
    if (o.target) {
      const t = unitById(o.target);
      if (t && t.hp > 0) {
        const tz = t.pz + (isAir(t) ? 1.2 : 0.3);
        line([from, [t.px, t.py, tz]], '#ff4a2a', o.type === 'engage');
        cross(t.px, t.py, tz);
      }
    }
    if (o.unload) {
      const h = centerOf(o.unload.c, o.unload.r);
      line([from, h], '#7cf06a', false);
      const q = P(...h);
      if (q) {
        ctx.fillStyle = '#7cf06a';
        ctx.fillRect(Math.round(q.x) - 2, Math.round(q.y) - 2, 4, 4);
      }
    }
    if (o.type === 'load' || o.load) {
      const c = unitById(o.type === 'load' ? o.cargo : o.load);
      if (c) line([from, [c.px, c.py, c.pz + 0.05]], '#7cf06a', true);
    }
    const mid = o.type === 'repair' ? o.mend : o.repair;
    if (mid) {
      const t = unitById(mid);
      if (t) line([from, [t.px, t.py, t.pz + 0.3]], '#7cf06a', true);
    }
    const sb = o.type === 'build' ? o : o.build;
    if (sb) {
      // ghost scaffold where the structure will go
      const site = sb.kind === 'bridge' ? sb.at : o.path ? o.path[o.path.length - 1] : { c: u.c, r: u.r };
      const q = P(...centerOf(site.c, site.r));
      if (q) {
        ctx.globalAlpha = 0.7;
        drawSprite(ctx, STRUCT_SPR.scaffold, q.x, q.y + 2, clamp(q.s / 12, 0.6, 3), false);
        ctx.globalAlpha = 1;
      }
    }
    if (o.starget) {
      const c3 = centerOf(o.starget.c, o.starget.r, 0.2);
      line([from, c3], '#ff4a2a', false);
      cross(...c3);
    }
    if (o.road || o.type === 'road') {
      const q = P(...from);
      if (q) {
        const w = Math.max(3, Math.round(q.s / 4));
        ctx.fillStyle = '#1b140e';
        ctx.fillRect(Math.round(q.x - w / 2) - 1, Math.round(q.y) - 2, w + 2, 4);
        ctx.fillStyle = '#e8c47a';
        ctx.fillRect(Math.round(q.x - w / 2), Math.round(q.y) - 1, w, 2);
      }
    }
    if (o.flag || o.type === 'flag' || o.capture || o.type === 'capture') {
      const q = P(from[0] + 0.3, from[1], from[2]);
      if (q) {
        ctx.globalAlpha = 0.75;
        drawSprite(ctx, FLAG_SPR[u.pid], q.x, q.y, clamp(q.s / 12, 0.6, 3), false);
        ctx.globalAlpha = 1;
      }
    }
  };
  for (const u of aliveUnits()) if (u.pid === me() && B.orders[u.id]) drawOne(u, B.orders[u.id]);
  if (R.sel && R.pending) drawOne(R.sel, { path: R.pending.path, target: null });
}

function drawText(ctx, text, x, y, color) {
  ctx.font = '8px "Press Start 2P", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#1b140e';
  for (const [dx, dy] of [
    [-1, 0],
    [1, 0],
    [0, -1],
    [0, 1],
    [1, 1],
  ])
    ctx.fillText(text, Math.round(x) + dx, Math.round(y) + dy);
  ctx.fillStyle = color;
  ctx.fillText(text, Math.round(x), Math.round(y));
}

function drawEffects(P, now) {
  const ctx = R.ctx;
  for (let i = R.fx.length - 1; i >= 0; i--) {
    const e = R.fx[i],
      p = (now - e.t0) / e.dur;
    if (p >= 1) {
      R.fx.splice(i, 1);
      continue;
    }
    if (p < 0) continue;
    if (e.k === 'proj') {
      const x = lerp(e.ax, e.bx, p),
        y = lerp(e.ay, e.by, p),
        z = lerp(e.az, e.bz, p) + Math.sin(Math.PI * p) * e.arc;
      const q = P(x, y, z);
      if (!q) continue;
      const liftTop = appState.prefs.view === 'top' ? Math.sin(Math.PI * p) * e.arc * q.s * 0.6 : 0;
      const q0 = P(
        lerp(e.ax, e.bx, Math.max(0, p - 0.06)),
        lerp(e.ay, e.by, Math.max(0, p - 0.06)),
        lerp(e.az, e.bz, Math.max(0, p - 0.06)) + Math.sin(Math.PI * Math.max(0, p - 0.06)) * e.arc
      );
      ctx.strokeStyle = e.style === 'air' ? '#fff27a' : '#ffb03a';
      ctx.lineWidth = e.style === 'sea' ? 2 : 1;
      if (q0) {
        ctx.beginPath();
        ctx.moveTo(q0.x, q0.y - liftTop);
        ctx.lineTo(q.x, q.y - liftTop);
        ctx.stroke();
      }
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(Math.round(q.x) - 1, Math.round(q.y - liftTop) - 1, 2, 2);
      continue;
    }
    const q = P(e.x, e.y, e.z);
    if (!q) continue;
    const sc = clamp(q.s / 12, 0.5, 6);
    if (e.k === 'boom') {
      const r = (2 + p * 5 * e.size) * sc;
      ctx.fillStyle = p < 0.15 ? '#ffffff' : p < 0.4 ? '#ffe04a' : p < 0.7 ? '#ff8a2a' : 'rgba(90,80,70,' + (1 - p) + ')';
      ctx.beginPath();
      ctx.arc(Math.round(q.x), Math.round(q.y - 3 * sc), Math.max(1, r), 0, Math.PI * 2);
      ctx.fill();
      if (p < 0.6) {
        ctx.fillStyle = '#ffcc3a';
        ctx.beginPath();
        ctx.arc(Math.round(q.x), Math.round(q.y - 3 * sc), Math.max(1, r * 0.5), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = p < 0.5 ? '#ffe04a' : '#6a5a4a';
      for (const pt of e.parts)
        ctx.fillRect(
          Math.round(q.x + pt.vx * p * 14 * sc),
          Math.round(q.y - 3 * sc + (pt.vy * p + p * p * 1.5) * 12 * sc),
          Math.max(1, Math.round(sc)),
          Math.max(1, Math.round(sc))
        );
    } else if (e.k === 'flash') {
      ctx.fillStyle = '#fff27a';
      const r = Math.round(4 * sc * (1 - p));
      ctx.fillRect(Math.round(q.x) - r, Math.round(q.y - 4 * sc), r * 2, Math.max(1, Math.round(sc)));
      ctx.fillRect(Math.round(q.x) - 1, Math.round(q.y - 4 * sc) - r, Math.max(1, Math.round(sc)), r * 2);
    } else if (e.k === 'dust') {
      ctx.fillStyle = `rgba(220,200,160,${0.7 * (1 - p)})`;
      const r = Math.max(1, Math.round((1 + p * 3) * sc));
      ctx.fillRect(Math.round(q.x - r), Math.round(q.y - r - p * 4 * sc), r * 2, r * 2);
    } else if (e.k === 'text') {
      ctx.globalAlpha = p > 0.7 ? (1 - p) / 0.3 : 1;
      drawText(ctx, e.text, q.x, q.y - 16 - p * 14, e.color);
      ctx.globalAlpha = 1;
    }
  }
}

// A structure on its hex: sprite, owner's flag (capturable kinds), scaffold and progress while building,
// HP bar when damaged, and capture progress.
function drawStruct(ctx, so, g, t) {
  const S = STRUCTS[so.kind],
    spr = STRUCT_SPR[so.kind],
    m = g.mid;
  if (so.build) ctx.globalAlpha = 0.45;
  drawSprite(ctx, spr, m.x, m.y, m.sc, false);
  ctx.globalAlpha = 1;
  if (so.build) {
    drawSprite(ctx, STRUCT_SPR.scaffold, m.x, m.y, m.sc, false);
    R.labels.push({ x: t.wx, y: t.wy, z: t.z, text: `${so.build.prog}/${so.build.need}`, color: ARMIES[so.build.pid].light });
  } else if (S.capture && so.owner != null && g.ownAt) drawSprite(ctx, FLAG_SPR[so.owner], g.ownAt.x, g.ownAt.y, g.ownAt.sc, false);
  if (so.hp < so.maxHp) {
    const bw = Math.max(8, Math.round(spr.w * m.sc * 0.8)),
      bx = Math.round(m.x - bw / 2),
      by = Math.round(m.y + 2);
    ctx.fillStyle = '#1b140e';
    ctx.fillRect(bx - 1, by - 1, bw + 2, 4);
    ctx.fillStyle = so.hp / so.maxHp < 0.34 ? '#d23a22' : '#f5c518';
    ctx.fillRect(bx, by, Math.max(1, Math.round((bw * so.hp) / so.maxHp)), 2);
  }
  if (so.capPid != null) R.labels.push({ x: t.wx, y: t.wy, z: t.z, text: `${so.prog}/${CAPTURE_TURNS}`, color: ARMIES[so.capPid].light });
}
