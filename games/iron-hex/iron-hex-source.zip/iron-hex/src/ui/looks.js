// Period looks: medieval sprites, which look each unit wears, unlocks, and the Looks panel in the Unit library.
// ---- Looks ----------------------------------------------------------------
let SKIN_SPR = {},
  SKIN_WHITE = {};
function buildSkinSprites() {
  for (const per in SKIN_ART) {
    SKIN_SPR[per] = {};
    SKIN_WHITE[per] = {};
    for (const t in SKIN_ART[per]) {
      SKIN_SPR[per][t] = ARMIES.map(a => makeSprite(SKIN_ART[per][t], UNIT_PAL(a)));
      SKIN_WHITE[per][t] = makeSprite(SKIN_ART[per][t], { k: 1, t: 1, d: 1, l: 1, g: 1, w: 1, s: 1 }, '#ffffff');
    }
  }
}
// Which look a unit wears in this battle: its army's period, if that period has art for the type and,
// for your army, you've unlocked it for that unit type.
function lookOf(u) {
  const B = appState.battle;
  if (!B) return 'modern';
  const per = (B.skins || [])[u.pid];
  if (!per || per === 'modern' || !SKIN_SPR[per] || !SKIN_SPR[per][u.type]) return 'modern';
  if (u.pid === me() && !(B.skinUnlocked || []).includes(u.type)) return 'modern';
  return per;
}
function spriteFor(u, white) {
  const per = lookOf(u);
  if (per === 'modern') return white ? SPR_WHITE[u.type] : SPR[u.type][u.pid];
  return white ? SKIN_WHITE[per][u.type] : SKIN_SPR[per][u.type][u.pid];
}
// The unit types whose look you have unlocked for the period you picked for your army.
function refreshUnlocks() {
  const S = appState.settings,
    per = (S.skins || [])[0] || 'modern',
    prof = loadProfile();
  S.skinUnlocked = per === 'modern' ? [] : TYPE_ORDER.filter(t => usablePeriods(prof, t).includes(per));
}

// ---- Looks in the Unit library ---------------------------------------------
function looksHtml(type) {
  if (UNIT_TYPES[type].custom) return '';
  const prof = loadProfile(),
    have = unlockedPeriods(prof, type),
    u = (prof.units || {})[type] || {};
  const periods = Object.entries(SKIN_PERIODS).filter(([k, p]) => k === 'modern' || p.ready);
  return `<h3 class="rule-group">Looks</h3><div class="looks">${periods
    .map(
      ([
        k,
        p,
      ]) => `<figure class="look"><canvas class="px" width="48" height="32" data-look="${escapeHtml(k)}" data-look-type="${escapeHtml(type)}" data-locked="${escapeHtml(have.includes(k) ? 0 : 1)}"></canvas>
      <figcaption>${escapeHtml(k === 'modern' ? UNIT_TYPES[type].short : SKIN_NAMES[k][type])}<small>${p.name}${have.includes(k) ? '' : ' · locked'}</small></figcaption></figure>`
    )
    .join('')}</div>
    <ul class="ladder">${SKIN_LADDER.map(s => {
      const v = Math.min(u[s.stat] || 0, s.need),
        done = (u[s.stat] || 0) >= s.need;
      return `<li class="${done ? 'done' : ''}"><span>${done ? '✓' : '○'} ${escapeHtml(s.label)}</span><span>${SKIN_PERIODS[s.period].name}${SKIN_PERIODS[s.period].ready ? '' : ' (coming later)'}</span><span class="bar ${done ? '' : 'mid'}" style="--pct:${Math.round((100 * v) / s.need)}%"><i></i></span><small>${v} / ${s.need}</small></li>`;
    }).join('')}</ul>`;
}
function paintLooks(root) {
  root.querySelectorAll('[data-look]').forEach(cv => {
    const x = cv.getContext('2d'),
      per = cv.dataset.look,
      t = cv.dataset.lookType;
    x.imageSmoothingEnabled = false;
    x.clearRect(0, 0, cv.width, cv.height);
    const s = per === 'modern' ? SPR[t][appState.library.pid] : SKIN_SPR[per][t][appState.library.pid];
    const sc = Math.min(2, Math.floor(Math.min(cv.width / s.w, cv.height / s.h)) || 1);
    x.drawImage(s.n, Math.round((cv.width - s.w * sc) / 2), Math.round((cv.height - s.h * sc) / 2), s.w * sc, s.h * sc);
    if (cv.dataset.locked === '1') {
      x.globalCompositeOperation = 'source-atop';
      x.fillStyle = 'rgba(27,20,14,.88)';
      x.fillRect(0, 0, cv.width, cv.height);
      x.globalCompositeOperation = 'source-over';
    }
  });
}
