// Accessibility: colorblind-safe army colors, army shape markers, reduced motion, a keyboard hex cursor, and
// screen-reader announcements (a polite live region). Preferences live in appState.prefs.

// ---- Colors and shapes ----
// The standard palette, and a colorblind-safe one (Okabe–Ito blue, orange, bluish green, reddish purple).
const PALETTES = {
  standard: [
    { color: '#3f7fd6', dark: '#23488a', light: '#a8d4ff' },
    { color: '#d0402a', dark: '#7a2014', light: '#ffb09a' },
    { color: '#7a9a2a', dark: '#44581a', light: '#d6ee98' },
    { color: '#e0a52a', dark: '#8a5e0e', light: '#ffe39a' },
  ],
  colorblind: [
    { color: '#0072b2', dark: '#00426a', light: '#8cc8ec' },
    { color: '#e69f00', dark: '#8a5f00', light: '#ffd889' },
    { color: '#009e73', dark: '#005c43', light: '#8fe0c6' },
    { color: '#cc79a7', dark: '#7d3f63', light: '#f2c6de' },
  ],
};
const ARMY_SHAPES = ['●', '■', '▲', '◆'];
const shapesOn = () => !!(appState.prefs.shapes || appState.prefs.palette === 'colorblind');
// Recolor every army and rebuild the sprites and cached tiles that carry army colors.
function applyPalette() {
  const pal = PALETTES[appState.prefs.palette] || PALETTES.standard;
  ARMIES.forEach((a, i) => Object.assign(a, pal[i]));
  buildSprites();
  buildSkinSprites();
  R.tileCache = null;
  R.geomSig = null;
}
// A small shape marker beside a unit's health bar (drawn by the renderer when shapes are on).
function drawArmyShape(ctx, pid, x, y) {
  ctx.fillStyle = '#1b140e';
  ctx.fillRect(x - 3, y - 3, 7, 7);
  ctx.fillStyle = ARMIES[pid].color;
  const s = pid % 4;
  if (s === 0) {
    ctx.beginPath();
    ctx.arc(x + 0.5, y + 0.5, 2.6, 0, Math.PI * 2);
    ctx.fill();
  } else if (s === 1) ctx.fillRect(x - 2, y - 2, 5, 5);
  else if (s === 2) {
    ctx.beginPath();
    ctx.moveTo(x + 0.5, y - 2.5);
    ctx.lineTo(x + 3, y + 2.5);
    ctx.lineTo(x - 2, y + 2.5);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.moveTo(x + 0.5, y - 3);
    ctx.lineTo(x + 3.5, y + 0.5);
    ctx.lineTo(x + 0.5, y + 3.5);
    ctx.lineTo(x - 2.5, y + 0.5);
    ctx.closePath();
    ctx.fill();
  }
}

// ---- Reduced motion ----
const reducedMotion = () => !!appState.prefs.reducedMotion;
function initMotionPref() {
  if (appState.prefs.reducedMotion === undefined && window.matchMedia)
    appState.prefs.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

// ---- Screen-reader announcements ----
let srTimer = null;
function announce(text) {
  if (appState.prefs.announce === false) return;
  const el = $('#sr-live');
  if (!el) return;
  clearTimeout(srTimer);
  el.textContent = '';
  srTimer = setTimeout(() => (el.textContent = text), 60); // re-set so repeated messages are read again
}
const TERRAIN_WORDS = t => (TERRAIN[t] && TERRAIN[t].name ? TERRAIN[t].name.toLowerCase() : 'ground');
function describeUnit(u) {
  const T = UNIT_TYPES[u.type],
    side = u.pid === me() ? 'Your' : isAlly(me(), u.pid) ? 'Allied' : 'Enemy';
  const bits = [`${side} ${u.name}, ${T.name}`, `${u.hp} of ${u.maxHp} HP`];
  if (u.pid === me()) {
    bits.push(`ammo ${u.ammo} of ${u.maxAmmo}`);
    if (u.fuel != null) bits.push(`fuel ${Math.round(u.fuel)}`);
    if (u.dug && appState.battle.rules.entrench) bits.push(`dug in, level ${u.dug}`);
    if (u.supp && appState.battle.rules.suppression) bits.push('suppressed');
    if (u.cut && appState.battle.rules.supplyLines) bits.push('cut off from supply');
    if (appState.battle.rules.command && outOfCommand(u)) bits.push('out of command');
    if (appState.battle.rules.ew && jammed(u)) bits.push('jammed');
    if (u.dug && appState.battle.rules.entrench) bits.push(`dug in, level ${u.dug}`);
    if (u.supp && appState.battle.rules.suppression) bits.push('suppressed');
    if (u.cut && appState.battle.rules.supplyLines) bits.push('cut off from supply');
    if (appState.battle.rules.command && outOfCommand(u)) bits.push('out of command');
    if (appState.battle.rules.ew && jammed(u)) bits.push('jammed');
    const st = moraleState(u);
    if (st) bits.push(`morale ${st.toLowerCase()}`);
    const o = appState.battle.orders[u.id];
    bits.push(o ? 'order: ' + orderLabel(o) : 'awaiting orders');
  }
  return bits.join(', ');
}
function describeHex(c, r) {
  const B = appState.battle,
    t = tileAt(c, r);
  if (!t) return 'Off the map.';
  const parts = [`Column ${c + 1}, row ${r + 1}: ${TERRAIN_WORDS(t.t)}`];
  const units = aliveUnits().filter(u => u.c === c && u.r === r && (u.pid === me() || canSee(me(), u)));
  for (const u of units) parts.push(describeUnit(u));
  const s = structAt(c, r);
  if (s) parts.push(`${STRUCTS[s.kind].name}${s.owner != null ? ' held by ' + B.players[s.owner].name : ''}`);
  const city = B.cities && B.cities[key(c, r)];
  if (city) parts.push(`city${city.owner != null ? ' held by ' + B.players[city.owner].name : ', neutral'}`);
  if (B.rules.airSup) {
    const ctl = airControl({ c, r });
    if (ctl != null) parts.push(ctl === teamOf(me()) ? 'your side controls the air' : 'the enemy controls the air');
  }
  if (
    B.rules.aaUmbrella &&
    aliveUnits().some(
      o => isAAUnit(UNIT_TYPES[o.type]) && hexDist(o, { c, r }) <= REAL.UMBRELLA_RANGE && (o.pid === me() || canSee(me(), o))
    )
  )
    parts.push('under an anti-aircraft umbrella');
  const own = B.territory && B.territory[key(c, r)];
  if (own != null) parts.push(`territory of ${B.players[own].name}`);
  if (R.mode === 'move' && R.reach) {
    const n = R.reach.get(key(c, r)),
      far = R.travel && R.travel.get(key(c, r));
    parts.push(n && n.end ? 'reachable this turn' : far && far.turns >= 2 ? `about ${far.turns} turns away` : 'not reachable');
  }
  return parts.join('. ') + '.';
}
function situationReport() {
  const B = appState.battle;
  const lines = [`Turn ${B.turn}.`];
  for (const p of B.players) {
    const n = allAlive().filter(u => u.pid === p.id).length;
    const hidden = B.rules.fog && isEnemy(me(), p.id);
    const who = p.id === me() ? 'You' : p.name;
    lines.push(
      `${who}: ${hidden ? 'unknown number of' : n} units, ${Math.round(territoryShare(B, p.id) * 100)} percent territory${isAlly(me(), p.id) ? ', allied' : ''}.`
    );
  }
  const mine = aliveUnits().filter(u => u.pid === me()),
    waiting = mine.filter(u => !B.orders[u.id]).length;
  lines.push(`${waiting} of ${mine.length} of your units await orders.`);
  if (B.objective && OBJ_TEXT[B.objective.type]) lines.push('Objective: ' + OBJ_TEXT[B.objective.type](B.objective) + '.');
  return lines.join(' ');
}

// ---- Keyboard hex cursor ----
// With a unit selected (or while choosing a destination or target), arrow keys move a cursor over hexes and
// Enter acts on that hex exactly as a tap would. Without a selection, arrows pan the map as before.
function cursorActive() {
  return !!R.sel || (R.mode && R.mode !== 'idle');
}
function moveCursor(dc, dr) {
  const B = appState.battle;
  const k = R.kc || (R.sel ? { c: R.sel.c, r: R.sel.r } : { c: Math.floor(B.mapDef.W / 2), r: Math.floor(B.mapDef.H / 2) });
  R.kc = { c: clamp(k.c + dc, 0, B.mapDef.W - 1), r: clamp(k.r + dr, 0, B.mapDef.H - 1) };
  const t = tileAt(R.kc.c, R.kc.r);
  R.cam.x = t.wx;
  R.cam.y = t.wy;
  announce(describeHex(R.kc.c, R.kc.r));
}
function cursorTap() {
  if (!R.kc) return false;
  const pk = R.pick && R.pick.find(x => x.t.c === R.kc.c && x.t.r === R.kc.r);
  if (!pk) return false;
  const cx = pk.pts.reduce((s, p) => s + p.x, 0) / pk.pts.length,
    cy = pk.pts.reduce((s, p) => s + p.y, 0) / pk.pts.length;
  onTap(cx, cy);
  return true;
}
// The cursor's outline, drawn by the renderer on top of the board.
function drawCursor(ctx) {
  if (!R.kc || !cursorActive() || !R.pick) return;
  const pk = R.pick.find(x => x.t.c === R.kc.c && x.t.r === R.kc.r);
  if (!pk) return;
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 2;
  ctx.setLineDash([4, 3]);
  ctx.beginPath();
  pk.pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.closePath();
  ctx.stroke();
  ctx.setLineDash([]);
}
