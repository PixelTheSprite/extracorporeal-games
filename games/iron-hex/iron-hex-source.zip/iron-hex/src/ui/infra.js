// Infrastructure Editor: place structures on any map (generated, real-world or your own) and save the layout.
// Layouts are stored in this browser (localStorage) and chosen on the Quick battle screen.
const LS_LAYOUTS = 'ironhex_layouts';
const INFRA_HINT = {
  airfield: 'Airfields go on open land: not water, cities or mountains.',
  port: 'Ports go on land next to water (not cities or mountains).',
  bridge: 'Bridges go on shallow water (the lighter blue).',
  depot: 'Depots go on open land: not water, cities or mountains.',
  fort: 'Fortifications go on open land: not water, cities or mountains.',
};
const infra = { mapId: 'strait', tool: 'airfield', owner: 0, structs: {}, name: '', def: null, hover: null };
function loadLayouts() {
  return storedList(LS_LAYOUTS).filter(L => L && /^[a-z0-9_-]{1,60}$/i.test(L.id || '') && Array.isArray(L.structs));
}
const storeLayouts = list => store.set(LS_LAYOUTS, list);
// Only the random generated map depends on a seed; layouts made for it remember which one.
const layoutSeed = mapId => {
  const p = MAP_PRESETS.find(m => m.id === mapId);
  return p ? (p.seed ?? appState.settings.randomSeed) : null;
};
// Every map on offer, as [{ group, id, name }], and its definition (custom maps come from browser storage).
const allMaps = () => [
  ...MAP_PRESETS.map(m => ({ group: 'Generated', id: m.id, name: m.name })),
  ...REAL_MAPS.map(m => ({ group: 'Real world', id: m.id, name: m.name })),
  ...loadMaps().map(m => ({ group: 'Your maps', id: m.id, name: m.name })),
];
function anyMapDef(id) {
  const c = loadMaps().find(m => m.id === id);
  return c ? clone(c) : mapDefFor(id);
}
const anyMapName = id => (allMaps().find(m => m.id === id) || { name: id }).name;
function infraDef() {
  const tag = infra.mapId + '|' + layoutSeed(infra.mapId);
  if (!infra.def || infra.defTag !== tag) {
    infra.def = anyMapDef(infra.mapId);
    infra.defTag = tag;
  }
  return infra.def;
}
const ownerNames = () => {
  const d = infraDef();
  return d.sides ? d.sides.map(s => s.name) : ARMIES.slice(0, d.spawns.length).map(a => a.name);
};
function infraLayout() {
  return {
    mapId: infra.mapId,
    seed: layoutSeed(infra.mapId),
    structs: Object.entries(infra.structs).map(([k, v]) => {
      const [c, r] = unkey(k);
      return { c, r, kind: v.kind, owner: v.owner };
    }),
  };
}
function infraStatus(msg) {
  $('#infra-status').textContent = msg;
}

function renderInfra() {
  if (!allMaps().some(m => m.id === infra.mapId)) {
    infra.mapId = 'strait';
    infra.structs = {};
  }
  let grp = '';
  $('#infra-map').innerHTML =
    allMaps()
      .map(m => {
        const open = m.group !== grp ? `${grp ? '</optgroup>' : ''}<optgroup label="${m.group}">` : '';
        grp = m.group;
        return (
          open +
          `<option value="${escapeHtml(m.id)}" ${m.id === infra.mapId ? 'selected' : ''}>${escapeHtml(m.name)}${m.id === 'random' ? ` (seed ${appState.settings.randomSeed})` : ''}</option>`
        );
      })
      .join('') + '</optgroup>';
  $('#infra-tools').innerHTML = STRUCT_ORDER.filter(k => !STRUCTS[k].rule) // rule structures (silos) are built in battle only
    .concat(['erase'])
    .map(
      k =>
        `<button class="btn sm alt" data-tool="${escapeHtml(k)}" aria-pressed="${infra.tool === k}">${k === 'erase' ? 'Erase' : STRUCTS[k].name}</button>`
    )
    .join('');
  $('#infra-tooldesc').textContent =
    infra.tool === 'erase' ? 'Tap a structure to remove it.' : `${STRUCTS[infra.tool].desc} ${INFRA_HINT[infra.tool]}`;
  if (infra.owner != null && infra.owner >= ownerNames().length) infra.owner = 0;
  $('#infra-owner').innerHTML = [['Neutral', null, '#8b97a3']]
    .concat(ownerNames().map((n, i) => [n, i, ARMIES[i].color]))
    .map(
      ([n, v, col]) =>
        `<button class="btn sm alt owner-btn" data-owner="${escapeHtml(v)}" aria-pressed="${infra.owner === v}"><i style="background:${col}"></i>${escapeHtml(n)}</button>`
    )
    .join('');
  const list = loadLayouts();
  $('#infra-list').innerHTML = list.length
    ? list
        .map(
          L => `<div class="layout-row"><span><b>${escapeHtml(L.name)}</b><small>${escapeHtml(anyMapName(L.mapId))}${L.mapId === 'random' ? ` · seed ${L.seed}` : ''} · ${L.structs.length} structures</small></span>
    <span class="row-btns"><button class="btn sm alt" data-lay-load="${escapeHtml(L.id)}">Edit</button><button class="btn sm" data-lay-use="${escapeHtml(L.id)}">Use in Quick battle</button><button class="btn sm red" data-lay-del="${escapeHtml(L.id)}" aria-label="Delete ${escapeHtml(L.name)}">✕</button></span></div>`
        )
        .join('')
    : '<p class="src">No saved layouts yet.</p>';
  drawInfra();
}
// Top-down map with spawns and structures. Returns the hex size so taps can be mapped back to hexes.
function infraGeom(cv, def) {
  const sz = Math.min(cv.width / (def.W * SQ3 + 1), cv.height / (def.H * 1.5 + 0.5));
  const ox = (cv.width - (def.W * SQ3 + SQ3 / 2) * sz) / 2 + (SQ3 / 2) * sz,
    oy = (cv.height - (def.H * 1.5 + 0.5) * sz) / 2 + sz;
  return {
    sz,
    ox,
    oy,
    at: (c, r) => {
      const w = toWorld(c, r);
      return { x: ox + w.x * sz, y: oy + w.y * sz };
    },
  };
}
function drawInfra() {
  const cv = $('#infra-canvas'),
    x = cv.getContext('2d'),
    def = infraDef(),
    G = infraGeom(cv, def);
  x.imageSmoothingEnabled = false;
  x.fillStyle = '#10213d';
  x.fillRect(0, 0, cv.width, cv.height);
  for (let r = 0; r < def.H; r++)
    for (let c = 0; c < def.W; c++) {
      const p = G.at(c, r);
      x.fillStyle = TERRAIN[def.rows[r][c]].color;
      x.beginPath();
      HEX_CORNERS.forEach(([a, b], i) => {
        const px = p.x + a * G.sz,
          py = p.y + b * G.sz;
        i ? x.lineTo(px, py) : x.moveTo(px, py);
      });
      x.closePath();
      x.fill();
      x.strokeStyle = 'rgba(0,0,0,.18)';
      x.stroke();
    }
  def.spawns.forEach((s, i) => {
    const p = G.at(s.c, s.r);
    x.fillStyle = '#1b140e';
    x.fillRect(Math.round(p.x) - 5, Math.round(p.y) - 5, 11, 11);
    x.fillStyle = ARMIES[i].color;
    x.fillRect(Math.round(p.x) - 4, Math.round(p.y) - 4, 9, 9);
  });
  const sc = Math.max(0.5, G.sz / 12);
  for (const [k, v] of Object.entries(infra.structs)) {
    const [c, r] = unkey(k),
      p = G.at(c, r);
    drawSprite(x, STRUCT_SPR[v.kind], p.x, p.y + 4 * sc, sc, false);
    if (v.owner != null) drawSprite(x, FLAG_SPR[v.owner], p.x + 6 * sc, p.y + 3 * sc, sc * 0.8, false);
  }
  if (infra.hover) {
    const p = G.at(infra.hover.c, infra.hover.r);
    x.strokeStyle = '#fff';
    x.lineWidth = 2;
    x.beginPath();
    HEX_CORNERS.forEach(([a, b], i) => {
      const px = p.x + a * G.sz,
        py = p.y + b * G.sz;
      i ? x.lineTo(px, py) : x.moveTo(px, py);
    });
    x.closePath();
    x.stroke();
    x.lineWidth = 1;
  }
}
function infraHexAt(e) {
  const cv = $('#infra-canvas'),
    rc = cv.getBoundingClientRect(),
    def = infraDef(),
    G = infraGeom(cv, def);
  const px = ((e.clientX - rc.left) * cv.width) / rc.width,
    py = ((e.clientY - rc.top) * cv.height) / rc.height;
  let best = null,
    bd = Infinity;
  for (let r = 0; r < def.H; r++)
    for (let c = 0; c < def.W; c++) {
      const p = G.at(c, r),
        d = Math.hypot(p.x - px, p.y - py);
      if (d < bd) {
        bd = d;
        best = { c, r };
      }
    }
  return bd <= G.sz ? best : null;
}
function infraPlace(h) {
  const def = infraDef(),
    k = key(h.c, h.r),
    cur = infra.structs[k];
  if (infra.tool === 'erase') {
    if (cur) {
      delete infra.structs[k];
      infraStatus('Removed.');
    }
    drawInfra();
    return;
  }
  if (def.spawns.some(s => s.c === h.c && s.r === h.r)) {
    infraStatus('Spawn points stay clear.');
    return;
  }
  if (!siteOk(infra.tool, def.rows[h.r][h.c], isCoastal(def.rows, def.W, def.H, h.c, h.r))) {
    infraStatus(INFRA_HINT[infra.tool]);
    return;
  }
  if (cur && cur.kind === infra.tool && cur.owner === infra.owner) {
    delete infra.structs[k];
    infraStatus('Removed.');
  } else {
    infra.structs[k] = { kind: infra.tool, owner: infra.owner };
    infraStatus(`${STRUCTS[infra.tool].name} placed for ${infra.owner == null ? 'nobody (neutral)' : ownerNames()[infra.owner]}.`);
  }
  SFX.play('click');
  drawInfra();
}
const infraCanvas = $('#infra-canvas');
infraCanvas.addEventListener('click', e => {
  const h = infraHexAt(e);
  if (h) infraPlace(h);
});
infraCanvas.addEventListener('pointermove', e => {
  const h = infraHexAt(e);
  if ((h && key(h.c, h.r)) !== (infra.hover && key(infra.hover.c, infra.hover.r))) {
    infra.hover = h;
    drawInfra();
  }
});
infraCanvas.addEventListener('pointerleave', () => {
  infra.hover = null;
  drawInfra();
});
$('#infra-map').addEventListener('change', e => {
  infra.mapId = e.target.value;
  infra.structs = {};
  infra.def = null;
  infraStatus('New map: layout cleared.');
  renderInfra();
});
$('#scr-infra').addEventListener('click', e => {
  const tool = e.target.closest('[data-tool]');
  if (tool) {
    infra.tool = tool.dataset.tool;
    SFX.play('click');
    renderInfra();
    return;
  }
  const own = e.target.closest('[data-owner]');
  if (own) {
    infra.owner = own.dataset.owner === 'null' ? null : +own.dataset.owner;
    SFX.play('click');
    renderInfra();
    return;
  }
  if (e.target.closest('#btn-infra-auto')) {
    infra.structs = {};
    for (const s of autoLayout(infraDef(), infraDef().spawns.length)) infra.structs[key(s.c, s.r)] = { kind: s.kind, owner: s.owner };
    infraStatus('Placed an airfield, port and depot near each spawn point.');
    SFX.play('click');
    drawInfra();
    return;
  }
  if (e.target.closest('#btn-infra-clear')) {
    infra.structs = {};
    infraStatus('Cleared.');
    drawInfra();
    return;
  }
  if (e.target.closest('#btn-infra-save')) {
    const L = infraLayout(),
      problems = validateLayout(L, infraDef());
    if (!L.structs.length) {
      infraStatus('Place at least one structure first.');
      return;
    }
    if (problems.length) {
      infraStatus(problems[0]);
      return;
    }
    const list = loadLayouts(),
      name = ($('#infra-name').value || '').trim() || `${anyMapName(infra.mapId)} layout ${list.length + 1}`;
    const existing = list.find(x => x.name === name);
    const saved = Object.assign(existing || { id: Date.now().toString(36) }, L, { name });
    if (!existing) list.push(saved);
    infraStatus(storeLayouts(list) ? `Saved “${name}”.` : 'Could not save: browser storage is unavailable.');
    renderInfra();
    return;
  }
  const ld = e.target.closest('[data-lay-load]'),
    use = e.target.closest('[data-lay-use]'),
    del = e.target.closest('[data-lay-del]');
  const list = loadLayouts(),
    L = list.find(x => x.id === (ld || use || del || {}).dataset?.[ld ? 'layLoad' : use ? 'layUse' : 'layDel']);
  if (!L) return;
  if (ld) {
    infra.mapId = L.mapId;
    if (L.mapId === 'random') appState.settings.randomSeed = L.seed;
    infra.def = null;
    infra.structs = {};
    for (const s of L.structs) infra.structs[key(s.c, s.r)] = { kind: s.kind, owner: s.owner };
    $('#infra-name').value = L.name;
    infraStatus(`Editing “${L.name}”.`);
    renderInfra();
  } else if (use) {
    appState.settings.mapId = L.mapId;
    if (L.mapId === 'random') appState.settings.randomSeed = L.seed;
    const cm = loadMaps().find(m => m.id === L.mapId);
    if (cm) appState.settings.customMap = clone(cm);
    appState.settings.layout = clone(L);
    infraStatus(`Quick battle will use “${L.name}”.`);
    SFX.play('select');
  } else if (del) {
    storeLayouts(list.filter(x => x.id !== L.id));
    if (appState.settings.layout && appState.settings.layout.id === L.id) appState.settings.layout = null;
    infraStatus(`Deleted “${L.name}”.`);
    renderInfra();
  }
});
