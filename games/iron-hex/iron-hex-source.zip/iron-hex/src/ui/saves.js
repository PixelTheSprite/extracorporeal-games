// Battle saves: named save slots behind a small storage interface, plus export/import as .json files.
//
// A SaveStore holds save slots. Each slot = { id, name, savedAt, turn, mapName, mode, armies } plus its data
// (a snapshot()). Methods are async so a remote store can stand in for the browser one:
//   list() -> [meta]   get(id) -> data | null   put(meta, data) -> id   remove(id)
// LocalSaveStore keeps slots in this browser. CloudSaveStore is the cross-device version, written against
// the hosted runtime's per-viewer private storage (db paths data/users/<id>/saves/...), which needs no new
// database; it is switched off (CLOUD_SAVES = false) until cross-device saves are turned on.
const SAVE_MAX = 12,
  CLOUD_SAVES = false;
const LS_SAVE_INDEX = 'ironhex_saves',
  lsSlot = id => 'ironhex_save_' + id;
const saveMeta = (name, data) => {
  const b = data.battle;
  return {
    name: String(name || 'Battle').slice(0, 60),
    savedAt: new Date().toISOString(),
    turn: b.turn,
    mapName: b.mapDef.name,
    mode: b.campaign ? 'Campaign: ' + b.campaign.title : 'Quick battle',
    armies: b.players.map(p => p.name).join(' vs '),
  };
};

const LocalSaveStore = {
  kind: 'local',
  label: 'This browser',
  async list() {
    return storedList(LS_SAVE_INDEX);
  },
  async get(id) {
    return store.get(lsSlot(id), null);
  },
  async put(meta, data) {
    const list = await this.list(),
      id = meta.id || Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36);
    if (!meta.id && list.length >= SAVE_MAX) throw new Error(`All ${SAVE_MAX} save slots are full. Overwrite or delete one first.`);
    if (!store.set(lsSlot(id), data))
      throw new Error('Browser storage is full or unavailable. Delete a save, or export this battle to a file instead.');
    const entry = Object.assign({}, meta, { id }),
      i = list.findIndex(x => x.id === id);
    if (i >= 0) list[i] = entry;
    else list.unshift(entry);
    store.set(LS_SAVE_INDEX, list);
    return id;
  },
  async remove(id) {
    store.remove(lsSlot(id));
    store.set(
      LS_SAVE_INDEX,
      (await this.list()).filter(x => x.id !== id)
    );
  },
};
// Cross-device saves (off). Uses the hosted runtime's private per-viewer store: nobody else, the owner included,
// can read data/users/<id>/. Each save is one document (under the store's 256 KiB document limit).
function CloudSaveStore(db, uid) {
  const col = () => db.collection(`data/users/${uid}/saves`);
  return {
    kind: 'cloud',
    label: 'Your account (all devices)',
    async list() {
      const s = await col().get();
      return s.docs
        .filter(d => d.exists)
        .map(d => Object.assign({}, d.data().meta, { id: d.id }))
        .sort((a, b) => (a.savedAt < b.savedAt ? 1 : -1));
    },
    async get(id) {
      const d = await col().doc(id).get();
      return d.exists ? JSON.parse(d.data().json) : null;
    },
    async put(meta, data) {
      const { id, ...rest } = meta,
        ref = id ? col().doc(id) : col().doc();
      await ref.set({ meta: rest, json: JSON.stringify(data) });
      return ref.id;
    },
    async remove(id) {
      await col().doc(id).delete();
    },
  };
}
// The stores on offer: always this browser; your account too once cross-device saves are switched on.
async function saveStores() {
  const out = [LocalSaveStore];
  if (CLOUD_SAVES) {
    const db = await sbInit();
    const uid = db && (await SB.user.id());
    if (uid) out.push(CloudSaveStore(db, uid));
  }
  return out;
}
// One older single save (from before slots) moves into a slot.
async function migrateOldSave() {
  const old = fallbackLoad(LS_SAVE);
  if (!old || !old.battle) return;
  try {
    await LocalSaveStore.put(saveMeta('Saved battle', old), old);
    store.remove(LS_SAVE);
  } catch (e) {
    /* keep the old save if there's no room */
  }
}

// ---- dialogs (in-page: the hosted game blocks browser popups and file pickers) ----
const sv = { confirmDel: null, confirmNew: false };
const fmtWhen = iso => {
  const d = new Date(iso);
  return isNaN(d) ? '' : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
};
function openSaveDialog() {
  if (R.busy || !appState.battle) return;
  const B = appState.battle,
    def = `${B.mapDef.name}, turn ${B.turn}`;
  saveStores().then(async stores => {
    const st = stores[0],
      list = await st.list();
    showDialog(`<div class="panel save-dlg" role="dialog" aria-modal="true" aria-labelledby="sv-title">
      <h2 id="sv-title">Save battle</h2>
      <label class="field">Name <input id="sv-name" type="text" maxlength="60" value="${escapeHtml(def)}"></label>
      <div class="row-end"><button class="btn alt" id="sv-export">Export to a file</button><button class="btn" id="sv-new">Save to a new slot</button></div>
      <h3 class="rule-group">Or overwrite a slot (${list.length} of ${SAVE_MAX} used)</h3>
      <div class="layout-list">${list.length ? list.map(m => `<div class="layout-row"><span><b>${escapeHtml(m.name)}</b><small>${escapeHtml(m.mode)} · ${escapeHtml(m.mapName)} · turn ${m.turn} · ${fmtWhen(m.savedAt)}</small></span><span class="row-btns"><button class="btn sm alt" data-sv-over="${escapeHtml(m.id)}">Overwrite</button></span></div>`).join('') : '<p class="src">No saves yet.</p>'}</div>
      <p class="status" id="sv-status" role="status"></p>
      <div class="row-end"><span></span><button class="btn alt" id="sv-close">Close</button></div></div>`);
    $('#sv-name').focus();
    $('#sv-name').select();
    const done = async id => {
      try {
        const data = snapshot();
        await st.put(Object.assign(saveMeta($('#sv-name').value.trim() || def, data), id ? { id } : {}), data);
        $('#sv-status').textContent = 'Saved.';
        setTimeout(closeModal, 700);
        $('#save-status').textContent = `Saved “${$('#sv-name').value.trim() || def}”.`;
      } catch (e) {
        $('#sv-status').textContent = e.message;
      }
    };
    $('#sv-new').onclick = () => done(null);
    $('#modal')
      .querySelectorAll('[data-sv-over]')
      .forEach(b => (b.onclick = () => done(b.dataset.svOver)));
    $('#sv-export').onclick = async () => {
      $('#sv-status').textContent = await ueDownload(
        `${B.mapDef.name.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-turn-${B.turn}.json`,
        JSON.stringify(snapshot())
      );
    };
    $('#sv-close').onclick = () => closeModal();
  });
}
function openLoadDialog() {
  if (R.busy) return;
  saveStores().then(async stores => {
    const st = stores[0],
      list = await st.list(),
      auto = fallbackLoad(LS_AUTO);
    showDialog(`<div class="panel save-dlg" role="dialog" aria-modal="true" aria-labelledby="ld-title">
      <h2 id="ld-title">Load battle</h2>
      <div class="layout-list">${auto && auto.battle ? `<div class="layout-row"><span><b>Autosave</b><small>${escapeHtml(auto.battle.mapDef.name)} · turn ${auto.battle.turn} · ${fmtWhen(auto.savedAt)}</small></span><span class="row-btns"><button class="btn sm" data-ld-auto="1">Load</button></span></div>` : ''}
      ${
        list
          .map(
            m => `<div class="layout-row"><span><b>${escapeHtml(m.name)}</b><small>${escapeHtml(m.mode)} · ${escapeHtml(m.mapName)} · turn ${m.turn} · ${escapeHtml(m.armies || '')} · ${fmtWhen(m.savedAt)}</small></span>
        <span class="row-btns"><button class="btn sm" data-ld="${escapeHtml(m.id)}">Load</button><button class="btn sm alt" data-ld-export="${escapeHtml(m.id)}">Export</button><button class="btn sm red" data-ld-del="${escapeHtml(m.id)}">${sv.confirmDel === m.id ? 'Delete?' : '✕'}</button></span></div>`
          )
          .join('') || (auto ? '' : '<p class="src">No saved battles yet. Save one from the battle screen.</p>')
      }</div>
      <label class="btn alt file-btn" style="justify-self:start">Import a save file<input id="ld-import" type="file" accept=".json,application/json"></label>
      <p class="status" id="ld-status" role="status"></p>
      <div class="row-end"><span></span><button class="btn alt" id="ld-close">Close</button></div></div>`);
    const say = t => {
      $('#ld-status').textContent = t;
    };
    const start = (data, from) => {
      if (applySave(data)) {
        closeModal();
        refreshUnlocks();
        enterBattle('Loaded ' + from);
      } else say("That save could not be loaded: it is damaged, from a newer version, or uses units this game doesn't know.");
    };
    $('#modal')
      .querySelectorAll('[data-ld]')
      .forEach(
        b => (b.onclick = async () => start(await st.get(b.dataset.ld), '“' + (list.find(m => m.id === b.dataset.ld) || {}).name + '”'))
      );
    $('#modal')
      .querySelectorAll('[data-ld-auto]')
      .forEach(b => (b.onclick = () => start(auto, 'the autosave')));
    $('#modal')
      .querySelectorAll('[data-ld-export]')
      .forEach(
        b =>
          (b.onclick = async () => {
            const m = list.find(x => x.id === b.dataset.ldExport),
              d = await st.get(m.id);
            say(await ueDownload(`${m.name.replace(/[^a-z0-9]+/gi, '-').toLowerCase() || 'battle'}.json`, JSON.stringify(d)));
          })
      );
    $('#modal')
      .querySelectorAll('[data-ld-del]')
      .forEach(
        b =>
          (b.onclick = async () => {
            if (sv.confirmDel !== b.dataset.ldDel) {
              sv.confirmDel = b.dataset.ldDel;
              openLoadDialog();
              return;
            }
            sv.confirmDel = null;
            await st.remove(b.dataset.ldDel);
            openLoadDialog();
          })
      );
    $('#ld-import').onchange = async e => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      if (tooBig(f)) {
        say('That file is too large to be a save (over 5 MB).');
        return;
      }
      let data;
      try {
        data = JSON.parse(await f.text());
      } catch (err) {
        say("That file isn't a save (not JSON).");
        return;
      }
      if (!data || data.app !== 'iron-hex' || !data.battle) {
        say("That file isn't an Iron Hex battle save.");
        return;
      }
      try {
        await st.put(saveMeta(f.name.replace(/\.json$/i, ''), data), data);
      } catch (err) {
        /* full: still loadable directly */
      }
      start(data, 'from ' + f.name);
    };
    $('#ld-close').onclick = () => closeModal();
  });
}
function openNewDialog() {
  if (R.busy || !appState.battle) return;
  const camp = appState.battle.campaign;
  showDialog(`<div class="panel" role="dialog" aria-modal="true" aria-labelledby="nw-title"><h2 id="nw-title">${camp ? 'Restart this mission?' : 'Start a new battle?'}</h2>
    <p>${camp ? `Restarts ${escapeHtml(camp.title)} with your task force as it was at the start of the mission.` : 'Same map, armies, rules and roster, with a fresh battle seed.'} Progress in this battle is lost unless you save it first.</p>
    <div class="row-end"><button class="btn alt" id="nw-cancel">Cancel</button><button class="btn alt" id="nw-save">Save first</button><button class="btn red" id="nw-go">${camp ? 'Restart mission' : 'New battle'}</button></div></div>`);
  $('#nw-cancel').focus();
  $('#nw-cancel').onclick = () => closeModal();
  $('#nw-save').onclick = () => openSaveDialog();
  $('#nw-go').onclick = () => {
    closeModal();
    if (camp) startMission();
    else {
      refreshUnlocks();
      newBattle();
      enterBattle('New battle started');
    }
  };
}
