// Battle overlays: fog shading, hidden enemies, sightings and decoys on the map, conditions and funds chips,
// and morale badges on unit cards.
// Hexes your team can't currently see are drawn darker (fog rule only).
const fogShade = k => {
  const B = appState.battle;
  return !R.replay && B && B.rules && B.rules.fog && B.vis && !(B.vis[teamOf(me())] || new Set()).has(k);
};
// Enemy units you can't see aren't drawn (and so can't be tapped).
const drawnForYou = u => !!R.replay || !appState.battle.rules.fog || canSee(me(), u); // replays show everything
// Sightings (last-known positions, with confidence under Fading intel) and your own decoys.
function drawSightings(P, now) {
  const B = appState.battle;
  if (!B.rules.fog || R.replay) return;
  const ctx = R.ctx;
  // Sightings change only when vision or intel does: cache them between frames.
  const sk = B.turn + '|' + B.visKey + '|' + Object.keys((B.intel || {})[teamOf(me())] || {}).length;
  if (!R.sightCache || R.sightCache.k !== sk) R.sightCache = { k: sk, list: sightingsFor(me()) };
  for (const s of R.sightCache.list) {
    const t = tileAt(s.c, s.r),
      p = P(t.wx, t.wy, t.z + 0.1);
    if (!p) continue;
    const sc = clamp(p.s / 12, 0.5, 4),
      spr = s.type && SPR[s.type] ? SPR[s.type][s.pid] : null;
    ctx.globalAlpha = 0.35 + 0.35 * (s.conf || 1);
    if (spr) drawSprite(ctx, spr, p.x, p.y, sc, false);
    else drawText(ctx, '?', p.x, p.y - 4 * sc, ARMIES[s.pid].light);
    ctx.globalAlpha = 1;
    const age = B.turn - s.turn;
    R.labels.push({
      x: t.wx,
      y: t.wy,
      z: t.z,
      text: B.rules.intelFade ? `${Math.round(100 * (s.conf || 1))}%` : age ? `${age}t ago` : 'seen',
      color: '#cfe3ff',
    });
  }
  for (const d of B.decoys || []) {
    if (d.pid !== me() && !isAlly(me(), d.pid)) continue;
    const t = tileAt(d.c, d.r),
      p = P(t.wx + 0.3, t.wy + 0.25, t.z);
    if (!p) continue;
    ctx.globalAlpha = 0.4;
    drawSprite(ctx, SPR[d.mimic][d.pid], p.x, p.y, clamp(p.s / 14, 0.4, 3), false);
    ctx.globalAlpha = 1;
    R.labels.push({ x: t.wx + 0.3, y: t.wy + 0.25, z: t.z, text: `decoy ${DECOY_TURNS - (B.turn - d.turn0)}t`, color: '#cfe3ff' });
  }
}
// HUD chips for conditions and funds.
function phase7Chips(B) {
  let out = '';
  if (B.rules.weather && B.weather) {
    const w = WEATHER[B.weather.now],
      next = B.weather.forecast.map(f => WEATHER[f].icon).join(' ');
    out += `<span class="chip rules-chip" title="${escapeHtml(w.name)}${isNight(B.turn) ? ', night' : ', day'}: ${escapeHtml(w.desc)} Forecast: ${B.weather.forecast.map(f => WEATHER[f].name).join(', then ')}.">${isNight(B.turn) ? '🌙 Night' : '☀ Day'} · ${w.icon} ${w.name} → ${next}</span>`;
  }
  out += strategicChips(B);
  const season = seasonOf(B);
  if (season)
    out += `<span class="chip rules-chip" title="Season: ${season === 'Winter' ? 'snow slows ground units off-road; shallows are frozen' : season === 'Summer' ? 'good campaigning weather' : 'mud slows vehicles off-road'}">${season === 'Winter' ? '❄' : season === 'Summer' ? '☀' : '🌧'} ${season}</span>`;
  if (B.rules.vp && B.vp)
    out += `<span class="chip rules-chip" title="Victory points: the first team to ${vpTarget(B)} wins">★ ${B.vp[teamOf(me())] || 0} / ${vpTarget(B)}</span>`;
  if ((B.rules.income || B.rules.production) && B.funds)
    out += `<span class="chip rules-chip" title="Funds${B.rules.income ? ' and income per turn' : ''}">💰 ${B.funds[me()] || 0}${B.rules.income ? ` (+${incomeOf(B, me())}/turn)` : ''}</span>`;
  return out;
}
// Morale on unit cards (morale rule).
const moraleBadge = u => {
  const st = moraleState(u);
  return st
    ? `<span class="morale ${st.toLowerCase()}" title="Morale ${u.morale}">${st === 'Steady' ? '' : st + ' '}${u.morale}</span>`
    : '';
};

// Realism status on unit cards: dug in, suppressed, cut off.
function realismBadge(u) {
  const B = appState.battle,
    out = [];
  if (B.rules.entrench && u.dug) out.push(`<span class="real-badge" title="Dug in: ${u.dug * 10}% less damage taken">⛏${u.dug}</span>`);
  if (B.rules.suppression && u.supp)
    out.push('<span class="real-badge bad" title="Suppressed: can’t move, half damage this turn">Suppressed</span>');
  if (B.rules.command && UNIT_TYPES[u.type].domain === 'land' && outOfCommand(u))
    out.push(
      '<span class="real-badge bad" title="Out of command: more than 6 hexes from a command post (or jammed); moves 1 hex less">No command</span>'
    );
  if (B.rules.ew && jammed(u)) out.push('<span class="real-badge bad" title="Jammed by an enemy drone: sight −2">Jammed</span>');
  if (B.rules.ammo && usesAmmoTypes(UNIT_TYPES[u.type]) && u.pid === me()) {
    const a = (R.ammoPick && R.ammoPick[u.id]) || u.ammoType || 'he';
    out.push(
      `<span class="real-badge" title="Loaded: ${a === 'ap' ? 'armor-piercing' : 'high-explosive'} rounds">${a.toUpperCase()}</span>`
    );
  }
  if (B.rules.supplyLines && u.cut)
    out.push(
      `<span class="real-badge bad" title="Cut off from supply for ${u.cut} turn${u.cut === 1 ? '' : 's'}: no rearming or refueling">Cut off</span>`
    );
  return out.join('');
}

// Mines (rule): you see your own side's mines (a small ✕ in the army color); the enemy's stay hidden.
function drawOwnMines(P) {
  const B = appState.battle;
  if (!B.rules.mines || !B.mines || R.replay) return;
  const ctx = R.ctx;
  for (const [k, m] of Object.entries(B.mines)) {
    if (isEnemy(me(), m.pid)) continue;
    const [c, r] = unkey(k),
      t = tileAt(c, r),
      q = P(t.wx, t.wy, t.z + 0.05);
    if (!q) continue;
    const s = Math.max(2, q.s * 0.18);
    ctx.strokeStyle = ARMIES[m.pid].color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(q.x - s, q.y - s);
    ctx.lineTo(q.x + s, q.y + s);
    ctx.moveTo(q.x + s, q.y - s);
    ctx.lineTo(q.x - s, q.y + s);
    ctx.stroke();
  }
}
