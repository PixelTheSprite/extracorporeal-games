// ---------- HUD buttons ----------
// Save, Load and New open in-page dialogs (ui/saves.js); Exit leaves immediately, cancelling any turn still resolving.
$('#btn-save').addEventListener('click', () => openSaveDialog());
$('#btn-load').addEventListener('click', () => openLoadDialog());
$('#btn-new').addEventListener('click', () => openNewDialog());
$('#btn-diplo').addEventListener('click', () => openDiploDialog());
$('#btn-prod').addEventListener('click', () => openProductionDialog());
$('#btn-help').addEventListener('click', () => showHelp());
$('#btn-exit').addEventListener('click', () => {
  R.session++;
  R.tweens = [];
  R.fx = [];
  R.busy = false;
  R.ended = true;
  clearSelection();
  closeModal();
  $('#banner-host').innerHTML = '';
  SFX.play('click');
  // Back to where you came from: online matches to Multiplayer, replays to Replays.
  const from = R.mp ? 'multi' : R.replay ? 'replays' : 'select';
  leaveOnlineMatch();
  stopReplay();
  stopTutorial();
  appState.me = 0;
  R.seatQueue = null;
  $('#btn-done').hidden = false;
  go(from);
});

$('#btn-sound').addEventListener('click', () => {
  appState.prefs.sound = !appState.prefs.sound;
  SFX.init();
  $('#btn-sound').setAttribute('aria-pressed', appState.prefs.sound);
  savePrefs();
  SFX.play('click');
});

function savePrefs() {
  store.set(LS_PREFS, appState.prefs);
}

function loadPrefs() {
  const p = store.get(LS_PREFS, {});
  if (p && typeof p === 'object') Object.assign(appState.prefs, p);
  $('#btn-sound').setAttribute('aria-pressed', appState.prefs.sound);
}

$('#btn-launch').addEventListener('click', () => startStrikeMode());
