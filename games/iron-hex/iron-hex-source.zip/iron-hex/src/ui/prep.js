// ---------- Quick battle prepare ----------
// Maps on offer: generated presets, the real-world maps, and maps saved from the Map Editor.
function prepMaps() {
  const S = appState.settings;
  return [
    ...MAP_PRESETS.map(m => ({
      group: 'Generated',
      id: m.id,
      name: m.name,
      blurb: m.blurb + (m.id === 'random' ? ` Seed ${S.randomSeed}.` : ''),
      def: () => genMap(m.kind, m.seed ?? S.randomSeed, m.name),
    })),
    ...REAL_MAPS.map(m => ({
      group: 'Real world',
      id: m.id,
      name: m.name,
      blurb: `${m.blurb} ${m.W} × ${m.H} hexes, about ${m.km} km per hex. Sides: ${m.sides.map(s => s.name).join(', ')}. Terrain is approximate; starting positions are each side's own territory, not current front lines.`,
      def: () => m,
    })),
    ...loadMaps().map(m => ({
      group: 'Your maps',
      id: m.id,
      name: m.name,
      blurb: `Made in the Map Editor. ${m.W} × ${m.H} hexes, ${m.spawns.length} spawn points.`,
      def: () => m,
      custom: m,
    })),
  ];
}
function renderPrep() {
  const S = appState.settings;
  const maps = prepMaps(),
    cur = maps.find(m => m.id === S.mapId) || maps[0];
  if (cur.id !== S.mapId) S.mapId = cur.id;
  if (cur.custom) S.customMap = clone(cur.custom);
  const def = cur.def(),
    maxArmies = def.spawns.length;
  S.armies = Math.min(S.armies, maxArmies);
  if (def.sides && !(S.playSide < def.sides.length)) S.playSide = 0;
  const sideOrder = [...def.spawns.keys()];
  const ps = def.sides ? S.playSide || 0 : 0;
  if (ps) {
    sideOrder.splice(sideOrder.indexOf(ps), 1);
    sideOrder.unshift(ps);
  }
  $('#seg-armies').innerHTML = [2, 3, 4]
    .filter(n => n <= maxArmies)
    .map(
      n =>
        `<button class="btn alt" role="radio" aria-checked="${S.armies === n}" aria-pressed="${S.armies === n}" data-armies="${escapeHtml(n)}">${n} armies</button>`
    )
    .join('');
  S.hotseat = Math.min(S.hotseat || 1, S.armies);
  $('#hotseat-pick').innerHTML = Array.from(
    { length: S.armies },
    (_, i) =>
      `<option value="${i + 1}" ${S.hotseat === i + 1 ? 'selected' : ''}>${i === 0 ? '1 (you against the AI)' : i + 1 + ' people'}</option>`
  ).join('');
  syncTeams();
  const teamsOn = new Set(S.teams.slice(0, S.armies)).size < S.armies;
  let html = def.sides
    ? `<label class="field">You command <select id="play-side">${def.sides.map((s, i) => `<option value="${i}" ${i === ps ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}</select></label>`
    : '';
  for (let i = 0; i < S.armies; i++) {
    const a = ARMIES[i],
      side = def.sides ? def.sides[sideOrder[i]].name : a.name;
    html += `<div class="army-row"><span class="sw" style="background:${a.color}"></span><span class="nm">${escapeHtml(side)}${i === 0 ? ' — you' : ''}${teamsOn ? `<span class="team-tag">${TEAM_NAMES[S.teams[i]]}</span>` : ''}</span>`;
    if (i < (S.hotseat || 1))
      html += `<span class="strat-desc" style="grid-column:auto">${i === 0 ? 'Human commander' : 'Player ' + (i + 1) + ' (this device)'}</span>`;
    else {
      const st = S.strategies[i] || 'balanced';
      html += `<select data-strat="${escapeHtml(i)}" aria-label="AI strategy for ${escapeHtml(side)}">${Object.entries(STRATS)
        .map(([k, v]) => `<option value="${k}" ${k === st ? 'selected' : ''}>AI: ${v.label}</option>`)
        .join('')}</select>
      <span class="strat-desc">${STRATS[st].desc}</span>`;
    }
    html += `</div>`;
  }
  $('#roster').innerHTML = html;
  const sum = rulesSummary(S.rules);
  const vs = victorySummary(S.victory);
  $('#rules-summary').textContent =
    'Victory: ' +
    vs.charAt(0).toUpperCase() +
    vs.slice(1) +
    '. Roster: ' +
    rosterTotal(currentRoster()) +
    ' units per army. Rules: ' +
    sum +
    '.';
  let grp = '';
  $('#map-list').innerHTML = maps
    .map(m => {
      const head = m.group !== grp ? `<h3 class="rule-group">${m.group}</h3>` : '';
      grp = m.group;
      return (
        head +
        `<button class="map-card" role="radio" aria-checked="${S.mapId === m.id}" data-map="${escapeHtml(m.id)}">
    <canvas class="px" width="150" height="100" data-preview="${escapeHtml(m.id)}"></canvas>
    <span><b>${escapeHtml(m.name)}</b><small>${escapeHtml(m.blurb)}</small></span></button>`
      );
    })
    .join('');
  $$('[data-preview]').forEach(cv => {
    const m = maps.find(p => p.id === cv.dataset.preview),
      d = m.def();
    const spawns = m.id === S.mapId ? sideOrder.map(i => d.spawns[i]) : d.spawns;
    drawMapPreview(cv, Object.assign({}, d, { spawns }), m.id === S.mapId ? S.armies : d.spawns.length);
  });
  $('#btn-reroll').hidden = S.mapId !== 'random';
  // Infrastructure layouts saved for this map (and, for random maps, this seed)
  const fits = L => L.mapId === S.mapId && (S.mapId !== 'random' || L.seed === S.randomSeed);
  const lays = loadLayouts().filter(fits);
  if (S.layout && !fits(S.layout)) S.layout = null;
  $('#prep-layout').innerHTML =
    '<option value="">None</option>' +
    lays
      .map(
        L =>
          `<option value="${escapeHtml(L.id)}" ${S.layout && S.layout.id === L.id ? 'selected' : ''}>${escapeHtml(L.name)} (${L.structs.length})</option>`
      )
      .join('');
  $('#prep-layout-note').textContent = lays.length
    ? 'Structures from the Infrastructure editor are in place when the battle starts.'
    : 'No saved layouts for this map. Make one in the Infrastructure editor, or let engineers build during the battle.';
}

function drawMapPreview(cv, def, armies) {
  const x = cv.getContext('2d');
  x.imageSmoothingEnabled = false;
  x.fillStyle = '#10213d';
  x.fillRect(0, 0, cv.width, cv.height);
  const sz = Math.min(cv.width / (def.W * SQ3 + 1), cv.height / (def.H * 1.5 + 0.5));
  const ox = (cv.width - (def.W * SQ3 + SQ3 / 2) * sz) / 2 + (SQ3 / 2) * sz,
    oy = (cv.height - (def.H * 1.5 + 0.5) * sz) / 2 + sz;
  for (let r = 0; r < def.H; r++)
    for (let c = 0; c < def.W; c++) {
      const w = toWorld(c, r);
      x.fillStyle = TERRAIN[def.rows[r][c]].color;
      x.beginPath();
      HEX_CORNERS.forEach(([a, b], i) => {
        const px = ox + (w.x + a) * sz,
          py = oy + (w.y + b) * sz;
        i ? x.lineTo(px, py) : x.moveTo(px, py);
      });
      x.fill();
    }
  def.spawns.slice(0, armies).forEach((s, i) => {
    const w = toWorld(s.c, s.r);
    x.fillStyle = '#1b140e';
    x.fillRect(Math.round(ox + w.x * sz) - 4, Math.round(oy + w.y * sz) - 4, 9, 9);
    x.fillStyle = ARMIES[i].color;
    x.fillRect(Math.round(ox + w.x * sz) - 3, Math.round(oy + w.y * sz) - 3, 7, 7);
  });
}

$('#scr-prep').addEventListener('click', e => {
  const S = appState.settings;
  const a = e.target.closest('[data-armies]');
  if (a) {
    S.armies = +a.dataset.armies;
    SFX.play('click');
    renderPrep();
    return;
  }
  const m = e.target.closest('[data-map]');
  if (m) {
    S.mapId = m.dataset.map;
    S.playSide = 0;
    SFX.play('click');
    renderPrep();
  }
});

$('#prep-layout').addEventListener('change', e => {
  const L = loadLayouts().find(x => x.id === e.target.value);
  appState.settings.layout = L ? clone(L) : null;
});
$('#scr-prep').addEventListener('change', e => {
  if (e.target.id === 'play-side') {
    appState.settings.playSide = +e.target.value;
    renderPrep();
    $('#play-side').focus();
    return;
  }
  const s = e.target.closest('[data-strat]');
  if (s) {
    appState.settings.strategies[+s.dataset.strat] = s.value;
    renderPrep();
  }
});

$('#btn-reroll').addEventListener('click', () => {
  appState.settings.randomSeed = Math.floor(Math.random() * 1e6);
  SFX.play('click');
  renderPrep();
});

$('#btn-start-battle').addEventListener('click', () => {
  SFX.play('select');
  refreshUnlocks();
  newBattle();
  enterBattle();
});

$('#btn-prep-load').addEventListener('click', () => openLoadDialog());

$('#hotseat-pick').addEventListener('change', e => {
  appState.settings.hotseat = +e.target.value;
  renderPrep();
});
