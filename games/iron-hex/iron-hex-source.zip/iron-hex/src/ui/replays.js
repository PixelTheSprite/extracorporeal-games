// Replays: your recent battles (kept in this browser), replays other players posted (hosted game), files.
// A replay is { app:'iron-hex-replay', meta, start, log } (core/replay.js); watching replays it turn by turn.
const LS_REPLAYS = 'ironhex_replays',
  REPLAYS_KEPT = 5;
const localReplays = () => storedList(LS_REPLAYS);
function keepReplay(rep) {
  if (!rep) return;
  let list = [Object.assign({ id: 'r' + Date.now().toString(36) }, rep)].concat(localReplays()).slice(0, REPLAYS_KEPT);
  while (list.length && !store.set(LS_REPLAYS, list)) list = list.slice(0, -1); // drop the oldest if storage is full
}
const replayMeta = (B, out, win) => ({
  title: B.campaign ? B.campaign.title : B.mode === 'online' ? 'Online match' : B.mode === 'hotseat' ? 'Hot-seat battle' : 'Quick battle',
  mapName: B.mapDef.name,
  armies: B.players.map(p => p.name),
  turns: B.turn,
  at: new Date().toISOString(),
  result: win
    ? `${B.players
        .filter(p => teamOf(p.id) === teamOf(win.id))
        .map(p => p.name)
        .join(' + ')} won`
    : 'Draw',
});

// ---- shared replays (hosted game) ----
async function postReplay(rep) {
  const db = await sbInit(),
    uid = db && (await SB.user.id());
  if (!db || !uid) throw new Error('Sharing replays needs the hosted game.');
  const rid = 'r' + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);
  await putBig(db, `replays/${rid}/data/rep`, rep);
  await db.doc(`replays/${rid}`).set(Object.assign({}, rep.meta, { by: uid, at: Date.now() }));
  return rid;
}
async function sharedReplays() {
  const db = await sbInit();
  if (!db) return null;
  const q = await db.collection('replays').get();
  return q.docs
    .filter(d => d.exists)
    .map(d => Object.assign({ id: d.id }, d.data()))
    .sort((a, b) => b.at - a.at)
    .slice(0, 30);
}

// ---- the Replays screen ----
async function renderReplays() {
  const loc = localReplays();
  $('#rp-local').innerHTML = loc.length
    ? String(
        html`${loc.map(
          r =>
            html`<div class="layout-row">
              <span
                ><b>${r.meta.title}</b
                ><small>${r.meta.mapName} · ${r.meta.armies.join(' vs ')} · ${r.meta.turns} turns · ${r.meta.result || ''}</small></span
              >
              <span class="row-btns"
                ><button class="btn sm" data-rp-watch="${r.id}">Watch</button
                ><button class="btn sm alt" data-rp-export="${r.id}">Export</button
                ><button class="btn sm alt" data-rp-share="${r.id}">Share</button></span
              >
            </div>`
        )}`
      )
    : '<p class="src">Finish a battle and it appears here (the last 5 are kept).</p>';
  $('#rp-shared').innerHTML = '<p class="src">Loading…</p>';
  const shared = await sharedReplays().catch(() => null);
  if (!shared) {
    $('#rp-shared').innerHTML = '<p class="src">Shared replays are available in the hosted game.</p>';
    return;
  }
  let names = {};
  try {
    const user = await claude.use('user');
    if (user) names = await user.profiles([...new Set(shared.map(r => r.by))]);
  } catch (e) {}
  $('#rp-shared').innerHTML = shared.length
    ? String(
        html`${shared.map(
          r =>
            html`<div class="layout-row">
              <span
                ><b>${r.title}</b
                ><small
                  >${r.mapName} · ${(r.armies || []).join(' vs ')} · ${r.turns} turns · ${r.result || ''} · shared by
                  ${(names[r.by] && names[r.by].name) || 'someone'}</small
                ></span
              >
              <span class="row-btns"><button class="btn sm" data-rp-shared="${r.id}">Watch</button></span>
            </div>`
        )}`
      )
    : '<p class="src">No shared replays yet.</p>';
}
$('#scr-replays').addEventListener('click', async e => {
  const say = t => ($('#rp-status').textContent = t);
  const w = e.target.closest('[data-rp-watch]'),
    x = e.target.closest('[data-rp-export]'),
    s = e.target.closest('[data-rp-share]'),
    sh = e.target.closest('[data-rp-shared]');
  const find = id => localReplays().find(r => r.id === id);
  if (w) return startReplay(find(w.dataset.rpWatch));
  if (x) {
    const r = find(x.dataset.rpExport);
    return say(await ueDownload(`replay-${r.meta.mapName.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.json`, JSON.stringify(r)));
  }
  if (s) {
    say('Sharing…');
    try {
      await postReplay(find(s.dataset.rpShare));
      say('Shared: other players can watch it under Shared replays.');
      renderReplays();
    } catch (err) {
      say(err.message);
    }
    return;
  }
  if (sh) {
    say('Loading…');
    try {
      const db = await sbInit();
      const rep = await getBig(db, `replays/${sh.dataset.rpShared}/data/rep`);
      say('');
      startReplay(rep);
    } catch (err) {
      say('That replay could not be loaded.');
    }
  }
});
$('#rp-import').addEventListener('change', async e => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  const say = t => ($('#rp-status').textContent = t);
  if (tooBig(f)) return say('That file is too large to be a replay (over 5 MB).');
  try {
    const rep = JSON.parse(await f.text());
    if (rep.app !== 'iron-hex-replay' || !Array.isArray(rep.log)) throw 0;
    startReplay(rep);
  } catch (err) {
    say('That file isn’t an Iron Hex replay.');
  }
  e.target.value = '';
});

// ---- the viewer (the battle screen in replay mode) ----
function startReplay(rep) {
  if (!rep || !loadReplayStart(rep)) {
    $('#rp-status').textContent = 'That replay could not be loaded.';
    return;
  }
  appState.me = 0;
  R.replay = { rep, i: 0, playing: false };
  enterBattle('Replay: ' + (rep.meta.title || 'battle'));
  replayBar();
}
function stopReplay() {
  if (!R.replay) return;
  R.replay.playing = false;
  R.replay = null;
  $('#replay-bar').hidden = true;
}
function replayBar() {
  const rp = R.replay;
  if (!rp) return;
  $('#replay-bar').hidden = false;
  $('#rp-turn').textContent = `Turn ${Math.min(rp.i + 1, rp.rep.log.length)} of ${rp.rep.log.length}${rp.done ? ' · finished' : ''}`;
  $('#rp-play').textContent = rp.playing ? '⏸ Pause' : '▶ Play';
  $('#rp-play').disabled = !!rp.done;
  $('#rp-step').disabled = rp.playing || !!rp.done;
}
async function replayStep() {
  const rp = R.replay;
  if (!rp || R.busy || rp.done) return;
  R.busy = true;
  replayBar();
  const out = await replayTurn(rp.rep, rp.i);
  R.busy = false;
  if (R.replay !== rp) return;
  rp.i++;
  if (out.end || rp.i >= rp.rep.log.length) {
    rp.done = true;
    rp.playing = false;
    banner(out.end ? 'Battle over' : 'End of replay');
  } else $('#hud-turn').textContent = 'Turn ' + appState.battle.turn;
  renderHud();
  renderCards();
  replayBar();
}
async function replayPlay() {
  const rp = R.replay;
  if (!rp) return;
  rp.playing = !rp.playing;
  replayBar();
  while (rp.playing && R.replay === rp && !rp.done) await replayStep();
}
function replayRestart() {
  const rp = R.replay;
  if (!rp) return;
  rp.playing = false;
  rp.done = false;
  rp.i = 0;
  if (!loadReplayStart(rp.rep)) return;
  R.replay = rp;
  initUnitVisuals();
  renderHud();
  renderCards();
  replayBar();
}
$('#rp-play').addEventListener('click', () => replayPlay());
$('#rp-step').addEventListener('click', () => replayStep());
$('#rp-restart').addEventListener('click', () => replayRestart());
