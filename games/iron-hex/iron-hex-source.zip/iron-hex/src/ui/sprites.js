// ---------- Sprites (pixel art as strings) ----------
const SPRITE_ART = {
  arty: [
    '..............k.',
    '............kkwk',
    '..........kkwwk.',
    '....kkkkkkwwkk..',
    '...kddddwwkk....',
    '..kkdddddkkkk...',
    '.klldddddllllk..',
    'ktttttttttttttk.',
    'ktttttttttttttk.',
    'ktttttttttttttk.',
    'kwwwwwwwwwwwwwk.',
    'kwgwgwgwgwgwgwk.',
    '.kkkkkkkkkkkkk..',
  ],
  sub: [
    '..........k...........',
    '.........kwk..........',
    '.........kwk..........',
    '........klwk..........',
    '.......kttttk.........',
    '.......kttttk.........',
    '..kkkkkkttttkkkkkkk...',
    '.ktttttttttttttttttkk.',
    'kddddddddddddddddddddk',
    'ddddddddddddddddddddk.',
    'kkkkkkkkkkkkkkkkkkkk..',
  ],
  carrier: [
    '...............kwk.....',
    '...............kwk.....',
    '...............kwk.....',
    '..............ktttk....',
    '......k.......ktttk....',
    '....kklkk.....ktttk....',
    '.kkklllllkkkkkktttkkkk.',
    'kgggggggggggggggggggggk',
    'ddddddddddddddddddddddk',
    'ddddddddddddddddddddddk',
    'kkttttttttttttttttttkk.',
    '..kkkkkkkkkkkkkkkkkk...',
  ],

  tank: [
    '......kkkkk.....',
    '.....kttlttk....',
    '.....ktttttkkkkk',
    '.....kddddkggggk',
    '..kkkkkkkkkkkkk.',
    '.kttttttttttttk.',
    'kddddddddddddddk',
    'kwwwwwwwwwwwwwwk',
    'kwgwgwgwgwgwgwwk',
    '.kwwwwwwwwwwwwk.',
    '..kkkkkkkkkkkk..',
  ],
  plane: [
    '.kk.............',
    '.ktk............',
    '.kttkkkkkkkkk...',
    'kttttttttllltkk.',
    'kddddddddddddtkk',
    '.kkkkddddddkkk.k',
    '......kttttk....',
    '.......kkkk.....',
  ],
  inf: [
    '....kkkk....',
    '...kddddk...',
    '...kssssk...',
    '....kssk....',
    '...kttttkkkk',
    '..kttlttgggk',
    '..kttttkkkk.',
    '...kttttk...',
    '...kddddk...',
    '...kdk.kdk..',
    '..kddk.kddk.',
    '..kkk..kkk..',
  ],
  eng: [
    '......kkk.......',
    '.....kdddk......',
    '.....ksssk......',
    '......kssk..kk..',
    '....kttttkkkk...',
    '...kttlttgk.....',
    '..kkkttttkkkkk..',
    '.kwwk.kddk.kwwk.',
    'kwggwkkkkkkwggwk',
    'kwggwk....kwggwk',
    '.kwwk......kwwk.',
  ],
  aa: [
    '..........k..k..',
    '.........k..k...',
    '........k..k....',
    '......kkkkk.....',
    '.....kttltk.....',
    '..kkkkkkkkkkkkk.',
    '.kttttttttttttk.',
    'kddddddddddddddk',
    'kwgwgwgwgwgwgwwk',
    '.kwwwwwwwwwwwwk.',
    '..kkkkkkkkkkkk..',
  ],
  apc: [
    '....kkkkkkkkk...',
    '...kttttttttk...',
    '.kkktlttttttk...',
    'kttttttttttttk..',
    'kddddddddddddddk',
    '.kwwk..kwgwgwgk.',
    'kwggwk.kgwgwgwgk',
    '.kwwk...kkkkkkk.',
  ],
  at: [
    '....kkkk....',
    '...kddddk...',
    'kggggggggggk',
    '....kssk....',
    '...kttttk...',
    '..kttlttk...',
    '..kttttk....',
    '...kttttk...',
    '...kddddk...',
    '...kdk.kdk..',
    '..kddk.kddk.',
    '..kkk..kkk..',
  ],
  bomber: [
    '.kk.................',
    '.ktk................',
    '.kttkkkkkkkkkkkkk...',
    'kttttttttttttllltkk.',
    'kddddddddddddddddtkk',
    '.kkkkkddddddddkkkk.k',
    '......kttttttk......',
    '.......kkkkkk.......',
  ],
  drone: [
    '.k..............',
    'kkk..........kk.',
    '.kttttttttttttlk',
    'gkddddddddddddk.',
    '.k....kkkkk.....',
    '.....kttttttk...',
    '......kkkkkk....',
  ],
  battleship: [
    '...........k............',
    '..........kgk...........',
    '.......kkkkgkkkk........',
    '.kkkkk.kgggggggk.kkkkk..',
    '..kggk.kgglggggk.kggk...',
    'kkkkkkkkkkkkkkkkkkkkkkkk',
    'kttttttttttttttttttttttk',
    '.kddddddddddddddddddddk.',
    '..kddddddddddddddddddk..',
    '...kkkkkkkkkkkkkkkkkk...',
  ],
  lst: [
    '..k...................',
    '..k...................',
    '.kkkk.................',
    '.kgggk................',
    '.kglgk................',
    'kkkkkkkkkkkkkkkkkkkkk.',
    'kttttttttttttttttttttk',
    '.kddddddddddddddddddk.',
    '..kkkkkkkkkkkkkkkkkk..',
  ],
  ship: [
    '........k...........',
    '........k....k......',
    '.......kkk...k......',
    '......kgggkkkkk.....',
    '....kkgglggggk.kkkk.',
    'kkkkkkkkkkkkkkkkkkkk',
    'kttttttttttttttttttk',
    '.kddddddddddddddddk.',
    '..kkkkkkkkkkkkkkkk..',
  ],
};

const DECOR_ART = {
  tree: {
    pal: { k: '#1b2a14', f: '#3f8a2e', F: '#6cc04a', b: '#6b4a2a' },
    rows: ['...k...', '..kfk..', '.kfFfk.', '.kfffk.', 'kfFfffk', 'kfffFfk', '.kkkkk.', '...b...', '...b...'],
  },
  peak: {
    pal: { k: '#2a221c', W: '#f4f4f4', g: '#9a8c7c', d: '#6a5e52' },
    rows: ['......k......', '.....kWk.....', '....kWWgk....', '...kWgggdk...', '..kggggddgk..', '.kgggddgggdk.', 'kggddgggddggk'],
  },
  hill: { pal: { k: '#4a3a1c', h: '#9a8448', H: '#c8b070' }, rows: ['...kkkkk...', '..khhhhhk..', '.khhHhhhhk.', 'khhhhhHhhhk'] },
  city: {
    pal: { k: '#3a3028', w: '#d8cdb8', y: '#f5c518' },
    rows: [
      '..kkk.......',
      '..kwk.kkkk..',
      'kkkwk.kwwk..',
      'kwkkkkkwwkkk',
      'kwkwykwkkkwk',
      'kwkwwkwkykwk',
      'kwkwykwkwkwk',
      'kwkwwkwkwkwk',
      'kkkkkkkkkkkk',
    ],
  },
};

function makeSprite(rows, pal, solid) {
  const h = rows.length,
    w = rows[0].length;
  const mk = flip => {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const x = c.getContext('2d');
    rows.forEach((row, j) =>
      [...row].forEach((ch, i) => {
        if (ch === '.' || !pal[ch]) return;
        x.fillStyle = solid || pal[ch];
        x.fillRect(flip ? w - 1 - i : i, j, 1, 1);
      })
    );
    return c;
  };
  return { n: mk(false), f: mk(true), w, h };
}

const SPR = {},
  SPR_WHITE = {},
  DECOR = {};
let FLAG_SPR = [];

function buildSprites() {
  for (const type in SPRITE_ART) buildUnitSprite(type);
  for (const k in DECOR_ART) DECOR[k] = makeSprite(DECOR_ART[k].rows, DECOR_ART[k].pal);
  STRUCT_SPR = {};
  for (const k in STRUCT_ART) STRUCT_SPR[k] = makeSprite(STRUCT_ART[k].rows, STRUCT_ART[k].pal);
  FLAG_SPR = ARMIES.map(a =>
    makeSprite(['kk....', 'kttttk', 'ktlttk', 'kttttk', 'kkkkk.', 'k.....', 'k.....', 'k.....', 'kk....'], {
      k: '#1b140e',
      t: a.color,
      l: a.light,
    })
  );
}

function drawSprite(ctx, spr, x, yBottom, scale, flip) {
  const w = Math.max(1, Math.round(spr.w * scale)),
    h = Math.max(1, Math.round(spr.h * scale));
  ctx.drawImage(flip ? spr.f : spr.n, Math.round(x - w / 2), Math.round(yBottom - h), w, h);
  return { x0: Math.round(x - w / 2), y0: Math.round(yBottom - h), x1: Math.round(x + w / 2), y1: Math.round(yBottom) };
}

// Infrastructure sprites (drawn on the hex, with the owner's flag beside capturable ones)
let STRUCT_SPR = {};
const STRUCT_ART = {
  airfield: {
    pal: { k: '#1b140e', g: '#8b97a3', w: '#5a5a5a', y: '#f5c518' },
    rows: [
      '..kk..........',
      '..kgk.........',
      '..kgk.........',
      'kkkkkkkkkkkkkk',
      'kwwwwwwwwwwwwk',
      'kwyywwyywwyywk',
      'kwwwwwwwwwwwwk',
      'kkkkkkkkkkkkkk',
    ],
  },
  port: {
    pal: { k: '#1b140e', g: '#8b97a3', b: '#8a5a2a' },
    rows: [
      '...kkkkkkkk...',
      '...kg.....k...',
      '...kg.....k...',
      '...kg....kgk..',
      '..kkkk...kk...',
      'kkkkkkkkkkkkkk',
      'kbbbbbbbbbbbbk',
      '.k.k.k.k.k.k.k',
    ],
  },
  bridge: {
    pal: { k: '#1b140e', b: '#8a5a2a' },
    rows: ['k............k', 'kkkkkkkkkkkkkk', 'kbbbbbbbbbbbbk', 'kkkkkkkkkkkkkk', '.k...k..k...k.', '.k...k..k...k.'],
  },
  depot: {
    pal: { k: '#1b140e', b: '#a07040', y: '#f5c518' },
    rows: ['...kkkk.....', '...kyyk.....', 'kkkkkkkkkkk.', 'kbbbkbbbkbbk', 'kbybkbybkbyk', 'kbbbkbbbkbbk', 'kkkkkkkkkkkk'],
  },
  fort: {
    pal: { k: '#1b140e', g: '#8b8b80', s: '#c8b070' },
    rows: ['...kkkkkk...', '..kggggggk..', '.kgkkkkkkgk.', 'kssssssssssk', 'kssksskssksk', 'kssssssssssk', 'kkkkkkkkkkkk'],
  },
  silo: {
    // a concrete pad with an open hatch and a missile nose showing
    pal: { k: '#1b140e', g: '#9aa0a6', d: '#5f6670', r: '#d0402a', w: '#e8e8e8' },
    rows: [
      '.....kk.....',
      '....krrk....',
      '....kwwk....',
      '....kwwk....',
      '..kkkwwkkk..',
      '.kgggkkgggk.',
      'kgdddddddgk.',
      'kgggggggggk.',
      'kkkkkkkkkkk.',
    ],
  },
  scaffold: {
    pal: { k: '#1b140e', y: '#e8c47a' },
    rows: ['kykykykykyk', 'kkkkkkkkkkk', 'k.y.k.y.k.k', 'k..yk..yk.k', 'k.y.k.y.k.k', 'kkkkkkkkkkk'],
  },
};
