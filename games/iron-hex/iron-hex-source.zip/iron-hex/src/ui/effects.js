// ---------- Resolution (all orders at once) ----------
function tween(dur, fn) {
  return new Promise(res => R.tweens.push({ t0: performance.now(), dur, fn, res }));
}

function runTweens(now) {
  for (let i = R.tweens.length - 1; i >= 0; i--) {
    const tw = R.tweens[i],
      p = clamp((now - tw.t0) / tw.dur, 0, 1);
    tw.fn(p);
    if (p >= 1) {
      R.tweens.splice(i, 1);
      tw.res();
    }
  }
}

const fxAdd = e => {
  if (reducedMotion() && !e.text) return; // reduced motion: keep text, skip particles
  e.t0 = performance.now();
  R.fx.push(e);
  return e;
};

const fxText = (u, text, color) => fxAdd({ k: 'text', x: u.px, y: u.py, z: u.pz + (isAir(u) ? 1.2 : 0), text, color, dur: 1100 });

function fxBoom(x, y, z, size) {
  const parts = Array.from({ length: 6 + size * 5 }, () => ({ vx: (Math.random() - 0.5) * 2, vy: -Math.random() * 2 - 0.3 }));
  fxAdd({ k: 'boom', x, y, z, size, parts, dur: 500 + size * 250 });
}

async function animateShot(sh) {
  await sleep(Math.random() * 180);
  const a = sh.u,
    t = sh.t,
    dom = UNIT_TYPES[a.type].domain;
  a.fx = t.px - a.px;
  a.fy = t.py - a.py;
  const az = a.pz + (isAir(a) ? 1.2 : 0.3),
    tz = t.pz + (isAir(t) ? 1.2 : 0.3);
  addFx({ k: 'flash', x: a.px, y: a.py, z: az, dur: 120 });
  SFX.play(dom === 'air' ? 'mg' : 'shot');
  const dur = dom === 'sea' ? 750 : dom === 'air' ? 260 : 340;
  const n = dom === 'air' ? 4 : 1;
  const bx = t.px,
    by = t.py;
  for (let i = 0; i < n; i++) {
    setTimeout(
      () =>
        addFx({
          k: 'proj',
          ax: a.px,
          ay: a.py,
          az,
          bx: bx + (sh.hit ? 0 : (Math.random() - 0.5) * 1.4),
          by: by + (sh.hit ? 0 : (Math.random() - 0.5) * 1.4),
          bz: tz,
          arc: dom === 'sea' ? 1.8 : 0.15,
          style: dom,
          dur,
        }),
      i * 60
    );
  }
  await sleep(dur + (n - 1) * 60);
  if (sh.hit) {
    t.dispHp = Math.max(0, (t.dispHp ?? t.hp) - sh.dmg);
    t.hitT = performance.now();
    boom(t.px, t.py, tz, 1);
    floatText(t, '-' + sh.dmg, '#ffe04a');
    SFX.play('boom');
    R.shake = Math.max(R.shake, 3);
    if (t.dispHp <= 0 && !t.gone) {
      t.gone = true;
      t.goneTurn = appState.battle.turn;
      boom(t.px, t.py, tz - 0.1, 3);
      floatText(t, t.cargo ? 'Sunk with cargo' : 'Destroyed', '#ff6a4a');
      R.shake = 10;
      SFX.play('bigboom');
    }
  } else {
    addFx({ k: 'dust', x: t.px + 0.5, y: t.py + 0.3, z: t.pz, dur: 600 });
    floatText(t, 'Miss', '#cfe3ff');
  }
  renderCards();
}

$('#btn-done').addEventListener('click', () => {
  if (!$('#btn-done').disabled) onDone();
});

function endBattle(remaining, reason = 'destruction', out = {}) {
  const B = appState.battle,
    V = victory();
  R.ended = true;
  store.remove(LS_AUTO);
  const win = out.winner !== undefined ? out.winner : pickWinner(remaining);
  const how = !win
    ? 'No army survived.'
    : reason === 'territory'
      ? `${escapeHtml(win.name)} held ${Math.round(territoryShare(B, win.id) * 100)}% of the map for ${V.hold} turn${V.hold > 1 ? 's' : ''}.`
      : reason === 'timeout'
        ? `${escapeHtml(win.name)} ${V.mode === 'territory' ? 'held the most territory' : 'held the field'} when the ${turnLimit(B.mapDef)}-turn limit hit.`
        : reason === 'points'
          ? `${escapeHtml(win.name)} reached ${vpTarget(B)} victory points.`
          : reason === 'objective' || reason === 'objective-failed'
            ? escapeHtml(out.detail || '')
            : `${escapeHtml(win.name)} is the last army standing.`;
  const youWin = win && teamOf(win.id) === teamOf(me());
  const mode = battleMode(B),
    winners = win
      ? B.players
          .filter(p => teamOf(p.id) === teamOf(win.id))
          .map(p => p.name)
          .join(' + ')
      : '';
  const title = !win
    ? 'Draw'
    : mode === 'hotseat'
      ? `${winners} win${winners.includes(' + ') ? '' : 's'}!`
      : youWin
        ? 'Mission complete!'
        : 'Mission failed';
  // Hot-seat battles aren't anyone's personal record; online and single-player record your own army's result.
  const { lines, camp } =
    mode === 'hotseat' || B.tutorial ? { lines: [], camp: null } : recordBattle(B, Object.assign({ remaining, reason }, out), win);
  const rep = mode === 'online' ? null : replayOf(B, replayMeta(B, out, win));
  if (rep) keepReplay(rep);
  recordTelemetry(B, win).catch(() => {}); // only with “Share balance data” on
  musicJingle(mode === 'hotseat' ? true : !!youWin);
  const campHtml = camp
    ? (youWin
        ? [
            ...camp.promotions.map(x => escapeHtml(x) + '.'),
            camp.fallen.length ? `Lost for good: ${escapeHtml(camp.fallen.join(', '))}.` : '',
            camp.replaced.length ? `Replacements join: ${escapeHtml(camp.replaced.join(', '))}.` : '',
            camp.state.done
              ? `<b>${escapeHtml(campaignById(camp.state.id).name)} is complete!</b>`
              : `Next mission: <b>${escapeHtml(campaignById(camp.state.id).missions[camp.state.mission].title)}</b>.`,
          ]
        : ['Your task force is restored to how it was before the mission. Try again, or change your approach.']
      ).filter(Boolean)
    : [];
  if (youWin) SFX.play('fanfare');
  const rows = B.players
    .map(p => {
      const left = allAlive().filter(u => u.pid === p.id).length,
        total = B.units.filter(u => u.pid === p.id).length;
      return `<tr><td><span class="chip" style="border:0;background:none;padding:0"><i style="background:${ARMIES[p.id].color}"></i>${escapeHtml(p.name)}</span></td><td>${p.ai ? 'AI ' + STRATS[p.ai].label : 'You'}</td><td>${left} of ${total}</td><td>${Math.round(territoryShare(B, p.id) * 100)}%</td></tr>`;
    })
    .join('');
  showDialog(`<div class="panel" role="dialog" aria-modal="true" aria-labelledby="end-title">
    <h2 class="end-title ${youWin || !win ? '' : 'fail'}" id="end-title">${title}</h2>
    <p style="text-align:center">${how} Battle lasted ${B.turn} turns.</p>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Army</th><th>Commander</th><th>Units left</th><th>Territory</th></tr></thead><tbody>${rows}</tbody></table></div>
    ${
      campHtml.length || lines.length
        ? `<ul class="uc-list end-notes">${campHtml
            .concat(lines)
            .map(l => `<li>${l}</li>`)
            .join('')}</ul>`
        : ''
    }
    <p class="status" id="end-share"></p>
    <div class="row-end"><button class="btn alt" id="end-hq">Command HQ</button>${camp ? `<button class="btn" id="end-camp">${youWin ? (camp.state.done ? 'Campaign summary' : 'Continue campaign') : 'Retry mission'}</button>` : mode === 'online' ? '' : '<button class="btn" id="end-again">Rematch</button>'}</div>
    <div class="row-end"><button class="btn sm alt" id="end-watch">Watch replay</button><button class="btn sm alt" id="end-share-rp">Share replay</button></div></div>`);
  $('#end-hq').onclick = () => {
    const back = R.mp ? 'multi' : 'select';
    leaveOnlineMatch();
    go(back);
  };
  // Replays: this battle's (online, the match's, from the shared database).
  const getRep = async () => (rep ? rep : R.mp ? matchReplay(R.mp.db, R.mp.mid) : null);
  $('#end-watch').onclick = async () => {
    const r = await getRep();
    if (!r) return;
    closeModal();
    leaveOnlineMatch();
    startReplay(r);
  };
  sbInit().then(db => {
    if (!db && $('#end-share-rp')) $('#end-share-rp').hidden = true;
  });
  $('#end-share-rp').onclick = async () => {
    $('#end-share').textContent = 'Sharing…';
    try {
      await postReplay(await getRep());
      $('#end-share').textContent = 'Replay shared: anyone with this game can watch it under Replays.';
      $('#end-share-rp').disabled = true;
    } catch (e) {
      $('#end-share').textContent = (e && e.message) || 'Couldn’t share the replay.';
    }
  };
  if ($('#end-again')) {
    $('#end-again').onclick = () => {
      closeModal();
      refreshUnlocks();
      newBattle();
      enterBattle();
    };
    $('#end-again').focus();
  }
  if ($('#end-camp')) {
    $('#end-camp').onclick = () => {
      closeModal();
      if (youWin) go('campaign');
      else startMission();
    };
    $('#end-camp').focus();
  }
  renderHud();
  updateDone();
  $('#hint').textContent = '';
}

// ---- Browser view: real animation, sound and DOM updates for the game logic's VIEW hooks ----
const BrowserView = {
  // Waits started during a battle never resume once that battle is left (R.session changes),
  // so an in-progress turn can't touch the next battle.
  sleep: ms => {
    const s = R.session;
    return new Promise(r =>
      setTimeout(() => {
        if (R.session === s) r();
      }, ms)
    );
  },
  tween: (dur, fn) => tween(dur, fn),
  text: (u, text, color) => fxText(u, text, color),
  fx: e => fxAdd(e),
  boom: (x, y, z, size) => fxBoom(x, y, z, size),
  sfx: name => SFX.play(name),
  banner: text => banner(text),
  cards: () => renderCards(),
  hud: () => renderHud(),
  shake: n => {
    R.shake = Math.max(R.shake, n);
  },
  shot: sh => animateShot(sh),
  missile: async (from, to) => {
    // a missile arcs from the silo to its target, then a large blast
    banner('Missile!');
    SFX.play('fire');
    const a = tileAt(from.c, from.r),
      b = tileAt(to.c, to.r),
      dummy = { type: 'inf', px: a.wx, py: a.wy, pz: a.z + 0.5 };
    await VIEW.tween(700, f => {
      dummy.px = a.wx + (b.wx - a.wx) * f;
      dummy.py = a.wy + (b.wy - a.wy) * f;
      dummy.pz = a.z + 0.5 + Math.sin(f * Math.PI) * 6;
      if (!reducedMotion()) fxAdd({ kind: 'spark', x: dummy.px, y: dummy.py, z: dummy.pz, life: 250 });
    });
    if (!reducedMotion()) for (let i = 0; i < 3; i++) fxAdd({ kind: 'boom', x: b.wx + (i - 1) * 0.3, y: b.wy, z: b.z, life: 600 });
    SFX.play('boom');
  },
  sshot: sh => {
    R.worldVer = (R.worldVer || 0) + 1; // structure damage shows on the cached terrain
    return animateStructShot(sh);
  },
};
// The Done button: lock input, play the turn through simulateTurn, then end the battle or start the next turn.
async function resolveTurn() {
  const B = appState.battle;
  if (R.planning) {
    setTimeout(() => {
      if (appState.battle === B) resolveTurn();
    }, 100);
    return;
  } // wait for the AI to finish planning
  if (R.busy) return;
  setMusicIntensity(1); // the battle theme heats up while the turn plays out
  R.busy = true;
  clearSelection();
  R.busy = true;
  updateDone();
  updateHint();
  renderHud();
  const orders = Object.assign({}, B.orders, R.aiOrders);
  banner('Engage!');
  SFX.play('fanfare');
  await sleep(900);
  const out = await simulateTurn(orders);
  R.busy = false;
  if (out.end) {
    endBattle(out.remaining, out.reason, out);
    return;
  }
  beginTurn();
  setTimeout(() => {
    if (appState.battle === B && !R.ended) fallbackSave(snapshot(), LS_AUTO);
  }, 50); // autosave after the turn appears
}

// A shot at a structure: projectile to the hex, explosion, damage number; a bigger blast if it is destroyed.
async function animateStructShot(sh) {
  await sleep(Math.random() * 180);
  const a = sh.u,
    t = tileAt(sh.at.c, sh.at.r),
    dom = UNIT_TYPES[a.type].domain;
  a.fx = t.wx - a.px;
  a.fy = t.wy - a.py;
  const az = a.pz + (isAir(a) ? 1.2 : 0.3),
    tz = t.z + 0.3;
  fxAdd({ k: 'flash', x: a.px, y: a.py, z: az, dur: 120 });
  SFX.play(dom === 'air' ? 'mg' : 'shot');
  const dur = dom === 'sea' ? 750 : dom === 'air' ? 260 : 340;
  fxAdd({ k: 'proj', ax: a.px, ay: a.py, az, bx: t.wx, by: t.wy, bz: tz, arc: dom === 'sea' ? 1.8 : 0.15, style: dom, dur });
  await sleep(dur);
  fxBoom(t.wx, t.wy, tz, sh.destroyed ? 3 : 1);
  SFX.play(sh.destroyed ? 'bigboom' : 'boom');
  fxAdd({
    k: 'text',
    x: t.wx,
    y: t.wy,
    z: tz,
    text: sh.destroyed ? STRUCTS[sh.s.kind].name + ' destroyed' : '-' + sh.dmg,
    color: sh.destroyed ? '#ff6a4a' : '#ffe04a',
    dur: 1100,
  });
  if (sh.destroyed) R.shake = Math.max(R.shake, 8);
  for (const u of sh.drowned || []) {
    u.dispHp = 0;
    u.gone = true;
    u.goneTurn = appState.battle.turn;
    fxText(u, 'Fell in', '#ff6a4a');
  }
  renderCards();
}
