// Phase 12 interface: launching missiles (targeting mode), enemy-missile warnings, and city investment.
// Launches and investments are army actions in the orders: 'strike:<silo>' and 'invest:<city>'.
const readySilos = () => {
  const B = appState.battle;
  return B && B.rules.missiles ? ownSilos(B, me()).filter(s => siloReady(B, s)) : [];
};
function updateLaunchButton() {
  const b = $('#btn-launch');
  if (!b) return;
  const n = readySilos().length;
  b.hidden = !n || !!R.replay;
  b.textContent = `🚀 Launch${n > 1 ? ` (${n})` : ''}`;
}
// Enter targeting mode for the next ready silo without a launch order (or cycle through them).
function startStrikeMode() {
  const B = appState.battle,
    silos = readySilos();
  if (!silos.length || R.busy) return;
  const next = silos.find(s => !B.orders['strike:' + s.k]) || silos[0];
  clearSelection();
  R.mode = 'strike';
  R.strikeSilo = next.k;
  $('#hint').textContent =
    'Missile: tap a hex your side can see within the orange range (it hits that hex hard and the six around it). Esc to cancel.';
  announce('Missile targeting. Choose a hex within range that your side can see.');
}
// A tap in targeting mode: order the strike if the hex is valid.
function strikeTap(t) {
  const B = appState.battle,
    k = R.strikeSilo;
  if (!t || !strikeTargetOk(B, me(), k, t)) {
    $('#hint').textContent = 'That hex is out of range or out of sight. Pick another, or Esc to cancel.';
    return;
  }
  B.orders['strike:' + k] = { type: 'strike', target: { c: t.c, r: t.r } };
  SFX.play('order');
  R.mode = 'idle';
  R.strikeSilo = null;
  updateHint();
  renderHud();
  announce(`Missile launch ordered at column ${t.c + 1}, row ${t.r + 1}.`);
}
// Range and target overlay for targeting mode, plus markers for ordered launches.
function strikeOverlay(o) {
  const B = appState.battle;
  if (R.mode === 'strike' && R.strikeSilo) {
    const sh = keyHex(R.strikeSilo);
    for (let r = sh.r - REAL.MISSILE_RANGE; r <= sh.r + REAL.MISSILE_RANGE; r++)
      for (let c = sh.c - REAL.MISSILE_RANGE - 1; c <= sh.c + REAL.MISSILE_RANGE + 1; c++)
        if (r >= 0 && c >= 0 && r < B.mapDef.H && c < B.mapDef.W && strikeTargetOk(B, me(), R.strikeSilo, { c, r }))
          o.set(key(c, r), 'rgba(255,150,40,.22)');
  }
  for (const [k, ord] of Object.entries(B.orders || {}))
    if (k.startsWith('strike:') && ord.target) o.set(key(ord.target.c, ord.target.r), 'rgba(255,60,30,.55)');
}
function strategicChips(B) {
  let out = '';
  if (B.rules.missiles) {
    const enemyReady = Object.entries(B.structs || {}).some(
      ([k, s]) =>
        s.kind === 'silo' &&
        s.owner != null &&
        isEnemy(me(), s.owner) &&
        siloReady(B, Object.assign({ k }, s)) &&
        (!fogOn() || (B.vis && B.vis[teamOf(me())] && B.vis[teamOf(me())].has(k)))
    );
    if (enemyReady)
      out += '<span class="chip rules-chip warn-chip" title="An enemy silo you can see has a missile ready">⚠ Enemy missile ready</span>';
    const ordered = Object.keys(B.orders || {}).filter(k => k.startsWith('strike:')).length;
    if (ordered) out += `<span class="chip rules-chip">🚀 ${ordered} launch${ordered > 1 ? 'es' : ''} ordered</span>`;
  }
  return out;
}
// Labels on the map: silo charge, city levels (collected while the terrain is drawn).
function strategicLabels(t, B) {
  const k = key(t.c, t.r),
    s = B.structs && B.structs[k],
    c = B.cities && B.cities[k];
  if (B.rules.missiles && s && s.kind === 'silo' && !s.build && s.owner != null && (s.owner === me() || isAlly(me(), s.owner))) {
    const need = chargeNeeded(B, s.owner, t);
    R.labels.push({ x: t.wx, y: t.wy, z: t.z, text: (s.charge || 0) >= need ? 'READY' : `${s.charge || 0}/${need}`, color: '#ffb03a' });
  }
  if (B.rules.cityDev && c && cityLevel(c) > 1)
    R.labels.push({ x: t.wx + 0.3, y: t.wy, z: t.z, text: '★'.repeat(cityLevel(c) - 1), color: '#ffd84a' });
}
// The Invest section of the Build dialog.
function investSectionHtml(B) {
  if (!B.rules.cityDev) return '';
  if (!B.rules.income) return '<p class="src">City development needs Income on.</p>';
  const cities = Object.entries(B.cities).filter(([, c]) => c.owner === me());
  return String(
    html`<h3 class="rule-group">Invest in your cities</h3>
      ${cities.map(([k, c]) => {
        const lvl = cityLevel(c),
          h = keyHex(k),
          ordered = !!(B.orders || {})['invest:' + k];
        const status = c.investing
          ? `growing to level ${c.investing.to}, ${c.investing.turns} turn${c.investing.turns === 1 ? '' : 's'} left`
          : lvl >= 3
            ? 'fully developed'
            : `next level costs ${REAL.CITY_LEVEL_COST[lvl + 1]}`;
        return html`<div class="layout-row">
          <span><b>City ${h.c + 1},${h.r + 1} · level ${lvl}</b><small>${status}${ordered ? ' · investment ordered' : ''}</small></span
          ><span class="row-btns"
            ><button class="btn sm" data-invest="${k}" ${!ordered && investOk(B, me(), k) ? '' : 'disabled'}>Invest</button></span
          >
        </div>`;
      })}`
  );
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-invest]');
  if (!b) return;
  const B = appState.battle;
  B.orders['invest:' + b.dataset.invest] = { type: 'invest' };
  SFX.play('order');
  renderHud();
  openProductionDialog();
});
