// Music: chiptune generated live with WebAudio (no audio files). A look-ahead scheduler queues 16th-note steps a
// little ahead of time. Each scene has a key, a chord progression and a tempo; melodies are short motifs
// repeated with variations; bass, arpeggio and drums follow the chords. In battle, intensity rises while a turn
// resolves. Music uses Math.random (never the battle's seeded generator), so it can't affect gameplay.
const MUSIC = {
  scene: null,
  intensity: 0.3,
  gain: null,
  timer: null,
  step: 0,
  next: 0,
  bar: 0,
  motif: null,
  jingle: null,
  SCENES: {
    menu: { root: 60, scale: [0, 2, 4, 5, 7, 9, 11], prog: [0, 4, 5, 3], bpm: 100 }, // C major: I V vi IV
    battle: { root: 57, scale: [0, 2, 3, 5, 7, 8, 10], prog: [0, 5, 2, 6], bpm: 112 }, // A minor: i VI III VII
  },
};
const musicOn = () => appState.prefs.sound !== false && appState.prefs.music !== false;
const midiHz = m => 440 * Math.pow(2, (m - 69) / 12);

function musicStart() {
  if (!SFX.ctx || MUSIC.timer) return;
  const c = SFX.ctx;
  MUSIC.gain = c.createGain();
  MUSIC.gain.gain.value = 0;
  MUSIC.gain.connect(c.destination);
  MUSIC.next = c.currentTime + 0.1;
  MUSIC.timer = setInterval(musicTick, 25);
}
function musicPrefChanged() {
  if (MUSIC.gain) MUSIC.gain.gain.setTargetAtTime(musicOn() ? 0.5 : 0, SFX.ctx.currentTime, 0.2);
}
function setMusicScene(name) {
  if (MUSIC.scene === name) return;
  MUSIC.scene = name;
  MUSIC.bar = 0;
  MUSIC.step = 0;
  MUSIC.motif = null;
}
function setMusicIntensity(x) {
  MUSIC.intensity = clamp(x, 0, 1);
}
// Victory and defeat fanfares, then the menu theme.
function musicJingle(win) {
  MUSIC.jingle = {
    notes: win
      ? [
          [72, 1],
          [76, 1],
          [79, 1],
          [84, 3],
        ]
      : [
          [69, 1.5],
          [68, 1.5],
          [67, 1.5],
          [64, 4],
        ],
    i: 0,
    at: 0,
  };
}

function voice(type, freq, t, dur, vol, slide = 0) {
  const c = SFX.ctx,
    o = c.createOscillator(),
    g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq + slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.005);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(MUSIC.gain);
  o.start(t);
  o.stop(t + dur + 0.02);
}
function drum(kind, t, vol) {
  const c = SFX.ctx;
  if (kind === 'kick') return voice('sine', 130, t, 0.14, vol, -95);
  const s = c.createBufferSource(),
    f = c.createBiquadFilter(),
    g = c.createGain();
  s.buffer = SFX.noise;
  f.type = kind === 'hat' ? 'highpass' : 'bandpass';
  f.frequency.value = kind === 'hat' ? 7000 : 1800;
  const dur = kind === 'hat' ? 0.04 : 0.11;
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f).connect(g).connect(MUSIC.gain);
  s.start(t, Math.random() * 0.5);
  s.stop(t + dur);
}
// A two-bar motif: rhythm (which 16th steps play) and scale degrees, built by a short random walk.
function newMotif() {
  const rhythms = [
    [0, 4, 6, 8, 12, 14],
    [0, 2, 4, 8, 10, 12],
    [0, 3, 6, 8, 12],
    [0, 4, 8, 10, 11, 12, 14],
  ];
  const r = rhythms[Math.floor(Math.random() * rhythms.length)];
  let d = 4 + Math.floor(Math.random() * 3);
  const deg = r.map(() => (d = clamp(d + [-2, -1, -1, 1, 1, 2][Math.floor(Math.random() * 6)], 0, 9)));
  return { r, deg };
}
function scaleNote(S, chordDeg, deg, octave) {
  const n = S.scale.length,
    i = chordDeg + deg;
  return S.root + 12 * octave + S.scale[((i % n) + n) % n] + 12 * Math.floor(i / n);
}
function musicTick() {
  const c = SFX.ctx;
  if (!c || !MUSIC.gain) return;
  const target = musicOn() && MUSIC.scene ? 0.5 : 0;
  if (Math.abs(MUSIC.gain.gain.value - target) > 0.01) MUSIC.gain.gain.setTargetAtTime(target, c.currentTime, 0.3);
  if (!MUSIC.scene || target === 0) {
    MUSIC.next = c.currentTime + 0.1;
    return;
  }
  const S = MUSIC.SCENES[MUSIC.scene === 'battle' ? 'battle' : 'menu'],
    hot = MUSIC.scene === 'battle' ? MUSIC.intensity : 0.35;
  const stepDur = 60 / (S.bpm + 18 * hot) / 4;
  while (MUSIC.next < c.currentTime + 0.12) {
    const t = MUSIC.next,
      s = MUSIC.step % 16;
    if (MUSIC.jingle) {
      // fanfare overrides the theme until it's done
      const j = MUSIC.jingle;
      if (j.at <= 0) {
        const nt = j.notes[j.i];
        if (!nt) {
          MUSIC.jingle = null;
          setMusicScene('menu');
        } else {
          voice('square', midiHz(nt[0]), t, stepDur * 2 * nt[1], 0.07);
          voice('triangle', midiHz(nt[0] - 24), t, stepDur * 2 * nt[1], 0.12);
          j.at = nt[1] * 2;
          j.i++;
        }
      }
      j.at--;
    } else {
      const chord = S.prog[Math.floor(MUSIC.bar / 2) % S.prog.length];
      if (!MUSIC.motif || (s === 0 && MUSIC.bar % 8 === 0)) MUSIC.motif = newMotif();
      // bass: roots on the beat, octave pushes when the battle heats up
      if (s === 0 || s === 8) voice('triangle', midiHz(scaleNote(S, chord, 0, -2)), t, stepDur * 3, 0.16);
      if (hot > 0.5 && (s === 4 || s === 12)) voice('triangle', midiHz(scaleNote(S, chord, 0, -1)), t, stepDur * 1.5, 0.1);
      // arpeggio: chord tones on 8ths
      if (s % 2 === 0) voice('square', midiHz(scaleNote(S, chord, [0, 2, 4, 2][(s / 2) % 4], 0)), t, stepDur * 0.9, 0.018 + 0.012 * hot);
      // melody: the motif, varied on every second pass
      const m = MUSIC.motif,
        k = m.r.indexOf(s);
      if (k >= 0 && (MUSIC.bar % 4 !== 3 || k < m.r.length - 2)) {
        const varied = MUSIC.bar % 2 === 1 && k === m.r.length - 1 ? 2 : 0;
        voice('square', midiHz(scaleNote(S, chord, m.deg[k] + varied, 1)), t, stepDur * 1.6, 0.035);
      }
      // drums
      if (s === 0 || s === 8 || (hot > 0.6 && s === 6)) drum('kick', t, 0.22);
      if (s === 4 || s === 12) drum('snare', t, 0.05 + 0.05 * hot);
      if (hot > 0.25 && s % 2 === 0) drum('hat', t, 0.02 + 0.02 * hot);
    }
    MUSIC.next += stepDur;
    MUSIC.step++;
    if (MUSIC.step % 16 === 0) MUSIC.bar++;
  }
}
