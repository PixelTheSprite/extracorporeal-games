// Community (hosted game): a gallery of shared maps, unit packs and campaigns, and opt-in balance telemetry.
// Storage (each person writes only their own documents; everyone can read):
//   gallery/<uid>                 { items: [{ id, kind: 'map'|'units'|'campaign', name, desc, at }] }
//   gallery/<uid>/data/<id>(.N)   the shared thing itself (chunked JSON)
//   telemetry/<uid>               running totals for that player's finished battles (no names, no free text)
// Everything installed from the gallery is validated like an imported file and gets a fresh local id.

// ---- the gallery ----
const GALLERY_KINDS = { map: 'Map', units: 'Unit pack', campaign: 'Campaign' };
const gal = { filter: 'all', msg: '' };
async function communityDb() {
  const db = await sbInit().catch(() => null),
    uid = db && (await SB.user.id().catch(() => null));
  return db && uid ? { db, uid } : null;
}
async function shareItem(kind, name, desc, data) {
  const c = await communityDb();
  if (!c) throw new Error('Sharing needs the hosted game.');
  const id = kind[0] + Date.now().toString(36) + Math.floor(Math.random() * 1e5).toString(36);
  await putBig(c.db, `gallery/${c.uid}/data/${id}`, data);
  const ref = c.db.doc(`gallery/${c.uid}`),
    cur = (await ref.get()).data() || { items: [] };
  cur.items = [{ id, kind, name: String(name).slice(0, 60), desc: String(desc || '').slice(0, 200), at: Date.now() }]
    .concat(cur.items || [])
    .slice(0, 50);
  await ref.set(cur);
  return id;
}
async function unshareItem(id) {
  const c = await communityDb();
  if (!c) return;
  const ref = c.db.doc(`gallery/${c.uid}`),
    cur = (await ref.get()).data() || { items: [] };
  cur.items = (cur.items || []).filter(x => x.id !== id);
  await ref.set(cur);
}
// Install: validate, give a fresh id, add to this browser.
function installShared(kind, data) {
  if (kind === 'map') {
    const m = Object.assign(clone(data), { id: 'm' + Date.now().toString(36) });
    const probs = validateMapDef(m);
    if (probs.length) throw new Error('That map didn’t pass the checks: ' + probs[0]);
    storeMaps([m].concat(loadMaps()));
    return `Installed the map “${m.name}”: pick it on the Quick battle screen.`;
  }
  if (kind === 'units') {
    const list = Array.isArray(data) ? data : [];
    const mine = loadUnits(),
      added = [];
    for (const raw of list.slice(0, 24)) {
      const T = clone(raw);
      T.id = slugId(String(T.name || 'unit')); // always a fresh, safe id
      T.custom = true;
      const probs = registerCustomUnit(T);
      if (probs.length) continue;
      mine.push(T);
      added.push(T.name);
    }
    storeUnits(mine);
    if (!added.length) throw new Error('None of those units passed the checks.');
    return `Installed ${added.length} unit${added.length === 1 ? '' : 's'}: ${added.join(', ')}.`;
  }
  if (kind === 'campaign') {
    const c = Object.assign(clone(data), { id: 'c-' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36) });
    const probs = validateCampaign(c);
    if (probs.length) throw new Error('That campaign didn’t pass the checks: ' + probs[0]);
    ceSave([c].concat(customCampaignDrafts()));
    return `Installed the campaign “${c.name}”: find it on the Campaign screen.`;
  }
  throw new Error('Unknown kind of item.');
}
async function renderGallery() {
  $('#gal-status').textContent = gal.msg || '';
  // what you can share
  const maps = loadMaps(),
    units = loadUnits(),
    camps = customCampaigns();
  $('#gal-mine').innerHTML =
    String(
      html` ${maps.map(
        m =>
          html`<div class="layout-row">
            <span><b>${m.name}</b><small>Map · ${m.W} × ${m.H}</small></span
            ><span class="row-btns"><button class="btn sm" data-gal-share="map:${m.id}">Share</button></span>
          </div>`
      )}
      ${
        units.length
          ? html`<div class="layout-row">
              <span><b>Your units (${units.length})</b><small>Unit pack · ${units.map(u => u.name).join(', ')}</small></span
              ><span class="row-btns"><button class="btn sm" data-gal-share="units:all">Share</button></span>
            </div>`
          : ''
      }
      ${camps.map(
        c =>
          html`<div class="layout-row">
            <span><b>${c.name}</b><small>Campaign · ${Object.keys(c.missions).length} missions</small></span
            ><span class="row-btns"><button class="btn sm" data-gal-share="campaign:${c.id}">Share</button></span>
          </div>`
      )}`
    ) || '<p class="src">Make a map, unit or campaign in the Editors to share it here.</p>';
  const c = await communityDb();
  if (!c) {
    $('#gal-list').innerHTML = '<p class="src">The community gallery is available in the hosted game (for people with access to it).</p>';
    return;
  }
  const q = await c.db.collection('gallery').get();
  const items = q.docs
    .filter(d => d.exists)
    .flatMap(d => ((d.data() || {}).items || []).map(x => Object.assign({ by: d.id }, x)))
    .filter(x => GALLERY_KINDS[x.kind]);
  let names = {};
  try {
    const user = await claude.use('user');
    if (user) names = await user.profiles([...new Set(items.map(x => x.by))]);
  } catch (e) {}
  const shown = items
    .filter(x => gal.filter === 'all' || x.kind === gal.filter)
    .sort((a, b) => b.at - a.at)
    .slice(0, 60);
  $('#gal-filter').innerHTML = ['all', 'map', 'units', 'campaign']
    .map(
      k =>
        `<button class="btn sm alt" aria-pressed="${gal.filter === k}" data-gal-filter="${k}">${k === 'all' ? 'All' : GALLERY_KINDS[k] + 's'}</button>`
    )
    .join('');
  $('#gal-list').innerHTML = shown.length
    ? String(
        html`${shown.map(
          x =>
            html`<div class="layout-row">
              <span
                ><b>${x.name}</b
                ><small
                  >${GALLERY_KINDS[x.kind]} · shared by
                  ${x.by === c.uid ? 'you' : (names[x.by] && names[x.by].name) || 'someone'}${x.desc ? ' · ' + x.desc : ''}</small
                ></span
              >
              <span class="row-btns"
                ><button class="btn sm" data-gal-get="${x.by}:${x.id}:${x.kind}">Install</button
                >${x.by === c.uid ? html`<button class="btn sm red" data-gal-del="${x.id}">Remove</button>` : ''}</span
              >
            </div>`
        )}`
      )
    : '<p class="src">Nothing shared yet.</p>';
}
$('#scr-gallery').addEventListener('click', async e => {
  const say = t => {
    gal.msg = t;
    $('#gal-status').textContent = t;
  };
  const f = e.target.closest('[data-gal-filter]'),
    sh = e.target.closest('[data-gal-share]'),
    get = e.target.closest('[data-gal-get]'),
    del = e.target.closest('[data-gal-del]');
  if (f) {
    gal.filter = f.dataset.galFilter;
    return renderGallery();
  }
  try {
    if (sh) {
      const [kind, id] = sh.dataset.galShare.split(':');
      say('Sharing…');
      if (kind === 'map') {
        const m = loadMaps().find(x => x.id === id);
        await shareItem('map', m.name, `${m.W} × ${m.H}`, m);
      }
      if (kind === 'units') {
        const us = loadUnits();
        await shareItem('units', us.length === 1 ? us[0].name : `${us.length} units`, us.map(u => u.name).join(', '), us);
      }
      if (kind === 'campaign') {
        const cp = customCampaigns().find(x => x.id === id);
        await shareItem('campaign', cp.name, `${Object.keys(cp.missions).length} missions`, cp);
      }
      say('Shared: it’s in the gallery below for everyone with this game.');
    }
    if (get) {
      const [by, id, kind] = get.dataset.galGet.split(':'),
        c = await communityDb();
      say('Installing…');
      say(installShared(kind, await getBig(c.db, `gallery/${by}/data/${id}`)));
    }
    if (del) {
      await unshareItem(del.dataset.galDel);
      say('Removed from the gallery.');
    }
  } catch (err) {
    say((err && err.message) || 'That didn’t work; try again.');
  }
  renderGallery();
});

// ---- opt-in balance telemetry ----
// What is sent (only with the setting on): for each finished battle, which rules were on, the unit types your army
// fielded, the kind of map, the number of turns, the battle mode, and whether you won, lost or drew. No names,
// no map or unit names, nothing you typed. It's added to totals in your own document, which only you can change.
async function recordTelemetry(B, win) {
  if (!appState.prefs.telemetry || B.tutorial || R.replay) return;
  const c = await communityDb();
  if (!c) return;
  const ref = c.db.doc(`telemetry/${c.uid}`),
    t = (await ref.get()).data() || { battles: 0, turns: 0, results: {}, modes: {}, maps: {}, rules: {}, units: {} };
  const inc = (o, k) => {
    o[k] = (o[k] || 0) + 1;
  };
  t.battles++;
  t.turns += B.turn;
  inc(t.results, !win ? 'draw' : teamOf(win.id) === teamOf(me()) ? 'win' : 'loss');
  inc(t.modes, battleMode(B));
  inc(t.maps, B.mapDef.kind === 'real' ? 'real' : B.mapDef.kind === 'custom' ? 'custom' : 'generated');
  for (const [k, v] of Object.entries(B.rules)) if (v && RULES[k]) inc(t.rules, k);
  for (const ty of new Set(
    everyUnit(B)
      .filter(u => u.pid === me())
      .map(u => u.type)
  ))
    if (!UNIT_TYPES[ty] || !UNIT_TYPES[ty].custom) inc(t.units, ty);
    else inc(t.units, 'custom');
  await ref.set(t);
}
// Everyone's totals, combined (shown on the Leaderboard screen).
async function renderBalanceData() {
  const el = $('#lb-balance');
  if (!el) return;
  const c = await communityDb();
  if (!c) {
    el.innerHTML = '<p class="src">Balance data is collected in the hosted game from players who opt in (Battle settings).</p>';
    return;
  }
  const q = await c.db.collection('telemetry').get();
  const all = { battles: 0, turns: 0, results: {}, rules: {}, units: {}, players: 0 };
  for (const d of q.docs) {
    const t = d.exists && d.data();
    if (!t || !t.battles) continue;
    all.players++;
    all.battles += t.battles;
    all.turns += t.turns || 0;
    for (const f of ['results', 'rules', 'units']) for (const [k, v] of Object.entries(t[f] || {})) all[f][k] = (all[f][k] || 0) + v;
  }
  if (!all.battles) {
    el.innerHTML = '<p class="src">No balance data yet. Turn on “Share balance data” in Battle settings to contribute.</p>';
    return;
  }
  const pct = n => Math.round((100 * n) / all.battles) + '%';
  const top = (o, label) =>
    Object.entries(o)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([k, v]) => html`<li>${label(k)}: ${pct(v)} of battles</li>`);
  el.innerHTML = String(
    html`<p>
        ${all.battles} battles from ${all.players} player${all.players === 1 ? '' : 's'} · average ${Math.round(all.turns / all.battles)}
        turns · ${pct(all.results.win || 0)} won, ${pct(all.results.loss || 0)} lost.
      </p>
      <h3 class="rule-group">Most used rules</h3>
      <ul class="uc-list">
        ${top(all.rules, k => (RULES[k] ? RULES[k].label : k))}
      </ul>
      <h3 class="rule-group">Most fielded units</h3>
      <ul class="uc-list">
        ${top(all.units, k => (UNIT_TYPES[k] ? UNIT_TYPES[k].name : k === 'custom' ? 'Custom units' : k))}
      </ul>`
  );
}
