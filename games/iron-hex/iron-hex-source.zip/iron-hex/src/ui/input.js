// ---------- Input on the battlefield ----------
function pointInPoly(x, y, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const a = pts[i],
      b = pts[j];
    if (a.y > y !== b.y > y && x < ((b.x - a.x) * (y - a.y)) / (b.y - a.y) + a.x) inside = !inside;
  }
  return inside;
}

function pickTile(x, y) {
  for (let i = R.pick.length - 1; i >= 0; i--) if (pointInPoly(x, y, R.pick[i].pts)) return R.pick[i].t;
  return null;
}

function pickUnit(x, y) {
  for (let i = R.boxes.length - 1; i >= 0; i--) {
    const b = R.boxes[i];
    if (x >= b.x0 - 1 && x <= b.x1 + 1 && y >= b.y0 - 1 && y <= b.y1 + 1) return b.u;
  }
  return null;
}

function onTap(x, y) {
  if (R.replay) return; // watching, not ordering
  if (R.busy || R.ended) return;
  if (R.mode === 'strike') return strikeTap(pickTile(x, y)); // missile targeting
  const u = pickUnit(x, y),
    t = u ? tileAt(u.c, u.r) : pickTile(x, y);
  const unitsOnTile = t ? aliveUnits().filter(o => o.c === t.c && o.r === t.r) : [];
  if (R.mode === 'target') {
    const cand = u && R.targets.list.includes(u) ? u : unitsOnTile.find(o => R.targets.list.includes(o));
    if (cand) {
      const s = R.sel;
      if (R.targets.engage) setOrder(s, { type: 'engage', target: cand.id });
      else if (R.targets.path) setOrder(s, { type: 'move', path: R.targets.path, target: cand.id });
      else setOrder(s, { type: 'fire', target: cand.id });
    } else {
      const s = R.sel;
      R.mode = 'menu';
      R.targets = null;
      openUnitMenu(s, { c: s.c, r: s.r });
    }
    updateHint();
    return;
  }
  if (R.mode === 'move') {
    const node = t && R.reach.get(key(t.c, t.r));
    if (node && node.end && node.cost > 0 && R.amove) setOrder(R.sel, { type: 'amove', path: pathTo(node) });
    else if (node && node.end && node.cost > 0) {
      R.mode = 'dest';
      openDestMenu(R.sel, node);
    } else if (node && node.cost === 0) {
      const s = R.sel;
      R.mode = 'menu';
      R.reach = null;
      openUnitMenu(s, { c: s.c, r: s.r });
    } else if (t && R.travel && R.travel.get(key(t.c, t.r)) && R.travel.get(key(t.c, t.r)).turns >= 2) {
      const far = R.travel.get(key(t.c, t.r)); // a multi-turn move: the unit goes as far as it can each turn
      setOrder(R.sel, { type: 'move', path: pathTo(far), target: null, multi: { dest: { c: t.c, r: t.r }, turns: far.turns } });
    } else clearSelection();
    updateHint();
    return;
  }
  if (R.mode === 'dest') {
    R.pending = null;
    R.mode = 'move';
    closeMenu();
    updateHint();
    return;
  }
  if (R.mode === 'unload') {
    const spot = t && R.unload.list.find(h => h.c === t.c && h.r === t.r),
      s = R.sel;
    if (spot)
      setOrder(
        s,
        R.unload.path
          ? { type: 'move', path: R.unload.path, target: null, unload: { c: spot.c, r: spot.r } }
          : { type: 'unload', unload: { c: spot.c, r: spot.r } }
      );
    else {
      R.mode = 'menu';
      R.unload = null;
      R.pending = null;
      openUnitMenu(s, { c: s.c, r: s.r });
    }
    updateHint();
    return;
  }
  if (R.mode === 'bridge' || R.mode === 'starget') {
    const st = R.mode === 'bridge' ? R.bridge : R.starget,
      s = R.sel;
    const hit = t && st.list.find(h => h.c === t.c && h.r === t.r);
    if (hit && R.mode === 'bridge')
      setOrder(
        s,
        st.path
          ? { type: 'move', path: st.path, target: null, build: { kind: st.kind, at: hit } }
          : { type: 'build', kind: st.kind, at: hit }
      );
    else if (hit) setOrder(s, st.path ? { type: 'move', path: st.path, target: null, starget: hit } : { type: 'fire', starget: hit });
    else {
      R.mode = 'menu';
      R.bridge = null;
      R.starget = null;
      R.pending = null;
      openUnitMenu(s, { c: s.c, r: s.r });
    }
    updateHint();
    return;
  }
  if (R.mode === 'repair') {
    const cand = u && R.repair.list.includes(u) ? u : unitsOnTile.find(o => R.repair.list.includes(o)),
      s = R.sel;
    if (cand)
      setOrder(s, R.repair.path ? { type: 'move', path: R.repair.path, target: null, repair: cand.id } : { type: 'repair', mend: cand.id });
    else {
      R.mode = 'menu';
      R.repair = null;
      R.pending = null;
      openUnitMenu(s, { c: s.c, r: s.r });
    }
    updateHint();
    return;
  }
  if (R.mode === 'load') {
    const cand = u && R.loadList.includes(u) ? u : unitsOnTile.find(o => R.loadList.includes(o)),
      s = R.sel;
    if (cand) setPair(s, cand, R.loadPath);
    else {
      R.mode = 'menu';
      R.loadList = null;
      openUnitMenu(s, { c: s.c, r: s.r });
    }
    updateHint();
    return;
  }
  // idle / menu
  let pickU = u;
  if (!pickU && unitsOnTile.length) {
    const own = unitsOnTile.filter(o => o.pid === me());
    pickU = own.find(o => !R.sel || o.id !== R.sel.id) || own[0] || unitsOnTile[0];
  }
  if (pickU && pickU.pid === me()) selectUnit(pickU);
  else if (pickU) {
    clearSelection();
    showIntel(pickU);
  } else if (t && structAt(t.c, t.r)) {
    clearSelection();
    showStructInfo(t);
  } else clearSelection();
}

function panScreen(dx, dy) {
  const c = R.cam,
    v = appState.prefs.view;
  let rx, ry;
  if (v === 'top') {
    c.x -= dx / c.zoom;
    c.y -= dy / c.zoom;
  } else {
    if (v === 'iso') {
      rx = -dx / c.zoom;
      ry = -dy / (c.zoom * 0.55);
    } else {
      rx = (-dx * 7) / (c.zoom * 9);
      ry = -dy / (c.zoom * 0.6);
    }
    const ca = Math.cos(c.angle),
      sa = Math.sin(c.angle);
    c.x += rx * ca + ry * sa;
    c.y += -rx * sa + ry * ca;
  }
  const def = appState.battle.mapDef;
  c.x = clamp(c.x, 0, def.W * SQ3);
  c.y = clamp(c.y, 0, def.H * 1.5);
}

function zoomBy(f) {
  const c = R.cam;
  c.zoom = clamp(c.zoom * f, 5, appState.prefs.view === 'ground' ? 20 : 30);
}

function setupCanvasInput() {
  const cv = R.cvs;
  const local = e => {
    const r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) / R.PX, y: (e.clientY - r.top) / R.PX };
  };
  cv.addEventListener('pointerdown', e => {
    SFX.init();
    cv.setPointerCapture(e.pointerId);
    R.pointers.set(e.pointerId, local(e));
    if (R.pointers.size === 1) R.drag = { start: local(e), last: local(e), moved: false };
    else {
      R.drag = null;
      const p = [...R.pointers.values()];
      R.pinch = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y);
    }
  });
  cv.addEventListener('pointermove', e => {
    const p = local(e);
    if (R.pointers.has(e.pointerId)) R.pointers.set(e.pointerId, p);
    if (R.pointers.size === 2 && R.pinch) {
      const q = [...R.pointers.values()],
        d = Math.hypot(q[0].x - q[1].x, q[0].y - q[1].y);
      zoomBy(d / R.pinch);
      R.pinch = d;
      positionMenu(menuAnchor());
      return;
    }
    if (R.drag) {
      const dx = p.x - R.drag.last.x,
        dy = p.y - R.drag.last.y;
      if (Math.hypot(p.x - R.drag.start.x, p.y - R.drag.start.y) > (4 / R.PX) * 2) R.drag.moved = true;
      if (R.drag.moved) {
        panScreen(dx, dy);
        positionMenu(menuAnchor());
      }
      R.drag.last = p;
    } else R.hover = pickTile(p.x, p.y);
  });
  const up = e => {
    const had = R.pointers.has(e.pointerId);
    R.pointers.delete(e.pointerId);
    if (R.pointers.size < 2) R.pinch = null;
    if (had && R.drag && !R.drag.moved && e.type === 'pointerup') {
      const p = local(e);
      onTap(p.x, p.y);
    }
    if (!R.pointers.size) R.drag = null;
  };
  cv.addEventListener('pointerup', up);
  cv.addEventListener('pointercancel', up);
  cv.addEventListener('pointerleave', () => {
    R.hover = null;
  });
  cv.addEventListener(
    'wheel',
    e => {
      e.preventDefault();
      zoomBy(e.deltaY < 0 ? 1.12 : 1 / 1.12);
      positionMenu(menuAnchor());
    },
    { passive: false }
  );
}

function menuAnchor() {
  if (R.mode === 'dest' && R.pending) return R.pending.path[R.pending.path.length - 1];
  if (R.sel && R.mode === 'menu') return { c: R.sel.c, r: R.sel.r };
  return null;
}

document.addEventListener('keydown', e => {
  if (appState.screen !== 'battle') return;
  if (e.target.tagName === 'SELECT') return;
  const k = e.key;
  if (k === 'Escape') {
    if (!$('#modal').hidden) closeModal();
    else clearSelection();
    return;
  }
  if (!$('#modal').hidden) return;
  if (k === '?') {
    showHelp();
    return;
  }
  if (k === '1') setView('top');
  else if (k === '2') setView('iso');
  else if (k === '3') setView('ground');
  else if (k === 'q' || k === 'Q') rotate(-1);
  else if (k === 'e' || k === 'E') rotate(1);
  else if (k === '+' || k === '=') zoomBy(1.15);
  else if (k === '-' || k === '_') zoomBy(1 / 1.15);
  // Arrows move the hex cursor while a unit is selected; otherwise they (and WASD) pan the map.
  else if (k.startsWith('Arrow') && cursorActive()) {
    e.preventDefault();
    moveCursor(k === 'ArrowLeft' ? -1 : k === 'ArrowRight' ? 1 : 0, k === 'ArrowUp' ? -1 : k === 'ArrowDown' ? 1 : 0);
  } else if (k === 'ArrowLeft' || k === 'a') panScreen(12, 0);
  else if (k === 'ArrowRight' || k === 'd') panScreen(-12, 0);
  else if (k === 'ArrowUp' || k === 'w') panScreen(0, 12);
  else if (k === 'ArrowDown' || k === 's') panScreen(0, -12);
  else if (k === 'r' || k === 'R') announce(situationReport());
  else if ((k === 'Enter' || k === ' ') && cursorActive() && R.kc && document.activeElement === document.body) {
    e.preventDefault();
    cursorTap();
  } else if (k === 'Tab' && !R.busy) {
    e.preventDefault();
    const mine = aliveUnits().filter(u => u.pid === me());
    if (!mine.length) return;
    const unordered = mine.filter(u => !appState.battle.orders[u.id]);
    const pool = unordered.length ? unordered : mine;
    const i = R.sel ? pool.findIndex(u => u.id === R.sel.id) : -1;
    const next = pool[(i + 1) % pool.length];
    const t = tileAt(next.c, next.r);
    R.cam.x = t.wx;
    R.cam.y = t.wy;
    selectUnit(next);
  } else if (k === 'Enter' && !$('#btn-done').disabled && document.activeElement === document.body) $('#btn-done').click();
  else return;
  positionMenu(menuAnchor());
});
