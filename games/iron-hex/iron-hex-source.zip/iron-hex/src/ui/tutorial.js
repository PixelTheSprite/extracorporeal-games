// The tutorial: a small hand-built battle with a coach panel that teaches by doing. Each step waits for you to
// actually do the thing (checked a few times a second), then moves on; doing a later step early skips ahead.
// It doesn't count toward records or look unlocks.
const TUTORIAL_MAP = {
  id: 'tutorial',
  name: 'Training Ground',
  kind: 'custom',
  W: 12,
  H: 9,
  rows: [
    'pppppppppppp',
    'ppfpppppppcp',
    'pppphpppfppp',
    'ppppppcppppp',
    'pppfppppphpp',
    'pppppppppppp',
    'pcfpppphpppp',
    'pppppppppppp',
    'pppppppppppp',
  ],
  spawns: [
    { c: 1, r: 6 },
    { c: 10, r: 1 },
  ],
  roads: [],
};
const TOWN = { c: 6, r: 3 };
const TUTORIAL_STEPS = [
  {
    id: 'select',
    text: 'Tap your Sherman tank to select it (or press Tab). Its card at the bottom shows health, ammo and orders.',
    done: () => R.sel && R.sel.pid === me() && R.sel.type === 'tank',
  },
  {
    id: 'move',
    text: 'Choose Move, then tap a blue hex toward the town in the middle of the map, and pick Wait to move there and hold (Fire appears when an enemy is in reach). Fainter rings are 2–4 turns away: tapping one gives an order that lasts several turns.',
    done: B => tutUnits(B, 'tank').some(u => B.orders[u.id] && /move/.test(B.orders[u.id].type)),
  },
  {
    id: 'second',
    text: 'Every unit needs an order before you can end the turn. Select the rifle squad and move it toward the town too (Move, a blue hex, then Wait).',
    done: B => tutUnits(B, 'inf').some(u => B.orders[u.id]),
  },
  {
    id: 'done',
    text: 'Press Done (or Enter). Both sides’ orders now play out at the same time: units move and fire simultaneously.',
    done: B => B.turn >= 2,
  },
  {
    id: 'attack',
    text: 'An enemy rifle squad guards the town. Units fire automatically at enemies in range, and you can order Fire at a target or Attack-move toward one. Damage it.',
    done: B => tutEnemyHurt(B),
  },
  {
    id: 'capture',
    text: 'Only infantry can capture. Move your rifle squad onto the town and choose Capture; holding it for a couple of turns makes it yours.',
    done: B => {
      const c = B.cities && B.cities[key(TOWN.c, TOWN.r)];
      return R.ended || (!!c && (c.owner === me() || c.capPid === me())); // winning first also counts
    },
  },
  {
    id: 'win',
    text: 'Destroy the last enemy to win. Tips: ? shows help, R reads a situation report, and the Battle settings presets set up quick or long games.',
    done: () => R.ended,
  },
];
const tutUnits = (B, type) => aliveUnits().filter(u => u.pid === me() && u.type === type);
function tutEnemyHurt(B) {
  const e = everyUnit(B).filter(u => u.pid !== me());
  return e.some(u => u.hp < u.maxHp);
}

function startTutorial() {
  appState.tutorialSaved = appState.settings;
  appState.settings = Object.assign(defaultSettings(), {
    mapId: 'tutorial',
    customMap: clone(TUTORIAL_MAP),
    armies: 2,
    hotseat: 1,
    roster: { tank: 1, inf: 1 },
    strategies: [null, 'defensive'],
    victory: { mode: 'destruction', pct: 60, hold: 3 }, // destruction: the default
  });
  Object.assign(appState.settings.rules, { exhaust: false, attrition: false, fog: false });
  newBattle(20240);
  const B = appState.battle;
  B.tutorial = true;
  // The enemy: a single, already-weakened rifle squad beside the town.
  const foe = B.units.find(u => u.pid === 1 && u.type === 'inf');
  B.units = B.units.filter(u => u.pid !== 1 || u === foe);
  Object.assign(foe, { c: TOWN.c + 2, r: TOWN.r, hp: 40 });
  startReplayLog(B);
  appState.settings = appState.tutorialSaved;
  R.tutorial = { step: 0, timer: setInterval(tutorialCheck, 300) };
  enterBattle('Tutorial');
  renderTutor();
}
function tutorialCheck() {
  const T = R.tutorial,
    B = appState.battle;
  if (!T || !B || !B.tutorial) return stopTutorial();
  let moved = false;
  while (T.step < TUTORIAL_STEPS.length && TUTORIAL_STEPS[T.step].done(B)) {
    T.step++;
    moved = true;
  }
  if (T.step >= TUTORIAL_STEPS.length) {
    appState.prefs.tutorialDone = true;
    savePrefs();
    stopTutorial();
    return;
  }
  if (moved) {
    renderTutor();
    SFX.play('order');
    announce('Tutorial: ' + TUTORIAL_STEPS[T.step].text);
  }
}
function stopTutorial() {
  if (!R.tutorial) return;
  clearInterval(R.tutorial.timer);
  R.tutorial = null;
  $('#tutor').hidden = true;
}
function renderTutor() {
  const T = R.tutorial;
  if (!T) return;
  const st = TUTORIAL_STEPS[T.step];
  $('#tutor').hidden = false;
  $('#tutor').innerHTML = String(
    html`<b>Tutorial · step ${T.step + 1} of ${TUTORIAL_STEPS.length}</b>
      <p>${st.text}</p>
      <button class="btn sm alt" id="tutor-skip">End tutorial</button>`
  );
  $('#tutor-skip').onclick = () => {
    appState.prefs.tutorialDone = true;
    savePrefs();
    stopTutorial();
  };
}
