// The Build dialog (Mid-battle production rule): buy one unit a turn at your bases.
function openProductionDialog() {
  const B = appState.battle;
  if (!B || !(B.rules.production || (B.rules.cityDev && B.rules.income)) || R.busy) return;
  B.prodQueue = B.prodQueue || {};
  const q = (B.prodQueue[me()] = B.prodQueue[me()] || []);
  const funds = B.funds[me()] || 0;
  const types = TYPE_ORDER.filter(t => typeAllowed(t, B.rules) && productionSites(B, me(), t).length);
  const alive = allAlive().filter(u => u.pid === me()).length;
  showDialog(`<div class="panel save-dlg" role="dialog" aria-modal="true" aria-labelledby="pr-title"><h2 id="pr-title">Production</h2>
    <p>Funds <b>${funds}</b> · ${B.rules.income ? `income +${incomeOf(B, me())} a turn` : 'no income (Income is off)'} · ${alive} of ${ARMY_CAP} units. One purchase arrives at the end of each turn.</p>
    ${q.length ? `<p>Ordered: ${q.map((x, i) => `${escapeHtml(UNIT_TYPES[x.type].name)} <button class="btn sm alt" data-pr-del="${escapeHtml(i)}" aria-label="Cancel ${escapeHtml(UNIT_TYPES[x.type].name)}">✕</button>`).join(' ')}</p>` : ''}
    <div class="layout-list">${
      types
        .map(t => {
          const T = UNIT_TYPES[t],
            price = priceOf(T),
            sites = productionSites(B, me(), t);
          const can = !q.length && funds >= price && alive < ARMY_CAP;
          return `<div class="layout-row"><span class="ue-row"><canvas class="px" width="24" height="16" data-spr-type="${escapeHtml(t)}" data-spr-pid="0"></canvas><span><b>${escapeHtml(T.name)}</b><small>${escapeHtml(T.role)} · ${price} funds · ${sites.length} site${sites.length === 1 ? '' : 's'}</small></span></span>
        <span class="row-btns"><select data-pr-site="${escapeHtml(t)}" aria-label="Where to build ${escapeHtml(T.name)}">${sites.map(s => `<option value="${s.c},${s.r}">${structAt(s.c, s.r) ? STRUCTS[structAt(s.c, s.r).kind].name : B.mapDef.spawns[0].c === s.c && B.mapDef.spawns[0].r === s.r ? 'Capital' : 'City'} ${s.c},${s.r}</option>`).join('')}</select><button class="btn sm" data-pr-buy="${escapeHtml(t)}" ${can ? '' : 'disabled'}>Buy</button></span></div>`;
        })
        .join('') || '<p class="src">You have no production sites: capture a city, or hold an airfield or port.</p>'
    }</div>
    ${investSectionHtml(B)}
    <div class="row-end"><span></span><button class="btn" id="pr-close">Close</button></div></div>`);
  paintSprites($('#modal'));
  $('#pr-close').focus();
  $('#modal')
    .querySelectorAll('[data-pr-buy]')
    .forEach(
      b =>
        (b.onclick = () => {
          const t = b.dataset.prBuy,
            [c, r] = unkey($(`[data-pr-site="${escapeHtml(t)}"]`).value);
          q.push({ type: t, at: { c, r } });
          SFX.play('order');
          renderHud();
          openProductionDialog();
        })
    );
  $('#modal')
    .querySelectorAll('[data-pr-del]')
    .forEach(
      b =>
        (b.onclick = () => {
          q.splice(+b.dataset.prDel, 1);
          renderHud();
          openProductionDialog();
        })
    );
  $('#pr-close').onclick = () => closeModal();
}
