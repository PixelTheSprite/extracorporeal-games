// Diagnostics screen: runs the same regression suites as tests/run.mjs, in the browser, with no graphics.
const DIAG_SUITES = {
  quick: {
    label: 'Quick',
    desc: 'About a dozen battles: every rule on, every rule off, each rule alone, and harder setups (territory victory, every unit type, defensive AIs, four armies). Then checks that the same seed replays identically, that a save reloaded mid-battle continues identically, and that an old version-1 save still loads and plays. Takes a few seconds.',
  },
  full: {
    label: 'Full',
    desc: 'Every one of the 64 combinations of the six rules, under both victory conditions (128 battles), plus every real-world map, a 40 × 30 custom map, the harder setups and the same checks. Takes about three minutes.',
  },
};
const diag = { suite: 'quick', running: false, stop: false, rows: [] };
function renderDiag() {
  $('#diag-suite').innerHTML = Object.entries(DIAG_SUITES)
    .map(
      ([k, s]) =>
        `<button class="btn alt" role="radio" aria-checked="${diag.suite === k}" aria-pressed="${diag.suite === k}" data-suite="${escapeHtml(k)}" ${diag.running ? 'disabled' : ''}>${s.label}</button>`
    )
    .join('');
  $('#diag-desc').textContent = DIAG_SUITES[diag.suite].desc;
  $('#btn-diag-run').disabled = diag.running;
  $('#btn-diag-stop').disabled = !diag.running;
  renderDiagTable();
}
function renderDiagTable() {
  const tag = { pass: '<b class="ok">PASS</b>', warn: '<b class="warn">WARN</b>', fail: '<b class="bad">FAIL</b>' };
  $('#diag-table').innerHTML = diag.rows.length
    ? `<thead><tr><th>Result</th><th>Check</th><th>Details</th><th>Time</th></tr></thead><tbody>${diag.rows
        .map(
          r =>
            `<tr><td>${tag[r.status]}</td><td>${escapeHtml(r.label)}</td><td>${escapeHtml(r.detail)}</td><td>${r.ms ? r.ms + ' ms' : ''}</td></tr>`
        )
        .join('')}</tbody>`
    : '';
}
async function runDiag() {
  if (diag.running) return;
  diag.running = true;
  diag.stop = false;
  diag.rows = [];
  renderDiag();
  const bar = $('#diag-bar'),
    status = $('#diag-status'),
    t0 = Date.now();
  status.textContent = 'Running…';
  const rows = await runSuite(
    diag.suite,
    async (frac, row) => {
      diag.rows.push(row);
      bar.style.setProperty('--pct', Math.round(frac * 100) + '%');
      renderDiagTable();
      await new Promise(r => setTimeout(r, 0)); // let the page repaint between battles
    },
    () => diag.stop
  );
  const n = s => rows.filter(r => r.status === s).length;
  status.textContent = `${diag.stop ? 'Stopped. ' : ''}${n('pass')} passed, ${n('warn')} warnings, ${n('fail')} failed in ${((Date.now() - t0) / 1000).toFixed(1)} s. Warnings are battles that reached their turn limit (60 turns on a standard map, more on bigger maps).`;
  diag.running = false;
  renderDiag();
}
$('#scr-diag').addEventListener('click', e => {
  const b = e.target.closest('[data-suite]');
  if (b && !diag.running) {
    diag.suite = b.dataset.suite;
    SFX.play('click');
    renderDiag();
    return;
  }
  if (e.target.closest('#btn-diag-run')) {
    SFX.play('click');
    runDiag();
  }
  if (e.target.closest('#btn-diag-stop')) {
    diag.stop = true;
  }
});

// Performance test: the largest setup on this device; frames per second idle, panning and while a turn resolves.
async function runPerfTest() {
  const out = $('#perf-result'),
    saved = clone(appState.settings);
  out.textContent = 'Running… (about 20 seconds)';
  Object.assign(appState.settings, { mapId: 'real-suwalki', armies: 4, hotseat: 1 });
  delete appState.settings.seats;
  refreshUnlocks();
  newBattle(4242);
  enterBattle('Performance test');
  const settle = async () => {
    for (let i = 0; i < 200 && (R.planning || R.busy); i++) await sleep(100);
  };
  const measure = ms =>
    new Promise(res => {
      const times = [];
      let last = performance.now(),
        stop = false;
      const tick = t => {
        times.push(t - last);
        last = t;
        markActive();
        if (!stop) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      setTimeout(() => {
        stop = true;
        const s = times.slice(2).sort((a, b) => a - b);
        res(Math.round(1000 / s[Math.floor(s.length / 2)]));
      }, ms);
    });
  await settle();
  const idle = await measure(2000);
  const pan = setInterval(() => (R.cam.x += 0.25), 16);
  const panning = await measure(2000);
  clearInterval(pan);
  const B = appState.battle;
  Object.assign(B.orders, planAI(Object.assign({}, B.players[0], { ai: 'balanced' })));
  updateDone();
  const resolving = measure(5000);
  $('#btn-done').click();
  const turn = await resolving;
  await settle();
  R.session++;
  R.ended = true;
  appState.settings = saved;
  go('diag');
  const worst = Math.min(idle, panning, turn),
    verdict = worst >= 30 ? 'smooth' : worst >= 20 ? 'playable' : 'slow';
  $('#perf-result').textContent = `Idle ${idle} fps · panning ${panning} fps · turn resolving ${turn} fps: ${verdict}.`;
  return { idle, panning, turn, verdict };
}
$('#btn-perf').addEventListener('click', () => runPerfTest());
