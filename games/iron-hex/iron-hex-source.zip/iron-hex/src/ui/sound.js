// ---------- Sound (tiny WebAudio synth) ----------
const SFX = {
  ctx: null,
  noise: null,
  init() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      const b = this.ctx.createBuffer(1, this.ctx.sampleRate, this.ctx.sampleRate),
        d = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.noise = b;
      musicStart(); // music shares this audio context
    } catch (e) {
      this.ctx = null;
    }
  },
  tone(freq, dur, type = 'square', vol = 0.06, slide = 0) {
    const c = this.ctx,
      o = c.createOscillator(),
      g = c.createGain(),
      t = c.currentTime;
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq + slide), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(c.destination);
    o.start(t);
    o.stop(t + dur);
  },
  burst(dur, vol, cutoff) {
    const c = this.ctx,
      s = c.createBufferSource(),
      f = c.createBiquadFilter(),
      g = c.createGain(),
      t = c.currentTime;
    s.buffer = this.noise;
    f.type = 'lowpass';
    f.frequency.setValueAtTime(cutoff, t);
    f.frequency.exponentialRampToValueAtTime(80, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(c.destination);
    s.start(t);
    s.stop(t + dur);
  },
  play(k) {
    if (!appState.prefs.sound || !this.ctx) return;
    try {
      if (k === 'click') this.tone(660, 0.06, 'square', 0.04);
      else if (k === 'select') {
        this.tone(520, 0.05);
        setTimeout(() => this.tone(780, 0.06), 50);
      } else if (k === 'order') this.tone(880, 0.08, 'square', 0.05, 200);
      else if (k === 'shot') {
        this.burst(0.15, 0.12, 2400);
        this.tone(180, 0.1, 'square', 0.05, -120);
      } else if (k === 'mg') {
        for (let i = 0; i < 3; i++) setTimeout(() => this.burst(0.05, 0.08, 4000), i * 60);
      } else if (k === 'boom') this.burst(0.5, 0.22, 900);
      else if (k === 'bigboom') {
        this.burst(1.1, 0.32, 700);
        this.tone(70, 0.6, 'sawtooth', 0.08, -40);
      } else if (k === 'move') this.tone(110, 0.35, 'sawtooth', 0.03, -30);
      else if (k === 'fanfare') [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => this.tone(f, 0.18, 'square', 0.05), i * 140));
    } catch (e) {
      /* ignore audio errors */
    }
  },
};
