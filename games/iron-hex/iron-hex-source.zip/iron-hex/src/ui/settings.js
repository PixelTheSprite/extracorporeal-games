// Presets from the A/B tests (tools/ab). Each sets the full rule set (defaults plus changes), victory and roster.
const PRESETS = [
  {
    id: 'standard',
    name: 'Standard',
    desc: 'The defaults: 8 units each, destruction victory, core rules and supply exhaustion on. About 28 turns of 26 s, roughly 12 minutes.',
  },
  {
    id: 'quick',
    name: 'Quick skirmish',
    desc: '4 units each, territory victory. Shortest games: about 16 turns of 19 s, roughly 5 minutes.',
    victory: { mode: 'territory', pct: 60, hold: 3 },
    roster: { tank: 1, inf: 2, plane: 1 },
  },
  {
    id: 'light',
    name: 'Long, light-touch game',
    desc: '6 units each; Morale, Fog of war and Fading intel on, Real-time fire off. Short turns, longer games: about 35 turns of 22 s, every test game decisive.',
    rules: { morale: true, fog: true, intelFade: true, realtime: false },
    roster: { tank: 2, inf: 2, eng: 1, plane: 1 },
  },
  {
    id: 'marathon',
    name: 'Marathon',
    desc: '8 units each; Morale, Fog of war and Fading intel on, Real-time fire off. The most turns with natural endings: about 42 turns of 29 s, roughly 20 minutes.',
    rules: { morale: true, fog: true, intelFade: true, realtime: false },
  },
];
function presetSettings(pr) {
  const d = defaultSettings();
  return {
    rules: Object.assign({}, d.rules, pr.rules || {}),
    victory: Object.assign({}, d.victory, pr.victory || {}),
    roster: Object.assign({}, pr.roster || d.roster),
    budget: 0,
  };
}
const sameJSON = (a, b) => {
  const norm = o =>
    JSON.stringify(
      Object.keys(o)
        .sort()
        .reduce((m, k) => (o[k] ? (m[k] = o[k]) : null, m), {})
    );
  return norm(a) === norm(b);
};
function activePreset() {
  const S = appState.settings;
  return PRESETS.find(pr => {
    const x = presetSettings(pr);
    return (
      sameJSON(x.rules, S.rules) &&
      sameJSON(x.roster, S.roster || DEFAULT_ROSTER) &&
      x.victory.mode === S.victory.mode &&
      (x.victory.mode !== 'territory' || (x.victory.pct === S.victory.pct && x.victory.hold === S.victory.hold)) &&
      !(S.budget || 0)
    );
  });
}
function renderPresets() {
  const act = activePreset();
  $('#preset-pick').innerHTML =
    PRESETS.map(
      pr =>
        `<button class="pick-row preset-row" role="radio" aria-checked="${act === pr}" data-preset="${escapeHtml(pr.id)}"><span class="preset-dot">${act === pr ? '●' : '○'}</span><span><b>${pr.name}</b><small>${pr.desc}</small></span></button>`
    ).join('') + `<p class="src">${act ? `Current settings: ${act.name}.` : 'Current settings: Custom.'}</p>`;
}
// ---------- Battle settings ----------
function renderRosterPicker() {
  if ($('#preset-pick')) renderPresets(); // the preset marker follows roster changes
  const S = appState.settings;
  if (!S.roster) S.roster = Object.assign({}, DEFAULT_ROSTER);
  const R0 = S.roster,
    total = rosterTotal(R0),
    cost = rosterCost(R0),
    budget = S.budget || 0;
  let group = '';
  // Units that come with a realism rule are only offered while that rule is on.
  $('#unit-roster').innerHTML = TYPE_ORDER.filter(t => typeAllowed(t, S.rules))
    .map(t => {
      const T = UNIT_TYPES[t],
        n = R0[t] || 0;
      const head = T.domain !== group ? `<h3 class="rule-group">${DOMAIN_LABEL[T.domain]}</h3>` : '';
      group = T.domain;
      return (
        head +
        `<div class="pick-row"><canvas class="px" width="28" height="21" data-spr-type="${escapeHtml(t)}" data-spr-pid="0"></canvas>
      <span><b>${escapeHtml(T.name)}</b><small>${escapeHtml(T.role)}${T.custom ? ' · custom' : ''} · ${priceOf(T)} points</small></span>
      <span class="stepper"><button class="btn sm alt" data-pick="${escapeHtml(t)}" data-d="-1" aria-label="One fewer ${escapeHtml(T.name)}" ${n <= 0 || total <= 1 ? 'disabled' : ''}>−</button>
      <output aria-label="${escapeHtml(T.name)} count">${n}</output>
      <button class="btn sm alt" data-pick="${escapeHtml(t)}" data-d="1" aria-label="One more ${escapeHtml(T.name)}" ${n >= ROSTER_MAX_EACH || total >= ROSTER_MAX_TOTAL || (budget && cost + priceOf(T) > budget) ? 'disabled' : ''}>+</button></span></div>`
      );
    })
    .join('');
  $('#pick-total').innerHTML =
    `${total} unit${total === 1 ? '' : 's'} per army (max ${ROSTER_MAX_TOTAL}) · ${cost} points${budget ? ` of ${budget}` : ''} <label class="budget-row">Budget <select id="budget-pick">${BUDGETS.map(b => `<option value="${b}" ${b === budget ? 'selected' : ''}>${b ? b + ' points' : 'No limit'}</option>`).join('')}</select></label>${budget && cost > budget ? ' <b class="bad">Over budget: remove units</b>' : ''}`;
  paintSprites($('#unit-roster'));
}

function renderLooksPicker() {
  const S = appState.settings;
  S.skins = S.skins || ['modern', 'modern', 'modern', 'modern'];
  const periods = Object.entries(SKIN_PERIODS).filter(([, p]) => p.ready);
  refreshUnlocks();
  $('#looks-pick').innerHTML = ARMIES.map(
    (
      a,
      i
    ) => `<div class="pick-row looks-row"><span class="sw" style="background:${a.color};width:22px;height:22px;border:3px solid var(--ink)"></span>
    <span><b>${i === 0 ? 'Your army' : 'Army ' + (i + 1)}</b><small>${i === 0 ? (S.skins[0] === 'modern' ? 'Modern look' : `${S.skinUnlocked.length} of ${TYPE_ORDER.filter(t => SKIN_ART[S.skins[0]] && SKIN_ART[S.skins[0]][t]).length} unit types unlocked`) : 'AI armies may wear any look'}</small></span>
    <select data-look-army="${escapeHtml(i)}" aria-label="Look for ${i === 0 ? 'your army' : 'army ' + (i + 1)}">${periods.map(([k, p]) => `<option value="${k}" ${S.skins[i] === k ? 'selected' : ''}>${p.name}</option>`).join('')}</select></div>`
  ).join('');
}
function renderSettings() {
  const S = appState.settings,
    V = S.victory;
  renderPresets();
  renderAccess();
  renderLooksPicker();
  renderRosterPicker();
  const anyClaim = S.rules.terrRadius || S.rules.terrPaint || S.rules.terrSpread;
  $('#victory').innerHTML =
    `<legend>Victory condition</legend>` +
    Object.entries(VICTORY)
      .map(
        ([k, v]) => `<label class="radio-row">
      <input type="radio" name="victory" value="${k}" ${V.mode === k ? 'checked' : ''}>
      <span><b>${v.label}</b><small>${v.desc}</small></span></label>
      ${
        k === 'territory' && V.mode === 'territory'
          ? `<div class="victory-opts">
        <label>Share of the map<select data-vic="pct">${[40, 50, 60, 75].map(n => `<option value="${n}" ${V.pct === n ? 'selected' : ''}>${n}%</option>`).join('')}</select></label>
        <label>Held for<select data-vic="hold">${[1, 2, 3, 5].map(n => `<option value="${n}" ${V.hold === n ? 'selected' : ''}>${n} turn${n > 1 ? 's' : ''} in a row</option>`).join('')}</select></label>
        ${anyClaim ? '' : '<p class="warn">All territory rules are off, so armies can only claim their supply hexes. Turn on at least one territory rule below.</p>'}
      </div>`
          : ''
      }`
      )
      .join('');
  let group = '';
  $('#rules').innerHTML = Object.entries(RULES)
    .map(([k, r]) => {
      const head = r.group !== group ? `<h3 class="rule-group">${r.group}</h3>` : '';
      group = r.group;
      return (
        head +
        `<div class="rule-row">
    <button class="btn sm alt" data-rule="${escapeHtml(k)}" aria-pressed="${!!S.rules[k]}" aria-label="${r.label}">${S.rules[k] ? 'On' : 'Off'}</button>
    <span><b>${r.label}</b><small>${r.desc}</small></span></div>`
      );
    })
    .join('');
}

$('#scr-settings').addEventListener('change', e => {
  if (e.target.id === 'budget-pick') {
    appState.settings.budget = +e.target.value;
    renderRosterPicker();
    $('#budget-pick').focus();
    return;
  }
  const la = e.target.closest('[data-look-army]');
  if (la) {
    appState.settings.skins[+la.dataset.lookArmy] = la.value;
    SFX.play('click');
    renderLooksPicker();
    $(`[data-look-army="${escapeHtml(la.dataset.lookArmy)}"]`).focus();
    return;
  }
  const V = appState.settings.victory;
  if (e.target.name === 'victory') {
    V.mode = e.target.value;
    SFX.play('click');
    renderSettings();
    $(`input[name="victory"][value="${V.mode}"]`).focus();
    return;
  }
  const sel = e.target.closest('[data-vic]');
  if (sel) {
    V[sel.dataset.vic] = +sel.value;
    SFX.play('click');
  }
});

$('#scr-settings').addEventListener('click', e => {
  const pr = e.target.closest('[data-preset]');
  if (pr) {
    const x = presetSettings(PRESETS.find(p => p.id === pr.dataset.preset));
    Object.assign(appState.settings, x);
    SFX.play('select');
    renderSettings();
    $(`[data-preset="${escapeHtml(pr.dataset.preset)}"]`).focus();
    return;
  }
  const pk = e.target.closest('[data-pick]');
  if (pk && !pk.disabled) {
    const R0 = appState.settings.roster,
      t = pk.dataset.pick,
      d = +pk.dataset.d;
    R0[t] = clamp((R0[t] || 0) + d, 0, ROSTER_MAX_EACH);
    if (!R0[t]) delete R0[t];
    SFX.play('click');
    renderRosterPicker();
    const again = $(`[data-pick="${escapeHtml(t)}"][data-d="${escapeHtml(d)}"]`);
    (again && !again.disabled ? again : $(`[data-pick="${escapeHtml(t)}"][data-d="${escapeHtml(-d)}"]`))?.focus();
    return;
  }
  if (e.target.closest('#btn-roster-reset')) {
    appState.settings.roster = Object.assign({}, DEFAULT_ROSTER);
    SFX.play('click');
    renderRosterPicker();
    return;
  }
  const rl = e.target.closest('[data-rule]');
  if (!rl) return;
  const S = appState.settings;
  S.rules[rl.dataset.rule] = !S.rules[rl.dataset.rule];
  SFX.play('click');
  renderSettings();
  $(`[data-rule="${escapeHtml(rl.dataset.rule)}"]`).focus();
});

// ---- Display, sound and accessibility (device preferences) ----
const ACCESS_PREFS = [
  {
    k: 'palette',
    label: 'Colorblind-safe colors',
    desc: 'Blue, orange, green and purple armies (Okabe–Ito), with shape markers.',
    on: v => v === 'colorblind',
    set: on => (on ? 'colorblind' : 'standard'),
  },
  { k: 'shapes', label: 'Army shape markers', desc: 'A circle, square, triangle or diamond beside every unit and in the battle bar.' },
  { k: 'reducedMotion', label: 'Reduced motion', desc: 'No screen shake or explosion particles.' },
  {
    k: 'announce',
    label: 'Screen-reader announcements',
    desc: 'Read out selected units, the hex under the keyboard cursor, and a summary each turn (R repeats it).',
    on: v => v !== false,
  },
  {
    k: 'telemetry',
    label: 'Share balance data',
    desc: 'Off unless you turn it on. After each battle, adds to your totals in the hosted game: which rules were on, your unit types, the kind of map, turns, mode and result. No names, nothing you typed. Everyone’s totals appear on the Leaderboard screen.',
  },
  { k: 'music', label: 'Music', desc: 'Chiptune generated in the browser; it follows the battle.', on: v => v !== false },
];
function renderAccess() {
  const P = appState.prefs;
  $('#access-pick').innerHTML = String(
    html`${ACCESS_PREFS.map(a => {
      const on = a.on ? a.on(P[a.k]) : !!P[a.k];
      return html`<div class="pick-row grant-row">
        <span><b>${a.label}</b><small>${a.desc}</small></span
        ><button class="btn sm alt" data-access="${a.k}" aria-pressed="${on}" aria-label="${a.label}">${on ? 'On' : 'Off'}</button>
      </div>`;
    })}`
  );
}
$('#access-pick').addEventListener('click', e => {
  const b = e.target.closest('[data-access]');
  if (!b) return;
  const a = ACCESS_PREFS.find(x => x.k === b.dataset.access),
    P = appState.prefs;
  const on = !(a.on ? a.on(P[a.k]) : !!P[a.k]);
  P[a.k] = a.set ? a.set(on) : on;
  if (a.k === 'palette') applyPalette();
  if (a.k === 'music' && typeof musicPrefChanged === 'function') musicPrefChanged();
  savePrefs();
  SFX.play('click');
  renderAccess();
  $(`[data-access="${a.k}"]`).focus();
});
