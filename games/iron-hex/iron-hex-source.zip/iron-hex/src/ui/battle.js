function enterBattle(msg) {
  const B = appState.battle;
  R.map = B.map || buildMap(B.mapDef); // the battle's own map
  if (!B.map) attachMap(B, R.map);
  R.session++;
  R.fx = [];
  R.tweens = [];
  R.sel = null;
  R.mode = 'idle';
  R.pending = null;
  R.reach = null;
  R.targets = null;
  R.busy = false;
  R.ended = false;
  ensureLogistics(B);
  initUnitVisuals();
  go('battle');
  resizeCanvas();
  setView(appState.prefs.view || 'iso', true);
  $('#save-status').textContent = msg || '';
  // Replays play turns from their log; everything else starts a turn of orders.
  $('#btn-done').hidden = !!R.replay;
  $('#cards').classList.toggle('replay', !!R.replay);
  if (R.replay) {
    renderHud();
    renderCards();
    banner('Replay');
  } else beginTurn();
  if (!appState.prefs.seenHelp)
    setTimeout(() => {
      if (appState.screen === 'battle') showHelp();
    }, 1600);
}

// ---------- Turn flow ----------
function beginTurn() {
  const B = appState.battle;
  markActive(1500);
  B.orders = {};
  R.aiOrders = {};
  // Overwatch that stands, and moves still under way: for everyone at this device (hot-seat) or just you.
  const here = battleMode(B) === 'hotseat' ? B.players.filter(p => !p.ai).map(p => p.id) : [me()];
  R.standingNote = here.flatMap(pid => applyStanding(B, pid)).join('; ');
  if (battleMode(B) !== 'online') planAIInFrames(B); // online, the resolving device plans the AI armies
  R.busy = false;
  R.mode = 'idle';
  R.sel = null;
  R.reach = null;
  R.targets = null;
  R.pending = null;
  $('#hud-turn').textContent = 'Turn ' + B.turn;
  renderHud();
  renderCards();
  updateDone();
  updateHint();
  const mode = battleMode(B),
    humanAlive = mode === 'hotseat' ? humansAlive(B).length > 0 : inFight(me());
  banner(humanAlive ? 'Turn ' + B.turn : 'Spectating');
  if (humanAlive) setTimeout(() => announce(situationReport()), 400);
  setMusicIntensity(0.3);
  if (mode === 'hotseat' && humanAlive) startHotseatTurn(B);
  const sess = R.session;
  if (!humanAlive && mode !== 'online')
    // online, the match moves on when the remaining players submit
    setTimeout(() => {
      if (appState.screen === 'battle' && !R.ended && R.session === sess) resolveTurn();
    }, 1400);
}

function renderHud() {
  updateLaunchButton();
  R.worldVer = (R.worldVer || 0) + 1; // the world may have changed: refresh the cached terrain
  const hb = $('#btn-diplo');
  if (hb && appState.battle) hb.hidden = !appState.battle.players.some(p => isAlly(me(), p.id));
  const B = appState.battle;
  const pb = $('#btn-prod');
  if (pb) pb.hidden = !(B.rules && (B.rules.production || (B.rules.cityDev && B.rules.income)));
  if (B.rules && B.rules.fog && !B.vis) computeVision(B);
  $('#hud-chips').innerHTML =
    B.players
      .map(p => {
        const n = allAlive().filter(u => u.pid === p.id).length,
          hidden = B.rules && B.rules.fog && isEnemy(me(), p.id);
        const theirs = aliveUnits().filter(u => u.pid === p.id);
        const share = Math.round(100 * territoryShare(B, p.id)),
          V = victory();
        const held = V.mode === 'territory' && B.holds && B.holds[teamOf(p.id)] ? ` ⚑${B.holds[teamOf(p.id)]}/${V.hold}` : ''; // streaks are kept per team
        let status;
        if (!n) status = 'out';
        else if (p.ai) status = R.busy ? 'resolving' : '<span class="ok">✓ ready</span>';
        else if (R.mp && p.id !== me())
          status = R.mp.submitted.includes(p.id) ? '<span class="ok">✓ ready</span>' : 'deciding'; // another player, online
        else status = theirs.every(u => B.orders[u.id]) ? '<span class="ok">✓ ready</span>' : p.id === me() ? 'giving orders' : 'waiting';
        const label = p.ai ? `AI, ${STRATS[p.ai].label.toLowerCase()}` : p.id === me() ? 'You' : playerName(p.id);
        return `<span class="chip ${n ? '' : 'out'}" title="${escapeHtml(p.name)} (${label}), ${n} units, ${share}% territory"><i style="background:${ARMIES[p.id].color}"></i>${shapesOn() ? ARMY_SHAPES[p.id] + ' ' : ''}${p.ai || p.id !== me() ? escapeHtml(p.short || p.name.split(' ')[0]) : 'You'} ${hidden && n ? '?' : n}u ${share}%${held} ${status}</span>`;
      })
      .join('') +
    phase7Chips(B) +
    (B.objective
      ? `<span class="chip rules-chip obj-chip" title="Mission objective">Objective: ${escapeHtml(objectiveLabel(B))}</span>`
      : `<span class="chip rules-chip" title="Victory condition">Goal: ${victorySummary(victory())}</span>`) +
    `<span class="chip rules-chip" title="Active rules: ${rulesSummary(rules())}">Rules: ${
      Object.keys(RULES)
        .filter(k => rules()[k])
        .map(k => RULES[k].short)
        .join(', ') || 'classic'
    }</span>`;
}

function orderLabel(o) {
  if (!o) return 'Awaiting orders';
  if (o.type === 'hold') return (appState.battle.rules.realtime ? 'Overwatch' : 'Hold') + ' (standing)'; // holds stay until you give another order
  if (o.multi) return `Moving: ${o.multi.turns > 1 ? `about ${o.multi.turns} turns` : 'arrives this turn'}`;
  if (o.type === 'flag') return 'Plant flag';
  if (o.type === 'capture') return 'Capture';
  if (o.capture) return 'Move + capture';
  if (o.flag) return 'Move + flag';
  if (o.type === 'repair') {
    const t = unitById(o.mend);
    return 'Repair ' + (t ? t.name : '');
  }
  if (o.type === 'road') return 'Build road';
  if (o.repair) return 'Move + repair';
  if (o.road) return 'Move + road';
  if (o.type === 'build') return 'Build ' + STRUCTS[o.kind].name;
  if (o.type === 'decoy') return 'Plant decoy';
  if (o.type === 'mine') return 'Lay mine';
  if (o.type === 'broadcast') return 'Broadcast';
  if (o.type === 'demolish') return 'Blow bridge';
  if (o.build) return 'Move + build ' + STRUCTS[o.build.kind].name;
  if (o.starget) return o.type === 'move' ? 'Move + bombard' : 'Bombard';
  if (o.type === 'fire') return 'Fire';
  if (o.type === 'engage') return 'Engage';
  if (o.type === 'amove') return 'Attack-move';
  if (o.type === 'load') {
    const c = unitById(o.cargo);
    return 'Load ' + (c ? c.name : '');
  }
  if (o.load) {
    const c = unitById(o.load);
    return 'Move + load ' + (c ? c.name : '');
  }
  if (o.type === 'board') {
    const t = unitById(o.transport);
    return 'Board ' + (t ? t.name : '');
  }
  if (o.type === 'unload') return 'Unload';
  if (o.unload) return 'Move + unload';
  return o.target ? 'Move + fire' : 'Move';
}

function renderCards() {
  const B = appState.battle,
    mine = everyUnit(B).filter(u => u.pid === me()); // your fallen keep their (greyed) cards
  $('#cards').innerHTML = mine
    .map(u => {
      const hp = u.dispHp ?? u.hp;
      const pct = Math.round((100 * hp) / u.maxHp),
        cls = pct < 34 ? 'low' : pct < 67 ? 'mid' : '';
      const dead = hp <= 0,
        aboard = !dead && u.in ? unitById(u.in) : null;
      const cargo = u.cargo ? unitById(u.cargo) : null;
      const ordText = dead
        ? 'Destroyed'
        : aboard
          ? 'Aboard ' + aboard.name
          : orderLabel(B.orders[u.id]) + (cargo ? ' (carrying ' + cargo.name + ')' : '');
      return `<button class="card ${dead ? 'dead' : ''}" data-uid="${escapeHtml(u.id)}" aria-current="${R.sel && R.sel.id === u.id}" ${dead || aboard ? 'disabled' : ''} aria-label="${escapeHtml(u.name)}, ${hp} of ${u.maxHp} health, ${u.ammo} ammo, ${orderLabel(B.orders[u.id])}">
      <canvas class="px" width="24" height="18" data-thumb="${escapeHtml(u.type)}" data-thumb-uid="${escapeHtml(u.id)}"></canvas>
      <span class="cn">${escapeHtml(u.name)}${dead ? '' : moraleBadge(u) + realismBadge(u)}</span>
      <span><span class="bar ${cls}" style="--pct:${pct}%"><i></i></span>${u.maxFuel ? `<span class="bar fuel ${u.fuel <= u.maxFuel * 0.3 ? 'low' : ''}" style="--pct:${Math.round((100 * u.fuel) / u.maxFuel)}%" title="Fuel ${Math.round(u.fuel)}/${u.maxFuel}"><i></i></span>` : ''}</span>
      <span class="meta"><span>${dead ? 'KIA' : hp + '/' + u.maxHp}</span><span class="ammo" title="Ammo">${'▮'.repeat(u.ammo)}${'▯'.repeat(Math.max(0, u.maxAmmo - u.ammo))}</span></span>
      <span class="ord ${B.orders[u.id] || aboard ? 'set' : ''}">${escapeHtml(ordText)}</span></button>`;
    })
    .join('');
  $$('[data-thumb]').forEach(cv => {
    const x = cv.getContext('2d');
    x.imageSmoothingEnabled = false;
    const tu = unitById(+cv.dataset.thumbUid),
      s = tu ? spriteFor(tu) : SPR[cv.dataset.thumb][0];
    x.clearRect(0, 0, cv.width, cv.height);
    x.drawImage(s.n, Math.round((cv.width - s.w) / 2), Math.round((cv.height - s.h) / 2));
  });
}

$('#cards').addEventListener('click', e => {
  if (R.replay) return;
  const c = e.target.closest('[data-uid]');
  if (!c || R.busy) return;
  const u = unitById(+c.dataset.uid);
  if (!u || u.hp <= 0 || u.in) return;
  const t = tileAt(u.c, u.r);
  R.cam.x = t.wx;
  R.cam.y = t.wy;
  selectUnit(u);
});

function updateDone() {
  const B = appState.battle,
    mine = aliveUnits().filter(u => u.pid === me());
  $('#btn-done').disabled = R.busy || R.planning || !mine.length || !mine.every(u => B.orders[u.id]);
  $('#btn-done').textContent = R.busy
    ? 'Resolving…'
    : R.planning
      ? 'Enemy planning…'
      : battleMode(B) === 'hotseat' && (R.seatQueue || []).length > 1
        ? 'Done: next player'
        : 'Done';
  const od = onlineDoneState();
  if (od) {
    $('#btn-done').disabled = true;
    $('#btn-done').textContent = od.text;
  }
}

function updateHint() {
  const B = appState.battle,
    mine = aliveUnits().filter(u => u.pid === me());
  const n = mine.filter(u => B.orders[u.id]).length;
  let h = '';
  if (R.busy) h = 'Orders are resolving…';
  else if (R.mode === 'unload') h = 'Pick a green beach hex to land the cargo. It can act next turn.';
  else if (R.mode === 'load') h = 'Pick a green unit to load aboard.';
  else if (R.mode === 'bridge') h = 'Pick a green shallow-water hex for the bridge.';
  else if (R.mode === 'starget') h = 'Pick a red structure to bombard. Capturable ones can be taken intact by infantry instead.';
  else if (R.mode === 'repair') h = 'Pick a damaged green unit to repair. It must still be next to the engineer when the turn ends.';
  else if (R.mode === 'move' && R.amove) h = 'Attack-move: pick a blue hex. The unit stops at the first enemy in range.';
  else if (R.mode === 'move')
    h = R.amove
      ? 'Pick a blue hex to attack-move to. Esc to cancel.'
      : 'Blue: this turn. Fainter rings: 2, 3 and 4 turns away; the unit keeps going each turn until it arrives. Esc to cancel.';
  else if (R.mode === 'target' && R.targets && R.targets.engage)
    h = 'Engage: pick an enemy to chase. The unit closes in and fires once in range.';
  else if (R.mode === 'target') h = 'Pick a red target. Enemies that move out of range will be missed.';
  else if (mine.length)
    h = n === mine.length ? 'All units have orders. Press Done.' : `Tap a unit to give orders. ${n} of ${mine.length} ready.`;
  $('#hint').textContent = h;
  if (R.standingNote && R.mode === 'idle' && !R.busy) {
    const el = $('#hint');
    if (el) el.textContent = `${el.textContent} Standing orders: ${R.standingNote}.`;
  }
}

function banner(text) {
  const host = $('#banner-host');
  host.innerHTML = '';
  const b = document.createElement('div');
  b.className = 'banner';
  b.textContent = text;
  host.appendChild(b);
  setTimeout(() => b.remove(), 1500);
}

// AI armies plan one per frame, so a big battle doesn't freeze the page as a turn starts. Same order as before,
// so the seeded random choices (and battle results) are unchanged. Done stays disabled until every army is ready.
async function planAIInFrames(B) {
  const sess = R.session;
  R.planning = true;
  updateDone();
  for (const p of B.players) {
    if (!p.ai || !allAlive().some(u => u.pid === p.id)) continue;
    await new Promise(r => setTimeout(r, 0));
    if (R.session !== sess || appState.battle !== B) return; // the battle was left or replaced meanwhile
    Object.assign(R.aiOrders, planAI(p));
  }
  R.planning = false;
  updateDone();
}

// A human player's display name: online, the person in that seat (resolved fresh each time); otherwise the army.
function playerName(pid) {
  const n = R.mp && R.mp.names && R.mp.names[pid];
  return n || (appState.battle.players[pid] && appState.battle.players[pid].short) || 'Player';
}
