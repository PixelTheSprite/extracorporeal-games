// Unit Editor: look up a real vehicle (Claude in the hosted page, or copy-paste), check and adjust its stats,
// set game values and abilities, draw or import pixel art, then save. Units live in this browser and can be
// exported to / imported from a .json file.
const LS_UNITS = 'ironhex_units';
const loadUnits = () => storedList(LS_UNITS),
  storeUnits = list => store.set(LS_UNITS, list);
const UNIT_PAL = a => ({ k: '#1b140e', t: a.color, d: a.dark, l: a.light, g: '#8b97a3', w: '#3a3a3a', s: '#e8b888' });
const PAL_LABEL = { '.': 'Clear', k: 'Outline', t: 'Paint', d: 'Paint (dark)', l: 'Paint (light)', g: 'Metal', w: 'Dark metal', s: 'Skin' };
function buildUnitSprite(id) {
  SPR[id] = ARMIES.map(a => makeSprite(SPRITE_ART[id], UNIT_PAL(a)));
  SPR_WHITE[id] = makeSprite(SPRITE_ART[id], { k: 1, t: 1, d: 1, l: 1, g: 1, w: 1, s: 1 }, '#ffffff');
}
// Custom types can arrive from storage, a loaded save or an import: make sure each has sprites.
function ensureCustomSprites() {
  for (const T of Object.values(UNIT_TYPES))
    if (T.custom && (!SPR[T.id] || SPRITE_ART[T.id] !== T.art)) {
      SPRITE_ART[T.id] = T.art;
      buildUnitSprite(T.id);
    }
}
function installCustomUnit(T) {
  const p = registerCustomUnit(T);
  if (!p.length) {
    SPRITE_ART[T.id] = T.art;
    buildUnitSprite(T.id);
  }
  return p;
}
function loadCustomUnitsAtBoot() {
  const bad = [];
  for (const T of loadUnits()) {
    const p = installCustomUnit(T);
    if (p.length) bad.push(...p);
  }
  if (bad.length) console.warn('Custom units skipped:\n' + bad.join('\n'));
}

const ue = { draft: null, sample: undefined, busy: false, ctl: null, color: 't', tool: 'pencil', painting: false, status: '' };
function ueNewDraft(fromId = 'tank') {
  const d = draftFromUnit(UNIT_TYPES[fromId], true);
  d.name = 'New unit';
  d.short = 'Unit';
  return d;
}
async function ueSample() {
  if (ue.sample !== undefined) return ue.sample;
  try {
    ue.sample = window.claude && window.claude.use ? await window.claude.use('sample') : null;
  } catch (e) {
    ue.sample = null;
  }
  return ue.sample;
}
const ueSay = msg => {
  ue.status = msg;
  const el = $('#ue-status');
  if (el) el.textContent = msg;
};

async function renderUnitEdit() {
  if (!ue.draft) ue.draft = ueNewDraft();
  ensureCustomSprites();
  const d = ue.draft,
    q = $('#ue-query').value;
  $('#ue-prompt').value = lookupPrompt(q.trim() || 'NAME OF THE VEHICLE');
  $('#ue-base').innerHTML =
    '<option value="">Start from an existing unit…</option>' +
    TYPE_ORDER.map(
      t => `<option value="${escapeHtml(t)}">${escapeHtml(UNIT_TYPES[t].name)}${UNIT_TYPES[t].custom ? ' (custom)' : ''}</option>`
    ).join('');
  $('#ue-name').value = d.name;
  $('#ue-short').value = d.short;
  $('#ue-role').value = d.role;
  $('#ue-domain').innerHTML = DOMAINS.map(x => `<option value="${x}" ${x === d.domain ? 'selected' : ''}>${DOMAIN_LABEL[x]}</option>`).join(
    ''
  );
  ueRenderStats();
  ueRenderGame();
  ueRenderArt();
  ueRenderList();
  $('#ue-status').textContent = ue.status;
  const s = await ueSample();
  $('#btn-ue-lookup').hidden = !s;
  $('#ue-lookup-note').textContent = s
    ? "Claude looks the vehicle up and fills in the form (uses your Claude usage; the first lookup asks permission). Lookups come from Claude's knowledge, not live sources: check the numbers before relying on them."
    : "Built-in lookup isn't available here (it needs the hosted game). Use copy and paste below, or fill in the form by hand.";
  if (!s) $('#ue-manual').open = true;
}
function ueRenderStats() {
  const d = ue.draft;
  $('#ue-stats').innerHTML =
    `<thead><tr><th>Stat</th><th>Real value</th><th>Scale</th><th>Score</th><th>Override</th></tr></thead><tbody>` +
    STAT_KEYS.map(k => {
      const s = d.stats[k],
        sc = STAT_SCALES[d.domain][k],
        rated = s.rated || !sc.max;
      const score = s.override != null ? s.override : rated ? clamp(Math.round(s.value), 0, 10) : scoreStat(d.domain, k, s.value);
      return `<tr class="stat-main"><td>${STAT_LABEL[k]}</td>
      <td><input type="number" step="any" min="0" data-ue-val="${escapeHtml(k)}" value="${s.value}" aria-label="${STAT_LABEL[k]} real value"></td>
      <td>${rated ? 'Rating 0–10' : `0–${sc.max} ${sc.unit}`}${sc.ratedOk ? `<label class="mini"><input type="checkbox" data-ue-rated="${escapeHtml(k)}" ${rated ? 'checked' : ''}> rated</label>` : ''}</td>
      <td><b class="score">${score}</b></td>
      <td><input type="number" min="0" max="10" step="1" data-ue-ovr="${escapeHtml(k)}" value="${s.override ?? ''}" placeholder="–" aria-label="${STAT_LABEL[k]} score override"></td></tr>
      <tr class="stat-note"><td colspan="5"><input type="text" maxlength="120" data-ue-note="${escapeHtml(k)}" value="${escapeHtml(s.note || '')}" placeholder="What the number is (e.g. road speed, turret front)" aria-label="${STAT_LABEL[k]} note"></td></tr>`;
    }).join('') +
    '</tbody>';
  $('#ue-sources').innerHTML =
    (d.sources.length ? `<li><b>Sources named by the lookup:</b> ${d.sources.map(escapeHtml).join('; ')}</li>` : '') +
    (d.confidence ? `<li><b>Confidence:</b> ${escapeHtml(d.confidence)}</li>` : '') +
    (d.caveats ? `<li><b>Caveats:</b> ${escapeHtml(d.caveats)}</li>` : '');
  ueRenderDerived();
}
function ueRenderDerived() {
  const T = unitFromDraft(ue.draft);
  derive(T);
  $('#ue-derived').innerHTML =
    `<span>Move ${T.move}</span><span>HP ${T.hp}</span><span>Evasion ${T.evade}%</span><span>${STAT_KEYS.map(k => T.stats[k]).join(' / ')}</span>`;
}
function ueRenderGame() {
  const d = ue.draft,
    ab = new Set(d.abilities);
  $('#ue-rmin').value = d.range[0];
  $('#ue-rmax').value = d.range[1];
  $('#ue-ammo').value = d.ammo;
  $('#ue-fuel').value = d.fuel ?? '';
  $('#ue-fuel').disabled = d.domain === 'land' && ab.has('foot');
  for (const x of DOMAINS) $(`#ue-eff-${x}`).value = d.eff[x];
  $('#ue-abilities').innerHTML = Object.entries(ABILITIES)
    .filter(([k]) => d.domain === 'land' || !['captures', 'foot'].includes(k))
    .map(
      ([k, label]) =>
        `<label class="check"><input type="checkbox" data-ue-ab="${escapeHtml(k)}" ${ab.has(k) ? 'checked' : ''}> ${label}</label>`
    )
    .join('');
  ueRenderDerived();
}
// ---- pixel editor ----
function ueRenderArt() {
  const a = ue.draft.art;
  $('#ue-aw').value = a[0].length;
  $('#ue-ah').value = a.length;
  $('#ue-palette').innerHTML = [...SPRITE_KEYS]
    .map(
      k =>
        `<button class="btn sm alt sw-btn" data-ue-color="${escapeHtml(k)}" aria-pressed="${ue.color === k}" title="${PAL_LABEL[k]}"><i style="background:${k === '.' ? 'transparent' : UNIT_PAL(ARMIES[0])[k]}"></i>${PAL_LABEL[k]}</button>`
    )
    .join('');
  $('#ue-tools').innerHTML =
    [
      ['pencil', 'Pencil'],
      ['fill', 'Fill'],
    ]
      .map(([k, n]) => `<button class="btn sm alt" data-ue-tool="${escapeHtml(k)}" aria-pressed="${ue.tool === k}">${n}</button>`)
      .join('') + '<button class="btn sm alt" id="btn-ue-flip">Flip</button><button class="btn sm alt" id="btn-ue-clear">Clear</button>';
  drawArt();
}
function drawArt() {
  const cv = $('#ue-canvas'),
    x = cv.getContext('2d'),
    a = ue.draft.art,
    H = a.length,
    W = a[0].length;
  const cs = Math.floor(Math.min(cv.width / W, cv.height / H)),
    ox = Math.floor((cv.width - cs * W) / 2),
    oy = Math.floor((cv.height - cs * H) / 2);
  ue.grid = { cs, ox, oy, W, H };
  x.fillStyle = '#10213d';
  x.fillRect(0, 0, cv.width, cv.height);
  const pal = UNIT_PAL(ARMIES[0]);
  for (let r = 0; r < H; r++)
    for (let c = 0; c < W; c++) {
      const k = a[r][c];
      x.fillStyle = k === '.' ? ((r + c) % 2 ? '#2a3a55' : '#22314a') : pal[k];
      x.fillRect(ox + c * cs, oy + r * cs, cs, cs);
    }
  x.strokeStyle = 'rgba(255,255,255,.08)';
  for (let c = 0; c <= W; c++) {
    x.beginPath();
    x.moveTo(ox + c * cs + 0.5, oy);
    x.lineTo(ox + c * cs + 0.5, oy + H * cs);
    x.stroke();
  }
  for (let r = 0; r <= H; r++) {
    x.beginPath();
    x.moveTo(ox, oy + r * cs + 0.5);
    x.lineTo(ox + W * cs, oy + r * cs + 0.5);
    x.stroke();
  }
  // previews in every army color, at game scale (2x)
  const pv = $('#ue-preview'),
    px = pv.getContext('2d');
  px.imageSmoothingEnabled = false;
  px.clearRect(0, 0, pv.width, pv.height);
  ARMIES.forEach((arm, i) => {
    const s = makeSprite(a, UNIT_PAL(arm));
    px.drawImage(s.n, 4 + i * (pv.width / 4), Math.round((pv.height - H * 2) / 2), W * 2, H * 2);
  });
}
function ueCellAt(e) {
  const cv = $('#ue-canvas'),
    rc = cv.getBoundingClientRect(),
    g = ue.grid;
  const px = ((e.clientX - rc.left) * cv.width) / rc.width,
    py = ((e.clientY - rc.top) * cv.height) / rc.height;
  const c = Math.floor((px - g.ox) / g.cs),
    r = Math.floor((py - g.oy) / g.cs);
  return c >= 0 && r >= 0 && c < g.W && r < g.H ? { c, r } : null;
}
function uePaint(cell) {
  const a = ue.draft.art.map(r => r.split(''));
  if (ue.tool === 'fill') {
    const from = a[cell.r][cell.c];
    if (from === ue.color) return;
    const q = [cell];
    while (q.length) {
      const { c, r } = q.pop();
      if (a[r] && a[r][c] === from) {
        a[r][c] = ue.color;
        q.push({ c: c + 1, r }, { c: c - 1, r }, { c, r: r + 1 }, { c, r: r - 1 });
      }
    }
  } else a[cell.r][cell.c] = ue.color;
  ue.draft.art = a.map(r => r.join(''));
  drawArt();
}
function ueResizeArt(W, H) {
  W = clamp(W | 0, 4, ART_MAX.W);
  H = clamp(H | 0, 4, ART_MAX.H);
  const a = ue.draft.art,
    oh = a.length;
  // keep the bottom-left: the sprite stands on its bottom row
  ue.draft.art = Array.from({ length: H }, (_, r) => {
    const src = a[r - (H - oh)];
    return Array.from({ length: W }, (_, c) => (src && src[c]) || '.').join('');
  });
  ueRenderArt();
}
// Image -> sprite rows in the game palette: drop the background, shrink to fit, map colors, add an outline.
function imageToArt(img, maxW, maxH, outline) {
  const cv = document.createElement('canvas');
  cv.width = img.naturalWidth;
  cv.height = img.naturalHeight;
  const x = cv.getContext('2d');
  x.drawImage(img, 0, 0);
  const { data, width: w, height: h } = x.getImageData(0, 0, cv.width, cv.height);
  const px = (i, j) => {
    const o = (j * w + i) * 4;
    return [data[o], data[o + 1], data[o + 2], data[o + 3]];
  };
  const corner = px(0, 0),
    opaqueBg = corner[3] > 200;
  const isBg = p => p[3] < 128 || (opaqueBg && Math.abs(p[0] - corner[0]) + Math.abs(p[1] - corner[1]) + Math.abs(p[2] - corner[2]) < 60);
  let x0 = w,
    y0 = h,
    x1 = -1,
    y1 = -1;
  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++)
      if (!isBg(px(i, j))) {
        x0 = Math.min(x0, i);
        y0 = Math.min(y0, j);
        x1 = Math.max(x1, i);
        y1 = Math.max(y1, j);
      }
  if (x1 < 0) throw new Error('The image looks empty (only background).');
  const bw = x1 - x0 + 1,
    bh = y1 - y0 + 1,
    sc = Math.min(maxW / bw, maxH / bh);
  const W = Math.max(4, Math.round(bw * sc)),
    H = Math.max(4, Math.round(bh * sc));
  const classify = (r, g, b) => {
    const mx = Math.max(r, g, b) / 255,
      mn = Math.min(r, g, b) / 255,
      l = (mx + mn) / 2,
      d = mx - mn;
    const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
    let hue = 0;
    if (d) {
      const R = r / 255,
        G = g / 255,
        B = b / 255;
      hue = mx === R ? ((G - B) / d) % 6 : mx === G ? (B - R) / d + 2 : (R - G) / d + 4;
      hue = (hue * 60 + 360) % 360;
    }
    if (l < 0.18) return 'k';
    if (s < 0.2) return l < 0.4 ? 'w' : 'g';
    if (hue >= 15 && hue <= 45 && s < 0.65 && l > 0.55 && l < 0.85) return 's';
    return l < 0.35 ? 'd' : l < 0.62 ? 't' : 'l';
  };
  const rows = [];
  for (let r = 0; r < H; r++) {
    let row = '';
    for (let c = 0; c < W; c++) {
      const sx0 = x0 + Math.floor((c * bw) / W),
        sx1 = x0 + Math.max(Math.floor(((c + 1) * bw) / W), Math.floor((c * bw) / W) + 1);
      const sy0 = y0 + Math.floor((r * bh) / H),
        sy1 = y0 + Math.max(Math.floor(((r + 1) * bh) / H), Math.floor((r * bh) / H) + 1);
      let n = 0,
        fg = 0,
        R = 0,
        G = 0,
        B = 0;
      for (let j = sy0; j < sy1; j++)
        for (let i = sx0; i < sx1; i++) {
          n++;
          const p = px(i, j);
          if (!isBg(p)) {
            fg++;
            R += p[0];
            G += p[1];
            B += p[2];
          }
        }
      row += fg * 2 < n ? '.' : classify(R / fg, G / fg, B / fg);
    }
    rows.push(row);
  }
  if (outline) {
    const a = rows.map(r => r.split('')),
      out = a.map(r => r.slice());
    for (let r = 0; r < H; r++)
      for (let c = 0; c < W; c++) {
        if (a[r][c] === '.') continue;
        const edge = [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ].some(([dc, dr]) => {
          const n = a[r + dr] && a[r + dr][c + dc];
          return !n || n === '.';
        });
        if (edge) out[r][c] = 'k';
      }
    return out.map(r => r.join(''));
  }
  return rows;
}
function ueRenderList() {
  const list = loadUnits();
  $('#ue-list').innerHTML = list.length
    ? list
        .map(
          T => `<div class="layout-row"><span class="ue-row"><canvas class="px" width="24" height="16" data-spr-type="${escapeHtml(T.id)}" data-spr-pid="0"></canvas><span><b>${escapeHtml(T.name)}</b><small>${escapeHtml(T.role)}, ${DOMAIN_LABEL[T.domain].toLowerCase()} · ${STAT_KEYS.map(k => T.stats[k]).join('/')}${UNIT_TYPES[T.id] ? '' : ' · not installed'}</small></span></span>
    <span class="row-btns"><button class="btn sm alt" data-ue-edit="${escapeHtml(T.id)}">Edit</button><button class="btn sm alt" data-ue-export="${escapeHtml(T.id)}">Export</button><button class="btn sm" data-ue-roster="${escapeHtml(T.id)}">Add to roster</button><button class="btn sm red" data-ue-del="${escapeHtml(T.id)}" aria-label="Delete ${escapeHtml(T.name)}">✕</button></span></div>`
        )
        .join('')
    : '<p class="src">No custom units yet.</p>';
  paintSprites($('#ue-list'));
}
// Export: the hosted page's downloads capability, or a plain download link when the file is opened locally.
async function ueDownload(filename, text) {
  const dl = window.claude && window.claude.use ? await window.claude.use('downloads').catch(() => null) : null;
  if (dl) {
    try {
      await dl.save({ filename, data: text });
      return 'Export ready: confirm the download.';
    } catch (e) {
      return e && e.code === 'declined' ? 'Export cancelled.' : 'Export failed: ' + ((e && e.message) || 'unavailable');
    }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(a.href);
    a.remove();
  }, 500);
  return 'Exported ' + filename + '.';
}
const ueExportText = units => JSON.stringify({ app: 'iron-hex-units', version: 1, exportedAt: new Date().toISOString(), units }, null, 2);
function ueApplyAnswer(answer) {
  const art = ue.draft.art,
    id = ue.draft.id;
  const d = parseLookup(answer);
  d.id = id;
  d.art = art.join('').replace(/\./g, '').length
    ? art
    : draftFromUnit(UNIT_TYPES[d.domain === 'air' ? 'plane' : d.domain === 'sea' ? 'ship' : 'tank'], true).art;
  ue.draft = d;
  renderUnitEdit();
  ueSay(
    `Filled in from the lookup for ${d.name}${d.confidence ? ` (${d.confidence} confidence)` : ''}. Check each value; type a score in Override to change it.`
  );
}

// ---- events ----
const ueCanvas = $('#ue-canvas');
ueCanvas.addEventListener('pointerdown', e => {
  const c = ueCellAt(e);
  if (!c) return;
  ueCanvas.setPointerCapture(e.pointerId);
  ue.painting = ue.tool === 'pencil';
  uePaint(c);
});
ueCanvas.addEventListener('pointermove', e => {
  if (!ue.painting) return;
  const c = ueCellAt(e);
  if (c) uePaint(c);
});
const ueStop = () => {
  ue.painting = false;
};
ueCanvas.addEventListener('pointerup', ueStop);
ueCanvas.addEventListener('pointercancel', ueStop);
$('#scr-unitedit').addEventListener('input', e => {
  const d = ue.draft,
    t = e.target;
  if (t.dataset.ueVal) {
    const v = parseFloat(t.value);
    if (isFinite(v)) {
      d.stats[t.dataset.ueVal].value = Math.max(0, v);
      ueRenderStatsKeepFocus();
    }
  } else if (t.dataset.ueOvr) {
    const v = t.value === '' ? null : clamp(Math.round(+t.value), 0, 10);
    d.stats[t.dataset.ueOvr].override = v;
    ueRenderStatsKeepFocus();
  } else if (t.dataset.ueNote) d.stats[t.dataset.ueNote].note = t.value;
  else if (t.id === 'ue-query') $('#ue-prompt').value = lookupPrompt(t.value.trim() || 'NAME OF THE VEHICLE');
});
// Re-render the scores without losing the field being typed in
function ueRenderStatsKeepFocus() {
  const d = ue.draft;
  $$('#ue-stats tbody tr.stat-main').forEach((tr, i) => {
    const k = STAT_KEYS[i],
      s = d.stats[k],
      sc = STAT_SCALES[d.domain][k],
      rated = s.rated || !sc.max;
    tr.querySelector('.score').textContent =
      s.override != null ? s.override : rated ? clamp(Math.round(s.value), 0, 10) : scoreStat(d.domain, k, s.value);
  });
  ueRenderDerived();
}
$('#scr-unitedit').addEventListener('change', async e => {
  const d = ue.draft,
    t = e.target;
  if (t.id === 'ue-name') d.name = t.value.trim();
  else if (t.id === 'ue-short') d.short = t.value.trim().slice(0, 10);
  else if (t.id === 'ue-role') d.role = t.value.trim();
  else if (t.id === 'ue-domain') {
    d.domain = t.value;
    for (const k of STAT_KEYS) {
      const sc = STAT_SCALES[d.domain][k];
      if (!sc.max) d.stats[k].rated = true;
      else if (!sc.ratedOk) d.stats[k].rated = false;
    }
    d.eff = Object.assign({}, EFF[d.domain]);
    d.abilities = d.abilities.filter(a => d.domain === 'land' || !['captures', 'foot'].includes(a));
    ueRenderStats();
    ueRenderGame();
  } else if (t.dataset.ueRated) {
    d.stats[t.dataset.ueRated].rated = t.checked;
    ueRenderStats();
  } else if (t.id === 'ue-rmin' || t.id === 'ue-rmax') {
    d.range = [clamp(+$('#ue-rmin').value | 0, 0, 4), clamp(+$('#ue-rmax').value | 0, 0, 6)];
    if (d.range[1] < d.range[0]) d.range[1] = d.range[0];
    ueRenderGame();
  } else if (t.id === 'ue-ammo') {
    d.ammo = clamp(+t.value | 0, 1, 12);
    ueRenderGame();
  } else if (t.id === 'ue-fuel') {
    d.fuel = t.value === '' ? null : clamp(+t.value | 0, 5, 99);
    ueRenderGame();
  } else if (t.id && t.id.startsWith('ue-eff-')) {
    d.eff[t.id.slice(7)] = clamp(Math.round(+t.value * 10) / 10, 0, 2);
  } else if (t.dataset.ueAb) {
    const s = new Set(d.abilities);
    t.checked ? s.add(t.dataset.ueAb) : s.delete(t.dataset.ueAb);
    d.abilities = [...s];
    if (t.dataset.ueAb === 'foot' && t.checked) d.fuel = null;
    ueRenderGame();
  } else if (t.id === 'ue-aw' || t.id === 'ue-ah') ueResizeArt(+$('#ue-aw').value, +$('#ue-ah').value);
  else if (t.id === 'ue-base' && t.value) {
    ue.draft = draftFromUnit(UNIT_TYPES[t.value], !UNIT_TYPES[t.value].custom);
    ueSay(`Started from ${UNIT_TYPES[t.value].name}.`);
    renderUnitEdit();
  } else if (t.id === 'ue-image' && t.files && t.files[0]) {
    const f = t.files[0],
      url = URL.createObjectURL(f),
      img = new Image();
    img.onload = () => {
      try {
        ue.draft.art = imageToArt(img, +$('#ue-aw').value || 16, +$('#ue-ah').value || 12, $('#ue-outline').checked);
        ueRenderArt();
        ueSay('Image converted. Saturated colors became the army paint; touch it up with the pencil.');
      } catch (err) {
        ueSay(err.message);
      }
      URL.revokeObjectURL(url);
      t.value = '';
    };
    img.onerror = () => {
      ueSay('That file could not be read as an image.');
      t.value = '';
    };
    img.src = url;
  } else if (t.id === 'ue-import' && t.files && t.files[0]) {
    if (tooBig(t.files[0])) {
      ueSay('That file is too large to be a unit export (over 5 MB).');
      t.value = '';
      return;
    }
    try {
      const j = JSON.parse(await t.files[0].text()),
        units = j && j.app === 'iron-hex-units' && Array.isArray(j.units) ? j.units : null;
      if (!units) throw new Error('That file is not an Iron Hex unit export.');
      const list = loadUnits();
      let ok = 0;
      const bad = [];
      for (const T of units) {
        if (typeof T.id !== 'string' || !SAFE_UNIT_ID.test(T.id) || (UNIT_TYPES[T.id] && !UNIT_TYPES[T.id].custom))
          T.id = slugId(String(T.name || 'unit'));
        const p = installCustomUnit(T);
        if (p.length) {
          bad.push(`${T.name || T.id}: ${p[0]}`);
          continue;
        }
        const i = list.findIndex(x => x.id === T.id);
        if (i >= 0) list[i] = T;
        else list.push(T);
        ok++;
      }
      storeUnits(list);
      ueSay(`Imported ${ok} unit${ok === 1 ? '' : 's'}.${bad.length ? ' Skipped: ' + bad.join('; ') : ''}`);
      ueRenderList();
    } catch (err) {
      ueSay(err.message);
    }
    t.value = '';
  }
});
$('#scr-unitedit').addEventListener('click', async e => {
  const t = e.target;
  const col = t.closest('[data-ue-color]');
  if (col) {
    ue.color = col.dataset.ueColor;
    ueRenderArt();
    return;
  }
  const tool = t.closest('[data-ue-tool]');
  if (tool) {
    ue.tool = tool.dataset.ueTool;
    ueRenderArt();
    return;
  }
  if (t.closest('#btn-ue-flip')) {
    ue.draft.art = ue.draft.art.map(r => [...r].reverse().join(''));
    drawArt();
    return;
  }
  if (t.closest('#btn-ue-clear')) {
    ue.draft.art = ue.draft.art.map(r => '.'.repeat(r.length));
    drawArt();
    return;
  }
  if (t.closest('#btn-ue-lookup')) {
    const q = $('#ue-query').value.trim();
    if (!q) {
      ueSay('Type the name of a vehicle, aircraft or ship first.');
      return;
    }
    const sample = await ueSample();
    if (!sample || ue.busy) return;
    ue.busy = true;
    ue.ctl = new AbortController();
    $('#btn-ue-stop').hidden = false;
    $('#btn-ue-lookup').disabled = true;
    ueSay(`Thinking… looking up ${q}. This can take up to a minute.`);
    try {
      ueApplyAnswer(await sample.json(lookupPrompt(q), { signal: ue.ctl.signal, modelTier: 'default' }));
    } catch (err) {
      const code = err && err.code;
      if (['not_granted', 'sampling_disabled', 'not_declared', 'capability_disabled', 'capability_removed'].includes(code)) {
        ue.sample = null;
        $('#btn-ue-lookup').hidden = true;
        $('#ue-manual').open = true;
        ueSay("Lookups with Claude aren't available here. Use copy and paste below.");
      } else if (code === 'cancelled') ueSay('Lookup stopped.');
      else if (code === 'rate_limited') ueSay('Too many lookups just now. Wait a moment, then try again.');
      else if (code === 'invalid_json') {
        $('#ue-answer').value = err.text || '';
        $('#ue-manual').open = true;
        ueSay("The answer wasn't clean JSON. It's in the answer box below: fix it or try again.");
      } else if (code) ueSay(`Lookup failed (${code}). Try again, or use copy and paste below.`);
      else ueSay(err.message || 'Lookup failed.');
    } finally {
      ue.busy = false;
      $('#btn-ue-stop').hidden = true;
      $('#btn-ue-lookup').disabled = false;
    }
    return;
  }
  if (t.closest('#btn-ue-stop')) {
    if (ue.ctl) ue.ctl.abort();
    return;
  }
  if (t.closest('#btn-ue-copy')) {
    const p = $('#ue-prompt');
    try {
      await navigator.clipboard.writeText(p.value);
      ueSay('Prompt copied. Paste it into a Claude chat, then paste the answer below.');
    } catch (err) {
      p.select();
      ueSay('Select-all is on: copy the prompt with Ctrl+C / Cmd+C.');
    }
    return;
  }
  if (t.closest('#btn-ue-use')) {
    try {
      ueApplyAnswer($('#ue-answer').value);
    } catch (err) {
      ueSay(err.message);
    }
    return;
  }
  if (t.closest('#btn-ue-new')) {
    ue.draft = ueNewDraft();
    $('#ue-query').value = '';
    ueSay('New unit (starting from the Sherman’s stats and art).');
    renderUnitEdit();
    return;
  }
  if (t.closest('#btn-ue-save')) {
    const d = ue.draft;
    d.name = $('#ue-name').value.trim() || d.name;
    d.short = ($('#ue-short').value.trim() || d.short).slice(0, 10);
    d.role = $('#ue-role').value.trim() || d.role;
    const T = unitFromDraft(d),
      p = installCustomUnit(T);
    if (p.length) {
      ueSay('Not saved: ' + p.map(x => x.replace(/^[^:]+: /, '')).join('; '));
      return;
    }
    d.id = T.id;
    const list = loadUnits(),
      i = list.findIndex(x => x.id === T.id);
    if (i >= 0) list[i] = T;
    else list.push(T);
    ueSay(
      storeUnits(list)
        ? `Saved ${T.name}: speed ${T.stats.speed}, maneuver ${T.stats.maneuver}, armor ${T.stats.armor}, firepower ${T.stats.firepower}. It's in the Unit library; add it to your roster to field it.`
        : 'Saved for this session only: browser storage is unavailable.'
    );
    ueRenderList();
    return;
  }
  const ed = t.closest('[data-ue-edit]'),
    ex = t.closest('[data-ue-export]'),
    ro = t.closest('[data-ue-roster]'),
    dl = t.closest('[data-ue-del]');
  const id = ed ? ed.dataset.ueEdit : ex ? ex.dataset.ueExport : ro ? ro.dataset.ueRoster : dl ? dl.dataset.ueDel : null;
  if (t.closest('#btn-ue-export-all')) {
    const units = loadUnits();
    ueSay(units.length ? await ueDownload('iron-hex-units.json', ueExportText(units)) : 'No custom units to export yet.');
    return;
  }
  if (!id) return;
  const list = loadUnits(),
    T = list.find(x => x.id === id);
  if (!T) return;
  if (ed) {
    ue.draft = draftFromUnit(T, false);
    ueSay(`Editing ${T.name}.`);
    renderUnitEdit();
  } else if (ex) ueSay(await ueDownload(`${T.short.replace(/[^a-z0-9-]+/gi, '-').toLowerCase() || 'unit'}.json`, ueExportText([T])));
  else if (ro) {
    const R0 = (appState.settings.roster = appState.settings.roster || Object.assign({}, DEFAULT_ROSTER));
    if (rosterTotal(R0) >= ROSTER_MAX_TOTAL) ueSay(`Your roster is full (${ROSTER_MAX_TOTAL} units). Make room in Battle settings.`);
    else if ((R0[id] || 0) >= ROSTER_MAX_EACH) ueSay(`You already have ${ROSTER_MAX_EACH} of these.`);
    else {
      R0[id] = (R0[id] || 0) + 1;
      ueSay(`${T.name} added: ${R0[id]} per army.`);
    }
  } else if (dl) {
    storeUnits(list.filter(x => x.id !== id));
    unregisterCustomUnit(id);
    if (appState.settings.roster) delete appState.settings.roster[id];
    if (ue.draft.id === id) ue.draft.id = null;
    ueSay(`Deleted ${T.name}. Saved battles that used it still carry its definition.`);
    ueRenderList();
  }
});
