// Records: local battle records and the unit profile, the optional shared board, end-of-battle bookkeeping
// (records, unlocks, campaign progress), and the Leaderboard screen.
// ---- Records and profile ----------------------------------------------------
const LS_RECORDS = 'ironhex_records',
  LS_PROFILE = 'ironhex_profile',
  LS_CAMPAIGN = 'ironhex_campaign';
const lsGet = (k, d) => store.get(k, d),
  lsSet = (k, v) => store.set(k, v);
const loadRecords = () => lsGet(LS_RECORDS, []);
const loadProfile = () => lsGet(LS_PROFILE, emptyProfile());
// Campaign progress, one saved state per campaign. (The single state from before multiple campaigns moves in.)
const LS_CAMPAIGN_PROGRESS = 'ironhex_campaign_progress',
  LS_CUSTOM_CAMPAIGNS = 'ironhex_custom_campaigns';
function campaignProgress() {
  const p = store.get(LS_CAMPAIGN_PROGRESS, null);
  if (p && typeof p === 'object') return p;
  const map = {},
    old = store.get(LS_CAMPAIGN, null);
  if (old && old.id) map[old.id] = old;
  store.set(LS_CAMPAIGN_PROGRESS, map);
  store.remove(LS_CAMPAIGN);
  return map;
}
const activeCampaignId = () => appState.prefs.campaignId || CAMPAIGN.id;
const loadCampaign = (id = activeCampaignId()) => campaignProgress()[id] || null;
function saveCampaign(state) {
  const p = campaignProgress();
  p[state.id] = state;
  store.set(LS_CAMPAIGN_PROGRESS, p);
}
// Every playable campaign: the built-in ones, then your own (only those that pass validation).
const customCampaignDrafts = () => storedList(LS_CUSTOM_CAMPAIGNS);
const customCampaigns = () => customCampaignDrafts().filter(c => !validateCampaign(c).length);
const allCampaigns = () => BUILTIN_CAMPAIGNS.concat(customCampaigns());
const campaignById = id => allCampaigns().find(c => c.id === id) || CAMPAIGN;

// ---- Shared board (hosted game only) ---------------------------------------
// Each viewer writes only their own document, board/<their id>; everyone reads all of them.
// Results come from each player's browser and aren't verified.
const SB = { db: undefined, user: null };
async function sbInit() {
  if (SB.db !== undefined) return SB.db;
  SB.db = null;
  try {
    if (window.claude && window.claude.use) {
      SB.db = await window.claude.use('db');
      SB.user = await window.claude.use('user');
    }
  } catch (e) {
    SB.db = null;
  }
  if (!SB.user) SB.db = null;
  return SB.db;
}
async function syncSharedBoard() {
  const db = await sbInit();
  if (!db) return "The shared board isn't available here.";
  const uid = await SB.user.id();
  if (!uid) return 'Sign in to post to the shared board.';
  const s = summarizeRecords(loadRecords()),
    best = {};
  for (const m of Object.values(s.byMap)) if (m.fastest != null) best[m.name.slice(0, 40)] = m.fastest;
  try {
    await db.doc('board/' + uid).set({
      uid,
      wins: s.wins,
      battles: s.battles,
      fastest: s.fastestWin ? s.fastestWin.turns : null,
      best,
      campaigns: loadRecords().filter(r => r.mode === 'campaign-complete').length,
      updatedAt: new Date().toISOString(),
    });
    return 'Your results are on the shared board.';
  } catch (e) {
    return e && e.code === 'invalid_argument'
      ? "Your access to this game can't post to the shared board."
      : "Couldn't reach the shared board just now.";
  }
}
async function readSharedBoard() {
  const db = await sbInit();
  if (!db) return null;
  const snap = await db.collection('board').get();
  const num = v => (typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0);
  const rows = snap.docs
    .filter(d => d.exists)
    .map(d => {
      const x = d.data() || {};
      return {
        uid: String(x.uid || d.id),
        wins: num(x.wins),
        battles: num(x.battles),
        fastest: typeof x.fastest === 'number' && x.fastest >= 1 ? Math.floor(x.fastest) : null,
        campaigns: num(x.campaigns),
      };
    });
  const names = rows.length ? await SB.user.profiles(rows.map(r => r.uid)) : {};
  const me = await SB.user.id();
  return rows
    .map(r => ({ ...r, name: (names[r.uid] && names[r.uid].name) || 'Someone', me: r.uid === me }))
    .sort((a, b) => b.wins - a.wins || (a.fastest ?? 999) - (b.fastest ?? 999));
}

// ---- End of battle: records, looks, campaign -------------------------------
// Returns HTML lines for the end screen and the campaign result (if a mission).
function recordBattle(B, out, win) {
  const youWin = !!win && teamOf(win.id) === teamOf(me());
  const rec = battleRecord(
    B,
    Object.assign({}, out, { winner: win }),
    B.campaign ? 'campaign' : 'quick',
    B.campaign ? { mission: B.campaign.title } : {}
  );
  lsSet(LS_RECORDS, loadRecords().concat([rec]).slice(-500));
  const { profile, unlocked } = applyBattleToProfile(loadProfile(), B, youWin);
  lsSet(LS_PROFILE, profile);
  refreshUnlocks();
  const lines = unlocked.map(x =>
    SKIN_PERIODS[x.period].ready
      ? `New look unlocked: <b>${escapeHtml(UNIT_TYPES[x.type].name)}</b> as ${escapeHtml(SKIN_NAMES[x.period][x.type])} (${SKIN_PERIODS[x.period].name}). Choose looks in Battle settings.`
      : `Earned the ${SKIN_PERIODS[x.period].name} look for ${escapeHtml(UNIT_TYPES[x.type].name)}; its art is coming later.`
  );
  let camp = null;
  const st = B.campaign && !B.campaign.test ? loadCampaign(B.campaign.id) : null; // test plays from the editor don't count
  if (B.campaign && st && st.mission === B.campaign.mission && !st.done) {
    camp = campaignAfterMission(st, B, youWin, campaignById(B.campaign.id));
    saveCampaign(camp.state);
    if (camp.state.done)
      lsSet(
        LS_RECORDS,
        loadRecords()
          .concat([Object.assign({}, rec, { mode: 'campaign-complete' })])
          .slice(-500)
      );
  }
  if (appState.prefs.shareBoard)
    syncSharedBoard().then(msg => {
      const el = $('#end-share');
      if (el) el.textContent = msg;
    });
  return { lines, camp, youWin };
}

// ---- Leaderboard screen -----------------------------------------------------
const lb = { tab: 'local', filter: 'all', confirm: false };
async function renderLeaderboard() {
  const db = await sbInit();
  $('#lb-tabs').innerHTML =
    `<button class="btn sm alt" data-lb-tab="local" aria-pressed="${lb.tab === 'local'}">Your records</button>` +
    (db ? `<button class="btn sm alt" data-lb-tab="shared" aria-pressed="${lb.tab === 'shared'}">Shared board</button>` : '');
  if (lb.tab === 'shared' && db) return renderSharedBoard();
  const all = loadRecords(),
    recs = all.filter(r => lb.filter === 'all' || (lb.filter === 'quick' ? r.mode === 'quick' : r.mode === 'campaign'));
  const s = summarizeRecords(recs);
  const tile = (n, v) => `<div class="lb-tile"><b>${v}</b><span>${n}</span></div>`;
  $('#lb-body').innerHTML = `<div class="seg">${[
    ['all', 'All battles'],
    ['quick', 'Quick battle'],
    ['campaign', 'Campaign'],
  ]
    .map(([k, n]) => `<button class="btn sm alt" data-lb-filter="${escapeHtml(k)}" aria-pressed="${lb.filter === k}">${n}</button>`)
    .join('')}</div>
    <div class="lb-tiles">${tile('Battles', s.battles)}${tile('Wins', s.wins)}${tile('Win rate', s.winRate + '%')}${tile('Fastest win', s.fastestWin ? turnsTxt(s.fastestWin.turns) : '–')}${tile('Best streak', s.bestStreak)}${tile('Current streak', s.streak)}</div>
    ${
      s.battles
        ? `<h2>By map</h2><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Map</th><th>Won</th><th>Lost</th><th>Drawn</th><th>Fastest win</th></tr></thead><tbody>${Object.values(
            s.byMap
          )
            .sort((a, b) => b.w + b.l + b.d - (a.w + a.l + a.d))
            .map(
              m =>
                `<tr><td>${escapeHtml(m.name)}</td><td>${m.w}</td><td>${m.l}</td><td>${m.d}</td><td>${m.fastest != null ? turnsTxt(m.fastest) : '–'}</td></tr>`
            )
            .join('')}</tbody></table></div>
    <h2>Against AI strategies</h2><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Opponent</th><th>Won</th><th>Lost</th><th>Drawn</th></tr></thead><tbody>${Object.values(
      s.byOpponent
    )
      .map(o => `<tr><td>${escapeHtml((STRATS[o.name] || { label: o.name }).label)}</td><td>${o.w}</td><td>${o.l}</td><td>${o.d}</td></tr>`)
      .join('')}</tbody></table></div>
    <h2>Recent battles</h2><div class="tbl-wrap"><table class="tbl"><thead><tr><th>When</th><th>Mode</th><th>Map</th><th>Result</th><th>Turns</th><th>Units lost</th></tr></thead><tbody>${recs
      .slice(-15)
      .reverse()
      .map(
        r =>
          `<tr><td>${escapeHtml(new Date(r.at).toLocaleDateString())}</td><td>${r.mode === 'campaign' ? 'Campaign: ' + escapeHtml(r.mission || '') : 'Quick'}</td><td>${escapeHtml(r.mapName)}</td><td>${r.result === 'win' ? 'Won' : r.result === 'loss' ? 'Lost' : 'Draw'}</td><td>${r.turns}</td><td>${r.lost} of ${r.fielded}</td></tr>`
      )
      .join('')}</tbody></table></div>`
        : '<p class="src">No battles recorded yet. Every Quick battle and campaign mission you finish is recorded here.</p>'
    }
    <div class="row-end"><span></span><button class="btn sm red" id="btn-lb-clear" ${all.length ? '' : 'disabled'}>${lb.confirm ? 'Click again to erase all records' : 'Clear records'}</button></div>`;
}
async function renderSharedBoard() {
  $('#lb-body').innerHTML = '<p class="status">Loading the shared board…</p>';
  let rows = null,
    err = '';
  try {
    rows = await readSharedBoard();
  } catch (e) {
    err = "Couldn't load the shared board just now.";
  }
  $('#lb-body').innerHTML =
    `<label class="check"><input type="checkbox" id="lb-share" ${appState.prefs.shareBoard ? 'checked' : ''}> Share my results here after each battle</label>
    <div class="seg"><button class="btn sm" id="btn-lb-post">Post my results now</button></div>
    <p class="status" id="lb-share-status" role="status">${err}</p>
    <p class="src">Everyone who opens this game can read this board, and each person posts only their own totals. Results come from each player's own browser and aren't verified.</p>
    ${
      rows && rows.length
        ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>#</th><th>Commander</th><th>Wins</th><th>Battles</th><th>Fastest win</th><th>Campaigns won</th></tr></thead><tbody>${rows
            .map(
              (r, i) =>
                `<tr${r.me ? ' class="me"' : ''}><td>${i + 1}</td><td>${escapeHtml(r.name)}${r.me ? ' (you)' : ''}</td><td>${r.wins}</td><td>${r.battles}</td><td>${r.fastest != null ? turnsTxt(r.fastest) : '–'}</td><td>${r.campaigns}</td></tr>`
            )
            .join('')}</tbody></table></div>`
        : rows
          ? '<p class="src">Nobody has posted yet.</p>'
          : ''
    }`;
}
$('#scr-leaderboard').addEventListener('click', async e => {
  const tab = e.target.closest('[data-lb-tab]');
  if (tab) {
    lb.tab = tab.dataset.lbTab;
    renderLeaderboard();
    return;
  }
  const f = e.target.closest('[data-lb-filter]');
  if (f) {
    lb.filter = f.dataset.lbFilter;
    renderLeaderboard();
    return;
  }
  if (e.target.closest('#btn-lb-clear')) {
    if (!lb.confirm) {
      lb.confirm = true;
      renderLeaderboard();
      setTimeout(() => {
        lb.confirm = false;
      }, 4000);
      return;
    }
    lb.confirm = false;
    lsSet(LS_RECORDS, []);
    renderLeaderboard();
    return;
  }
  if (e.target.closest('#btn-lb-post')) {
    $('#lb-share-status').textContent = 'Posting…';
    $('#lb-share-status').textContent = await syncSharedBoard();
    renderSharedBoard();
  }
});
$('#scr-leaderboard').addEventListener('change', e => {
  if (e.target.id === 'lb-share') {
    appState.prefs.shareBoard = e.target.checked;
    savePrefs();
  }
});
