import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame, startQuickBattle } from './helpers.mjs';

test('presets, diplomacy, and the three editors work end to end', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => go('settings'));
  await page.click('[data-preset="quick"]');
  assert.match(await page.innerText('#preset-pick'), /Current settings: Quick skirmish/);
  await page.click('[data-preset="standard"]');
  await page.evaluate(() => {
    go('prep');
  });
  await page.click('[data-armies="4"]');
  await page.evaluate(() => go('diplomacy'));
  await page.click('[data-dp-preset="2v2"]');
  assert.match(await page.innerText('#dp-summary'), /vs/);
  await startQuickBattle(page);
  assert.deepEqual(await page.evaluate(() => appState.battle.teams), [0, 0, 1, 1]);
  await page.click('#btn-exit');
  await page.evaluate(() => {
    localStorage.removeItem('ironhex_maps');
    go('mapedit');
  });
  await page.click('#btn-me-gen');
  await page.fill('#me-name', 'Test map');
  await page.click('#btn-me-save');
  assert.equal(await page.evaluate(() => loadMaps().length), 1);
  await page.evaluate(() => go('unitedit'));
  await page.fill('#ue-answer', JSON.stringify(await page.evaluate(() => LOOKUP_FIXTURE)));
  await page.click('#btn-ue-use');
  await page.click('#btn-ue-save');
  assert.ok(await page.evaluate(() => loadUnits().length >= 1));
  await page.evaluate(() => go('infra'));
  await page.click('#btn-infra-auto');
  await page.fill('#infra-name', 'Test layout');
  await page.click('#btn-infra-save');
  assert.ok(await page.evaluate(() => loadLayouts().some(l => l.name === 'Test layout')));
  assert.deepEqual(errors, []);
});
