import test from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { openGame, settle, GAME } from './helpers.mjs';
import { fakeRuntime } from './fake-runtime.mjs';

const fillOrders = page =>
  page.evaluate(() => {
    const B = appState.battle;
    const o = planAI({ ...B.players[me()], ai: 'balanced' });
    for (const [id, x] of Object.entries(o)) if (!B.orders[id]) B.orders[id] = x;
    updateDone();
  });

test('hot-seat: two players take turns behind a handoff screen, then the turn resolves', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => {
    go('prep');
  });
  await page.selectOption('#hotseat-pick', '2');
  await page.click('#btn-start-battle');
  await settle(page);
  assert.equal(await page.evaluate(() => battleMode(appState.battle)), 'hotseat');
  assert.ok(await page.evaluate(() => $('#modal').classList.contains('handoff') && !$('#modal').hidden), 'handoff screen covers the board');
  assert.equal(await page.evaluate(() => me()), 0);
  await page.click('#ho-ready');
  await fillOrders(page);
  assert.match(await page.innerText('#btn-done'), /next player/);
  await page.click('#btn-done');
  assert.equal(await page.evaluate(() => me()), 1, 'second player is up');
  await page.click('#ho-ready');
  await fillOrders(page);
  await page.click('#btn-done');
  await settle(page);
  assert.equal(await page.evaluate(() => appState.battle.turn), 2);
  assert.ok(await page.evaluate(() => $('#modal').classList.contains('handoff')), 'next turn starts with a handoff');
  assert.deepEqual(errors, []);
});

test('replays: a finished battle is kept and plays back turn by turn', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(async () => {
    const saved = VIEW;
    VIEW = NullView;
    appState.settings.roster = { tank: 1, inf: 2, plane: 1 };
    newBattle(42);
    let out = { end: false };
    while (!out.end) out = await simulateTurn(planAllAI('balanced'));
    keepReplay(replayOf(appState.battle, replayMeta(appState.battle, out, out.winner || pickWinner(out.remaining))));
    VIEW = saved;
  });
  await page.evaluate(() => go('replays'));
  await page.click('[data-rp-watch]');
  assert.equal(await page.evaluate(() => appState.screen), 'battle');
  assert.ok(await page.evaluate(() => !$('#replay-bar').hidden && $('#btn-done').hidden));
  await page.click('#rp-step');
  await settle(page);
  await page.click('#rp-step');
  await settle(page);
  assert.equal(await page.evaluate(() => R.replay.i), 2);
  await page.click('#rp-restart');
  assert.equal(await page.evaluate(() => R.replay.i), 0);
  await page.click('#btn-exit');
  assert.equal(await page.evaluate(() => appState.screen), 'replays');
  assert.deepEqual(errors, []);
});

test('online: two tabs (two players) create, join and play a turn of a match', async t => {
  const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  t.after(() => browser.close());
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 860 } });
  const open = async uid => {
    const p = await ctx.newPage();
    const errs = [];
    p.on('pageerror', e => errs.push(String(e)));
    await p.addInitScript(fakeRuntime(uid));
    await p.goto(GAME);
    await p.evaluate(() => {
      appState.prefs.sound = false;
      appState.prefs.seenHelp = true;
    });
    return { p, errs };
  };
  const A = await open('alice'),
    Bt = await open('bob');
  await A.p.evaluate(() => {
    localStorage.clear();
    appState.prefs.seenHelp = true;
    go('multi');
  });
  await A.p.waitForFunction(() => mpUI.uid === 'alice');
  await A.p.fill('#mp-name', 'Tab test');
  await A.p.click('#mp-create');
  await A.p.waitForFunction(() => /Created/.test($('#mp-status').textContent));
  await Bt.p.evaluate(() => go('multi'));
  await Bt.p.waitForSelector('[data-mp-join]', { timeout: 10000 });
  await Bt.p.click('[data-mp-join]');
  await Bt.p.waitForSelector('[data-mp-play]', { timeout: 10000 });
  await A.p.waitForSelector('[data-mp-play]', { timeout: 10000 });
  await A.p.click('[data-mp-play]');
  await Bt.p.click('[data-mp-play]');
  for (const x of [A, Bt]) await x.p.waitForFunction(() => appState.screen === 'battle' && R.mp && !R.busy);
  assert.deepEqual([await A.p.evaluate(() => me()), await Bt.p.evaluate(() => me())], [0, 1]);
  await fillOrders(A.p);
  await A.p.click('#btn-done');
  await A.p.waitForFunction(() => /Waiting for bob/.test($('#btn-done').textContent), null, { timeout: 10000 });
  await fillOrders(Bt.p);
  await Bt.p.click('#btn-done');
  for (const x of [A, Bt])
    await x.p.waitForFunction(() => R.mp && R.mp.turn === 2 && appState.battle.turn === 2 && !R.busy, null, { timeout: 60000 });
  const [ha, hb] = [await A.p.evaluate(() => stateHash(appState.battle)), await Bt.p.evaluate(() => stateHash(appState.battle))];
  assert.equal(ha, hb, 'both tabs hold the same battle after the turn');
  assert.deepEqual([A.errs, Bt.errs], [[], []]);
});
