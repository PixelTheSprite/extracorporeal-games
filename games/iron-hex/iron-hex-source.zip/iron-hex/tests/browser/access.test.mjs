import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame, startQuickBattle } from './helpers.mjs';

test('keyboard only: Tab to a unit, open Move, walk the cursor, Enter gives the order; announcements describe it', async t => {
  const { page, errors } = await openGame(t);
  await startQuickBattle(page);
  await page.waitForTimeout(700); // let the turn-start summary be read first
  await page.focus('body');
  await page.keyboard.press('Tab');
  await page.waitForTimeout(150);
  const sel = await page.evaluate(() => R.sel && R.sel.id);
  assert.ok(sel, 'Tab selects a unit');
  assert.match(await page.evaluate(() => $('#sr-live').textContent || ''), /Your .*HP/);
  // open Move from the unit's action menu with the keyboard
  await page.evaluate(() => document.querySelector('#action-menu [data-act=move]').focus());
  await page.keyboard.press('Enter');
  assert.equal(await page.evaluate(() => R.mode), 'move');
  // walk the cursor to a reachable hex and press Enter
  const target = await page.evaluate(() => {
    const n = [...R.reach.values()].find(n => n.end && n.cost > 0 && n.cost <= 2);
    return { dc: n.c - R.sel.c, dr: n.r - R.sel.r };
  });
  await page.evaluate(() => document.activeElement && document.activeElement.blur());
  for (let i = 0; i < Math.abs(target.dr); i++) await page.keyboard.press(target.dr > 0 ? 'ArrowDown' : 'ArrowUp');
  for (let i = 0; i < Math.abs(target.dc); i++) await page.keyboard.press(target.dc > 0 ? 'ArrowRight' : 'ArrowLeft');
  await page.waitForTimeout(150);
  assert.match(await page.evaluate(() => $('#sr-live').textContent || ''), /Column .*reachable this turn/);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(200);
  // Enter on a reachable hex either orders the move or opens the destination menu: both mean the tap landed
  const landed = await page.evaluate(id => !!appState.battle.orders[id] || R.mode === 'menu' || R.mode === 'dest', sel);
  assert.ok(landed, 'Enter acted on the cursor hex');
  await page.keyboard.press('r');
  await page.waitForTimeout(150);
  assert.match(await page.evaluate(() => $('#sr-live').textContent), /Turn 1\. You: \d+ units/);
  assert.deepEqual(errors, []);
});

test('colorblind palette, shape markers and reduced motion', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => go('settings'));
  await page.click('[data-access="palette"]');
  assert.equal(await page.evaluate(() => ARMIES[1].color), '#e69f00');
  assert.equal(await page.evaluate(() => shapesOn()), true);
  await page.click('[data-access="reducedMotion"]');
  assert.equal(await page.evaluate(() => appState.prefs.reducedMotion), true);
  await startQuickBattle(page);
  assert.match(await page.innerText('#hud-chips'), /● You/);
  assert.equal(
    await page.evaluate(() => {
      const n = R.fx.length;
      fxAdd({ kind: 'spark', x: 0, y: 0 });
      return R.fx.length - n;
    }),
    0,
    'particles suppressed'
  );
  await page.evaluate(() => go('settings'));
  await page.click('[data-access="palette"]');
  assert.equal(await page.evaluate(() => ARMIES[1].color), '#d0402a', 'back to standard');
  assert.deepEqual(errors, []);
});
