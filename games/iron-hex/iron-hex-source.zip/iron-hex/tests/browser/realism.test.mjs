import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame, startQuickBattle } from './helpers.mjs';

test('rule-gated units: offered only with their rule; the library says which rule; Lay mine appears for engineers', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => go('settings'));
  const picks = () => page.$$eval('#unit-roster [data-pick]', els => [...new Set(els.map(e => e.dataset.pick))]);
  assert.equal((await picks()).includes('arty'), false, 'no artillery while the rule is off');
  await page.click('[data-rule="artillery"]');
  assert.equal((await picks()).includes('arty'), true, 'artillery offered once the rule is on');
  await page.evaluate(() => go('library'));
  assert.match(await page.innerText('[data-lib="arty"]'), /needs the Artillery rule/);
  await page.evaluate(() => {
    go('settings');
  });
  await page.click('[data-rule="mines"]');
  await startQuickBattle(page);
  await page.evaluate(() => selectUnit(aliveUnits().find(u => u.pid === 0 && u.type === 'eng')));
  assert.ok(await page.isVisible('#action-menu [data-act="mine"]'), 'engineers can lay mines');
  await page.click('#action-menu [data-act="mine"]');
  assert.equal(
    await page.evaluate(() => {
      const u = aliveUnits().find(x => x.pid === 0 && x.type === 'eng');
      return appState.battle.orders[u.id].type;
    }),
    'mine'
  );
  assert.deepEqual(errors, []);
});

test('ammunition switch and Broadcast appear in unit menus; rounds ride along with the next order', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => {
    go('settings');
  });
  await page.click('[data-rule="ammo"]');
  await page.click('[data-rule="infoOps"]');
  await page.click('[data-rule="seasons"]');
  await startQuickBattle(page);
  assert.match(await page.innerText('#hud-chips'), /Spring|Summer|Autumn|Winter/);
  await page.evaluate(() => selectUnit(aliveUnits().find(u => u.pid === 0 && u.type === 'tank')));
  await page.click('#action-menu [data-act="ammo"]');
  const tank = await page.evaluate(() => aliveUnits().find(u => u.pid === 0 && u.type === 'tank').id);
  assert.match(await page.innerText('#cards'), /AP/);
  await page.evaluate(id => {
    const u = unitById(id);
    setOrder(u, { type: 'hold' });
  }, tank);
  assert.equal(await page.evaluate(id => appState.battle.orders[id].ammo, tank), 'ap');
  await page.evaluate(() => selectUnit(aliveUnits().find(u => u.pid === 0 && u.type === 'inf')));
  assert.ok(await page.isVisible('#action-menu [data-act="broadcast"]'));
  assert.deepEqual(errors, []);
});
