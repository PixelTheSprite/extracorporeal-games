import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame, startQuickBattle, playTurn } from './helpers.mjs';

test('a multi-turn move arrives over several turns; Overwatch stands until changed', async t => {
  const { page, errors } = await openGame(t);
  await startQuickBattle(page);
  const ids = await page.evaluate(() => {
    const B = appState.battle,
      tank = B.units.find(u => u.pid === 0 && u.type === 'tank'),
      inf = B.units.find(u => u.pid === 0 && u.type === 'inf');
    const far = [...travelField(tank).values()].filter(n => n.turns === 3).sort((a, b) => a.cost - b.cost)[0];
    setOrder(tank, { type: 'move', path: pathTo(far), target: null, multi: { dest: { c: far.c, r: far.r }, turns: 3 } });
    setOrder(inf, { type: 'hold' });
    return { tank: tank.id, inf: inf.id, dest: { c: far.c, r: far.r } };
  });
  let arrived = false;
  for (let i = 0; i < 5 && !arrived; i++) {
    await playTurn(page);
    assert.equal(
      await page.evaluate(id => appState.battle.orders[id] && appState.battle.orders[id].type, ids.inf),
      'hold',
      'Overwatch stands'
    );
    arrived = await page.evaluate(() => /arrived/.test(R.standingNote || ''));
  }
  assert.ok(arrived, 'tank arrived');
  assert.deepEqual(errors, []);
});
