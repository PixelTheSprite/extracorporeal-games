import test from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { GAME, settle } from './helpers.mjs';
import { fakeRuntime } from './fake-runtime.mjs';

async function twoPlayers(t, opts = {}) {
  const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  t.after(() => browser.close());
  const ctx = await browser.newContext(Object.assign({ viewport: { width: 1100, height: 900 } }, opts));
  const open = async uid => {
    const p = await ctx.newPage();
    const errs = [];
    p.on('pageerror', e => errs.push(String(e)));
    await p.addInitScript(fakeRuntime(uid));
    await p.goto(GAME);
    await p.evaluate(() => {
      appState.prefs.sound = false;
      appState.prefs.seenHelp = true;
    });
    return { p, errs, ctx };
  };
  return { open, ctx };
}

test('sharing: a map, unit pack and campaign made by one player are installed and played by another', async t => {
  const { open } = await twoPlayers(t);
  const A = await open('alice');
  await A.p.evaluate(() => {
    localStorage.clear();
    const m = Object.assign(genCustom(14, 10, 99, 'Alice Ridge', { water: 20, mountains: 15, forest: 25, desert: 10 }), {
      id: 'mymap',
      name: 'Alice Ridge',
      kind: 'custom',
    });
    storeMaps([m]);
    const u = Object.assign(clone(UNIT_TYPES.tank), { id: 'u_alice_tank', name: 'Alice Tank', custom: true, art: SPRITE_ART.tank.slice() });
    storeUnits([u]);
    ceSave([Object.assign(clone(ARCHIPELAGO), { id: 'c-alice', name: 'Alice Campaign' })]);
    go('gallery');
  });
  for (const k of ['map:mymap', 'units:all', 'campaign:c-alice']) {
    await A.p.click(`[data-gal-share="${k}"]`);
    await A.p.waitForFunction(() => /Shared/.test($('#gal-status').textContent));
  }
  const B = await open('bob');
  await B.p.evaluate(() => {
    for (const k of ['ironhex_maps', 'ironhex_units', 'ironhex_custom_campaigns']) localStorage.removeItem(k);
    go('gallery');
  });
  await B.p.waitForSelector('[data-gal-get]');
  for (const kind of ['map', 'units', 'campaign']) {
    await B.p.click(`[data-gal-get$=":${kind}"]`);
    await B.p.waitForFunction(() => /Installed/.test($('#gal-status').textContent));
  }
  const got = await B.p.evaluate(() => ({
    maps: loadMaps().map(m => m.name),
    units: loadUnits().map(u => u.name),
    safeIds: loadUnits().every(u => SAFE_UNIT_ID.test(u.id)),
    camps: customCampaigns().map(c => c.name),
  }));
  assert.deepEqual(got.maps, ['Alice Ridge']);
  assert.deepEqual(got.units, ['Alice Tank']);
  assert.ok(got.safeIds);
  assert.deepEqual(got.camps, ['Alice Campaign']);
  // Bob plays a battle on Alice's map
  const mapId = await B.p.evaluate(() => prepMaps().find(m => m.name === 'Alice Ridge').id);
  await B.p.evaluate(id => {
    appState.settings.mapId = id;
    go('prep');
    $('#btn-start-battle').click();
  }, mapId);
  await settle(B.p);
  assert.equal(await B.p.evaluate(() => appState.battle.mapDef.name), 'Alice Ridge');
  // a tampered post is refused, and no script runs
  await B.p.evaluate(async () => {
    const db = await claude.use('db');
    await putBig(db, 'gallery/mallory/data/x1', {
      id: 'm1" onmouseover="window.__pwn=1',
      name: '<img src=x onerror=window.__pwn=1>',
      W: 3,
      H: 3,
      rows: ['xx'],
      spawns: [],
    });
    await db.doc('gallery/mallory').set({ items: [{ id: 'x1', kind: 'map', name: '<img src=x onerror=window.__pwn=1>', at: Date.now() }] });
    go('gallery');
  });
  await B.p.waitForSelector('[data-gal-get="mallory:x1:map"]');
  await B.p.click('[data-gal-get="mallory:x1:map"]');
  await B.p.waitForFunction(() => /didn’t pass/.test($('#gal-status').textContent));
  assert.equal(await B.p.evaluate(() => !!window.__pwn), false);
  assert.deepEqual([A.errs, B.errs], [[], []]);
});

test('telemetry: nothing is sent unless opted in; totals appear on the Leaderboard', async t => {
  const { open } = await twoPlayers(t);
  const A = await open('alice');
  const finish = () =>
    A.p.evaluate(async () => {
      const saved = VIEW;
      VIEW = NullView;
      appState.settings.roster = { tank: 1, inf: 1 };
      newBattle(5);
      let o = { end: false };
      while (!o.end) o = await simulateTurn(planAllAI('balanced'));
      VIEW = saved;
      await recordTelemetry(appState.battle, o.winner || pickWinner(o.remaining));
    });
  await A.p.evaluate(() => {
    localStorage.clear();
    appState.prefs.telemetry = false;
  });
  await finish();
  assert.equal(
    await A.p.evaluate(async () => (await (await claude.use('db')).doc('telemetry/alice').get()).exists),
    false,
    'off: nothing sent'
  );
  await A.p.evaluate(() => {
    go('settings');
  });
  await A.p.click('[data-access="telemetry"]');
  await finish();
  await finish();
  const t2 = await A.p.evaluate(async () => (await (await claude.use('db')).doc('telemetry/alice').get()).data());
  assert.equal(t2.battles, 2);
  assert.ok(!JSON.stringify(t2).includes('alice'), 'no names in the data');
  await A.p.evaluate(() => go('leaderboard'));
  await A.p.waitForFunction(() => /2 battles from 1 player/.test($('#lb-balance').textContent));
  assert.deepEqual(A.errs, []);
});

test('performance test: smooth on an emulated mid-range phone (CPU slowed 4×)', async t => {
  const { open, ctx } = await twoPlayers(t, {
    viewport: { width: 390, height: 844 },
    deviceScaleFactor: 3,
    isMobile: true,
    hasTouch: true,
  });
  const A = await open('alice');
  const cdp = await ctx.newCDPSession(A.p);
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
  const r = await A.p.evaluate(() => runPerfTest());
  console.log('# phone emulation:', JSON.stringify(r));
  assert.equal(r.verdict, 'smooth');
  assert.deepEqual(A.errs, []);
});
