import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame, startQuickBattle } from './helpers.mjs';

test('missiles: a ready silo shows Launch; targeting orders a strike; the enemy warning appears', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => {
    go('settings');
  });
  await page.click('[data-rule="missiles"]');
  await startQuickBattle(page);
  assert.equal(await page.isVisible('#btn-launch'), false, 'no silo, no Launch button');
  const k = await page.evaluate(() => {
    const B = appState.battle,
      cap = B.mapDef.spawns[0];
    let at = null;
    for (let r = 0; r < B.mapDef.H && !at; r++)
      for (let c = 0; c < B.mapDef.W && !at; c++) if (hexDist({ c, r }, cap) === 2 && canBuildAt('silo', { c, r }, 0)) at = { c, r };
    const kk = key(at.c, at.r);
    B.structs[kk] = newStruct('silo', 0, null);
    B.structs[kk].charge = 99;
    const ek = key(B.mapDef.spawns[1].c, B.mapDef.spawns[1].r - 1);
    B.structs[ek] = B.structs[ek] || newStruct('silo', 1, null);
    B.structs[ek].charge = 99;
    renderHud();
    return kk;
  });
  assert.ok(await page.isVisible('#btn-launch'));
  assert.match(await page.innerText('#hud-chips'), /Enemy missile ready/);
  await page.click('#btn-launch');
  assert.equal(await page.evaluate(() => R.mode), 'strike');
  const target = await page.evaluate(sk => {
    const B = appState.battle;
    const e = aliveUnits().find(u => u.pid === 1 && strikeTargetOk(B, 0, sk, u)) || aliveUnits().find(u => u.pid === 1);
    return { c: e.c, r: e.r, ok: strikeTargetOk(B, 0, sk, e) };
  }, k);
  if (target.ok) {
    await page.evaluate(h => {
      const pk = R.pick.find(x => x.t.c === h.c && x.t.r === h.r);
      onTap(pk.pts.reduce((s, p) => s + p.x, 0) / pk.pts.length, pk.pts.reduce((s, p) => s + p.y, 0) / pk.pts.length);
    }, target);
    assert.deepEqual(await page.evaluate(sk => appState.battle.orders['strike:' + sk].target, k), { c: target.c, r: target.r });
    assert.match(await page.innerText('#hud-chips'), /1 launch ordered/);
  }
  assert.deepEqual(errors, []);
});

test('city development: invest from the Build dialog', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => {
    go('settings');
  });
  await page.click('[data-rule="income"]');
  await page.click('[data-rule="cityDev"]');
  await startQuickBattle(page);
  await page.evaluate(() => {
    appState.battle.funds[0] = 50;
  });
  await page.click('#btn-prod');
  assert.match(await page.innerText('#modal'), /Invest in your cities/);
  await page.click('[data-invest]');
  assert.ok(await page.evaluate(() => Object.keys(appState.battle.orders).some(k => k.startsWith('invest:'))));
  assert.match(await page.innerText('#modal'), /investment ordered/);
  assert.deepEqual(errors, []);
});
