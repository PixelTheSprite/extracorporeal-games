// A stand-in for the hosted runtime (window.claude) for browser tests: `db` backed by localStorage, shared by
// every tab of the same browser context (so two tabs act as two devices), and `user` with a fixed id per tab.
export const fakeRuntime = uid => `(() => {
  const UID = ${JSON.stringify(uid)}, K = 'fdb:', L = 'fdbl:';
  const read = p => { const v = localStorage.getItem(K + p); return v == null ? undefined : JSON.parse(v); };
  const write = (p, v) => (v === undefined ? localStorage.removeItem(K + p) : localStorage.setItem(K + p, JSON.stringify(v)));
  const snap = (p, v) => ({ id: p.split('/').pop(), exists: v !== undefined, data: () => (v === undefined ? undefined : JSON.parse(JSON.stringify(v))), metadata: { fromCache: false, hasPendingWrites: false } });
  const poll = (get, next) => { let last; const t = setInterval(async () => { const v = await get(); const j = JSON.stringify(v.docs ? v.docs.map(d => [d.id, d.data()]) : v.data()); if (j !== last) { last = j; next(v); } }, 400); return () => clearInterval(t); };
  const docRef = p => ({ id: p.split('/').pop(), path: p,
    async get() { return snap(p, read(p)); },
    async set(v) { write(p, JSON.parse(JSON.stringify(v))); },
    async update(v) { write(p, Object.assign(read(p) || {}, JSON.parse(JSON.stringify(v)))); },
    async delete() { write(p, undefined); },
    async acquire({ holder, ttlMs = 30000 }) { const now = Date.now(), l = JSON.parse(localStorage.getItem(L + p) || 'null');
      if (l && l.expires > now && l.holder !== holder) return { acquired: false };
      localStorage.setItem(L + p, JSON.stringify({ holder, expires: now + ttlMs })); return { acquired: true, holder }; },
    onSnapshot(next) { return poll(() => this.get(), next); },
    collection: s => colRef(p + '/' + s) });
  const colRef = p => ({ path: p, doc: id => docRef(p + '/' + (id || 'd' + Math.random().toString(36).slice(2))),
    async get() { const n = p.split('/').length + 1, docs = [];
      for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (!k.startsWith(K + p + '/')) continue; const path = k.slice(K.length); if (path.split('/').length === n) docs.push(snap(path, read(path))); }
      docs.sort((a, b) => (a.id < b.id ? -1 : 1)); return { docs, size: docs.length, empty: !docs.length, docChanges: () => [] }; },
    onSnapshot(next) { return poll(() => this.get(), next); } });
  const db = { doc: docRef, collection: colRef };
  const user = { id: async () => UID, me: async () => ({ id: UID, name: UID }), profiles: async ids => Object.fromEntries(ids.map(i => [i, { id: i, name: i }])), isOwner: () => false, canEdit: () => false, can: () => null };
  window.claude = { use: async name => (name === 'db' ? db : name === 'user' ? user : null) };
})();`;
