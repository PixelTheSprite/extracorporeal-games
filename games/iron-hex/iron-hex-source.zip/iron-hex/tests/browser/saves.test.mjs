import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { openGame, startQuickBattle, playTurn, settle } from './helpers.mjs';

test('save to a slot, reload the page, load it back; export and import a file', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => localStorage.removeItem('ironhex_saves'));
  await startQuickBattle(page);
  await playTurn(page);
  await page.click('#btn-save');
  await page.fill('#sv-name', 'Browser test');
  await page.click('#sv-new');
  await page.waitForTimeout(900);
  const turn = await page.evaluate(() => appState.battle.turn);
  await page.reload();
  await page.evaluate(() => {
    appState.prefs.seenHelp = true;
    go('prep');
  });
  await page.click('#btn-prep-load');
  await page.click('[data-ld]');
  await settle(page);
  assert.equal(await page.evaluate(() => appState.battle.turn), turn);
  await page.click('#btn-load');
  const dl = page.waitForEvent('download');
  await page.click('[data-ld-export]');
  const file = await (await dl).path();
  assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).app, 'iron-hex');
  await page.setInputFiles('#ld-import', file);
  await settle(page);
  assert.equal(await page.evaluate(() => appState.battle.turn), turn);
  assert.deepEqual(errors, []);
});
