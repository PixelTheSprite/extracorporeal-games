import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame, settle } from './helpers.mjs';

// Tap the reachable hex closest to the town (as a player would, through the real tap handler).
const tapTowardTown = page =>
  page.evaluate(() => {
    const n = [...R.reach.values()].filter(n => n.end && n.cost > 0).sort((a, b) => hexDist(a, TOWN) - hexDist(b, TOWN))[0];
    const pk = R.pick.find(x => x.t.c === n.c && x.t.r === n.r);
    onTap(pk.pts.reduce((s, p) => s + p.x, 0) / pk.pts.length, pk.pts.reduce((s, p) => s + p.y, 0) / pk.pts.length);
    document.querySelector('#action-menu [data-act=wait]')?.click(); // the plain move: go there and hold
  });
const step = page => page.evaluate(() => (R.tutorial ? TUTORIAL_STEPS[R.tutorial.step].id : 'complete'));

test('tutorial: a new player is walked from first selection to victory, step by step', async t => {
  const { page, errors } = await openGame(t);
  await page.click('text=Start game');
  assert.ok(await page.evaluate(() => $('#btn-tutorial').classList.contains('suggest')), 'HQ points new players at the tutorial');
  await page.click('#btn-tutorial');
  await settle(page);
  assert.equal(await step(page), 'select');
  assert.match(await page.innerText('#tutor'), /step 1 of 7/);
  // 1–2: select the tank and move it toward the town
  await page.evaluate(() => selectUnit(aliveUnits().find(u => u.pid === 0 && u.type === 'tank')));
  await page.waitForTimeout(400);
  assert.equal(await step(page), 'move');
  await page.click('#action-menu [data-act=move]');
  await tapTowardTown(page);
  await page.waitForTimeout(400);
  assert.equal(await step(page), 'second');
  // 3: the rifle squad
  await page.evaluate(() => selectUnit(aliveUnits().find(u => u.pid === 0 && u.type === 'inf')));
  await page.click('#action-menu [data-act=move]');
  await tapTowardTown(page);
  await page.waitForTimeout(400);
  assert.equal(await step(page), 'done');
  // 4: Done
  await page.click('#btn-done');
  await settle(page);
  await page.waitForTimeout(400);
  const seen = new Set(['select', 'move', 'second', 'done']);
  // 5–7: keep playing sensible orders until the tutorial completes
  for (let turn = 0; turn < 30 && (await step(page)) !== 'complete'; turn++) {
    seen.add(await step(page));
    if (await page.evaluate(() => R.ended)) break;
    await page.evaluate(() => {
      const B = appState.battle,
        inf = aliveUnits().find(u => u.pid === 0 && u.type === 'inf');
      const o = planAI({ ...B.players[0], ai: 'aggressive' });
      if (inf && inf.c === TOWN.c && inf.r === TOWN.r) o[inf.id] = { type: 'capture' };
      for (const [id, x] of Object.entries(o)) if (!B.orders[id]) B.orders[id] = x;
      updateDone();
    });
    await page.click('#btn-done');
    await settle(page);
    await page.waitForTimeout(400);
  }
  await page.waitForTimeout(500);
  seen.add(await step(page));
  assert.equal(await step(page), 'complete', 'every step completed; steps seen: ' + [...seen].join(', '));
  assert.ok(await page.evaluate(() => appState.prefs.tutorialDone));
  assert.deepEqual(errors, []);
});
