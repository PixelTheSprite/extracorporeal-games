import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame, startQuickBattle, playTurn, settle } from './helpers.mjs';

test('title to battle: a turn plays, AI plans across frames, Exit returns to HQ', async t => {
  const { page, errors } = await openGame(t);
  await page.click('text=Start game');
  assert.equal(await page.evaluate(() => appState.screen), 'select');
  await startQuickBattle(page);
  assert.equal(await page.evaluate(() => appState.battle.turn), 1);
  assert.ok(await page.evaluate(() => Object.keys(R.aiOrders).length > 0), 'AI orders planned');
  await playTurn(page);
  assert.equal(await page.evaluate(() => appState.battle.turn), 2);
  await page.click('#btn-exit');
  assert.equal(await page.evaluate(() => appState.screen), 'select');
  assert.deepEqual(errors, []);
});

test('every Command HQ screen opens without errors', async t => {
  const { page, errors } = await openGame(t);
  for (const s of [
    'library',
    'settings',
    'diplomacy',
    'campaign',
    'leaderboard',
    'multi',
    'replays',
    'unitedit',
    'mapedit',
    'infra',
    'diag',
    'prep',
  ]) {
    await page.evaluate(id => go(id), s);
    assert.equal(await page.evaluate(() => appState.screen), s);
  }
  assert.deepEqual(errors, []);
});
