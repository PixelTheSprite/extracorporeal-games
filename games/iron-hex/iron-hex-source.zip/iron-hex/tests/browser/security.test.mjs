import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { openGame } from './helpers.mjs';

const EVIL = 'u_x" onmouseover="window.__pwn=1" data-y="';
test('malicious unit files, saves and stored data never run script', async t => {
  const { page, errors } = await openGame(t, {
    init: `try { localStorage.setItem('ironhex_maps', JSON.stringify([{ id:'m1" onmouseover="window.__pwn=1', name:'x', kind:'custom', W:12, H:10, rows:Array(10).fill('pppppppppppp'), spawns:[{c:1,r:1},{c:10,r:8}], roads:[] }])); } catch (e) {}`,
  });
  assert.equal(await page.evaluate(() => loadMaps().length), 0, 'tampered map skipped');
  const unit = await page.evaluate(id => {
    const T = JSON.parse(JSON.stringify(UNIT_TYPES.tank));
    T.custom = true;
    T.art = SPRITE_ART.tank.slice();
    T.id = id;
    T.name = 'Evil <b>tank</b>';
    return T;
  }, EVIL);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ih-')),
    uf = path.join(dir, 'units.json'),
    sf = path.join(dir, 'save.json');
  fs.writeFileSync(uf, JSON.stringify({ app: 'iron-hex-units', version: 1, units: [unit] }));
  await page.evaluate(() => go('unitedit'));
  await page.setInputFiles('#ue-import', uf);
  await page.waitForTimeout(300);
  assert.ok(await page.evaluate(() => loadUnits().every(u => SAFE_UNIT_ID.test(u.id))), 'imported unit got a safe id');
  const save = await page.evaluate(() => {
    newBattle(3);
    return JSON.parse(JSON.stringify(snapshot()));
  });
  save.battle.customTypes = { [EVIL]: Object.assign({}, unit, { id: EVIL }) };
  save.battle.units[0].type = EVIL;
  fs.writeFileSync(sf, JSON.stringify(save));
  await page.evaluate(() => go('prep'));
  await page.click('#btn-prep-load');
  await page.setInputFiles('#ld-import', sf);
  await page.waitForTimeout(500);
  assert.equal(await page.evaluate(() => appState.screen), 'prep', 'malicious save refused');
  for (const s of ['library', 'settings', 'unitedit', 'prep', 'infra', 'mapedit']) {
    await page.evaluate(id => {
      closeModal();
      go(id);
      document.querySelectorAll('*').forEach(el => el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true })));
    }, s);
  }
  assert.equal(await page.evaluate(() => !!window.__pwn), false, 'no script ran');
  assert.deepEqual(errors, []);
});
