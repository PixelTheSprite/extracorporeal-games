// Shared setup for the browser tests: open the built game (dist/iron-hex.html) in Chromium and collect page errors.
// Uses Playwright's own browser, or the one at CHROMIUM_PATH if set. Run: npm run test:browser
import { chromium } from 'playwright';
import path from 'node:path';
import { root } from '../core.mjs';

export const GAME = 'file://' + path.join(root, 'dist/iron-hex.html');
export async function openGame(t, { viewport = { width: 1280, height: 900 }, init } = {}) {
  const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  const page = await browser.newPage({ viewport, acceptDownloads: true });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  if (init) await page.addInitScript(init);
  await page.goto(GAME);
  await page.evaluate(() => {
    appState.prefs.sound = false;
    appState.prefs.seenHelp = true;
  });
  t.after(() => browser.close());
  return { page, errors };
}
// Wait until the AI has finished planning and the turn isn't resolving.
export async function settle(page) {
  for (let i = 0; i < 400; i++) {
    if (await page.evaluate(() => !R.busy && !R.planning)) return;
    await page.waitForTimeout(100);
  }
  throw new Error('turn never settled');
}
// Give every one of your units without orders the AI's choice, then press Done and wait.
export async function playTurn(page) {
  await settle(page);
  await page.evaluate(() => {
    const B = appState.battle;
    const ai = planAI({ ...B.players[0], ai: 'balanced' });
    for (const [id, o] of Object.entries(ai)) if (!B.orders[id]) B.orders[id] = o;
    updateDone();
  });
  await page.click('#btn-done');
  await settle(page);
}
export async function startQuickBattle(page, setup = '') {
  if (setup) await page.evaluate(setup);
  await page.evaluate(() => go('prep'));
  await page.click('#btn-start-battle');
  await settle(page);
}
