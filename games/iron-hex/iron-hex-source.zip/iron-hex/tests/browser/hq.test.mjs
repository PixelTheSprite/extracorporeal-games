import test from 'node:test';
import assert from 'node:assert/strict';
import { openGame } from './helpers.mjs';

test('Command HQ: five items; Play, Editors and Extras are accordions that remember being open', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => {
    appState.prefs.hqOpen = {};
    go('select');
  });
  const top = await page.$$eval('#scr-select .hq-menu > .hq-btn, #scr-select .hq-menu > .hq-group > .hq-head', els =>
    els.map(e => e.childNodes[0].textContent.trim())
  );
  assert.deepEqual(top, ['Tutorial', 'Play', 'Editors', 'Leaderboard', 'Extras']);
  assert.equal(await page.isVisible('[data-go="campaign"]'), false, 'Play starts closed');
  // open Play with the keyboard
  await page.focus('[data-hq="play"]');
  await page.keyboard.press('Enter');
  assert.equal(await page.getAttribute('[data-hq="play"]', 'aria-expanded'), 'true');
  assert.deepEqual(await page.$$eval('#hq-play [data-go]', els => els.map(e => e.dataset.go)), ['campaign', 'prep', 'multi']);
  await page.click('[data-hq="editors"]');
  await page.click('[data-hq="extras"]');
  assert.deepEqual(await page.$$eval('#hq-editors [data-go]', els => els.map(e => e.dataset.go)), ['unitedit', 'infra', 'mapedit']);
  assert.deepEqual(await page.$$eval('#hq-extras [data-go]', els => els.map(e => e.dataset.go)), ['library', 'replays', 'gallery']);
  await page.click('[data-hq="editors"]');
  assert.equal(await page.getAttribute('[data-hq="editors"]', 'aria-expanded'), 'false');
  // remembered after a reload
  await page.reload();
  await page.evaluate(() => {
    appState.prefs.seenHelp = true;
    go('select');
  });
  assert.equal(await page.isVisible('[data-go="multi"]'), true, 'Play stays open');
  assert.equal(await page.isVisible('[data-go="infra"]'), false, 'Editors stays closed');
  await page.click('#hq-extras [data-go="library"]');
  assert.equal(await page.evaluate(() => appState.screen), 'library');
  assert.deepEqual(errors, []);
});

test('Unit library: units grouped under Land, Sea and Air', async t => {
  const { page, errors } = await openGame(t);
  await page.evaluate(() => go('library'));
  assert.deepEqual(await page.$$eval('#lib-list .lib-group', els => els.map(e => e.textContent)), ['Land', 'Sea', 'Air']);
  const groups = await page.evaluate(() =>
    [...document.querySelectorAll('#lib-list [role=group]')].map(g =>
      [...g.querySelectorAll('[data-lib]')].map(b => UNIT_TYPES[b.dataset.lib].domain)
    )
  );
  assert.deepEqual(
    groups.map(g => [...new Set(g)]),
    [['land'], ['sea'], ['air']]
  );
  assert.equal(groups.flat().length, await page.evaluate(() => Object.keys(UNIT_TYPES).length), 'every unit listed once');
  assert.deepEqual(errors, []);
});
