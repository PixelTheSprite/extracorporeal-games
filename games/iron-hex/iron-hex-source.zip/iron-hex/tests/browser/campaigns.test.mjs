import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { openGame, settle } from './helpers.mjs';

test('campaigns: old progress migrates; Archipelago plays; the editor builds, saves, plays and shares a campaign', async t => {
  const { page, errors } = await openGame(t);
  // progress saved before multiple campaigns existed
  await page.evaluate(() => {
    localStorage.clear();
    const st = newCampaignState(CAMPAIGN);
    st.mission = 'm2a';
    st.history = [{ title: 'Landfall', won: true, turns: 12 }];
    localStorage.setItem('ironhex_campaign', JSON.stringify(st));
  });
  await page.reload();
  await page.evaluate(() => {
    appState.prefs.sound = false;
    appState.prefs.seenHelp = true;
    go('campaign');
  });
  assert.match(await page.innerText('#camp-pick'), /The Iron Coast · mission 2 of 3/);
  assert.equal(await page.evaluate(() => localStorage.getItem('ironhex_campaign')), null, 'old key migrated');
  // Operation Archipelago
  await page.click('[data-camp="archipelago"]');
  await page.click('#btn-camp-start');
  await page.click('#btn-camp-go');
  await settle(page);
  assert.equal(await page.evaluate(() => appState.battle.campaign.title), 'Beachhead');
  await page.click('#btn-exit');
  // the editor: a new campaign with two missions, a survive objective, a branch and weather on
  await page.evaluate(() => go('campedit'));
  await page.click('[data-ce-new="blank"]');
  await page.fill('[data-ce="name"]', 'Night of <b>Steel</b><img src=x onerror="window.__pwn=1">');
  await page.click('[data-ce-act="addm"]');
  await page.selectOption('[data-ce-obj="m2"]', 'survive');
  await page.fill('[data-ce="missions.m2.objective.turns"]', '8');
  await page.selectOption('[data-ce-next="m1"]', 'branch');
  await page.check('[data-ce-rule="m2:weather"]');
  assert.match(await page.innerText('#ce-problems'), /Ready to play/);
  await page.click('[data-ce-act="save"]');
  assert.match(await page.innerText('#ce-status'), /Saved\. Play it/);
  const def = await page.evaluate(() => customCampaigns()[0]);
  assert.equal(def.missions.m2.objective.type, 'survive');
  assert.deepEqual(def.missions.m1.next, { within: 16, fast: 'm2', slow: 'm2' });
  assert.equal(def.missions.m2.rules.weather, true);
  // test play doesn't touch progress
  await page.click('[data-ce-mission="m2"] [data-ce-act^="test"]');
  await settle(page);
  assert.equal(await page.evaluate(() => appState.battle.campaign.test && appState.battle.rules.weather), true);
  await page.click('#btn-exit');
  assert.equal(await page.evaluate(id => loadCampaign(id), def.id), null);
  // it's on the Campaign screen, name shown as text
  await page.evaluate(() => go('campaign'));
  await page.click(`[data-camp="${def.id}"]`);
  assert.ok(
    await page.evaluate(() => [...document.querySelectorAll('#camp-body h2')].some(h => h.textContent.includes('<img src=x'))),
    'name is text, not markup'
  );
  await page.click('#btn-camp-start');
  await page.click('#btn-camp-go');
  await settle(page);
  assert.equal(await page.evaluate(() => appState.battle.campaign.id), def.id);
  await page.click('#btn-exit');
  // export and import
  await page.evaluate(() => go('campedit'));
  const dl = page.waitForEvent('download');
  await page.click(`[data-ce-export="${def.id}"]`);
  const file = await (await dl).path();
  assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).app, 'iron-hex-campaign');
  await page.setInputFiles('#ce-import', file);
  await page.waitForFunction(() => customCampaignDrafts().length === 2, null, { timeout: 5000 }); // import reads the file asynchronously
  assert.equal(await page.evaluate(() => !!window.__pwn), false, 'no script ran');
  assert.deepEqual(errors, []);
});
