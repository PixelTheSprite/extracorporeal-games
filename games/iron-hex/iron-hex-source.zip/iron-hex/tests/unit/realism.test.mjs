// Realism rules: the situations each rule is about, built directly.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadCore } from '../core.mjs';

const { run } = loadCore();
const setup = rules =>
  run(`VIEW = NullView; appState.settings = defaultSettings(); appState.settings.roster = { tank: 1, inf: 2 };
  Object.assign(appState.settings.rules, ${JSON.stringify(rules)}); newBattle(77); appState.battle`);

test('supply lines: a unit stranded deep in enemy ground is cut off; one at home is supplied', () => {
  setup({ supplyLines: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, u = B.units.find(x => x.pid === 0 && x.type === 'inf'), home = { c: u.c, r: u.r };
    const cap = B.mapDef.spawns[1];
    // drop it next to the enemy capital, in enemy territory
    let spot = null;
    for (let r = 0; r < B.mapDef.H && !spot; r++) for (let c = 0; c < B.mapDef.W && !spot; c++) {
      const d = hexDist({ c, r }, cap);
      if (d >= 2 && d <= 3 && !TERRAIN[tileAt(c, r).t].water && !unitAtLayer(c, r, false)) spot = { c, r };
    }
    for (const n of neighborsRaw(spot.c, spot.r, B.mapDef.W, B.mapDef.H).concat([spot])) B.territory[key(n.c, n.r)] = 1;
    Object.assign(u, { c: spot.c, r: spot.r });
    logSupplyLines(B);
    const strandedCut = u.cut;
    Object.assign(u, home); logSupplyLines(B);
    return JSON.stringify({ strandedCut, homeCut: u.cut });
  })()`)
  );
  assert.equal(r.strandedCut, 1);
  assert.equal(r.homeCut, 0);
});

test('surrender: badly hurt and cut off for 2 turns gives up; healthy does not', () => {
  setup({ supplyLines: true, surrender: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, [a, b] = B.units.filter(x => x.pid === 0 && x.type === 'inf');
    a.cut = 2; a.hp = Math.floor(a.maxHp * 0.2);
    b.cut = 2; b.hp = b.maxHp;
    logRealism(B, null);
    return JSON.stringify({ hurt: a.hp, healthy: b.hp, stat: B.stats.surrendered });
  })()`)
  );
  assert.equal(r.hurt, 0);
  assert.ok(r.healthy > 0);
  assert.equal(r.stat, 1);
});

test('surrender: a surrounded, badly hurt unit gives up even without supply lines', () => {
  setup({ surrender: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, u = B.units.find(x => x.pid === 0 && x.type === 'inf'), foes = B.units.filter(x => x.pid === 1);
    u.hp = 5;
    // ring it with enemy units' reach: place enemies on every other neighbour
    const ns = neighborsRaw(u.c, u.r, B.mapDef.W, B.mapDef.H).filter(n => costAt(UNIT_TYPES.inf, n.c, n.r) != null);
    ns.forEach((n, i) => { if (i % 2 === 0) { const f = foes[i / 2 % foes.length]; B.units.push(Object.assign({}, f, { id: 900 + i, c: n.c, r: n.r })); } });
    const before = surrounded(B, u);
    logRealism(B, null);
    return JSON.stringify({ before, hp: u.hp });
  })()`)
  );
  assert.equal(r.before, true);
  assert.equal(r.hp, 0);
});

test('entrenchment and suppression bookkeeping at the end of a turn', () => {
  setup({ entrench: true, suppression: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, [a, b] = B.units.filter(x => x.pid === 0 && x.type === 'inf');
    const st = new Map([[a.id, { hist: [{ c: a.c, r: a.r }] }], [b.id, { hist: [{ c: b.c, r: b.r }, { c: b.c + 1, r: b.r }] }]]);
    a.hp0 = a.hp; a.hp -= Math.ceil(a.maxHp * 0.3);    // lost 30% this turn
    b.hp0 = b.hp;
    logRealism(B, st); logRealism(B, st);
    return JSON.stringify({ aDug: a.dug, bDug: b.dug, aSupp: a.supp, bSupp: b.supp, aMoves: reachable(a).size });
  })()`)
  );
  assert.equal(r.aDug, 2, 'held twice: two levels');
  assert.equal(r.bDug, 0, 'moved: no entrenchment');
  assert.equal(r.bSupp, 0);
  assert.equal(r.aMoves, 1, 'suppressed: can only stay put');
});

test('urban combat and elevation change cover, cost, range and sight', () => {
  setup({ urban: true, elevation: true });
  const r = JSON.parse(
    run(
      `JSON.stringify({ footCity: terrainDef(UNIT_TYPES.inf, 'c'), tankCity: terrainDef(UNIT_TYPES.tank, 'c'), tankCost: urbanCost(UNIT_TYPES.tank, 'c'), infCost: urbanCost(UNIT_TYPES.inf, 'c') })`
    )
  );
  assert.deepEqual(r, { footCity: 0.45, tankCity: 0.1, tankCost: 1, infCost: 0 });
});

// ---- batch 2: command and air ----
test('command radius: far from every command post, a ground unit moves 1 hex less', () => {
  setup({ command: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, u = B.units.find(x => x.pid === 0 && x.type === 'tank'), near = moveOf(u);
    const far = { c: B.mapDef.spawns[1].c, r: B.mapDef.spawns[1].r }; u.c = far.c; u.r = far.r; // nowhere near our posts
    return JSON.stringify({ near, far: moveOf(u), full: UNIT_TYPES.tank.move });
  })()`)
  );
  assert.equal(r.near, r.full);
  assert.equal(r.far, r.full - 1);
});

test('electronic warfare: an enemy drone jams nearby units; a friendly drone cancels it', () => {
  setup({ ew: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, u = B.units.find(x => x.pid === 0 && x.type === 'inf');
    const mk = (pid, id) => { const d = { id, pid, type: 'drone', c: u.c + 1, r: u.r, hp: 40, maxHp: 40, ammo: 3, maxAmmo: 3, fuel: 30, maxFuel: 30 }; B.units.push(d); return d; };
    const before = jammed(u), s0 = sightOf(u);
    mk(1, 991); const enemyNear = jammed(u), s1 = sightOf(u);
    mk(0, 992); const countered = jammed(u);
    return JSON.stringify({ before, enemyNear, countered, sightDrop: s0 - s1 });
  })()`)
  );
  assert.deepEqual(r, { before: false, enemyNear: true, countered: false, sightDrop: 2 });
});

test('air superiority and AA umbrellas change damage', () => {
  setup({ airSup: true, aaUmbrella: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, inf = B.units.find(x => x.pid === 1 && x.type === 'inf');
    const plane = { id: 993, pid: 0, type: 'plane', c: inf.c, r: inf.r - 2, hp: 60, maxHp: 60 };
    B.units = B.units.filter(x => !(x.pid === 1 && (UNIT_TYPES[x.type].domain === 'air' || x.type === 'aa')));
    B.units.push(plane);
    const ctl = airControl(plane), withAir = commandAirDamage(plane, inf, inf);
    B.units.push({ id: 994, pid: 1, type: 'aa', c: inf.c + 1, r: inf.r, hp: 60, maxHp: 60 });
    const underUmbrella = commandAirDamage(plane, inf, inf);
    return JSON.stringify({ ourControl: ctl === teamOf(0), withAir, underUmbrella });
  })()`)
  );
  assert.equal(r.ourControl, true);
  assert.equal(r.withAir, 1.1);
  assert.equal(Math.round(r.underUmbrella * 100) / 100, 0.88);
});

test('order friction: orders sometimes go wrong, the same way every time for the same seed', () => {
  const play = () => {
    setup({ friction: true });
    return run(`(() => {
      const B = appState.battle; REAL.FRICTION_BASE = 1; // every eligible order goes wrong, to test what 'wrong' means
      const orders = planAllAI('balanced'), st = turnState(B, orders).st;
      const confused = [...st.values()].filter(s => s.confused);
      REAL.FRICTION_BASE = 0.05;
      return JSON.stringify({ n: confused.length, shorter: confused.every(s => !s.o.path || s.o.path.length < orders[[...st].find(([, x]) => x === s)[0]].path.length || s.o.target == null), stat: B.stats.friction });
    })()`);
  };
  const a = JSON.parse(play()),
    b = JSON.parse(play());
  assert.ok(a.n > 0, 'some orders went wrong');
  assert.ok(a.shorter, 'moves were cut short or targets dropped');
  assert.deepEqual(a, b, 'same seed, same friction');
});

// ---- batch 3: artillery, submarines, mines, carriers, railways ----
test('artillery: fires at what spotters see, never after moving; firing reveals it', () => {
  setup({ artillery: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, foe = B.units.find(x => x.pid === 1 && x.type === 'inf');
    const gun = { id: 995, pid: 0, type: 'arty', c: foe.c - 3, r: foe.r, hp: 80, maxHp: 80, ammo: 6, maxAmmo: 6 };
    B.units = B.units.filter(x => x.pid !== 0 || x.type === 'arty'); B.units.push(gun);
    const alone = spotted(0, foe);                               // nobody to spot for it
    B.units.push({ id: 996, pid: 0, type: 'inf', c: foe.c - 1, r: foe.r, hp: 70, maxHp: 70, ammo: 6, maxAmmo: 6 });
    const withSpotter = spotted(0, foe) && targetsFrom(gun, gun).includes(foe);
    gun.mv = B.turn; const afterMoving = bestTargetInRange(gun);
    return JSON.stringify({ alone, withSpotter, afterMoving: afterMoving === null, typeAllowedOff: typeAllowed('arty', {}), typeAllowedOn: typeAllowed('arty', { artillery: true }) });
  })()`)
  );
  assert.deepEqual(r, { alone: false, withSpotter: true, afterMoving: true, typeAllowedOff: false, typeAllowedOn: true });
});

test('submarines: hidden beyond 1 hex (2 from a destroyer); only destroyers can attack them', () => {
  setup({ subs: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, sub = { id: 997, pid: 1, type: 'sub', c: 5, r: 5, hp: 80, maxHp: 80 };
    B.units.push(sub);
    const tank = B.units.find(x => x.pid === 0 && x.type === 'tank'); tank.c = 9; tank.r = 5;
    const far = canSee(0, sub);
    const dd = { id: 998, pid: 0, type: 'ship', c: 7, r: 5, hp: 100, maxHp: 100 }; B.units.push(dd);
    return JSON.stringify({ far, nearDestroyer: canSee(0, sub), destroyerCanHit: canHit(dd, sub), tankCanHit: canHit(tank, sub) });
  })()`)
  );
  assert.deepEqual(r, { far: false, nearDestroyer: true, destroyerCanHit: true, tankCanHit: false });
});

test('mines: laid where an engineer stands; an enemy stepping on one is hurt and stopped; an engineer clears it', () => {
  setup({ mines: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle; B.units.push({ id: 999, pid: 0, type: 'eng', c: 6, r: 6, hp: 70, maxHp: 70, ammo: 4, maxAmmo: 4 });
    const eng = unitById(999), st = new Map([[eng.id, { o: { type: 'mine' } }]]);
    logMines(B, st);
    const laid = !!B.mines[key(6, 6)];
    const foe = B.units.find(x => x.pid === 1 && x.type === 'tank'), hp = foe.hp; foe.c = 6; foe.r = 6;
    const stopped = stepOnMine(B, foe), lost = hp - foe.hp;
    B.mines[key(7, 7)] = { pid: 0, sea: false }; const fe = { id: 1000, pid: 1, type: 'eng', c: 7, r: 7, hp: 70, maxHp: 70 };
    const engStopped = stepOnMine(B, fe);
    return JSON.stringify({ laid, stopped, lost, gone: !B.mines[key(6, 6)], engStopped, cleared: !B.mines[key(7, 7)], engHp: fe.hp });
  })()`)
  );
  assert.deepEqual(r, { laid: true, stopped: true, lost: 30, gone: true, engStopped: false, cleared: true, engHp: 70 });
});

test('carriers land aircraft; railways make roads in your territory cheap', () => {
  setup({ carriers: true, rail: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, plane = B.units.find(x => x.pid === 0 && x.type === 'plane') || (B.units.push({ id: 1001, pid: 0, type: 'plane', c: 3, r: 3, hp: 60, maxHp: 60 }), unitById(1001));
    const over = carrierUnder(plane);
    B.units.push({ id: 1002, pid: 0, type: 'carrier', c: plane.c, r: plane.r, hp: 120, maxHp: 120 });
    const k = key(plane.c, plane.r); B.roads[k] = true; B.territory[k] = 0;
    return JSON.stringify({ before: over, after: carrierUnder(plane), railMine: costAt(UNIT_TYPES.tank, plane.c, plane.r, 0), railTheirs: costAt(UNIT_TYPES.tank, plane.c, plane.r, 1) });
  })()`)
  );
  assert.equal(r.before, false);
  assert.equal(r.after, true);
  assert.ok(r.railMine < 0.5, 'a third of a hex on your railway');
  assert.ok(r.railTheirs >= 0.5, 'no railway in enemy territory');
});

test('a battle with every realism rule and the new units replays exactly', async () => {
  const want = await run(`(async () => { VIEW = NullView; appState.settings = defaultSettings();
    Object.assign(appState.settings.rules, Object.fromEntries(P11_KEYS.map(k => [k, true])));
    appState.settings.roster = { tank: 1, inf: 2, eng: 1, arty: 1, plane: 1, carrier: 1, ship: 1, sub: 1, lst: 1 };
    newBattle(31337); let o = { end: false }; while (!o.end) o = await simulateTurn(planAllAI('balanced'));
    globalThis.__rep = replayOf(appState.battle); return stateHash(appState.battle); })()`);
  const got = await run(`(async () => { loadReplayStart(__rep); let o = { end: false };
    for (let i = 0; i < __rep.log.length && !o.end; i++) o = await replayTurn(__rep, i); return stateHash(appState.battle); })()`);
  assert.equal(got, want);
});

// ---- batch 4: seasons, reinforcements, victory points, information operations, ammunition ----
test('seasons: winter snow slows ground units off-road and freezes the shallows; spring mud bogs down vehicles', () => {
  setup({ seasons: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, at = (season) => { B.seasonStart = SEASONS.indexOf(season); B.turn = 1; };
    at('Winter'); const winter = { inf: seasonCost(UNIT_TYPES.inf, 'p', false), road: seasonCost(UNIT_TYPES.inf, 'p', true), ice: frozenCost(UNIT_TYPES.tank, 'w') };
    at('Spring'); const spring = { tank: seasonCost(UNIT_TYPES.tank, 'p', false), inf: seasonCost(UNIT_TYPES.inf, 'p', false), ice: frozenCost(UNIT_TYPES.tank, 'w') };
    at('Summer'); const summer = seasonCost(UNIT_TYPES.tank, 'p', false);
    B.seasonStart = 0; B.turn = 16; const later = seasonOf(B);
    return JSON.stringify({ winter, spring, summer, later });
  })()`)
  );
  assert.deepEqual(r, { winter: { inf: 0.5, road: 0, ice: 2 }, spring: { tank: 0.5, inf: 0, ice: null }, summer: 0, later: 'Summer' });
});

test('timed reinforcements arrive every 8 turns at a held capital', () => {
  setup({ reinforce: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, n0 = B.units.length; B.turn = 7; logReinforcements(B); const at7 = B.units.length - n0;
    B.turn = 8; logReinforcements(B); return JSON.stringify({ at7, at8: B.units.length - n0, fromRoster: B.units.slice(n0).every(u => B.rosterTypes[u.pid].includes(u.type)) });
  })()`)
  );
  assert.deepEqual(r, { at7: 0, at8: 4, fromRoster: true });
});

test('victory points score cities and pick a winner; heavy losses make an army sue for peace', () => {
  setup({ vp: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle; scoreVictoryPoints(B); const one = Object.assign({}, B.vp);
    B.vp[teamOf(0)] = vpTarget(B); const winner = vpWinner(B);
    const before = warWeary(B, 1); for (const u of B.units.filter(u => u.pid === 1).slice(0, Math.ceil(B.units.filter(u => u.pid === 1).length * 0.8))) u.hp = 0;
    return JSON.stringify({ capitalsScore: one[teamOf(0)] === 1 && one[teamOf(1)] === 1, winner, before, after: warWeary(B, 1) });
  })()`)
  );
  assert.deepEqual(r, { capitalsScore: true, winner: 0, before: false, after: true });
});

test('information operations: a broadcast lowers morale unless the target can verify with friends nearby', () => {
  setup({ infoOps: true, morale: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle; initMorale(B);
    const sq = B.units.find(u => u.pid === 0 && u.type === 'inf');
    const lone = { id: 1101, pid: 1, type: 'inf', c: sq.c + 2, r: sq.r, hp: 70, maxHp: 70, morale: 60 };
    B.units = B.units.filter(u => u.pid === 0); B.units.push(lone);
    logBroadcasts(B, new Map([[sq.id, { o: { type: 'broadcast' } }]]));
    const alone = lone.morale;
    lone.morale = 60; B.units.push({ id: 1102, pid: 1, type: 'inf', c: lone.c + 1, r: lone.r, hp: 70, maxHp: 70 }, { id: 1103, pid: 1, type: 'tank', c: lone.c, r: lone.r + 1, hp: 90, maxHp: 90 });
    logBroadcasts(B, new Map([[sq.id, { o: { type: 'broadcast' } }]]));
    return JSON.stringify({ alone, verified: lone.morale });
  })()`)
  );
  assert.deepEqual(r, { alone: 50, verified: 60 });
});

test('ammunition: armor-piercing against armor, high-explosive against soldiers; loaded through the order', () => {
  setup({ ammo: true });
  const r = JSON.parse(
    run(`(() => {
    const B = appState.battle, tank = B.units.find(u => u.pid === 0 && u.type === 'tank'), foeTank = { type: 'tank' }, foeInf = { type: 'inf' };
    const he = [ammoDamage(tank, foeTank), ammoDamage(tank, foeInf)];
    turnState(B, { [tank.id]: { type: 'hold', ammo: 'ap' } });
    return JSON.stringify({ he, ap: [ammoDamage(tank, foeTank), ammoDamage(tank, foeInf)], loaded: tank.ammoType });
  })()`)
  );
  assert.deepEqual(r, { he: [0.75, 1.25], ap: [1.25, 0.7], loaded: 'ap' });
});
