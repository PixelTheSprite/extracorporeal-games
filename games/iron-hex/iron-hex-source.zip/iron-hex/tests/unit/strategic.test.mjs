// Missile silos and city development (Phase 12).
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadCore } from '../core.mjs';

const { run } = loadCore();
const setup = rules =>
  run(`VIEW = NullView; appState.settings = defaultSettings(); appState.settings.roster = { tank: 1, inf: 2, eng: 1 };
  Object.assign(appState.settings.rules, ${JSON.stringify(rules)}); newBattle(91); appState.battle`);
const placeSilo = `(() => { const B = appState.battle, cap = B.mapDef.spawns[0];
  let at = null; for (let r = 0; r < B.mapDef.H && !at; r++) for (let c = 0; c < B.mapDef.W && !at; c++) if (hexDist({ c, r }, cap) === 2 && canBuildAt('silo', { c, r }, 0) && !unitAtLayer(c, r, false)) at = { c, r };
  B.structs[key(at.c, at.r)] = newStruct('silo', 0, null); return key(at.c, at.r); })()`;

test('silos charge; more cities charge faster; an unready silo cannot fire', () => {
  setup({ missiles: true });
  const r = JSON.parse(
    run(`(() => { const B = appState.battle, k = ${placeSilo}, s = B.structs[k];
    const need = chargeNeeded(B, 0, keyHex(k)); const readyAt0 = siloReady(B, Object.assign({ k }, s));
    for (let i = 0; i < need; i++) logMissiles(B);
    const extra = Object.keys(B.cities).filter(x => B.cities[x].owner == null).slice(0, 4); extra.forEach(x => (B.cities[x].owner = 0));
    return JSON.stringify({ need, readyAt0, readyAfter: siloReady(B, Object.assign({ k }, s)), fasterWithCities: chargeNeeded(B, 0, keyHex(k)) < need || need === REAL.MISSILE_CHARGE_MIN, siloAllowedOff: structAllowed('silo', {}) });
  })()`)
  );
  assert.equal(r.readyAt0, false);
  assert.equal(r.readyAfter, true);
  assert.ok(r.fasterWithCities);
  assert.equal(r.siloAllowedOff, false);
});

test('a strike hits the target hard and its neighbours lightly; out of range or unseen targets are refused', async () => {
  setup({ missiles: true });
  const r = JSON.parse(
    await run(`(async () => { const B = appState.battle, k = ${placeSilo}, s = B.structs[k]; s.charge = 99;
    const sh = keyHex(k), foe = B.units.find(u => u.pid === 1 && u.type === 'tank'), mate = B.units.find(u => u.pid === 1 && u.type === 'inf');
    let tgt = null; for (let rr = 0; rr < B.mapDef.H && !tgt; rr++) for (let c = 0; c < B.mapDef.W && !tgt; c++) { const h = { c, r: rr }; if (hexDist(h, sh) === 6 && landPassAt(c, rr) && !unitAtLayer(c, rr, false)) tgt = h; }
    Object.assign(foe, { c: tgt.c, r: tgt.r }); const nb = neighborsRaw(tgt.c, tgt.r, B.mapDef.W, B.mapDef.H).find(n => landPassAt(n.c, n.r) && !unitAtLayer(n.c, n.r, false)); Object.assign(mate, { c: nb.c, r: nb.r });
    B.units = B.units.filter(u => !(u.pid === 1 && (u.type === 'aa' || UNIT_TYPES[u.type].domain === 'sea')));
    const far = { c: Math.min(B.mapDef.W - 1, sh.c + REAL.MISSILE_RANGE + 2), r: sh.r };
    const hp = [foe.hp, mate.hp];
    await fireMissiles(B, { ['strike:' + k]: { type: 'strike', target: tgt } });
    return JSON.stringify({ farOk: strikeTargetOk(B, 0, k, far), lostTarget: hp[0] - foe.hp, lostNeighbour: hp[1] - mate.hp, charge: s.charge, stat: B.stats.missiles });
  })()`)
  );
  assert.equal(r.farOk, false);
  assert.ok(r.lostTarget >= 30 && r.lostTarget <= 60, 'heavy damage on the target (less in cover)');
  assert.ok(r.lostNeighbour > 0 && r.lostNeighbour <= 20, 'light splash damage');
  assert.equal(r.charge, 0);
  assert.equal(r.stat, 1);
});

test('anti-aircraft and warships near the target can intercept', async () => {
  setup({ missiles: true });
  const n = JSON.parse(
    await run(`(async () => { const B = appState.battle, k = ${placeSilo}; let blocked = 0;
    const cap = B.mapDef.spawns[1], foe = B.units.find(u => u.pid === 1 && u.type === 'tank');
    B.units.push({ id: 1201, pid: 1, type: 'aa', c: foe.c, r: foe.r, hp: 60, maxHp: 60 }, { id: 1202, pid: 1, type: 'aa', c: foe.c, r: foe.r, hp: 60, maxHp: 60 });
    REAL.MISSILE_RANGE = 99;
    for (let i = 0; i < 40; i++) { B.structs[k].charge = 99; for (const g of [unitById(1201), unitById(1202)]) g.hp = 60; const before = B.stats.intercepted || 0; await fireMissiles(B, { ['strike:' + k]: { type: 'strike', target: { c: foe.c, r: foe.r } } }); if ((B.stats.intercepted || 0) > before) blocked++; }
    REAL.MISSILE_RANGE = 10; return String(blocked); })()`)
  );
  assert.ok(n > 15 && n < 40, `about 80% intercepted with two guards (${n}/40)`);
});

test('city development: investing pays, takes 3 turns, raises income and defense; capture drops a level', () => {
  setup({ cityDev: true, income: true, production: true });
  const r = JSON.parse(
    run(`(() => { const B = appState.battle, ck = key(B.mapDef.spawns[0].c, B.mapDef.spawns[0].r), c = B.cities[ck];
    B.funds[0] = 100; const income0 = incomeOf(B, 0);
    applyInvestments(B, { ['invest:' + ck]: { type: 'invest' } });
    const paid = 100 - B.funds[0]; logCityDev(B); logCityDev(B); const mid = cityLevel(c); logCityDev(B);
    const lvl = cityLevel(c), income2 = incomeOf(B, 0), def = cityDefense(keyHex(ck));
    cityCaptured(B, c);
    return JSON.stringify({ paid, mid, lvl, incomeGain: income2 - income0, def, afterCapture: cityLevel(c) });
  })()`)
  );
  assert.deepEqual(r, { paid: 20, mid: 1, lvl: 2, incomeGain: 2, def: 0.9, afterCapture: 1 });
});
