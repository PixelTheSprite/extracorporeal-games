// Unit tests for pure game-logic functions: node --test tests/unit/
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadCore } from '../core.mjs';

const { run } = loadCore();
const j = src => JSON.parse(run(`JSON.stringify(${src})`));

test('hexDist: offset hex distance, symmetric', () => {
  assert.equal(run('hexDist({ c:0, r:0 }, { c:0, r:0 })'), 0);
  assert.equal(run('hexDist({ c:0, r:0 }, { c:3, r:0 })'), 3);
  assert.equal(run('hexDist({ c:2, r:1 }, { c:2, r:2 })'), 1);
  for (const [a, b] of [
    [
      [1, 1],
      [5, 7],
    ],
    [
      [0, 3],
      [9, 0],
    ],
  ])
    assert.equal(
      run(`hexDist({ c:${a[0]}, r:${a[1]} }, { c:${b[0]}, r:${b[1]} })`),
      run(`hexDist({ c:${b[0]}, r:${b[1]} }, { c:${a[0]}, r:${a[1]} })`)
    );
});

test('unkey reverses key', () => {
  assert.deepEqual(j('unkey(key(12, 7))'), [12, 7]);
});

test('MinHeap pops lowest first, ties in insertion order (same as a stable sort)', () => {
  const order = j(
    `(() => { const h = heapOf(x => x.p); for (const [p, id] of [[2,'a'],[1,'b'],[2,'c'],[1,'d'],[0,'e']]) h.push({ p, id }); const out = []; while (h.length) out.push(h.shift().id); return out; })()`
  );
  assert.deepEqual(order, ['e', 'b', 'd', 'a', 'c']);
});

test('parseLookup reads a fenced JSON answer and rejects bad ones', () => {
  const d = j(`parseLookup('\`\`\`json\\n' + JSON.stringify(LOOKUP_FIXTURE) + '\\n\`\`\`')`);
  assert.equal(d.domain, 'land');
  assert.equal(d.stats.speed.value, 55);
  assert.throws(() => run(`parseLookup('{"found": false, "caveats": "no idea"}')`), /Not recognized/);
  assert.throws(() => run(`parseLookup('no json here')`), /No JSON/);
});

test('scoreStat normalizes against the domain scale and caps at 10', () => {
  assert.equal(run(`scoreStat('land', 'speed', 35)`), 5);
  assert.equal(run(`scoreStat('land', 'speed', 200)`), 10);
  assert.equal(run(`scoreStat('air', 'maneuver', 7.4)`), 7);
});

test('custom unit ids: only the safe pattern is accepted', () => {
  assert.equal(run(`SAFE_UNIT_ID.test('u_t34_85')`), true);
  assert.equal(run(`SAFE_UNIT_ID.test('u_x" onmouseover="1')`), false);
  assert.ok(j(`registerCustomUnit(Object.assign(fixtureUnit(), { id:'evil"' }))`).length > 0);
});

test('validateAll: every built-in unit type, map preset and real-world map is valid', () => {
  assert.deepEqual(j('validateAll()'), []);
});

test('validateMapDef catches broken maps', () => {
  const bad = j(`validateMapDef({ W:12, H:10, rows:Array(10).fill('pppppppppppp'), spawns:[{ c:1, r:1 }] })`);
  assert.ok(bad.some(p => /at least 2 spawn/.test(p)));
});

test('prices: built-ins fixed, custom units from stats, roster cost adds up', () => {
  assert.equal(run('priceOf(UNIT_TYPES.tank)'), 10);
  assert.equal(run('rosterCost({ tank:2, inf:2 })'), 28);
});

test('summarizeRecords: wins, streaks, fastest win', () => {
  const s = j(
    `summarizeRecords([{ at:'1', result:'win', turns:20, mapName:'A', opponents:['balanced'] }, { at:'2', result:'win', turns:12, mapName:'B', opponents:['balanced'] }, { at:'3', result:'loss', turns:30, mapName:'A', opponents:['balanced'] }])`
  );
  assert.equal(s.wins, 2);
  assert.equal(s.bestStreak, 2);
  assert.equal(s.streak, 0);
  assert.equal(s.fastestWin.turns, 12);
});

test('unlockedPeriods follows the ladder', () => {
  assert.deepEqual(j(`unlockedPeriods({ units:{ tank:{ battles:3, kills:12, wins:0, special:0 } } }, 'tank')`), [
    'modern',
    'medieval',
    'ancient',
  ]);
});

test('battle-dependent helpers: travelField, settleClaim, teamScore, save migration', () => {
  run(
    `VIEW = NullView; appState.settings = defaultSettings(); appState.settings.armies = 4; appState.settings.teams = [0, 0, 1, 1]; newBattle(11);`
  );
  // travel: a 3-turn hex really is 2–3 turns of movement away
  const far = j(
    `(() => { const u = appState.battle.units.find(x => x.type === 'tank'); const f = travelField(u, 4); const n = [...f.values()].find(n => n.turns === 3); return { cost:n.cost, move:UNIT_TYPES.tank.move }; })()`
  );
  assert.ok(far.cost > 2 * far.move && far.cost <= 3 * far.move);
  // allies sharing territory don't contest a hex; enemies do
  assert.equal(run('settleClaim(new Set([0, 1]), null)'), 0);
  assert.equal(run('settleClaim(new Set([0, 2]), null)'), undefined);
  assert.ok(run('teamScore(appState.battle, 0)') > 0);
  // a version-1 save migrates all the way to the current version
  const v = j(`(() => { const d = toV1Save(); return applySave(d) && appState.battle ? SAVE_VERSION : 0; })()`);
  assert.equal(v, run('SAVE_VERSION'));
});
