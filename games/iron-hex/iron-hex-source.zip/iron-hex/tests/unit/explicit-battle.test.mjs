// Game logic takes the battle explicitly: a battle handed to the AI and to turn resolution plays out exactly as it
// does through the global battle, even when the global battle and map belong to a different battle entirely.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadCore } from '../core.mjs';

const { run } = loadCore();
const RULES = `{ fog: true, intelFade: true, morale: true, weather: true, supplyLines: true, entrench: true, suppression: true, facing: true, friction: true, mines: true, missiles: true }`;
const make =
  seed => `(() => { VIEW = NullView; appState.settings = defaultSettings(); appState.settings.roster = { tank: 2, inf: 2, eng: 1, aa: 1, plane: 1 };
  Object.assign(appState.settings.rules, ${RULES}); newBattle(${seed}); return appState.battle; })()`;

test('a battle passed explicitly plays out identically, and the global battle is never touched', async () => {
  // 1. normally, through the global battle
  const normal = await run(
    `(async () => { ${make(4242)}; let o = { end: false }; while (!o.end) o = await simulateTurn(planAllAI('balanced')); return stateHash(appState.battle) + ' t' + appState.battle.turn; })()`
  );
  // 2. explicitly: the global battle (and map) are a decoy on another map; the real battle is handed in
  const explicit = JSON.parse(
    await run(`(async () => {
    const B = ${make(4242)};
    appState.settings.mapId = 'islands';
    const decoy = ${make(777)}; const decoyHash = stateHash(decoy);    // newBattle made the decoy current, with its own R.map
    assert = v => { if (!v) throw new Error('decoy'); };
    if (appState.battle !== decoy || R.map === B.map) throw new Error('setup');
    let o = { end: false };
    while (!o.end) o = await simulateTurn(planAllAI('balanced', B), B);
    return JSON.stringify({ result: stateHash(B) + ' t' + B.turn, decoyUntouched: stateHash(decoy) === decoyHash && appState.battle === decoy });
  })()`)
  );
  assert.equal(explicit.result, normal, 'same final state');
  assert.equal(explicit.decoyUntouched, true, 'the global battle was never read or changed');
});
