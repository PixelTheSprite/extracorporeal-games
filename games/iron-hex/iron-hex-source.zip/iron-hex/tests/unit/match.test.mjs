// Online matches: two "devices" (separate copies of the game logic) share one in-memory database.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadCore } from '../core.mjs';
import { createFakeStore } from '../fakedb.mjs';

function device(db, uid) {
  const core = loadCore();
  core.ctx.__db = db;
  core.run('VIEW = NullView;');
  return { uid, run: core.run, call: src => core.run(`(async () => { const db = __db; ${src} })()`) };
}
// Each device plays its own seat: load the current state, let the AI choose that seat's orders, submit.
async function playMySeat(d, mid, seat) {
  return d.call(`
    const m = (await db.doc('matches/${mid}').get()).data();
    if (m.status !== 'playing') return m.status;
    if ((await db.doc('matches/${mid}/orders/' + m.turn + '_${seat}').get()).exists) return 'waiting';
    const state = await getBig(db, 'matches/${mid}/data/state');
    const orders = await withBattle(state, B => planAI(Object.assign({}, B.players[${seat}], { ai: 'balanced' })));
    await submitOrders(db, '${mid}', '${d.uid}', ${seat}, m.turn, { orders });
    return 'submitted';`);
}
const tryResolve = (d, mid) => d.call(`return (await resolveMatchTurn(db, '${mid}', '${d.uid}', o => simulateTurn(o))).resolved;`);

test('two players finish a 3-seat match (one AI seat); each turn is resolved exactly once', async () => {
  const { db } = createFakeStore();
  const A = device(db, 'alice'),
    Bd = device(db, 'bob');
  const mid = await A.call(
    `return createMatch(db, 'alice', { name: 'Test', settings: Object.assign(defaultSettings(), { mapId: 'random', randomSeed: 99 }), seats: [{ human: true }, { human: true }, { human: false, ai: 'aggressive' }] });`
  );
  assert.equal(await A.call(`return (await db.doc('matches/${mid}').get()).data().status;`), 'open');
  assert.equal((await Bd.call(`return claimSeat(db, '${mid}', 'bob', 1);`)).ok, true);
  assert.equal((await A.call(`return claimSeat(db, '${mid}', 'carol', 1);`)).ok, false, 'a taken seat stays taken');
  assert.equal(await A.call(`return (await db.doc('matches/${mid}').get()).data().status;`), 'playing');
  let resolutions = 0,
    status = 'playing',
    guard = 0;
  while (status === 'playing' && guard++ < 80) {
    await Promise.all([playMySeat(A, mid, 0), playMySeat(Bd, mid, 1)]);
    const [ra, rb] = await Promise.all([tryResolve(A, mid), tryResolve(Bd, mid)]); // both race to resolve
    assert.ok(!(ra && rb), 'never resolved twice');
    resolutions += (ra ? 1 : 0) + (rb ? 1 : 0);
    status = await A.call(`return (await db.doc('matches/${mid}').get()).data().status;`);
  }
  const m = await A.call(`return (await db.doc('matches/${mid}').get()).data();`);
  assert.equal(m.status, 'finished');
  assert.equal(resolutions, m.result.turns, 'one resolution per turn');
  // both devices load the same final battle
  const hashA = await A.call(`return withBattle(await getBig(db, 'matches/${mid}/data/state'), B => stateHash(B));`);
  const hashB = await Bd.call(`return withBattle(await getBig(db, 'matches/${mid}/data/state'), B => stateHash(B));`);
  assert.equal(hashA, hashB);
  // and the match replays to the same final state
  const replayHash = await Bd.call(
    `const rep = await matchReplay(db, '${mid}'); loadReplayStart(rep); for (let i = 0; i < rep.log.length; i++) await replayTurn(rep, i); return stateHash(appState.battle);`
  );
  assert.equal(replayHash, hashA);
});

test('a missed deadline lets the turn resolve without the absent player', async () => {
  const { db } = createFakeStore();
  const A = device(db, 'alice'),
    Bd = device(db, 'bob');
  const mid = await A.call(
    `return createMatch(db, 'alice', { name: 'Deadline', settings: defaultSettings(), seats: [{ human: true }, { human: true }], deadlineHours: 1 });`
  );
  await Bd.call(`return claimSeat(db, '${mid}', 'bob', 1);`);
  await playMySeat(A, mid, 0);
  assert.equal(await tryResolve(A, mid), false, 'waits for Bob');
  await A.call(`await db.doc('matches/${mid}').update({ turnStarted: Date.now() - 2 * 3600000 });`); // two hours later
  assert.equal(await tryResolve(A, mid), true, 'resolves after the deadline');
  assert.equal(await A.call(`return (await db.doc('matches/${mid}').get()).data().turn;`), 2);
});

test('the host can start early: empty seats become AI', async () => {
  const { db } = createFakeStore();
  const A = device(db, 'alice');
  const mid = await A.call(
    `return createMatch(db, 'alice', { name: 'Early', settings: defaultSettings(), seats: [{ human: true }, { human: true }] });`
  );
  assert.equal(await A.call(`return startWithAI(db, '${mid}', 'alice');`), true);
  await playMySeat(A, mid, 0);
  assert.equal(await tryResolve(A, mid), true);
});
