// Loads the game logic (src/core, in manifest order) into a fresh VM context for Node tests.
// Top-level names are visible to code run in that context: core.run('hexDist({ c:0, r:0 }, { c:2, r:0 })').
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

export const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
export function loadCore() {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src/manifest.json'), 'utf8'));
  const code = manifest.core.map(f => fs.readFileSync(path.join(root, 'src', f), 'utf8')).join('\n');
  const ctx = vm.createContext({ console, Date, Math, JSON, Promise, Object, Array, Map, Set, Number, String, Error, Symbol });
  vm.runInContext(`'use strict';\n${code}`, ctx, { filename: 'core.js' });
  return { ctx, run: src => vm.runInContext(src, ctx) };
}
