// An in-memory stand-in for the hosted runtime's database: the same document/collection API the game uses,
// including leases (acquire) and snapshots, so match logic can be tested in Node with several "devices".
export function createFakeStore() {
  const docs = new Map(),
    leases = new Map(),
    listeners = new Set();
  let writes = 0;
  const snap = (path, v) => ({
    id: path.split('/').pop(),
    exists: v !== undefined,
    data: () => (v === undefined ? undefined : JSON.parse(JSON.stringify(v))),
    metadata: { fromCache: false, hasPendingWrites: false },
  });
  const notify = path => {
    for (const l of listeners) if (path === l.path || path.startsWith(l.path + '/')) l.fire();
  };
  const tick = () => new Promise(r => setTimeout(r, 0));
  const docRef = path => ({
    id: path.split('/').pop(),
    path,
    async get() {
      await tick();
      return snap(path, docs.get(path));
    },
    async set(v) {
      await tick();
      docs.set(path, JSON.parse(JSON.stringify(v)));
      writes++;
      notify(path);
    },
    async update(v) {
      await tick();
      docs.set(path, Object.assign(docs.get(path) || {}, JSON.parse(JSON.stringify(v))));
      writes++;
      notify(path);
    },
    async delete() {
      await tick();
      docs.delete(path);
      notify(path);
    },
    async acquire({ holder, ttlMs = 30000 }) {
      await tick();
      const now = Date.now(),
        l = leases.get(path);
      if (l && l.expires > now && l.holder !== holder) return { acquired: false, expiresAt: new Date(l.expires).toISOString() };
      leases.set(path, { holder, expires: now + ttlMs });
      return { acquired: true, holder, version: 1, expiresAt: new Date(now + ttlMs).toISOString() };
    },
    onSnapshot(next) {
      const l = { path, fire: () => next(snap(path, docs.get(path))) };
      listeners.add(l);
      setTimeout(l.fire, 0);
      return () => listeners.delete(l);
    },
    collection: sub => colRef(`${path}/${sub}`),
  });
  const colRef = path => ({
    path,
    doc: id => docRef(`${path}/${id || 'd' + Math.random().toString(36).slice(2)}`),
    async get() {
      await tick();
      const d = [...docs.keys()]
        .filter(k => k.startsWith(path + '/') && k.split('/').length === path.split('/').length + 1)
        .sort()
        .map(k => snap(k, docs.get(k)));
      return { docs: d, size: d.length, empty: !d.length, docChanges: () => [] };
    },
    onSnapshot(next) {
      const l = { path, fire: async () => next(await colRef(path).get()) };
      listeners.add(l);
      setTimeout(l.fire, 0);
      return () => listeners.delete(l);
    },
  });
  return { db: { doc: docRef, collection: colRef }, stats: () => ({ docs: docs.size, writes }) };
}
