# Phase 13: Restructure and export

**Shape:** Data/engine split, layout only (no behavior change)
**Depends on:** Phase 12; the explicit-battle refactor (game logic takes `B`)

## Goal
Reorganize the repository into the target layout, split the roadmap into small files, and add the files Claude Code reads first, so the first Claude Code session starts oriented and loads little. This is the last phase done in chat; export to Claude Code after it.

## Files touched
- `src/core/*.js` (28 files) → `engine/` subfolders; `src/ui/*.js` (36 files) → `ui/` subfolders
- `src/manifest.json`: new paths, same order. `build.mjs`, `tests/core.mjs`: new roots
- Split by section (largest files): `src/core/ai.js` (853 lines), `src/core/harness.js` (734), `src/ui/render.js` (762), `src/core/realism.js` (582)
- Data-heavy files, moved as they are (they become JSON in Phase 15): `src/core/skins.js` (937, sprite art), `src/core/realmaps.js` (819, maps)
- New: `CLAUDE.md`, `docs/ROADMAP.md`, `docs/phases/NN-*.md`, `docs/notes/*.md`, `docs/PROJECT_MAP.md`, `docs/HANDOFF.md`

## Target layout
```
CLAUDE.md
docs/      ROADMAP.md, phases/, notes/, HANDOFF.md, PROJECT_MAP.md
engine/    battle/ combat/ ai/ vision/ economy/ missions/ replay/ net/ rules/ (one file per optional rule)
content/   (Phase 15: units, structures, terrain, maps, campaigns, looks, rules.json; for now the two data-heavy files)
ui/        screens/ battle/ editors/ community/ a11y/ audio/
platform/  (Phase 16)   apps/ (Phases 17–19)
tests/     engine/ ui/ regression/ browser/ fixtures/
tools/     ab/ art/ codemod/ repo-map/
```

## Work items
- [ ] Baseline: run the full suite, unit and browser tests; keep the output to compare against
- [ ] Move game logic into `engine/` subfolders and interface code into `ui/` subfolders; update manifest paths only, keeping the order
- [ ] Split `ai.js`, `harness.js`, `render.js` and `realism.js` at their existing section comments into files under about 400 lines; append the new files to the manifest at the original's position
- [ ] Write `CLAUDE.md` (under about 80 lines): what Iron Hex is, commands, conventions (pass `B`; every rule is a toggle with values in `REAL`; prove changes with the suite), where things live
- [ ] Split the roadmap Claude Doc into `docs/ROADMAP.md` (index under about 80 lines), `docs/phases/01–20-*.md` (shipped phases condensed to outcomes and known issues), `docs/notes/` (architecture, balance, decisions)
- [ ] Regenerate `docs/PROJECT_MAP.md`; rewrite `docs/HANDOFF.md` for Phase 14
- [ ] Export: zip ready for `git init`, plus a first-session opener for Claude Code

## Data vs engine
Nothing changes form here. Note in `docs/notes/architecture.md` which files are content (sprite art, real maps, unit stats, campaigns, `REAL` values) for Phase 15 to move into JSON with schemas and registries.

## Checks
- `node build.mjs` succeeds; `node tests/run.mjs` identical to the baseline battle for battle
- `node --test tests/unit/*.test.mjs` and the browser tests pass
- A fresh session can name the next step from `CLAUDE.md`, `docs/ROADMAP.md` and `docs/HANDOFF.md` alone

## Gate
The reorganized repository builds the same game (full suite identical), and a fresh Claude Code session can say what's next by reading only `CLAUDE.md`, `docs/ROADMAP.md` and `docs/HANDOFF.md`.

## Status
Not started.

## Open items
- None yet.
