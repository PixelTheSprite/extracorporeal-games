# Handoff: after Phase 12 (Missiles and cities) and the explicit-battle refactor

Date: 2026-10-17
Next: Phase 13 (Restructure and export), first step: run the baseline (`npm test` full suite, unit, browser) and save its output before moving any file.

## What changed
- All 12 phases shipped; version 1.0.0-rc.3. Published: https://claude.ai/artifact/E3Eefgm6tCLUJdn62D1YXZ
- Game logic takes the battle as `B` (default `appState.battle`); the battle carries its own map (`B.map`). Codemod: `tools/codemod/battle-param.mjs`.
- Phase 12 added missile silos and city development (`src/core/missiles.js`, `src/ui/strategic.js`); A/B report in `tools/ab/phase12-report.md`.
- Roadmap now runs to Phase 20 (Claude Code, then web app, desktop, mobile). Full roadmap: the Claude Doc at https://claude.ai/code/artifact/5ad5c43b-2070-4892-baf2-4462ed9106c8

## Decisions made (and why)
- Export to Claude Code after Phase 13: later phases need native toolchains, git, CI and real devices.
- Target layout: `engine/`, `content/`, `ui/`, `platform/`, `apps/`, `tests/`, `tools/`, `docs/` (see the phase file).
- Phase 13 moves and splits files only; ES modules and JSON content wait for Phase 15.

## Gotchas
- The build concatenates files in `src/manifest.json` order into one HTML file; globals depend on that order. Moving files means updating paths only, keeping the order.
- `tests/core.mjs` loads core files from the manifest too; the regression suite (`node tests/run.mjs`) must stay identical battle for battle.
- `core/harness.js` swaps global state on purpose; the codemod skips it.
- Browser tests need `CHROMIUM_PATH` set to a Chromium binary in this environment.

## Verification
- Last run (rc.3): full suite 189 passed, 0 failed, identical to the pre-refactor run; 40 unit and 22 browser tests passed.
- Not verified on real devices: online match between two people, gallery share, phone performance test.

## Open items
- Choose missile values (Phase 12 A/B report); moved to Phase 14.
- AI never blows bridges; economy and all-realism battles tend to stall (Phase 14 playtesting).

## Read first next time
- `docs/phases/13-restructure.md`
- `docs/PROJECT_MAP.md` (files and functions), `src/manifest.json`, `build.mjs`
