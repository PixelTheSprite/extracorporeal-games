# Rasterizes real-world regions (longitude/latitude polygons, rivers, ranges, cities) onto Iron Hex's hex grid.
# Used by export.py; see regions.py for the geography.
import math, json, random
SQ3 = math.sqrt(3)
def world(c, r): return (SQ3 * (c + 0.5 * (r & 1)), 1.5 * r)
def nbrs(c, r, W, H):
    d = [(1,0),(1,-1),(0,-1),(-1,0),(0,1),(1,1)] if r & 1 else [(1,0),(0,-1),(-1,-1),(-1,0),(-1,1),(0,1)]
    return [(c+a, r+b) for a,b in d if 0 <= c+a < W and 0 <= r+b < H]
def pip(x, y, poly):
    ins = False; j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]; xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi: ins = not ins
        j = i
    return ins
def seg_dist(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay; L = dx*dx + dy*dy
    t = 0 if L == 0 else max(0, min(1, ((px-ax)*dx + (py-ay)*dy) / L))
    return math.hypot(px - ax - t*dx, py - ay - t*dy)

class Region:
    def __init__(s, spec):
        s.sp = spec; s.W, s.H = spec['W'], spec['H']
        s.lon0, s.lon1, s.lat0, s.lat1 = spec['bbox']
    # lon/lat <-> world (hex units); the grid spans the bbox exactly
    def to_w(s, lon, lat):
        x = (lon - s.lon0) / (s.lon1 - s.lon0) * (s.W * SQ3)
        y = (s.lat1 - lat) / (s.lat1 - s.lat0) * (s.H * 1.5) - 0.75
        return x, y
    def to_ll(s, c, r):
        x, y = world(c, r)
        return (s.lon0 + (x + SQ3/2) / (s.W * SQ3) * (s.lon1 - s.lon0), s.lat1 - (y + 0.75) / (s.H * 1.5) * (s.lat1 - s.lat0))
    def hex_at(s, lon, lat):
        x, y = s.to_w(lon, lat)
        best = None; bd = 1e9
        r0 = int(round(y / 1.5))
        for r in range(r0 - 1, r0 + 2):
            if not 0 <= r < s.H: continue
            for c in range(int(x / SQ3) - 2, int(x / SQ3) + 3):
                if not 0 <= c < s.W: continue
                wx, wy = world(c, r); d = math.hypot(wx - x, wy - y)
                if d < bd: bd, best = d, (c, r)
        return best
    def line_hexes(s, pts):  # every hex a polyline passes through (a connected chain)
        out = []
        for (a, b) in zip(pts, pts[1:]):
            n = 60
            for i in range(n + 1):
                h = s.hex_at(a[0] + (b[0]-a[0]) * i / n, a[1] + (b[1]-a[1]) * i / n)
                if h and (not out or out[-1] != h): out.append(h)
        return out
    def near_line(s, c, r, pts, width):  # distance from hex center to a polyline, in hexes
        x, y = world(c, r)
        ws = [s.to_w(*p) for p in pts]
        d = min(seg_dist(x, y, *ws[i], *ws[i+1]) for i in range(len(ws) - 1)) / SQ3
        return d <= width, d
    def build(s):
        sp, W, H = s.sp, s.W, s.H
        rnd = random.Random(sp.get('seed', 1))
        land = [[False]*W for _ in range(H)]
        for r in range(H):
            for c in range(W):
                lon, lat = s.to_ll(c, r)
                inside = any(pip(lon, lat, p) for p in sp.get('land', []))
                if inside and any(pip(lon, lat, p) for p in sp.get('water', [])): inside = False
                land[r][c] = inside
        for (lon, lat) in sp.get('islets', []):
            h = s.hex_at(lon, lat); land[h[1]][h[0]] = True
        g = [['~' if not land[r][c] else sp.get('base', 'p') for c in range(W)] for r in range(H)]
        # land terrain layers
        for r in range(H):
            for c in range(W):
                if not land[r][c]: continue
                lon, lat = s.to_ll(c, r)
                for t, polys in sp.get('areas', []):
                    if any(pip(lon, lat, p) for p in polys): g[r][c] = t
                for (pts, wm, wh) in sp.get('ranges', []):
                    ok, d = s.near_line(c, r, pts, wh)
                    if ok: g[r][c] = 'm' if d <= wm else ('h' if g[r][c] != 'm' else 'm')
                if 'noise' in sp:
                    t, p = sp['noise']
                    if g[r][c] == sp.get('base', 'p') and rnd.random() < p: g[r][c] = t
        # coast: beaches on some land hexes next to water; shallows next to land
        for r in range(H):
            for c in range(W):
                nb = nbrs(c, r, W, H)
                if land[r][c] and sp.get('beach', 0) and g[r][c] in 'pf' and any(not land[b][a] for a, b in nb) and rnd.random() < sp['beach']: g[r][c] = 's'
                if not land[r][c] and any(land[b][a] for a, b in nb): g[r][c] = 'w'
        for (lon, lat) in sp.get('shoals', []):
            h = s.hex_at(lon, lat); g[h[1]][h[0]] = 'w'
        for poly in sp.get('lakes', []):
            for r in range(H):
                for c in range(W):
                    if land[r][c] and pip(*s.to_ll(c, r), poly): g[r][c] = 'w'
        for pts in sp.get('rivers', []):
            for (c, r) in s.line_hexes(pts):
                if land[r][c]: g[r][c] = 'w'
        # cities: nearest land hex (searching outward if the point falls in water)
        cities = {}
        for name, lon, lat in sp['cities']:
            c, r = s.hex_at(lon, lat)
            if not land[r][c]:
                cand = [(abs(cc-c)+abs(rr-r), cc, rr) for rr in range(H) for cc in range(W) if land[rr][cc]]
                _, c, r = min(cand)
            g[r][c] = 'c'; cities[name] = (c, r)
        spawns = [cities[n] for n in sp['spawns']]
        # roads: shortest land routes between named cities (bridged rivers are fine to cross at a city)
        roads = set()
        for a, b in sp.get('roads', []):
            path = s.route(g, cities[a], cities[b])
            if path: roads.update(f'{c},{r}' for c, r in path if g[r][c] not in '~w')
        s.g, s.spawns, s.cities, s.roads = g, spawns, cities, roads
        return s
    def route(s, g, a, b):
        from heapq import heappush, heappop
        cost = {'s':1,'p':1,'f':2,'h':2,'m':3,'c':1}
        dist = {a:0}; prev = {}; q = [(0, a)]
        while q:
            d, cur = heappop(q)
            if cur == b: break
            if d > dist[cur]: continue
            for n in nbrs(*cur, s.W, s.H):
                t = g[n[1]][n[0]]
                if t not in cost: continue
                nd = d + cost[t]
                if nd < dist.get(n, 1e9): dist[n] = nd; prev[n] = cur; heappush(q, (nd, n))
        if b not in dist: return None
        p = [b]
        while p[-1] != a: p.append(prev[p[-1]])
        return p
    def km_per_hex(s):
        lat = (s.lat0 + s.lat1) / 2
        return round((s.lon1 - s.lon0) * 111.32 * math.cos(math.radians(lat)) / s.W)
