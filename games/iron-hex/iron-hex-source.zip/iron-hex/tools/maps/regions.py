# Geography for the real-world maps. Coordinates are (longitude, latitude), approximate at hex scale.
REGIONS = [
 dict(id='hormuz', name='Strait of Hormuz', W=33, H=30, bbox=(54.8, 58.2, 24.9, 27.4), seed=11, beach=0.35,
  land=[
   [(54.8,26.5),(55.2,26.58),(55.6,26.95),(56.1,27.12),(56.3,27.16),(56.7,27.05),(57.0,26.8),(57.2,26.3),(57.3,25.85),(57.7,25.68),(58.2,25.62),(58.2,27.6),(54.8,27.6)],   # Iran
   [(55.27,26.75),(55.7,26.97),(56.1,26.98),(56.28,26.9),(56.0,26.72),(55.6,26.66),(55.3,26.62)],                                                                         # Qeshm
   [(54.8,24.7),(54.8,24.95),(55.05,25.02),(55.27,25.26),(55.6,25.57),(55.95,25.8),(56.08,26.02),(56.2,26.2),(56.37,26.4),(56.47,26.2),(56.4,25.85),(56.28,25.62),(56.36,25.35),(56.36,25.0),(56.5,24.7)],  # UAE / Oman
  ],
  islets=[(56.46,27.06),(56.35,26.86),(55.3,26.26),(55.03,25.87),(55.15,26.28)],
  areas=[('s', [[(54.8,24.7),(55.9,24.7),(55.9,25.9),(54.8,25.9)], [(54.8,26.4),(58.2,26.4),(58.2,25.5),(56.9,25.5)]])],
  ranges=[([(55.0,27.3),(56.0,27.4),(57.0,27.35),(57.6,26.7),(58.1,26.2)], 0.9, 2.2), ([(56.3,26.3),(56.2,25.9),(56.15,25.5),(56.22,25.1),(56.25,24.9)], 0.6, 1.4)],
  cities=[('Bandar Abbas',56.27,27.18),('Qeshm',56.27,26.95),('Bandar Lengeh',54.88,26.56),('Minab',57.08,27.15),('Jask',57.77,25.64),('Dubai',55.27,25.2),('Ras al-Khaimah',55.95,25.79),('Khasab',56.25,26.18),('Fujairah',56.33,25.12)],
  spawns=['Bandar Abbas','Fujairah'],
  roads=[('Bandar Lengeh','Bandar Abbas'),('Bandar Abbas','Minab'),('Minab','Jask'),('Dubai','Ras al-Khaimah'),('Ras al-Khaimah','Fujairah')],
  sides=[('Iran','Iran'),('United States & Gulf partners','US-led')],
  blurb='The 40-kilometer-wide chokepoint between Iran and the Musandam peninsula, through which a large share of the world\'s seaborne oil passes. Qeshm and the smaller islands sit in the shipping lanes.'),

 dict(id='scs', name='South China Sea', W=25, H=30, bbox=(105.0, 121.5, 5.0, 22.0), seed=12, beach=0.3,
  land=[
   [(105.0,22.6),(113.0,22.6),(113.0,22.0),(112.0,21.7),(111.2,21.45),(110.6,21.0),(110.5,20.3),(110.2,20.3),(110.1,21.0),(109.6,21.5),(108.6,21.65),(108.0,21.55),(107.1,20.95),(106.7,20.85),(106.6,20.2),(105.9,19.7),(105.7,18.8),(106.5,17.6),(107.6,16.5),(108.2,16.05),(108.8,15.3),(109.2,13.8),(109.25,12.25),(109.2,11.9),(108.8,11.2),(108.1,10.9),(107.1,10.35),(106.7,9.9),(106.3,9.3),(105.4,8.65),(104.8,8.6)],  # Vietnam + south China
   [(108.6,19.2),(109.2,19.9),(110.0,20.1),(110.7,20.0),(111.0,19.6),(110.5,18.8),(109.6,18.2),(108.8,18.5)],   # Hainan
   [(120.6,22.2),(121.0,22.2),(120.9,21.9)],                                                                     # tip of Taiwan
   [(120.6,18.6),(120.3,17.6),(120.4,16.6),(119.8,16.3),(120.1,15.8),(119.9,15.3),(120.3,14.5),(120.6,14.4),(120.6,13.9),(121.6,13.8),(121.6,18.7)],  # Luzon
   [(120.3,13.5),(121.2,13.4),(121.5,12.6),(121.1,12.2),(120.5,12.6)],           # Mindoro
   [(117.2,8.4),(117.8,8.9),(118.7,9.8),(119.4,10.5),(119.7,11.3),(119.4,11.4),(118.9,10.6),(118.2,9.8),(117.4,8.9)],  # Palawan
   [(113.9,4.6),(115.3,5.4),(115.9,5.9),(116.4,6.5),(116.8,7.0),(117.3,6.6),(118.0,6.0),(118.7,5.6),(119.4,5.0),(119.5,4.6)],  # northern Borneo
  ],
  islets=[(114.36,10.38),(115.53,9.9),(112.9,8.65),(114.9,10.9),(111.62,16.83),(112.34,16.5),
          (117.35,8.6),(117.9,9.1),(118.4,9.6),(118.75,9.9),(119.2,10.4),(119.45,10.9),(119.6,11.3),(121.0,13.0),(120.7,12.8)],   # Palawan and Mindoro traced hex by hex (narrower than a hex)
  shoals=[(117.75,15.15)],
  areas=[('f', [[(113.9,4.6),(119.5,4.6),(119.4,5.6),(117.0,6.4),(115.5,5.6)], [(117.3,8.7),(119.6,11.2),(119.2,10.4),(118.0,9.2)], [(106.5,14.0),(108.5,14.0),(108.6,12.0),(107.0,12.0)]])],
  ranges=[([(105.4,20.3),(106.1,18.5),(107.0,16.6),(107.9,14.8),(108.3,12.6)], 0.7, 1.6), ([(120.9,18.0),(121.0,16.4)], 0.7, 1.4), ([(109.6,18.9),(109.7,18.6)], 0.5, 1.0), ([(116.4,6.2),(116.5,5.2)], 0.6, 1.2)],
  cities=[('Hanoi',105.85,21.03),('Haiphong',106.7,20.85),('Da Nang',108.2,16.05),('Cam Ranh',109.2,11.95),('Ho Chi Minh City',106.7,10.8),('Zhanjiang',110.36,21.27),('Haikou',110.33,20.03),('Sanya',109.51,18.25),('Manila',120.98,14.6),('Subic Bay',120.28,14.8),('Puerto Princesa',118.74,9.74),('Kota Kinabalu',116.07,5.98)],
  spawns=['Zhanjiang','Manila','Da Nang','Kota Kinabalu'],
  roads=[('Hanoi','Da Nang'),('Da Nang','Cam Ranh'),('Cam Ranh','Ho Chi Minh City'),('Manila','Subic Bay')],
  sides=[('China','China'),('Philippines','Philippines'),('Vietnam','Vietnam'),('Malaysia','Malaysia')],
  blurb='A huge, mostly open sea ringed by China, Vietnam, the Philippines and Malaysia, with the contested Paracel and Spratly islands and Scarborough Shoal in the middle. About 75 km per hex: a naval and air war.'),

 dict(id='donbas', name='Donbas', W=31, H=30, bbox=(35.8, 40.6, 46.9, 49.6), seed=13, noise=('f', 0.07),
  land=[[(35.0,46.0),(41.0,46.0),(41.0,50.0),(35.0,50.0)]],
  water=[[(35.0,46.0),(35.0,46.98),(36.5,46.98),(37.0,47.02),(37.55,47.07),(38.1,47.08),(38.6,47.15),(39.0,47.22),(39.3,47.2),(39.2,47.05),(38.7,46.95),(38.6,46.0)]],
  areas=[('f', [[(37.2,49.3),(38.6,49.18),(38.6,48.98),(37.3,49.08)]]), ('h', [[(37.8,48.25),(39.0,48.35),(40.3,48.2),(40.3,47.75),(39.0,47.75),(38.0,47.85)]])],
  rivers=[[(36.7,49.65),(36.85,49.45),(37.25,49.2),(37.57,49.03),(37.9,48.98),(38.45,48.92),(38.9,48.8),(39.5,48.65),(40.0,48.55),(40.65,48.4)],
          [(37.62,49.65),(37.6,49.4),(37.55,49.2),(37.45,49.12)],
          [(37.82,48.08),(37.65,47.5),(37.58,47.08)],
          [(38.9,49.65),(39.0,49.2),(39.1,48.85),(39.2,48.7)]],
  cities=[('Kramatorsk',37.56,48.72),('Sloviansk',37.62,48.85),('Izium',37.26,49.2),('Lyman',37.8,48.99),('Bakhmut',38.0,48.6),('Kostiantynivka',37.7,48.53),('Pokrovsk',37.18,48.28),('Donetsk',37.8,48.0),('Horlivka',38.05,48.3),('Debaltseve',38.4,48.34),('Alchevsk',38.8,48.47),('Sievierodonetsk',38.48,48.95),('Luhansk',39.3,48.57),('Starobilsk',38.92,49.28),('Volnovakha',37.5,47.6),('Mariupol',37.55,47.1),('Taganrog',38.9,47.22),('Rostov-on-Don',39.72,47.23)],
  spawns=['Kramatorsk','Rostov-on-Don'],
  roads=[('Izium','Sloviansk'),('Sloviansk','Kramatorsk'),('Kramatorsk','Kostiantynivka'),('Kostiantynivka','Bakhmut'),('Bakhmut','Debaltseve'),('Debaltseve','Luhansk'),('Kostiantynivka','Donetsk'),('Pokrovsk','Donetsk'),('Donetsk','Horlivka'),('Donetsk','Volnovakha'),('Volnovakha','Mariupol'),('Mariupol','Taganrog'),('Taganrog','Rostov-on-Don'),('Luhansk','Rostov-on-Don'),('Bakhmut','Sievierodonetsk')],
  sides=[('Ukraine','Ukraine'),('Russia','Russia')],
  blurb='Open steppe and industrial cities in eastern Ukraine, cut by the Siverskyi Donets river and its tributaries, with the hills of the Donets Ridge to the south and the Sea of Azov beyond. Rivers are fordable only with bridges.'),

 dict(id='taiwan', name='Taiwan Strait', W=27, H=30, bbox=(117.0, 122.3, 21.8, 26.4), seed=14, beach=0.3,
  land=[
   [(116.5,26.6),(120.2,26.6),(119.9,26.3),(119.6,25.95),(119.5,25.5),(119.0,25.2),(118.6,24.9),(118.6,24.6),(118.1,24.45),(117.5,23.7),(117.0,23.45),(116.5,23.4)],   # Fujian / Guangdong
   [(121.0,25.3),(121.55,25.3),(121.75,25.13),(121.9,24.9),(121.8,24.4),(121.6,23.9),(121.45,23.3),(121.2,22.8),(120.9,22.1),(120.85,21.9),(120.7,22.3),(120.3,22.6),(120.15,23.0),(120.15,23.5),(120.4,24.2),(120.7,24.6),(120.95,24.9)],   # Taiwan
  ],
  islets=[(119.58,23.57),(119.65,23.68),(118.35,24.45),(119.95,26.16)],
  areas=[('h', [[(116.5,26.6),(119.4,26.6),(119.2,25.6),(118.3,25.0),(117.4,24.1),(116.5,24.0)]])],
  ranges=[([(121.55,24.85),(121.25,24.0),(120.95,23.2),(120.8,22.35)], 0.7, 1.5), ([(117.2,25.6),(118.3,26.3)], 0.6, 1.2)],
  cities=[('Xiamen',118.09,24.48),('Quanzhou',118.6,24.9),('Fuzhou',119.3,26.08),('Putian',119.0,25.43),('Zhangzhou',117.65,24.51),('Taipei',121.55,25.03),('Hsinchu',120.97,24.8),('Taichung',120.68,24.15),('Tainan',120.2,23.0),('Kaohsiung',120.3,22.62),('Hualien',121.6,23.98)],
  spawns=['Xiamen','Taichung'],
  roads=[('Zhangzhou','Xiamen'),('Xiamen','Quanzhou'),('Quanzhou','Putian'),('Putian','Fuzhou'),('Taipei','Hsinchu'),('Hsinchu','Taichung'),('Taichung','Tainan'),('Tainan','Kaohsiung')],
  sides=[('China (PRC)','PRC'),('Taiwan (ROC)','ROC')],
  blurb='About 130 to 180 km of water between Fujian and Taiwan, with the Penghu islands mid-strait and Kinmen and Matsu just off the mainland coast. Taiwan\'s mountain spine leaves most of its cities on the western plain. Tanks need transports to cross.'),

 dict(id='dmz', name='Korean DMZ', W=31, H=30, bbox=(125.6, 129.2, 36.9, 39.3), seed=15, noise=('f', 0.08),
  land=[[(125.4,39.5),(127.5,39.5),(127.45,39.15),(127.6,39.05),(128.0,38.85),(128.35,38.6),(128.6,38.2),(128.9,37.75),(129.1,37.5),(129.35,36.8),(126.75,36.8),(126.6,37.2),(126.55,37.45),(126.62,37.62),(126.5,37.77),(126.1,37.78),(125.9,37.86),(125.7,37.95),(125.4,37.95)],
        [(126.38,37.6),(126.55,37.62),(126.52,37.8),(126.38,37.75)]],
  areas=[('h', [[(127.2,39.5),(127.45,39.15),(128.3,38.6),(128.8,37.7),(129.2,36.8),(127.6,36.8),(127.4,37.6),(127.0,38.6)]]),
         ('f', [[(126.6,37.83),(126.75,38.0),(127.3,38.32),(127.8,38.36),(128.1,38.4),(128.35,38.65),(128.4,38.55),(128.1,38.25),(127.8,38.22),(127.3,38.18),(126.8,37.9)]])],
  ranges=[([(127.9,39.1),(128.15,38.6),(128.45,38.1),(128.7,37.6),(128.95,37.0)], 1.1, 2.2)],
  rivers=[[(127.35,38.95),(127.2,38.7),(127.0,38.25),(126.75,37.95),(126.62,37.76)],
          [(127.7,37.55),(127.25,37.55),(127.0,37.52),(126.8,37.6),(126.62,37.74)]],
  cities=[('Seoul',126.98,37.57),('Incheon',126.7,37.46),('Uijeongbu',127.05,37.74),('Chuncheon',127.73,37.88),('Sokcho',128.59,38.2),('Gangneung',128.9,37.75),('Suwon',127.03,37.26),('Kaesong',126.55,37.97),('Pyonggang',127.3,38.42),('Wonsan',127.44,39.15),('Haeju',125.72,38.04),('Sariwon',125.76,38.51),('Pyongyang',125.75,39.03)],
  spawns=['Pyongyang','Seoul'],
  roads=[('Pyongyang','Sariwon'),('Sariwon','Kaesong'),('Kaesong','Seoul'),('Seoul','Uijeongbu'),('Seoul','Chuncheon'),('Chuncheon','Sokcho'),('Seoul','Suwon'),('Seoul','Incheon'),('Pyongyang','Wonsan'),('Gangneung','Sokcho')],
  sides=[('North Korea (DPRK)','DPRK'),('South Korea (ROK)','ROK')],
  blurb='The demilitarized zone splits the peninsula from the Han estuary to the east coast. Seoul sits barely 50 km south of it. Flat corridors in the west, the Taebaek mountains in the east, and the Imjin and Han rivers in between.'),

 dict(id='suwalki', name='Suwałki Gap', W=40, H=30, bbox=(20.0, 25.5, 53.3, 55.4), seed=16, noise=('f', 0.16),
  land=[[(19.0,53.0),(26.0,53.0),(26.0,56.0),(21.1,56.0),(20.95,55.15),(20.5,54.95),(20.0,54.95),(19.0,54.95)]],
  water=[[(19.0,54.38),(20.0,54.38),(20.55,54.66),(20.25,54.64),(20.0,54.55),(19.0,54.5)]],
  lakes=[[(20.6,54.97),(21.25,55.0),(21.3,55.3),(21.18,55.6),(21.05,55.6),(20.95,55.15)], [(21.55,53.68),(21.85,53.68),(21.82,53.82),(21.6,53.83)], [(21.7,54.0),(21.9,54.02),(21.86,54.18),(21.72,54.15)], [(22.2,53.73),(22.35,53.74),(22.3,53.85)]],
  areas=[('f', [[(22.9,53.75),(23.6,53.78),(23.55,54.0),(22.95,54.0)], [(22.2,54.25),(22.65,54.25),(22.6,54.45),(22.2,54.42)], [(24.2,53.9),(25.3,54.1),(25.2,54.45),(24.3,54.3)]]),
         ('h', [[(22.6,54.08),(23.2,54.1),(23.25,54.35),(22.7,54.4)]])],
  rivers=[[(23.75,53.55),(23.83,53.68),(23.98,54.0),(24.05,54.4),(23.95,54.75),(23.9,54.9),(23.4,54.98),(22.8,55.08),(21.88,55.08),(21.3,55.25)],
          [(25.6,54.75),(25.28,54.69),(24.6,54.85),(23.92,54.9)]],
  cities=[('Kaliningrad',20.5,54.71),('Chernyakhovsk',21.8,54.63),('Gusev',22.2,54.59),('Sovetsk',21.88,55.1),('Giżycko',21.76,54.04),('Ełk',22.36,53.83),('Suwałki',22.93,54.1),('Augustów',22.98,53.84),('Marijampolė',23.35,54.56),('Kaunas',23.9,54.9),('Alytus',24.05,54.4),('Vilnius',25.28,54.69),('Grodno',23.83,53.68),('Lida',25.3,53.89)],
  spawns=['Suwałki','Chernyakhovsk','Kaunas','Grodno'],
  roads=[('Kaliningrad','Chernyakhovsk'),('Chernyakhovsk','Gusev'),('Gusev','Marijampolė'),('Suwałki','Marijampolė'),('Marijampolė','Kaunas'),('Kaunas','Vilnius'),('Ełk','Suwałki'),('Augustów','Suwałki'),('Augustów','Grodno'),('Grodno','Lida'),('Lida','Vilnius'),('Giżycko','Ełk')],
  sides=[('Poland','Poland'),('Russia (Kaliningrad)','Russia'),('Lithuania','Lithuania'),('Belarus','Belarus')],
  teams=[0, 1, 0, 1],   # default alliances: Poland and Lithuania; Russia and Belarus
  blurb='The roughly 65-km strip of Polish-Lithuanian border between Russia\'s Kaliningrad exclave and Belarus, the only land link between the Baltic states and the rest of NATO. Lakes, forests and the Neman river channel any advance.'),

 dict(id='mandeb', name='Bab el-Mandeb', W=32, H=30, bbox=(41.0, 46.0, 11.0, 15.0), seed=17, base='s',
  land=[
   [(42.75,15.2),(46.2,15.2),(46.2,13.4),(45.5,13.0),(45.05,12.78),(44.5,12.75),(44.0,12.65),(43.6,12.65),(43.45,12.7),(43.3,13.0),(43.25,13.3),(43.25,13.75),(43.1,14.3),(42.95,14.8)],   # Yemen
   [(40.8,10.8),(40.8,14.7),(41.5,14.1),(42.0,13.6),(42.4,13.3),(42.74,13.0),(43.07,12.73),(43.25,12.5),(43.38,12.2),(43.3,11.96),(42.9,11.8),(42.55,11.65),(42.9,11.62),(43.15,11.58),(43.45,11.35),(43.6,11.2),(43.85,10.8)],   # Eritrea, Djibouti, Somaliland
  ],
  islets=[(43.42,12.66),(42.72,13.72),(42.76,14.0)],
  areas=[('h', [[(43.7,13.3),(46.2,13.6),(46.2,15.2),(43.6,15.2),(43.5,14.0)], [(41.6,11.3),(42.4,11.5),(42.4,12.3),(41.6,12.6)]])],
  ranges=[([(44.0,15.0),(44.15,14.2),(44.0,13.6),(44.6,13.9),(45.6,14.2)], 0.9, 1.8)],
  cities=[('Hodeidah',42.95,14.8),('Mocha',43.25,13.32),('Taiz',44.02,13.58),('Ibb',44.18,13.97),('Lahij',44.88,13.05),('Aden',45.03,12.8),('Assab',42.74,13.0),('Obock',43.29,11.96),('Tadjoura',42.88,11.79),('Djibouti',43.15,11.59)],
  spawns=['Hodeidah','Djibouti'],
  roads=[('Hodeidah','Mocha'),('Mocha','Taiz'),('Taiz','Ibb'),('Taiz','Lahij'),('Lahij','Aden'),('Djibouti','Tadjoura'),('Tadjoura','Obock')],
  sides=[('Houthis (Ansar Allah)','Houthis'),('US-led coalition','Coalition')],
  blurb='The 30-km "Gate of Tears" between Yemen and the Horn of Africa, joining the Red Sea to the Gulf of Aden. Perim island splits the channel; Yemen\'s highlands rise behind a narrow coastal plain.'),
]
