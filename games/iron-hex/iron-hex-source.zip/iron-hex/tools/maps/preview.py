# Renders a PNG preview of each region (needs Pillow).   Usage: python3 tools/maps/preview.py [out_dir]
import sys, math, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
OUT = sys.argv[1] if len(sys.argv) > 1 else '.'
from build import Region, world, SQ3
from regions import REGIONS
from PIL import Image, ImageDraw
COL = {'~':(43,88,160),'w':(74,142,210),'s':(226,194,122),'p':(140,176,74),'f':(74,130,54),'h':(176,154,88),'m':(138,125,112),'c':(184,170,148)}
SPC = [(63,127,214),(208,64,42),(122,154,42),(224,165,42)]
def render(R, path, sz=11):
    W, H = R.W, R.H
    im = Image.new('RGB', (int((W*SQ3+1)*sz)+20, int((H*1.5+1)*sz)+20), (16,33,61)); d = ImageDraw.Draw(im)
    pos = lambda c, r: (10 + (world(c,r)[0] + SQ3/2)*sz, 10 + (world(c,r)[1] + 1)*sz)
    for r in range(H):
        for c in range(W):
            x, y = pos(c, r)
            pts = [(x + sz*math.cos(math.radians(60*i-30)), y + sz*math.sin(math.radians(60*i-30))) for i in range(6)]
            d.polygon(pts, fill=COL[R.g[r][c]], outline=(0,0,0))
    for k in R.roads:
        c, r = map(int, k.split(',')); x, y = pos(c, r); d.ellipse([x-2,y-2,x+2,y+2], fill=(90,64,36))
    for name, (c, r) in R.cities.items():
        x, y = pos(c, r); d.text((x+4, y-6), name[:12], fill=(255,255,255))
    for i, (c, r) in enumerate(R.spawns):
        x, y = pos(c, r); d.rectangle([x-5,y-5,x+5,y+5], fill=SPC[i], outline=(0,0,0))
    im.save(path)
for spec in REGIONS:
    R = Region(spec).build()
    render(R, os.path.join(OUT, f'map_{spec["id"]}.png'))
    print(spec['id'], f'{R.W}x{R.H}', 'km/hex', R.km_per_hex(), 'roads', len(R.roads), 'spawns', R.spawns)
