"""Pixel art for the period looks, composed from shared parts.

Palette keys (the game colors them per army): k outline, t paint, d paint dark, l paint light,
g metal, w dark metal, s skin, . clear. Units face right. Sprites are at most 24 x 16.
Run:  python3 tools/art/looks.py  -> prints a JS object for core/skins.js (SKIN_ART entries).
Cultural notes: the Maori and Inca sets show warriors, tools, canoes and rafts only; no facial moko,
carvings or other sacred objects.
"""
import json, sys

class C:
    def __init__(s, w, h): s.w, s.h, s.g = w, h, [['.'] * w for _ in range(h)]
    def p(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h: s.g[y][x] = c
    def rect(s, x, y, w, h, c):
        for yy in range(y, y + h):
            for xx in range(x, x + w): s.p(xx, yy, c)
    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1): s.p(x, y, c)
    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1): s.p(x, y, c)
    def outline(s):
        # add a k outline around every painted pixel (4-neighbours), like the hand-drawn sets
        add = []
        for y in range(s.h):
            for x in range(s.w):
                if s.g[y][x] != '.': continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < s.w and 0 <= yy < s.h and s.g[yy][xx] not in '.k':
                        add.append((x, y)); break
        for x, y in add: s.g[y][x] = 'k'
        return s
    def rows(s):
        # trim fully empty rows/columns at the edges, keep at least one row
        g = s.g
        while len(g) > 1 and all(c == '.' for c in g[0]): g = g[1:]
        while len(g) > 1 and all(c == '.' for c in g[-1]): g = g[:-1]
        cols = [x for x in range(s.w) if any(r[x] != '.' for r in g)]
        x0, x1 = (cols[0], cols[-1]) if cols else (0, 0)
        return [''.join(r[x0:x1 + 1]) for r in g]

# ---- parts ----
def figure(c, x, y, head='bare', body='t', weapon=None, shield=None, legs='d'):
    """A standing soldier 6 wide x 10 tall at (x, y) top-left (inside outline)."""
    # head
    c.rect(x + 2, y + 1, 2, 2, 's')
    if head == 'helm':       c.hline(x + 1, x + 4, y, 'g'); c.p(x + 1, y + 1, 'g'); c.p(x + 4, y + 1, 'g')
    elif head == 'crest':    c.hline(x + 2, x + 3, y, 'g'); c.hline(x + 1, x + 4, y - 1, 'l'); c.p(x + 1, y + 1, 'g')
    elif head == 'cap':      c.hline(x + 1, x + 4, y, 'd'); c.p(x + 3, y - 1, 'd')
    elif head == 'topknot':  c.hline(x + 2, x + 3, y, 'w'); c.p(x + 3, y - 1, 'w')
    elif head == 'headband': c.hline(x + 2, x + 3, y, 'w'); c.hline(x + 1, x + 4, y + 1, 'l'); c.rect(x + 2, y + 2, 2, 1, 's')
    elif head == 'feather':  c.hline(x + 2, x + 3, y, 'w'); c.p(x + 1, y - 1, 'l'); c.p(x + 1, y, 'l')
    else:                    c.hline(x + 2, x + 3, y, 'w')
    # body and legs
    c.rect(x + 1, y + 3, 4, 4, body)
    c.p(x + 2, y + 4, 'l' if body == 't' else 't')
    c.rect(x + 1, y + 7, 1, 3, legs); c.rect(x + 4, y + 7, 1, 3, legs)
    c.p(x + 2, y + 7, legs); c.p(x + 3, y + 7, legs)
    # weapon (right hand) and shield (left)
    if weapon == 'spear':  c.vline(x + 5, y - 2, y + 9, 'w'); c.p(x + 5, y - 3, 'g')
    elif weapon == 'pike': c.vline(x + 5, y - 4, y + 9, 'w'); c.p(x + 5, y - 5, 'g'); c.p(x + 5, y - 4, 'g')
    elif weapon == 'club': c.vline(x + 5, y + 2, y + 6, 'w'); c.rect(x + 5, y + 1, 2, 2, 'w')
    elif weapon == 'mace': c.vline(x + 5, y + 2, y + 6, 'w'); c.rect(x + 5, y, 2, 2, 'g'); c.p(x + 7, y + 1, 'g')
    elif weapon == 'halberd': c.vline(x + 5, y - 3, y + 9, 'w'); c.rect(x + 6, y - 2, 1, 2, 'g'); c.p(x + 5, y - 4, 'g')
    elif weapon == 'staff': c.vline(x + 5, y - 1, y + 9, 'd'); c.p(x + 5, y - 2, 'l')
    elif weapon == 'sling': c.p(x + 5, y + 2, 'd'); c.p(x + 6, y + 1, 'd'); c.p(x + 7, y, 'g')
    elif weapon == 'tool': c.vline(x + 5, y + 1, y + 7, 'd'); c.hline(x + 4, x + 6, y + 1, 'g')
    elif weapon == 'xbow': c.hline(x + 4, x + 7, y + 4, 'd'); c.vline(x + 7, y + 3, y + 5, 'w')
    if shield == 'round':  c.rect(x - 1, y + 3, 2, 4, 'g'); c.p(x - 1, y + 4, 'l')
    elif shield == 'tall': c.rect(x - 1, y + 2, 2, 6, 'd'); c.vline(x - 1, y + 3, y + 6, 't')
    elif shield == 'small': c.rect(x - 1, y + 4, 2, 2, 'd')

def squad(c, n, gap, **kw):
    for i in range(n): figure(c, 1 + i * gap, 5 if i % 2 else 4, **kw)

def boat(c, length, kind, cargo=0):
    """Hull along the bottom; kind: oars | sail | junk | canoe | reed | raft | tower"""
    y = 10
    if kind == 'raft':
        c.rect(1, y, length, 2, 'd'); [c.p(1 + i, y, 'l') for i in range(0, length, 3)]
    elif kind == 'reed':
        c.rect(2, y, length - 2, 2, 'l'); c.p(1, y - 1, 'l'); c.p(length, y - 1, 'l'); c.p(0, y - 2, 'l'); c.p(length + 1, y - 2, 'l')
    elif kind == 'canoe':
        c.rect(2, y, length - 3, 2, 'd'); c.hline(1, length, y - 1, 't'); c.p(length + 1, y - 2, 'd'); c.p(length + 1, y - 3, 'd'); c.p(0, y - 2, 'd')
    else:
        c.rect(2, y, length - 2, 2, 'd'); c.hline(1, length, y - 1, 't'); c.p(length + 1, y - 1, 'g')
    if kind in ('oars', 'canoe'):
        for i in range(4, length - 2, 3): c.p(i, y + 2, 'w'); c.p(i - 1, y + 3, 'w')
    if kind == 'oars' or kind == 'sail':
        m = 2 + length // 2; c.vline(m, 1, y - 2, 'w'); c.rect(m - 3, 2, 7, 5, 'l'); c.vline(m, 2, 6, 't')
    if kind == 'junk':
        for m, h in ((4, 5), (2 + length // 2, 8)):
            c.vline(m, y - 1 - h, y - 2, 'w'); [c.hline(m - 2, m + 2, yy, 'l' if yy % 2 else 't') for yy in range(y - h, y - 1)]
    if kind == 'tower':
        c.rect(4, y - 6, length - 6, 5, 't'); c.rect(6, y - 9, length - 10, 3, 'd'); [c.p(xx, y - 4, 'w') for xx in range(5, length - 2, 2)]
    if kind == 'reed' or kind == 'raft':
        m = 2 + length // 2; c.vline(m, 2, y - 1, 'w'); c.rect(m - 2, 3, 5, 5, 'l')
    for i in range(cargo):
        figure(c, 3 + i * 5, y - 10 if kind != 'tower' else y - 13, head='bare', body='t')

def animal(c, kind):
    if kind == 'elephant':
        c.rect(3, 4, 11, 6, 'g'); c.rect(12, 3, 4, 5, 'g'); c.vline(16, 6, 10, 'g'); c.p(15, 8, 'w')
        for xx in (4, 7, 10, 13): c.rect(xx, 10, 2, 2, 'w')
        c.rect(6, 1, 5, 3, 't'); c.vline(8, -1, 0, 'w')
    elif kind == 'horse':
        c.rect(3, 6, 9, 4, 'd'); c.rect(11, 3, 3, 4, 'd'); c.p(14, 4, 'd'); c.p(2, 6, 'w')
        for xx in (3, 5, 9, 11): c.vline(xx, 10, 12, 'd')
    elif kind == 'llama':
        c.rect(3, 6, 7, 3, 'l'); c.vline(10, 1, 6, 'l'); c.rect(10, 1, 3, 2, 'l'); c.p(10, 0, 'l')
        for xx in (3, 5, 7, 9): c.vline(xx, 9, 11, 'l')
        c.rect(4, 4, 5, 2, 't')

def bird(c, big=True, kite=False):
    if kite:
        c.rect(5, 1, 6, 6, 't'); c.p(8, 0, 't'); c.vline(8, 1, 6, 'l'); c.hline(5, 10, 3, 'l'); c.p(4, 7, 'w'); c.p(3, 8, 'w'); c.p(2, 9, 'w')
        return
    # wings raised in a V, body below, head and beak to the right
    pat = (['d..........d..', 'td........dt..', 'ttd......dtt..', '.ttd....dtt...', '..ttdttdtt.ll.', '...tttttttlllg', '....ttttt.....', '.....d.d......']
           if big else ['.d......d...', '.td....dt...', '..tdttdt.lg.', '...tttttll..', '....t.t.....'])
    for y, row in enumerate(pat):
        for x, ch in enumerate(row):
            if ch != '.': c.p(x + 1, y + 1, ch)

def cart(c, cover=True, people=0):
    c.rect(2, 6, 12, 4, 'd'); c.rect(3, 10, 2, 2, 'w'); c.rect(11, 10, 2, 2, 'w')
    if cover: c.rect(2, 2, 12, 4, 'l'); [c.p(xx, 2, 't') for xx in range(3, 14, 3)]
    for i in range(people): figure(c, 4 + i * 4, -2, head='bare', body='t')

def engine(c, kind):
    if kind == 'scorpion':
        c.hline(2, 12, 4, 'd'); c.vline(5, 2, 6, 'w'); c.p(12, 3, 'g'); c.hline(4, 6, 2, 'w'); c.rect(4, 7, 3, 3, 'd'); c.vline(5, 10, 11, 'w')
        figure(c, 9, 2, head='crest', body='t')
    elif kind == 'onager':
        c.rect(2, 9, 12, 2, 'd'); c.rect(3, 11, 2, 1, 'w'); c.rect(11, 11, 2, 1, 'w'); c.vline(7, 2, 8, 'w'); c.rect(6, 1, 3, 2, 'g'); c.vline(4, 5, 8, 'd'); c.vline(10, 5, 8, 'd')
    elif kind == 'trebuchet':
        c.rect(3, 10, 10, 2, 'd'); c.vline(5, 4, 9, 'd'); c.vline(10, 4, 9, 'd'); c.hline(2, 13, 4, 'w'); c.rect(1, 5, 2, 2, 'g'); c.p(14, 3, 'w')
    elif kind == 'stones':
        for (xx, yy) in ((2, 6), (6, 3), (10, 5), (13, 2)): c.rect(xx, yy, 2, 2, 'g')
        for xx in (1, 5, 9): c.p(xx, 8, 'w')

def build(fn, w=24, h=16):
    c = C(w, h); fn(c); return c.outline().rows()

ART = {
  'ancient': {
    'tank':   lambda c: animal(c, 'elephant'),
    'aa':     lambda c: engine(c, 'scorpion'),
    'apc':    lambda c: cart(c, cover=False, people=2),
    'inf':    lambda c: squad(c, 2, 7, head='crest', weapon='spear', shield='round'),
    'at':     lambda c: squad(c, 2, 7, head='helm', weapon='pike', shield='tall'),
    'eng':    lambda c: figure(c, 2, 4, head='helm', weapon='tool', shield=None),
    'plane':  lambda c: bird(c, True),
    'bomber': lambda c: engine(c, 'onager'),
    'drone':  lambda c: bird(c, False),
    'ship':   lambda c: boat(c, 16, 'oars'),
    'battleship': lambda c: boat(c, 20, 'oars'),
    'lst':    lambda c: (boat(c, 18, 'raft'), animal_small_horse(c)),
  },
  'china': {
    'tank':   lambda c: (animal(c, 'horse'), cart_chariot(c)),
    'aa':     lambda c: squad(c, 2, 8, head='cap', weapon='xbow'),
    'apc':    lambda c: cart(c, cover=True),
    'inf':    lambda c: squad(c, 2, 7, head='cap', weapon='spear', shield='small'),
    'at':     lambda c: squad(c, 2, 7, head='helm', weapon='halberd'),
    'eng':    lambda c: figure(c, 2, 4, head='cap', weapon='tool'),
    'plane':  lambda c: bird(c, kite=True),
    'bomber': lambda c: engine(c, 'trebuchet'),
    'drone':  lambda c: bird(c, kite=True),
    'ship':   lambda c: boat(c, 16, 'junk'),
    'battleship': lambda c: boat(c, 20, 'tower'),
    'lst':    lambda c: boat(c, 18, 'raft', cargo=2),
  },
  'polynesian': {   # Maori
    'tank':   lambda c: squad(c, 3, 6, head='topknot', weapon='staff', body='d'),
    'aa':     lambda c: squad(c, 2, 8, head='topknot', weapon='spear'),
    'apc':    lambda c: squad(c, 2, 7, head='topknot', weapon='tool', body='l'),
    'inf':    lambda c: squad(c, 2, 7, head='topknot', weapon='club'),
    'at':     lambda c: squad(c, 2, 7, head='topknot', weapon='pike'),
    'eng':    lambda c: figure(c, 2, 4, head='topknot', weapon='tool', body='l'),
    'plane':  lambda c: bird(c, True),
    'bomber': lambda c: engine(c, 'stones'),
    'drone':  lambda c: bird(c, False),
    'ship':   lambda c: boat(c, 16, 'canoe'),
    'battleship': lambda c: boat(c, 21, 'canoe', cargo=3),
    'lst':    lambda c: (boat(c, 18, 'canoe', cargo=2), sail_mid(c, 18)),
  },
  'southamerica': {  # Inca
    'tank':   lambda c: squad(c, 3, 6, head='helm', weapon='mace', shield='small'),
    'aa':     lambda c: squad(c, 2, 8, head='headband', weapon='sling'),
    'apc':    lambda c: (animal(c, 'llama'), llama2(c)),
    'inf':    lambda c: squad(c, 2, 7, head='headband', weapon='mace', shield='small'),
    'at':     lambda c: squad(c, 2, 7, head='headband', weapon='spear', shield='small'),
    'eng':    lambda c: figure(c, 2, 4, head='headband', weapon='tool', body='l'),
    'plane':  lambda c: bird(c, True),
    'bomber': lambda c: engine(c, 'stones'),
    'drone':  lambda c: figure(c, 2, 4, head='feather', body='l'),
    'ship':   lambda c: boat(c, 15, 'reed'),
    'battleship': lambda c: boat(c, 20, 'raft', cargo=2),
    'lst':    lambda c: boat(c, 18, 'raft', cargo=1),
  },
}
def animal_small_horse(c):
    c.rect(6, 6, 6, 3, 'd'); c.rect(11, 4, 2, 3, 'd'); [c.vline(xx, 9, 9, 'd') for xx in (6, 8, 10)]
def cart_chariot(c):
    c.rect(0, 5, 4, 4, 't'); c.rect(1, 9, 2, 2, 'w'); c.vline(1, 1, 4, 'w'); c.p(1, 0, 'g'); c.rect(0, 2, 2, 2, 's')
def llama2(c):
    pass
def sail_mid(c, length):
    m = 2 + length // 2; c.vline(m, 1, 8, 'w'); c.rect(m - 2, 2, 5, 5, 'l')

# Medieval knight redraw: a mounted knight with lance and shield, replacing the old 'tank'.
def knight(c):
    animal(c, 'horse')
    c.rect(6, 2, 3, 4, 'g'); c.rect(6, 0, 3, 2, 'g'); c.p(8, 1, 'w')            # rider in plate, visored helm
    c.rect(4, 3, 2, 4, 't'); c.p(4, 4, 'l')                                     # shield in army colors
    c.hline(9, 18, 3, 'w'); c.p(19, 3, 'g')                                     # lance
    c.rect(4, 7, 8, 2, 't')                                                     # caparison

out = {p: {u: build(fn) for u, fn in units.items()} for p, units in ART.items()}
out['medievalKnight'] = build(knight)
json.dump(out, sys.stdout, indent=None)
