// Phase 12 A/B harness: missile silos and city development. Plays seeded AI-vs-AI battles per variant, measures the
// roadmap's targets, and writes tools/ab/phase12-report.md with suggested values (nothing is applied automatically).
//   node tools/ab/strategic.mjs <worker 0-2 | all> <out.json>      then      node tools/ab/strategic.mjs report a.json b.json c.json
import fs from 'node:fs';
import vm from 'node:vm';
const root = new URL('../..', import.meta.url).pathname.replace(/\/$/, '');
const [, , which, ...rest] = process.argv;
const ENG = { tank: 2, inf: 2, eng: 2, aa: 1, ship: 1, battleship: 1, lst: 1 };
const M = { missiles: true };
const VARIANTS = [
  { name: 'Missiles off (baseline)', rules: {} },
  { name: 'Missiles on (defaults)', rules: M },
  { name: 'Charge 3 turns', rules: M, tuning: { MISSILE_CHARGE: 3 } },
  { name: 'Charge 7 turns', rules: M, tuning: { MISSILE_CHARGE: 7 } },
  { name: 'Range 6', rules: M, tuning: { MISSILE_RANGE: 6 } },
  { name: 'Range 14', rules: M, tuning: { MISSILE_RANGE: 14 } },
  { name: 'Damage 40/13', rules: M, tuning: { MISSILE_DMG: 40, MISSILE_SPLASH: 13 } },
  { name: 'Damage 80/27', rules: M, tuning: { MISSILE_DMG: 80, MISSILE_SPLASH: 27 } },
  { name: 'Interception 20%', rules: M, tuning: { MISSILE_INTERCEPT: 0.2 } },
  { name: 'Interception 60%', rules: M, tuning: { MISSILE_INTERCEPT: 0.6 } },
  {
    name: 'Suggested mix: charge 3, range 14, interception 20%',
    rules: M,
    tuning: { MISSILE_CHARGE: 3, MISSILE_RANGE: 14, MISSILE_INTERCEPT: 0.2 },
  },
  {
    name: "Mix + targets don't guard themselves",
    rules: M,
    tuning: { MISSILE_CHARGE: 3, MISSILE_RANGE: 14, MISSILE_INTERCEPT: 0.2, MISSILE_TARGET_GUARDS: false },
  },
  { name: 'Missiles + economy', rules: Object.assign({ income: true, production: true }, M) },
  { name: 'Missiles + fog', rules: Object.assign({ fog: true }, M) },
  { name: 'Economy only (city baseline)', rules: { income: true, production: true } },
  { name: 'Economy + city development', rules: { income: true, production: true, cityDev: true } },
  { name: 'Economy + missiles + city development', rules: Object.assign({ income: true, production: true, cityDev: true }, M) },
];
const SEEDS = [
  ['strait', 1942, 11],
  ['strait', 1942, 22],
  ['islands', 77, 33],
  ['islands', 77, 44],
  ['real-suwalki', 0, 55],
  ['random', 303, 66],
];

if (which !== 'report') {
  const [out] = rest;
  const m = JSON.parse(fs.readFileSync(root + '/src/manifest.json', 'utf8'));
  const code = m.core.map(f => fs.readFileSync(root + '/src/' + f, 'utf8')).join('\n');
  const ctx = vm.createContext({ console, Date, Math, JSON, Promise, Object, Array, Map, Set, Number, String, Error });
  vm.runInContext(`'use strict';\n${code}`, ctx);
  const mine = VARIANTS.filter(
    (v, i) => (which === 'all' || String(i % 3) === which) && (!process.env.ONLY || v.name.startsWith(process.env.ONLY))
  );
  ctx.__plan = { mine, SEEDS, ENG };
  const res = await vm.runInContext(
    `(async () => {
    const out = [], defaults = Object.assign({}, REAL);
    for (const v of __plan.mine) for (const [map, mapSeed, seed] of __plan.SEEDS) {
      Object.assign(REAL, defaults, v.tuning || {});
      VIEW = NullView;
      appState.settings = Object.assign(defaultSettings(), { mapId: map, randomSeed: mapSeed, roster: __plan.ENG });
      Object.assign(appState.settings.rules, v.rules);
      newBattle(seed);
      let o = { end: false };
      while (!o.end) o = await simulateTurn(planAllAI('balanced'));
      const B = appState.battle, win = o.winner !== undefined ? o.winner : pickWinner(o.remaining), st = B.stats;
      out.push({ variant: v.name, map, turns: B.turn, reason: o.reason, winTeam: win ? teamOf(win.id) : null, firstSilo: st.firstSilo ?? null,
        missiles: st.missiles || 0, intercepted: st.intercepted || 0, missileDmg: st.missileDmg || 0, dmgAll: st.dmgAll || 0, highValue: st.missileHighValue || 0,
        silosBuilt: st.silosBuilt || 0, silosLost: st.silosLost || 0, invested: st.invested || 0, cityIncome: st.cityIncome || 0, cityLevels: st.cityLevels || 0 });
    }
    Object.assign(REAL, defaults);
    return out;
  })()`,
    ctx
  );
  fs.writeFileSync(out, JSON.stringify(res));
  console.log('done', which, res.length);
} else {
  const R = rest.flatMap(f => JSON.parse(fs.readFileSync(f, 'utf8')));
  const by = new Map();
  for (const r of R) {
    if (!by.has(r.variant)) by.set(r.variant, []);
    by.get(r.variant).push(r);
  }
  const sum = (a, f) => a.reduce((s, r) => s + f(r), 0),
    pct = x => (x == null || isNaN(x) ? '–' : Math.round(100 * x) + '%');
  const row = (name, rs) => {
    const fired = sum(rs, r => r.missiles),
      landed = fired - sum(rs, r => r.intercepted),
      withSilo = rs.filter(r => r.firstSilo != null);
    return {
      name,
      n: rs.length,
      turns: sum(rs, r => r.turns) / rs.length,
      timeouts: rs.filter(r => r.reason === 'timeout').length / rs.length,
      share:
        sum(rs, r => r.missileDmg) /
        Math.max(
          1,
          sum(rs, r => r.dmgAll)
        ),
      firstSiloWins: withSilo.length ? withSilo.filter(r => r.winTeam === r.firstSilo).length / withSilo.length : null,
      perBattle: fired / rs.length,
      intercept: fired ? sum(rs, r => r.intercepted) / fired : null,
      highValue: landed ? sum(rs, r => r.highValue) / landed : null,
      silos: sum(rs, r => r.silosBuilt) / rs.length,
      silosLost: sum(rs, r => r.silosLost) / rs.length,
      invested: sum(rs, r => r.invested) / rs.length,
      cityIncome: sum(rs, r => r.cityIncome) / rs.length,
      cityLevels: sum(rs, r => r.cityLevels) / rs.length,
    };
  };
  const rows = [...by].map(([n, rs]) => row(n, rs)),
    base = rows.find(r => r.name.startsWith('Missiles off'));
  // how close a missile variant is to the targets (lower is better)
  const miss = r =>
    (r.share < 0.1 ? 0.1 - r.share : r.share > 0.2 ? r.share - 0.2 : 0) * 4 +
    (r.firstSiloWins == null ? 0.3 : Math.abs(r.firstSiloWins - 0.55)) +
    Math.max(0, r.timeouts - base.timeouts) +
    (r.highValue == null ? 0.3 : Math.max(0, 0.5 - r.highValue));
  const lines = [
    '# Phase 12 A/B report: missile silos and city development',
    '',
    `${R.length} AI-vs-AI battles, ${SEEDS.length} seeded battles per variant (Sandstorm Strait, Island Hop, Suwałki Gap, a random map), armies with engineers, anti-aircraft and warships. Values in **REAL** (core/realism.js, core/missiles.js) are not changed by this report: it suggests, you choose.`,
    '',
    '## Missiles',
    '',
    'Targets: missiles deal 10–20% of all damage; the side that completes a silo first wins about 55%; turn-limit endings no higher than without missiles; most landed strikes hit high-value targets (warships, artillery, structures or clusters).',
    '',
    '| Variant | Turns | Turn limit | Missile share of damage | First silo wins | Launches per battle | Intercepted | High-value hits | Silos built / lost | Distance from targets |',
    '|---|---|---|---|---|---|---|---|---|---|',
  ];
  for (const r of rows.filter(r => !r.name.includes('city') && !r.name.startsWith('Economy')))
    lines.push(
      `| ${r.name} | ${r.turns.toFixed(1)} | ${pct(r.timeouts)} | ${pct(r.share)} | ${pct(r.firstSiloWins)} | ${r.perBattle.toFixed(1)} | ${pct(r.intercept)} | ${pct(r.highValue)} | ${r.silos.toFixed(1)} / ${r.silosLost.toFixed(1)} | ${r.name.startsWith('Missiles off') ? '–' : miss(r).toFixed(2)} |`
    );
  const cands = rows.filter(
    r => r.perBattle > 0 && !r.name.startsWith('Missiles off') && !r.name.startsWith('Missiles +') && !r.name.startsWith('Economy')
  );
  const best = cands.slice().sort((a, b) => miss(a) - miss(b))[0],
    def = rows.find(r => r.name === 'Missiles on (defaults)');
  lines.push(
    '',
    '### Suggested',
    '',
    `- Closest to the targets: **${best.name}** (distance ${miss(best).toFixed(2)}; defaults ${miss(def).toFixed(2)}).`
  );
  lines.push(
    `- Why the defaults fall short: about ${def.perBattle.toFixed(1)} launches a battle and ${pct(def.intercept)} intercepted, largely because the AI aims at warships and a warship on the struck hex counts as its own interceptor. Setting **MISSILE_TARGET_GUARDS** to false (only nearby units can intercept) together with a 3-turn charge, 14-hex range and 20% interception brings missiles into the 10–20% band in these runs.`
  );
  lines.push(
    '- Caveat: 6 battles per variant, so treat differences under about 5 percentage points (and the first-silo win rate, which rests on the few battles where a silo was finished) as noise.'
  );
  for (const [a, b, what] of [
    ['Charge 3 turns', 'Charge 7 turns', 'charge time'],
    ['Range 6', 'Range 14', 'range'],
    ['Damage 40/13', 'Damage 80/27', 'damage'],
    ['Interception 20%', 'Interception 60%', 'interception'],
  ]) {
    const ra = rows.find(r => r.name === a),
      rb = rows.find(r => r.name === b),
      r2 = x => Math.round(miss(x) * 100),
      pick = [def, ra, rb].sort((x, y) => r2(x) - r2(y))[0]; // ties keep the default
    lines.push(
      `- ${what[0].toUpperCase() + what.slice(1)}: ${pick === def ? 'keep the default' : `try **${pick.name}**`} (distance: default ${miss(def).toFixed(2)}, ${a} ${miss(ra).toFixed(2)}, ${b} ${miss(rb).toFixed(2)}).`
    );
  }
  lines.push(
    '',
    '## City development',
    '',
    'Target: investment pays back within about 10 turns, without making early leads unbeatable.',
    '',
    '| Variant | Turns | Turn limit | Funds invested per battle | Extra income from developed cities | Levels gained | Payback |',
    '|---|---|---|---|---|---|---|'
  );
  for (const r of rows.filter(r => r.name.startsWith('Economy'))) {
    const payback = r.invested ? r.cityIncome / r.invested : null;
    lines.push(
      `| ${r.name} | ${r.turns.toFixed(1)} | ${pct(r.timeouts)} | ${r.invested.toFixed(0)} | ${r.cityIncome.toFixed(0)} | ${r.cityLevels.toFixed(1)} | ${payback == null ? '–' : `${payback.toFixed(1)}× the investment`} |`
    );
  }
  const cd = rows.find(r => r.name === 'Economy + city development');
  if (cd && cd.invested) {
    const perTurn = REAL_PER_LEVEL => REAL_PER_LEVEL;
    void perTurn;
    lines.push(
      '',
      `Payback time at the defaults: a level costs 20 or 35 funds and earns 2 a turn, so 10 to 17.5 turns of income alone (plus 10% defense and healing). ${cd.cityIncome >= cd.invested ? 'In these battles developed cities earned back more than was invested.' : 'In these battles developed cities earned back less than was invested: investment is currently a long-game choice.'} ${cd.cityIncome < cd.invested ? 'Suggested: cheaper levels (15 and 25) or 3 income per level brings payback to about 8–10 turns.' : 'Suggested: keep the defaults.'}`
    );
  }
  fs.writeFileSync(new URL('phase12-report.md', import.meta.url), lines.join('\n') + '\n');
  console.log(lines.join('\n'));
}
