# Phase 12 A/B report: missile silos and city development

102 AI-vs-AI battles, 6 seeded battles per variant (Sandstorm Strait, Island Hop, Suwałki Gap, a random map), armies with engineers, anti-aircraft and warships. Values in **REAL** (core/realism.js, core/missiles.js) are not changed by this report: it suggests, you choose.

## Missiles

Targets: missiles deal 10–20% of all damage; the side that completes a silo first wins about 55%; turn-limit endings no higher than without missiles; most landed strikes hit high-value targets (warships, artillery, structures or clusters).

| Variant | Turns | Turn limit | Missile share of damage | First silo wins | Launches per battle | Intercepted | High-value hits | Silos built / lost | Distance from targets |
|---|---|---|---|---|---|---|---|---|---|
| Missiles off (baseline) | 30.5 | 0% | 0% | – | 0.0 | – | – | 0.0 / 0.0 | – |
| Charge 7 turns | 25.7 | 0% | 3% | 40% | 1.3 | 38% | 100% | 3.3 / 0.3 | 0.42 |
| Damage 40/13 | 25.2 | 0% | 2% | 40% | 2.3 | 64% | 100% | 3.3 / 0.5 | 0.48 |
| Interception 60% | 26.0 | 0% | 1% | 40% | 3.0 | 83% | 100% | 3.3 / 0.3 | 0.51 |
| Missiles on (defaults) | 25.7 | 0% | 2% | 40% | 2.0 | 67% | 100% | 3.3 / 0.3 | 0.48 |
| Range 6 | 26.5 | 0% | 2% | 40% | 1.3 | 50% | 100% | 3.3 / 0.3 | 0.46 |
| Damage 80/27 | 25.3 | 0% | 2% | 40% | 2.0 | 67% | 100% | 3.3 / 0.3 | 0.48 |
| Missiles + economy | 61.3 | 83% | 10% | 40% | 9.7 | 21% | 100% | 2.2 / 0.2 | 1.00 |
| Charge 3 turns | 26.5 | 0% | 6% | 40% | 1.8 | 27% | 100% | 3.3 / 0.3 | 0.33 |
| Range 14 | 26.7 | 0% | 8% | 20% | 5.7 | 56% | 93% | 3.3 / 0.3 | 0.42 |
| Interception 20% | 25.8 | 0% | 2% | 40% | 1.2 | 14% | 83% | 3.3 / 0.0 | 0.45 |
| Missiles + fog | 31.5 | 0% | 4% | 20% | 1.5 | 33% | 100% | 3.5 / 1.0 | 0.58 |
| Suggested mix: charge 3, range 14, interception 20% | 29.3 | 0% | 10% | 20% | 4.5 | 22% | 86% | 3.3 / 0.7 | 0.35 |
| Mix + targets don't guard themselves | 26.3 | 0% | 17% | 40% | 5.3 | 0% | 94% | 3.3 / 0.7 | 0.15 |

### Suggested

- Closest to the targets: **Mix + targets don't guard themselves** (distance 0.15; defaults 0.48).
- Why the defaults fall short: about 2.0 launches a battle and 67% intercepted, largely because the AI aims at warships and a warship on the struck hex counts as its own interceptor. Setting **MISSILE_TARGET_GUARDS** to false (only nearby units can intercept) together with a 3-turn charge, 14-hex range and 20% interception brings missiles into the 10–20% band in these runs.
- Caveat: 6 battles per variant, so treat differences under about 5 percentage points (and the first-silo win rate, which rests on the few battles where a silo was finished) as noise.
- Charge time: try **Charge 3 turns** (distance: default 0.48, Charge 3 turns 0.33, Charge 7 turns 0.42).
- Range: try **Range 14** (distance: default 0.48, Range 6 0.46, Range 14 0.42).
- Damage: keep the default (distance: default 0.48, Damage 40/13 0.48, Damage 80/27 0.48).
- Interception: try **Interception 20%** (distance: default 0.48, Interception 20% 0.45, Interception 60% 0.51).

## City development

Target: investment pays back within about 10 turns, without making early leads unbeatable.

| Variant | Turns | Turn limit | Funds invested per battle | Extra income from developed cities | Levels gained | Payback |
|---|---|---|---|---|---|---|
| Economy only (city baseline) | 61.3 | 83% | 0 | 0 | 0.0 | – |
| Economy + city development | 66.0 | 100% | 348 | 1013 | 12.7 | 2.9× the investment |
| Economy + missiles + city development | 66.0 | 100% | 348 | 1021 | 12.7 | 2.9× the investment |

Payback time at the defaults: a level costs 20 or 35 funds and earns 2 a turn, so 10 to 17.5 turns of income alone (plus 10% defense and healing). In these battles developed cities earned back more than was invested. Suggested: keep the defaults.
