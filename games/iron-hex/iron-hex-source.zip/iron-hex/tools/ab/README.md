# A/B testing Battle settings

Plays seeded AI-versus-AI battles under different settings and measures turns per battle, playback seconds per
turn (a timing view adds up every pause and tween the browser would play, without waiting), and your orders per
turn. Estimated turn time = playback + 4 s per unit you order + 3 s; game time = turns × turn time.

    node tools/ab/run.mjs all tools/ab/results.json     # every variant in variants.json × every seed in seeds.json
    node tools/ab/run.mjs 0 r0.json                     # or split across 3 workers: 0, 1, 2
    python3 tools/ab/agg.py tools/ab/results.json       # table vs the "Baseline" variant

Each variant is { name, settings } where settings override defaultSettings() (rules are merged onto the defaults).

## Phase 12: missiles and city development

    node tools/ab/strategic.mjs 0 a.json & node tools/ab/strategic.mjs 1 b.json & node tools/ab/strategic.mjs 2 c.json
    node tools/ab/strategic.mjs report a.json b.json c.json      # writes tools/ab/phase12-report.md

Variants can override any value in `REAL` with `tuning` (applied for the run, then restored). `ONLY=<name prefix>`
runs just the matching variants. The report suggests values; it never changes the game's defaults.
