import json, statistics as st, sys
files = sys.argv[1:] or ['res0.json','res1.json','res2.json']
R = sum((json.load(open(f)) for f in files), [])
DEC, OVER = 4.0, 3.0   # assumed seconds of player decision per unit ordered, plus per-turn overhead
by = {}
for r in R: by.setdefault(r['variant'], []).append(r)
rows = []
for v, rs in by.items():
    turns = [r['turns'] for r in rs]
    play = st.mean(r['playPerTurn'] for r in rs); orders = st.mean(r['ordersPerTurn'] for r in rs)
    turn_s = play + DEC * orders + OVER
    game_min = st.mean(r['turns'] * (r['playPerTurn'] + DEC * r['ordersPerTurn'] + OVER) for r in rs) / 60
    rows.append(dict(v=v, n=len(rs), turns=st.mean(turns), tmed=st.median(turns), play=play, orders=orders, turn_s=turn_s, game_min=game_min,
                     timeouts=sum(r['reason']=='timeout' for r in rs), win=sum(r['youWon'] for r in rs)))
base = next(r for r in rows if r['v'].startswith('Baseline'))
print(f"{'Variant':36} {'turns':>6} {'play s/turn':>11} {'orders/turn':>11} {'turn s':>7} {'game min':>8} {'Δturns':>7} {'Δturn s':>8} {'Δgame':>7} {'timeouts':>8}")
for r in sorted(rows, key=lambda r: r['game_min']):
    print(f"{r['v'][:36]:36} {r['turns']:6.1f} {r['play']:11.1f} {r['orders']:11.1f} {r['turn_s']:7.1f} {r['game_min']:8.1f} {100*(r['turns']/base['turns']-1):+6.0f}% {100*(r['turn_s']/base['turn_s']-1):+7.0f}% {100*(r['game_min']/base['game_min']-1):+6.0f}% {r['timeouts']:>4}/{r['n']}")
