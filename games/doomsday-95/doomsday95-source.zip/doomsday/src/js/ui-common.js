// Shared UI helpers: escaping, resource chips, card markup, dialogs, toast.
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const RES_COLOR = { E: "var(--res-E)", O: "var(--res-O)", M: "var(--res-M)", S: "var(--res-S)", X: "var(--res-X)" };
const TYPE_NAME = { contraption: "Contraption", distraction: "Distraction", worker: "Worker", doomsday: "Doomsday device" };
const RARITY_NAME = { common: "Common", uncommon: "Uncommon", rare: "Rare", legendary: "Legendary" };

function resIcon(k) { return Sprites.img("res_" + k, "", RES_NAME[k]); }
function resChips(r, showZero = false) {
  return RES.filter((k) => showZero || r[k]).map((k) => `<span class="rq" title="${RES_NAME[k]}">${resIcon(k)}${r[k] || 0}</span>`).join("");
}
function costPips(cost) {
  const ks = RES.filter((k) => cost[k]);
  if (!ks.length) return `<span class="pip free" title="Free">0</span>`;
  return ks.map((k) => `<span class="pip" style="--pc:${RES_COLOR[k]}" title="${cost[k]} ${RES_NAME[k]}">${cost[k]}</span>`).join("");
}
function costText(cost) {
  const ks = RES.filter((k) => cost[k]);
  return ks.length ? ks.map((k) => `${cost[k]} ${RES_NAME[k]}`).join(", ") : "free";
}

// variant: "full" (hand/inspector), "mini" (small), "plane" (board plane: frame, pips, effects only)
function cardHtml(card, variant = "full") {
  const cls = `card rar-${card.rarity} deck-${card.deck}${variant === "mini" ? " mini" : ""}${variant === "plane" ? " plane-card" : ""}`;
  const out = sumRes(card.produces) ? resChips(card.produces) : "";
  return `<div class="${cls}">
    <div class="c-top"><span class="pips">${card.type === "doomsday" ? `<span class="pip" style="--pc:#fff" title="Total cost">${sumRes(card.cost)}</span>` : costPips(card.cost)}</span></div>
    <div class="c-name">${esc(card.name)}</div>
    <div class="c-art">${Sprites.img(card.sprite, "", "")}</div>
    <div class="c-out">${out}</div>
    <div class="c-text">${esc(card.rulesText || card.flavor)}</div>
    <div class="c-type"><span>${TYPE_NAME[card.type]}</span><span>${RARITY_NAME[card.rarity]}</span></div>
  </div>`;
}

function winHtml(title, body, { icon = "icon_skull", cls = "", close = true } = {}) {
  return `<div class="win ${cls}" role="dialog" aria-label="${esc(title)}">
    <div class="titlebar">${Sprites.img(icon)}<span class="ttl">${esc(title)}</span>
      ${close ? `<button class="btn tb-btn" data-close aria-label="Close">×</button>` : ""}</div>
    <div class="win-body">${body}</div></div>`;
}

// buttons: [{ label, primary, onClick, keepOpen }]. Returns a close function.
function showDialog(title, body, buttons = [], opts = {}) {
  const layer = $("#dialogs");
  const wrap = document.createElement("div");
  wrap.className = "layer";
  wrap.innerHTML = winHtml(title, `${body}<div class="btn-row">${buttons.map((b, i) => `<button class="btn${b.primary ? " primary" : ""}" data-db="${i}">${esc(b.label)}</button>`).join("")}</div>`,
    { cls: "dialog" + (opts.wide ? " wide" : ""), close: opts.close !== false, icon: opts.icon });
  const close = () => wrap.remove();
  wrap.addEventListener("click", (e) => {
    const b = e.target.closest("[data-db]");
    if (b) { Sound.play("click"); const def = buttons[+b.dataset.db]; if (!def.keepOpen) close(); if (def.onClick) def.onClick(); return; }
    if (e.target.closest("[data-close]")) { close(); if (opts.onClose) opts.onClose(); }
    const h = e.target.closest("[data-pick]");
    if (h && opts.onPick) { opts.onPick(h.dataset.pick, close); }
  });
  layer.appendChild(wrap);
  const first = wrap.querySelector(".btn.primary") || wrap.querySelector(".btn");
  if (first) first.focus({ preventScroll: true });
  return close;
}
function closeDialogs() { $("#dialogs").innerHTML = ""; }

let toastTimer = null;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
}
function errorFeedback(msg, el) {
  Sound.play("error");
  toast(msg);
  const target = el || $(".match .win") || document.body;
  target.classList.remove("shake"); void target.offsetWidth; target.classList.add("shake");
}
const wait = (ms) => new Promise((r) => setTimeout(r, appState.settings.reducedMotion ? Math.min(ms, 120) : ms));
