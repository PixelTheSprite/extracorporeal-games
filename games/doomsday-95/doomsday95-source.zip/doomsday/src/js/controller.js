// Controller: turns taps into engine actions, runs setup dialogs and the AI's turns.
const Game = {
  async apply(action) {
    const g = appState.game;
    const r = applyAction(g, action);
    if (!r.ok) { if (action.p === 0) errorFeedback(r.error); return r; }
    Store.saveGame();
    Match.render();
    await Fx.run(r.events);
    if (g.phase === "over") this.finish();
    return r;
  },

  newMatch(deck) {
    closeDialogs();
    const seed = (Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0;
    appState.game = newGame(seed, deck);
    resetUi();
    appState.ui.busy = false;
    Store.saveGame();
    Match.render();
    this.setupFlow();
  },
  continueMatch() {
    const g = Store.loadGame();
    if (!g) return toast("No saved match found.");
    appState.game = g;
    resetUi();
    appState.ui.busy = false;
    Match.render();
    this.setupFlow();
  },

  async setupFlow() {
    const g = appState.game;
    while (g.phase === "setup" && g.players[1].setup !== "ready") await this.apply(AI.setupAction(g, 1));
    if (g.phase === "setup") {
      if (g.players[0].setup === "device") return this.deviceDialog();
      if (g.players[0].setup === "mulligan") return this.mulliganDialog();
    }
    if (g.phase === "bonus") {
      if (rival(g.first) === 1) await this.apply({ type: "bonus", p: 1, res: "E" });
      else return this.bonusDialog();
    }
    if (g.active === 1 && g.phase !== "over") this.aiLoop();
  },
  deviceDialog() {
    const g = appState.game;
    const opts = g.players[0].deviceChoices.map((inst) => {
      const c = cardOf(g, inst);
      return `<div style="display:flex;flex-direction:column;gap:6px;align-items:center;width:150px">
        <div style="--cw:130px;width:130px;height:180px;background:var(--desk2);border-radius:8px">${cardHtml(c, "full")}</div>
        <div style="font-size:11px;text-align:center">Needs ${esc(costText(c.cost))}</div>
        <button class="btn primary" data-pick="${inst}">Choose</button></div>`;
    }).join("");
    showDialog("Choose your doomsday device", `<p>This device sits beside your lab. The other two shuffle into your deck.</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">${opts}</div>`, [],
      { wide: true, close: false, onPick: async (inst, close) => { close(); await this.apply({ type: "chooseDevice", p: 0, inst }); this.setupFlow(); } });
  },
  mulliganDialog() {
    const g = appState.game, pl = g.players[0];
    const hand = pl.hand.map((i) => `<div style="--cw:84px;width:84px;height:117px;background:var(--desk2);border-radius:7px">${cardHtml(cardOf(g, i), "mini")}</div>`).join("");
    const firstMsg = g.first === 0 ? "You go first." : `${esc(g.players[1].short)} goes first; you'll get 1 bonus resource.`;
    showDialog("Your opening hand", `<p>${firstMsg} Keep this hand, or shuffle it back and draw 5 new cards (once).</p>
      <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:center">${hand}</div>`,
      [{ label: "Keep hand", primary: true, onClick: async () => { await this.apply({ type: "mulligan", p: 0, redraw: false }); this.setupFlow(); } },
        { label: "Mulligan", onClick: async () => { await this.apply({ type: "mulligan", p: 0, redraw: true }); this.setupFlow(); } }], { close: false });
  },
  bonusDialog() {
    const btns = RES.filter((k) => k !== "X").map((k) => `<button class="btn" data-pick="${k}" style="display:flex;gap:6px;align-items:center">${resIcon(k)}${RES_NAME[k]}</button>`).join("");
    showDialog("Going second", `<p>Take 1 extra resource of your choice (anything but MacGuffin).</p><div style="display:flex;gap:6px;flex-wrap:wrap">${btns}</div>`, [],
      { close: false, onPick: async (res, close) => { close(); await this.apply({ type: "bonus", p: 0, res }); this.setupFlow(); } });
  },

  // Resolves with { res: count } once the player has picked n resources, or null if they go back.
  idleDialog(n) {
    return new Promise((resolve) => {
      const pick = {};
      const kinds = RES.filter((k) => k !== "X");
      const total = () => kinds.reduce((s, k) => s + (pick[k] || 0), 0);
      const body = () => `<p>You have ${n} unused minion${n === 1 ? "" : "s"}. Each one gathers 1 resource of your choice (anything but MacGuffin).</p>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:6px">${kinds.map((k) => `<div class="field-row sunken" style="padding:2px 6px;background:var(--face)">
          ${resIcon(k)}<span style="flex:1">${RES_NAME[k]}</span>
          <button class="btn small" data-pick="-${k}" aria-label="One less ${RES_NAME[k]}" ${pick[k] ? "" : "disabled"}>−</button>
          <b style="min-width:14px;text-align:center">${pick[k] || 0}</b>
          <button class="btn small" data-pick="+${k}" aria-label="One more ${RES_NAME[k]}" ${total() < n ? "" : "disabled"}>+</button></div>`).join("")}</div>
        <div class="btn-row"><button class="btn primary" data-pick="ok" ${total() === n ? "" : "disabled"}>Collect (${total()}/${n} chosen)</button><button class="btn" data-pick="back">Back</button></div>`;
      showDialog("Idle minions", `<div id="idle-body" style="display:flex;flex-direction:column;gap:10px">${body()}</div>`, [], {
        close: false, icon: "minion",
        onPick: (v, close) => {
          if (v === "ok") { close(); return resolve(pick); }
          if (v === "back") { close(); return resolve(null); }
          const k = v.slice(1);
          pick[k] = Math.max(0, (pick[k] || 0) + (v[0] === "+" ? 1 : -1));
          Sound.play("click");
          $("#idle-body").innerHTML = body();
        },
      });
    });
  },

  async aiLoop() {
    const g = appState.game;
    if (appState.ui.busy) return;
    appState.ui.busy = true;
    resetUi();
    Match.render();
    while (g.active === 1 && g.phase !== "over" && appState.game === g) {
      await wait(cfg("aiDelayMs"));
      const a = AI.next(g, 1, appState.settings.difficulty);
      if (!a) break;
      const r = await this.apply(a);
      if (!r.ok) { console.error("AI action failed", a, r.error); break; }
    }
    appState.ui.busy = false;
    if (appState.game === g && g.phase !== "over") Match.render();
  },

  finish() {
    const g = appState.game, won = g.winner === 0, dev = deviceCard(g, g.winner);
    Store.clearGame();
    Sound.play(won ? "win" : "lose");
    setTimeout(() => showDialog(won ? "Victory" : "Defeat", `<div class="result-art">${Sprites.img(dev.sprite)}</div>
      <div class="bigwin">${won ? "The world is yours." : `${esc(g.players[g.winner].short)} ended the world.`}</div>
      <p style="text-align:center">${esc(dev.name)} fired after ${Math.ceil(g.turn / 2)} rounds.</p>`,
      [{ label: "Play again", primary: true, onClick: () => Desktop.villainSelect() }, { label: "Back to desktop", onClick: () => Desktop.show() }]), 500);
  },

  // ---- Player input ----
  tapHand(inst) {
    const g = appState.game, ui = appState.ui, c = cardOf(g, inst);
    if (!Match.myTurn() || g.phase === "charge" && ui.mode !== "discard") { ui.inspect = { kind: "card", id: c.id }; return Match.render(); }
    if (ui.mode === "burn" || ui.mode === "discard") {
      const limit = ui.mode === "burn" ? cfg("burnCards") : g.players[0].hand.length - cfg("handLimit");
      if (ui.picks.includes(inst)) ui.picks = ui.picks.filter((x) => x !== inst);
      else if (ui.picks.length < limit) ui.picks.push(inst);
      ui.inspect = { kind: "card", id: c.id };
      Sound.play("click");
      return Match.render();
    }
    if (ui.selected === inst) { resetUi(); return Match.render(); }
    resetUi();
    ui.selected = inst;
    ui.inspect = { kind: "hand", id: c.id };
    const afford = c.type === "doomsday" || canAfford(g.players[0], c.cost);
    if (afford) {
      if (c.type === "contraption") ui.mode = "build";
      else if (c.target && !c.modes) ui.mode = "target";
    }
    Sound.play("click");
    Match.render();
  },
  async tapCell(i) {
    const g = appState.game, ui = appState.ui, cell = g.board[i];
    if (cell) ui.inspect = { kind: "card", id: cardOf(g, cell.inst).id };
    if (!Match.myTurn() || g.phase !== "main") return Match.render();
    if (ui.mode === "build") {
      if (!canBuildAt(g, 0, i)) return errorFeedback("Build in a glowing slot: your lab or Public Works.");
      const r = await this.apply({ type: "play", p: 0, inst: ui.selected, cell: i });
      if (r.ok) { resetUi(); Match.render(); }
      return;
    }
    if (ui.mode === "target") {
      const c = cardOf(g, ui.selected);
      if (!cell || cell.owner !== 1) return errorFeedback("Target a rival machine.");
      ui.picks = ui.picks.includes(i) ? ui.picks.filter((x) => x !== i) : ui.picks.concat(i);
      if (ui.picks.length >= c.target.count) {
        const r = await this.apply({ type: "play", p: 0, inst: ui.selected, targets: ui.picks, mode: ui.cardMode || undefined });
        if (r.ok) { resetUi(); Match.render(); } else { ui.picks = []; Match.render(); }
      } else Match.render();
      return;
    }
    if (ui.mode === "scrap") {
      if (!cell || cell.owner !== 0) return errorFeedback("Tap one of your own machines.");
      const r = await this.apply({ type: "scrap", p: 0, cell: i });
      if (r.ok) { resetUi(); Match.render(); }
      return;
    }
    if (!ui.selected && cell) {
      if (cell.worker === 0) return this.apply({ type: "recall", p: 0, cell: i });
      if (canWork(g, 0, i)) {
        if (availableMinions(g, 0) <= 0) return errorFeedback("No free minions. Recruit, or burn 2 cards.");
        return this.apply({ type: "place", p: 0, cell: i });
      }
      if (cell.playedTurn === g.turn) toast("New machines can be worked next turn.");
      else if (cell.jamTurn >= g.turn) toast("That machine is jammed this turn.");
      else if (cell.worker === null && rowOf(i) === backRow(1)) toast("That's your rival's private lab.");
    }
    Match.render();
  },
  async act(name, el) {
    const g = appState.game, ui = appState.ui;
    switch (name) {
      case "playSelected": { const r = await this.apply({ type: "play", p: 0, inst: ui.selected, targets: ui.picks, mode: ui.cardMode || undefined }); if (r.ok) { resetUi(); Match.render(); } break; }
      case "cardMode": {
        const c = cardOf(g, ui.selected), m = el.dataset.mode;
        ui.cardMode = m;
        if (c.target && c.target.mode === m) { ui.mode = "target"; Match.render(); }
        else { const r = await this.apply({ type: "play", p: 0, inst: ui.selected, mode: m }); if (r.ok) { resetUi(); Match.render(); } }
        break;
      }
      case "cancel": resetUi(); Match.render(); break;
      case "recruit": await this.apply({ type: "recruit", p: 0 }); break;
      case "exchange": await this.apply({ type: "exchange", p: 0 }); break;
      case "burnMode": { const on = ui.mode === "burn"; resetUi(); if (!on) ui.mode = "burn"; Match.render(); break; }
      case "confirmBurn": { const r = await this.apply({ type: "burn", p: 0, insts: ui.picks }); if (r.ok) { resetUi(); Match.render(); } break; }
      case "scrapMode": { const on = ui.mode === "scrap"; resetUi(); if (!on) ui.mode = "scrap"; Match.render(); break; }
      case "collect": {
        const n = availableMinions(g, 0);
        const idle = n > 0 ? await this.idleDialog(n) : {};
        if (!idle) break;
        const r = await this.apply({ type: "collect", p: 0, idle });
        if (r.ok) { resetUi(); Match.render(); }
        break;
      }
      case "charge": await this.apply({ type: "charge", p: 0, res: el.dataset.res }); break;
      case "chargeAll": await this.apply({ type: "charge", p: 0 }); break;
      case "endTurn": {
        if (g.players[0].hand.length > cfg("handLimit")) { resetUi(); ui.mode = "discard"; Match.render(); break; }
        const r = await this.apply({ type: "endTurn", p: 0, discards: [] });
        if (r.ok) this.aiLoop();
        break;
      }
      case "confirmDiscard": { const r = await this.apply({ type: "endTurn", p: 0, discards: ui.picks }); if (r.ok) this.aiLoop(); break; }
      case "inspectDev": { ui.inspect = { kind: "card", id: deviceCard(g, +el.dataset.p).id }; Match.render(); break; }
    }
  },
};
