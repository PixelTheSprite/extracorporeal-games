// Startup and global input wiring.
function startApp() {
  if (!Registry.init()) {
    $("#screen").innerHTML = `<div class="layer">${winHtml("Card data error", `<p>The card data didn't pass validation:</p><ul>${Registry.errors.map((e) => `<li>${esc(e)}</li>`).join("")}</ul>`, { close: false })}</div>`;
    return;
  }
  Store.loadSettings();
  document.documentElement.classList.toggle("reduced", appState.settings.reducedMotion);
  Desktop.boot();
  setInterval(() => Desktop.tick(), 20000);

  document.addEventListener("click", (e) => {
    const menuBtn = e.target.closest('[data-act="menu"]');
    if (!menuBtn && !e.target.closest(".menu")) Desktop.closeMenu();
    const el = e.target.closest("[data-act], [data-hand], [data-cell]");
    if (!el || e.target.closest(".layer") && !el.dataset.act) return;
    if (el.dataset.hand) { if (!appState.ui.busy) Game.tapHand(el.dataset.hand); return; }
    if (el.dataset.cell !== undefined) { Game.tapCell(+el.dataset.cell); return; }
    const act = el.dataset.act;
    switch (act) {
      case "skipBoot": Desktop.show(); return;
      case "menu": Sound.play("click"); Desktop.menu(); return;
      case "newGame":
        Desktop.closeMenu();
        if (appState.screen === "match" && appState.game && appState.game.phase !== "over")
          showDialog("Start a new game?", "<p>Your current match is saved. Starting a new one replaces it.</p>", [{ label: "New game", primary: true, onClick: () => Desktop.villainSelect() }, { label: "Cancel" }]);
        else Desktop.villainSelect();
        return;
      case "pickDeck": Game.newMatch(el.dataset.deck); return;
      case "continue": Game.continueMatch(); return;
      case "howto": Desktop.closeMenu(); Desktop.howto(); return;
      case "settings": Desktop.closeMenu(); Desktop.settings(); return;
      case "toDesktop": Desktop.closeMenu(); appState.ui.busy = false; appState.game = null; Desktop.show(); return;
    }
    if (!appState.ui.busy && appState.screen === "match") Game.act(act, el);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { Desktop.closeMenu(); if (appState.screen === "match" && !appState.ui.busy) { resetUi(); Match.render(); } }
  });

  // Legendary holo follows the pointer on the inspector card.
  document.addEventListener("pointermove", (e) => {
    const t = e.target.closest("[data-tilt] .card.rar-legendary");
    if (!t) return;
    const r = t.getBoundingClientRect();
    t.classList.add("tilted");
    t.style.setProperty("--hx", ((e.clientX - r.left) / r.width) * 300 + "%");
    t.style.setProperty("--hy", ((e.clientY - r.top) / r.height) * 300 + "%");
  });
}
startApp();
