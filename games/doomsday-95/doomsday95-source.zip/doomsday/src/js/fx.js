// Animations driven by engine events, drawn on the #fx overlay after each render.
const Fx = {
  rect(el) { return el ? el.getBoundingClientRect() : null; },
  center(el) { const r = this.rect(el); return r ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : null; },
  cellEl(i) { return $(`[data-cell="${i}"]`); },
  boxEl(p) { return $(`[data-pbox="${p}"]`); },
  float(el, html, bad = false, dy = 0) {
    const c = this.center(el);
    if (!c) return;
    const d = document.createElement("div");
    d.className = "float-txt" + (bad ? " bad" : "");
    d.style.left = c.x + "px"; d.style.top = c.y + dy + "px";
    d.innerHTML = html;
    $("#fx").appendChild(d);
    setTimeout(() => d.remove(), 1200);
  },
  zap(a, b) {
    const A = this.center(this.cellEl(a)), B = this.center(this.cellEl(b));
    if (!A || !B) return;
    const pts = [];
    for (let s = 0; s <= 6; s++) {
      const t = s / 6, j = s === 0 || s === 6 ? 0 : (s % 2 ? 6 : -6);
      const nx = -(B.y - A.y), ny = B.x - A.x, len = Math.hypot(nx, ny) || 1;
      pts.push(`${Math.round(A.x + (B.x - A.x) * t + (nx / len) * j)},${Math.round(A.y + (B.y - A.y) * t + (ny / len) * j)}`);
    }
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.innerHTML = `<polyline points="${pts.join(" ")}" fill="none" stroke="#000" stroke-width="7" shape-rendering="crispEdges"/><polyline points="${pts.join(" ")}" fill="none" stroke="#fde047" stroke-width="3" shape-rendering="crispEdges"/>`;
    $("#fx").appendChild(svg);
    if (!appState.settings.reducedMotion) svg.animate([{ opacity: 1 }, { opacity: 0.2 }, { opacity: 1 }, { opacity: 0 }], { duration: 700, easing: "steps(4)" });
    setTimeout(() => svg.remove(), 700);
    this.lean(a, b); this.lean(b, a);
  },
  lean(a, b) {
    const pa = $(`[data-pop="${a}"]`), A = this.center(this.cellEl(a)), B = this.center(this.cellEl(b));
    if (!pa || !A || !B) return;
    const cls = Math.abs(B.x - A.x) > Math.abs(B.y - A.y) ? (B.x > A.x ? "lean-r" : "lean-l") : (B.y > A.y ? "lean-d" : "lean-u");
    pa.classList.add(cls);
    setTimeout(() => pa.classList.remove(cls), 700);
  },
  fly(sprite, fromEl, toEl) {
    const A = this.center(fromEl), B = this.center(toEl);
    if (!A || !B || appState.settings.reducedMotion) return;
    const img = document.createElement("img");
    img.className = "px flyer"; img.src = Sprites.url(sprite); img.alt = "";
    $("#fx").appendChild(img);
    const anim = img.animate([{ transform: `translate(${A.x - 28}px, ${A.y - 28}px) scale(.6)` }, { transform: `translate(${(A.x + B.x) / 2 - 28}px, ${Math.min(A.y, B.y) - 70}px) scale(1.4)` },
      { transform: `translate(${B.x - 28}px, ${B.y - 28}px) scale(1)` }], { duration: 520, easing: "steps(10)" });
    anim.onfinish = () => img.remove();
  },
  flash(el) { if (!el) return; el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash"); },

  async run(events) {
    const g = appState.game;
    const produced = events.filter((e) => e.type === "produce");
    if (produced.length) Sound.play("collect");
    for (const e of events) {
      switch (e.type) {
        case "play": {
          const c = cardOf(g, e.inst);
          if (c.type === "contraption") { const el = this.cellEl(e.cell); if (el) el.classList.add("arrive"); Sound.play("play"); }
          else if (c.type === "distraction") {
            Sound.play("hero");
            const to = e.targets && e.targets.length ? this.cellEl(e.targets[0]) : this.boxEl(c.effects.some((x) => x.action === "shield") ? e.p : 1 - e.p);
            this.fly(c.sprite, this.boxEl(e.p), to);
            await wait(380);
          } else Sound.play("play");
          break;
        }
        case "produce": this.float(this.cellEl(e.cell), resChips(e.res)); break;
        case "idle": this.float(this.boxEl(e.p), "Idle: +" + resChips(e.res), false, 20); break;
        case "tax": this.float(this.boxEl(e.p), "+" + resChips(e.res), false, 20); break;
        case "combo": this.zap(e.a, e.b); Sound.play("zap"); await wait(160); break;
        case "jam": this.flash(this.cellEl(e.cell)); break;
        case "swap": this.flash(this.cellEl(e.a)); this.flash(this.cellEl(e.b)); break;
        case "bounce": this.float(this.boxEl(1 - g.active), "Bounced!", true); break;
        case "sabotage": this.flash(this.boxEl(e.p)); this.float(this.boxEl(e.p), `-${e.amount} charge`, true); break;
        case "blocked": this.float(this.boxEl(e.p), "Shield blocked it!"); break;
        case "steal": this.float(this.boxEl(e.to), "Stole " + resChips(e.res)); break;
        case "shield": this.float(this.boxEl(e.p), "Shield up", false, -20); break;
        case "exchange": this.float(this.boxEl(e.p), "+" + resChips({ X: 1 })); Sound.play("charge"); break;
        case "recruit": this.float(this.boxEl(e.p), "+1 minion"); break;
        case "burn": this.float(this.boxEl(e.p), "+1 minion this turn"); break;
        case "deckout": this.float(this.boxEl(e.p), "Deck reshuffled, -1 minion", true); break;
        case "charge": this.flash($(`[data-meter="${e.p}${e.res}"]`)); Sound.play("charge"); break;
        case "place": Sound.play("place"); break;
      }
    }
  },
};
