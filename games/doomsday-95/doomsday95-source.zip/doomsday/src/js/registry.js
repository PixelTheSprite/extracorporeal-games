// Registry: the only way logic reaches card data. Validates DATA at startup.
const Registry = {
  cards: {},
  errors: [],
  init() {
    this.cards = {};
    this.errors = [];
    const need = ["id", "name", "deck", "type", "rarity", "copies", "cost", "produces", "effects", "sprite"];
    for (const c of DATA.cards) {
      for (const k of need) if (!(k in c)) this.errors.push(`Card ${c.id || "?"} is missing "${k}"`);
      if (c.copies > DATA.config.maxCopies) this.errors.push(`${c.id}: ${c.copies} copies is over the limit of ${DATA.config.maxCopies}`);
      if (!DATA.sprites.sprites[c.sprite]) this.errors.push(`${c.id}: sprite "${c.sprite}" not found`);
      this.cards[c.id] = c;
    }
    for (const deck of Object.keys(DATA.decks)) {
      const n = this.deckList(deck).length;
      if (n !== DATA.config.deckSize) this.errors.push(`Deck ${deck} has ${n} cards, expected ${DATA.config.deckSize}`);
    }
    return this.errors.length === 0;
  },
  card(id) {
    const c = this.cards[id];
    if (!c) throw new Error(`Unknown card ${id}`);
    return c;
  },
  deckCards(deck) { return DATA.cards.filter((c) => c.deck === deck); },
  deckList(deck) {
    const out = [];
    for (const c of this.deckCards(deck)) for (let i = 0; i < c.copies; i++) out.push(c.id);
    return out;
  },
};
