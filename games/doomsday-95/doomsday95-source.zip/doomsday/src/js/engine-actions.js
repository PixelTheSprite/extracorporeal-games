// Engine actions: newGame and applyAction(game, action) -> { ok, error?, events }.
// Every handler validates first and mutates only once the action is legal.

function newGame(seed, humanDeck) {
  const decks = [humanDeck, humanDeck === "tesla" ? "edison" : "tesla"];
  const game = { v: 1, seed, rng: seed >>> 0, turn: 0, active: 0, phase: "setup", first: 0,
    players: [], board: Array(COLS * ROWS).fill(null), insts: {}, nextInst: 1, log: [], winner: null, actions: [] };
  decks.forEach((deck, p) => {
    const lib = [];
    for (const id of Registry.deckList(deck)) {
      const inst = "c" + game.nextInst++;
      game.insts[inst] = { cardId: id, owner: p };
      lib.push(inst);
    }
    const isDev = (i) => cardOf(game, i).type === "doomsday";
    game.players.push({ deck, short: DATA.decks[deck].short, villain: DATA.decks[deck].villain, ai: p === 1,
      deviceChoices: lib.filter(isDev), library: rngShuffle(game, lib.filter((i) => !isDev(i))), hand: [], discard: [],
      res: Object.assign(emptyRes(), cfg("startRes")), minions: cfg("minionStart"), tempMinions: 0,
      device: null, shield: false, setup: "device" });
  });
  game.first = rngInt(game, 2);
  gameLog(game, `${pname(game, game.first)} will go first.`);
  return game;
}

function startTurn(game, p, events) {
  game.turn++;
  game.active = p;
  game.phase = "main";
  game.players[p].tempMinions = 0;
  events.push({ type: "turn", p });
  if (deviceFull(game, p)) return endGame(game, p, events, "fires the doomsday device");
  if (game.turn > cfg("maxTurns")) {
    const w = chargePct(game, 0) >= chargePct(game, 1) ? 0 : 1;
    return endGame(game, w, events, "wins on time with the most charge");
  }
  gameLog(game, `Turn ${Math.ceil(game.turn / 2)}: ${pname(game, p)}.`);
  drawCards(game, p, 1, events);
}

function endGame(game, p, events, how) {
  game.winner = p;
  game.phase = "over";
  gameLog(game, `${pname(game, p)} ${how}. The world ends.`);
  events.push({ type: "win", p });
}

const Actions = {
  chooseDevice(game, a, ev) {
    const pl = game.players[a.p];
    if (game.phase !== "setup" || pl.setup !== "device") return "Not choosing a device now.";
    if (!pl.deviceChoices.includes(a.inst)) return "That device isn't an option.";
    pl.device = { inst: a.inst, charge: emptyRes() };
    pl.library.push(...pl.deviceChoices.filter((i) => i !== a.inst));
    rngShuffle(game, pl.library);
    pl.deviceChoices = [];
    drawCards(game, a.p, cfg("startHand"), ev);
    pl.setup = "mulligan";
  },
  mulligan(game, a, ev) {
    const pl = game.players[a.p];
    if (game.phase !== "setup" || pl.setup !== "mulligan") return "Not deciding a mulligan now.";
    if (a.redraw) {
      pl.library.push(...pl.hand);
      pl.hand = [];
      rngShuffle(game, pl.library);
      drawCards(game, a.p, cfg("startHand"), ev);
    }
    pl.setup = "ready";
    if (game.players.every((x) => x.setup === "ready")) game.phase = "bonus";
  },
  bonus(game, a, ev) {
    const second = rival(game.first);
    if (game.phase !== "bonus" || a.p !== second) return "No bonus to take.";
    if (!RES.includes(a.res)) return "Unknown resource.";
    if (a.res === "X") return "The going-second bonus can't be MacGuffin.";
    game.players[second].res[a.res] += 1;
    gameLog(game, `${pname(game, second)} takes 1 ${RES_NAME[a.res]} for going second.`);
    startTurn(game, game.first, ev);
  },
  play(game, a, ev) {
    if (game.phase !== "main" || game.active !== a.p) return "You can only play cards during your build step.";
    const pl = game.players[a.p];
    if (!pl.hand.includes(a.inst)) return "That card isn't in your hand.";
    const card = cardOf(game, a.inst);
    const targets = a.targets || [];
    if (card.type !== "doomsday" && !canAfford(pl, card.cost)) return "Not enough resources.";
    if (card.type === "contraption" && (a.cell === undefined || !canBuildAt(game, a.p, a.cell))) return "Build in your lab or in Public Works.";
    if (card.type === "worker" && pl.minions >= minionCap(game, a.p)) return "You're at your minion cap.";
    if (card.modes && !card.modes.includes(a.mode)) return "Choose a mode first.";
    if (card.target && (!card.target.mode || card.target.mode === a.mode)) {
      const legal = rivalCells(game, a.p);
      const need = Math.min(card.target.count, card.target.optional ? legal.length : card.target.count);
      if (targets.length < need) return legal.length < card.target.count && !card.target.optional ? "Not enough rival contraptions to target." : "Choose a target.";
      if (new Set(targets).size !== targets.length || !targets.every((t) => legal.includes(t))) return "Target a rival contraption.";
    }
    pl.hand.splice(pl.hand.indexOf(a.inst), 1);
    if (card.type !== "doomsday") payCost(pl, card.cost);
    ev.push({ type: "play", p: a.p, inst: a.inst, cell: a.cell, targets });
    if (card.type === "contraption") {
      game.board[a.cell] = { inst: a.inst, owner: a.p, playedTurn: game.turn, jamTurn: -1, worker: null };
      gameLog(game, `${pname(game, a.p)} builds ${card.name}.`);
      resolveOnPlay(game, a.p, card, [], null, ev);
    } else if (card.type === "doomsday") {
      const old = pl.device, nc = emptyRes();
      RES.forEach((k) => { nc[k] = Math.min(Math.floor((old.charge[k] || 0) / 2), card.cost[k] || 0); });
      pl.discard.push(old.inst);
      pl.device = { inst: a.inst, charge: nc };
      gameLog(game, `${pname(game, a.p)} swaps in the ${card.name}.`);
    } else {
      gameLog(game, `${pname(game, a.p)} plays ${card.name}.`);
      resolveOnPlay(game, a.p, card, targets, a.mode, ev);
      pl.discard.push(a.inst);
    }
  },
  place(game, a, ev) {
    if (game.phase !== "main" || game.active !== a.p) return "Place minions during your turn.";
    if (availableMinions(game, a.p) <= 0) return "No minions left this turn.";
    if (!canWork(game, a.p, a.cell)) return "That contraption can't be worked right now.";
    game.board[a.cell].worker = a.p;
    ev.push({ type: "place", cell: a.cell, p: a.p });
  },
  recall(game, a, ev) {
    const cell = game.board[a.cell];
    if (game.phase !== "main" || game.active !== a.p || !cell || cell.worker !== a.p) return "No minion of yours there.";
    cell.worker = null;
    ev.push({ type: "recall", cell: a.cell });
  },
  recruit(game, a, ev) {
    const pl = game.players[a.p];
    if (game.phase !== "main" || game.active !== a.p) return "Recruit during your turn.";
    if (pl.minions >= minionCap(game, a.p)) return "You're at your minion cap.";
    if (sumRes(pl.res) < cfg("recruitCost")) return `Recruiting costs ${cfg("recruitCost")} resources.`;
    for (let n = cfg("recruitCost"); n > 0; n--) {
      const k = ["E", "O", "M", "S"].sort((x, y) => pl.res[y] - pl.res[x])[0];
      pl.res[pl.res[k] > 0 ? k : "X"]--;
    }
    pl.minions++;
    gameLog(game, `${pname(game, a.p)} recruits a minion.`);
    ev.push({ type: "recruit", p: a.p });
  },
  // MacGuffin Exchange: trade resources (never MacGuffin) for 1 MacGuffin, once per turn.
  exchange(game, a, ev) {
    const pl = game.players[a.p], cost = cfg("exchangeCost"), kinds = ["E", "O", "M", "S"];
    if (game.phase !== "main" || game.active !== a.p) return "Exchange during your build step.";
    if (pl.exchangedTurn === game.turn) return "You can exchange once per turn.";
    if (kinds.reduce((s, k) => s + pl.res[k], 0) < cost) return `The exchange costs ${cost} resources (not MacGuffin).`;
    for (let n = cost; n > 0; n--) pl.res[kinds.slice().sort((x, y) => pl.res[y] - pl.res[x])[0]]--;
    pl.res.X++;
    pl.exchangedTurn = game.turn;
    gameLog(game, `${pname(game, a.p)} trades ${cost} resources for 1 MacGuffin.`);
    ev.push({ type: "exchange", p: a.p });
  },
  burn(game, a, ev) {
    const pl = game.players[a.p], ids = a.insts || [];
    if (game.phase !== "main" || game.active !== a.p) return "Burn cards during your turn.";
    if (ids.length !== cfg("burnCards") || new Set(ids).size !== ids.length || !ids.every((i) => pl.hand.includes(i))) return `Choose ${cfg("burnCards")} cards from your hand.`;
    for (const i of ids) { pl.hand.splice(pl.hand.indexOf(i), 1); pl.discard.push(i); }
    pl.tempMinions++;
    gameLog(game, `${pname(game, a.p)} burns ${ids.length} cards for a temporary minion.`);
    ev.push({ type: "burn", p: a.p });
  },
  scrap(game, a, ev) {
    const cell = game.board[a.cell];
    if (game.phase !== "main" || game.active !== a.p) return "Scrap during your build step.";
    if (!cell || cell.owner !== a.p) return "You can only scrap your own contraptions.";
    game.players[a.p].discard.push(cell.inst);
    game.board[a.cell] = null;
    gameLog(game, `${pname(game, a.p)} scraps ${cardOf(game, cell.inst).name}.`);
    ev.push({ type: "scrap", cell: a.cell });
  },
  collect(game, a, ev) {
    if (game.phase !== "main" || game.active !== a.p) return "Nothing to collect right now.";
    // Each unused minion earns 1 resource of the player's choice.
    const idle = Math.max(0, availableMinions(game, a.p)), pick = a.idle || {};
    if (Object.keys(pick).some((k) => !RES.includes(k) || !(pick[k] >= 0))) return "Unknown resource choice.";
    if (pick.X) return "Idle minions can't gather MacGuffin.";
    const n = RES.reduce((s, k) => s + (pick[k] || 0), 0);
    if (n !== idle) return `Choose ${idle} resource${idle === 1 ? "" : "s"} for your unused minions.`;
    resolveCollect(game, a.p, ev);
    if (n) {
      addRes(game.players[a.p], pick);
      ev.push({ type: "idle", p: a.p, res: pick });
      gameLog(game, `${pname(game, a.p)}'s ${n} idle minion${n === 1 ? "" : "s"} gather ${RES.filter((k) => pick[k]).map((k) => `${pick[k]} ${RES_NAME[k]}`).join(", ")}.`);
    }
    game.phase = "charge";
  },
  charge(game, a, ev) {
    if (game.phase !== "charge" || game.active !== a.p) return "Charge after collecting.";
    const pl = game.players[a.p], need = deviceNeed(game, a.p);
    const keys = a.res ? [a.res] : RES;
    let moved = 0;
    for (const k of keys) {
      const amt = Math.min(pl.res[k], need[k], a.amount === undefined ? Infinity : a.amount);
      if (amt > 0) { pl.res[k] -= amt; pl.device.charge[k] += amt; moved += amt; ev.push({ type: "charge", p: a.p, res: k, amount: amt }); }
    }
    if (!moved) return "Nothing you hold can charge the device.";
  },
  endTurn(game, a, ev) {
    if (game.phase !== "charge" || game.active !== a.p) return "Collect before ending your turn.";
    const pl = game.players[a.p], dis = a.discards || [];
    if (!dis.every((i) => pl.hand.includes(i)) || new Set(dis).size !== dis.length) return "Discard cards from your hand.";
    if (pl.hand.length - dis.length > cfg("handLimit")) return `Discard down to ${cfg("handLimit")} cards.`;
    for (const i of dis) { pl.hand.splice(pl.hand.indexOf(i), 1); pl.discard.push(i); }
    RES.forEach((k) => { pl.res[k] = Math.min(pl.res[k], cfg("carryCap")); });
    game.board.forEach((c) => { if (c) c.worker = null; });
    pl.tempMinions = 0;
    ev.push({ type: "endTurn", p: a.p });
    startTurn(game, rival(a.p), ev);
  },
};

function applyAction(game, action) {
  const h = Actions[action.type];
  if (!h) return { ok: false, error: `Unknown action ${action.type}`, events: [] };
  if (game.phase === "over") return { ok: false, error: "The game is over.", events: [] };
  const events = [];
  const err = h(game, action, events);
  if (err) return { ok: false, error: err, events: [] };
  game.actions.push(action);
  return { ok: true, events };
}
