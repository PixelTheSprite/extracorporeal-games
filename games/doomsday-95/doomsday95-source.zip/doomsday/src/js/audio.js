// Tiny square-wave sound effects via Web Audio. Silent if unsupported or muted.
const Sound = {
  ctx: null,
  play(kind) {
    if (!appState.settings.sound) return;
    try {
      this.ctx = this.ctx || new (window.AudioContext || window.webkitAudioContext)();
      const seq = { click: [[660, 0.04]], play: [[440, 0.05], [660, 0.06]], place: [[330, 0.05]], zap: [[880, 0.03], [1320, 0.05]],
        error: [[220, 0.08], [160, 0.12]], collect: [[523, 0.05], [659, 0.05], [784, 0.07]], hero: [[392, 0.05], [523, 0.05], [392, 0.08]],
        win: [[523, 0.1], [659, 0.1], [784, 0.1], [1046, 0.3]], lose: [[392, 0.15], [330, 0.15], [262, 0.4]], charge: [[294, 0.04], [392, 0.06]] }[kind] || [[440, 0.05]];
      let t = this.ctx.currentTime;
      for (const [f, d] of seq) {
        const o = this.ctx.createOscillator(), g = this.ctx.createGain();
        o.type = "square"; o.frequency.value = f;
        g.gain.setValueAtTime(0.05, t); g.gain.exponentialRampToValueAtTime(0.001, t + d);
        o.connect(g).connect(this.ctx.destination); o.start(t); o.stop(t + d + 0.01);
        t += d;
      }
    } catch (e) { /* audio is optional */ }
  },
};
