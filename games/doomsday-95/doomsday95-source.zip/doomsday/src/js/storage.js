// Persistence: the match autosaves to localStorage after every action; settings save separately.
const Store = {
  KEY: "doomsday95.match", SKEY: "doomsday95.settings",
  saveGame() { try { if (appState.game) localStorage.setItem(this.KEY, JSON.stringify(appState.game)); } catch (e) { /* storage full or blocked */ } },
  loadGame() { try { const s = localStorage.getItem(this.KEY); return s ? JSON.parse(s) : null; } catch (e) { return null; } },
  clearGame() { try { localStorage.removeItem(this.KEY); } catch (e) { /* ignore */ } },
  hasGame() { const g = this.loadGame(); return !!(g && g.phase !== "over" && g.v === 1); },
  saveSettings() { try { localStorage.setItem(this.SKEY, JSON.stringify(appState.settings)); } catch (e) { /* ignore */ } },
  loadSettings() { try { const s = localStorage.getItem(this.SKEY); if (s) Object.assign(appState.settings, JSON.parse(s)); } catch (e) { /* ignore */ } },
};
