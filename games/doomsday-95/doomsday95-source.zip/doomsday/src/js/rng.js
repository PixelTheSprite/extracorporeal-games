// Seeded RNG (mulberry32). State lives in game.rng so matches replay exactly.
function rngNext(game) {
  let t = (game.rng = (game.rng + 0x6d2b79f5) >>> 0);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
function rngInt(game, n) { return Math.floor(rngNext(game) * n); }
function rngShuffle(game, arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = rngInt(game, i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
