// Single app state object for the UI layer. The game itself lives in appState.game.
const appState = {
  screen: "boot",
  game: null,
  settings: { sound: true, reducedMotion: false, difficulty: "normal" },
  ui: { selected: null, mode: null, picks: [], inspect: null, busy: false, cardMode: null, message: "" },
};
function resetUi() {
  Object.assign(appState.ui, { selected: null, mode: null, picks: [], inspect: null, cardMode: null, message: "" });
}
