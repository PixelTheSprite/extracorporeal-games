// AI: a greedy scorer that plays through the same actions as the player. No bluffing in v1.
const AI = {
  weights(game, p) {
    const need = deviceNeed(game, p), w = {};
    RES.forEach((k) => { w[k] = 1 + (need[k] > 0 ? 0.7 : 0) + (k === "X" ? 1.5 : 0); });
    return w;
  },
  val(r, w) { return RES.reduce((a, k) => a + (r[k] || 0) * w[k], 0); },

  setupAction(game, p) {
    const pl = game.players[p];
    if (pl.setup === "device") return { type: "chooseDevice", p, inst: pl.deviceChoices[rngInt(game, pl.deviceChoices.length)] };
    if (pl.setup === "mulligan") {
      const cheap = pl.hand.some((i) => { const c = cardOf(game, i); return c.type === "contraption" && sumRes(c.cost) <= 2; });
      return { type: "mulligan", p, redraw: !cheap };
    }
    return null;
  },

  slotScore(game, p, card, i) {
    let s = rowOf(i) === backRow(p) ? 1 : 0;
    for (const n of neighborsOf(i)) {
      const nc = cellCard(game, n);
      if (!nc) continue;
      if (RES.some((k) => card.produces[k] && nc.produces[k])) s += 0.8;
      const tagCombo = card.effects.some((e) => e.condition && (nc.tags || []).includes(e.condition.adjacentTag))
        || nc.effects.some((e) => e.trigger === "aura" && ((e.params.tag && (card.tags || []).includes(e.params.tag)) || (e.params.owned && game.board[n].owner === p)));
      if (tagCombo) s += 1.2;
      if (card.effects.some((e) => e.action === "gainPerAdjacentOwned") && game.board[n].owner === p) s += 0.8;
    }
    return s;
  },

  // Score every non-placement option; return the best { score, action }.
  bestMain(game, p) {
    const pl = game.players[p], foe = rival(p), w = this.weights(game, p);
    const opts = [];
    const late = Math.max(0.25, 1 - game.turn / 44);
    const foeCells = rivalCells(game, p);
    const cellVal = (i) => sumRes(cellCard(game, i).produces) + (cellCard(game, i).produces.X ? 2 : 0);
    const bestFoe = foeCells.slice().sort((a, b) => cellVal(b) - cellVal(a));
    const myPct = chargePct(game, p), foePct = chargePct(game, foe);
    for (const inst of pl.hand) {
      const c = cardOf(game, inst);
      if (c.type === "doomsday" || !canAfford(pl, c.cost)) continue;
      const costPenalty = sumRes(c.cost) * 0.25;
      if (c.type === "worker" && pl.minions < minionCap(game, p)) {
        const machines = game.board.filter((cell, i) => cell && (cell.owner === p || isPublicRow(rowOf(i)))).length;
        opts.push({ score: machines >= pl.minions ? 5 * late + 1 : 0.8, action: { type: "play", p, inst } });
      }
      if (c.type === "contraption") {
        const slots = game.board.map((_, i) => i).filter((i) => canBuildAt(game, p, i));
        if (!slots.length) {
          // Board full: scrap our weakest machine if this card is clearly better.
          const mine = game.board.map((cell, i) => (cell && cell.owner === p ? i : -1)).filter((i) => i >= 0);
          mine.sort((a, b) => this.val(cellCard(game, a).produces, w) - this.val(cellCard(game, b).produces, w));
          if (mine.length && this.val(c.produces, w) - this.val(cellCard(game, mine[0]).produces, w) >= 1.5)
            opts.push({ score: 2 + this.val(c.produces, w) * 0.5, action: { type: "scrap", p, cell: mine[0] } });
          continue;
        }
        slots.sort((a, b) => this.slotScore(game, p, c, b) - this.slotScore(game, p, c, a));
        const score = this.val(c.produces, w) * 2.4 * late + this.slotScore(game, p, c, slots[0]) - costPenalty;
        opts.push({ score, action: { type: "play", p, inst, cell: slots[0] } });
      }
      if (c.type === "distraction") {
        const acts = c.effects.map((e) => e.action);
        let score = 0, targets = [], mode;
        if (c.modes) {
          if (game.players[foe].res.X >= 1) { mode = "steal"; score = 4 + game.players[foe].res.X; }
          else if (bestFoe.length) { mode = "bounce"; targets = [bestFoe[0]]; score = 3.5; }
        } else if (acts.includes("sabotage")) {
          score = game.players[foe].shield ? 2 : foePct >= 0.3 ? 6 + foePct * 6 : 0;
          targets = bestFoe.slice(0, 1);
        } else if (acts.includes("shield")) {
          score = !pl.shield && myPct > 0.3 ? 5 : pl.hand.length < 3 ? 2 : 0;
        } else if (acts.includes("jam")) {
          if (bestFoe.length) { score = 2.5 + cellVal(bestFoe[0]) * 0.4; targets = [bestFoe[0]]; }
        } else if (acts.includes("steal")) {
          const most = Math.max(...RES.map((k) => game.players[foe].res[k]));
          if (most >= 2) score = 2.5 + most * 0.5;
        } else if (acts.includes("swap")) {
          if (bestFoe.length >= 2) { score = 3; targets = [bestFoe[0], bestFoe[bestFoe.length - 1]]; }
        }
        if (score > 0) opts.push({ score: score - costPenalty, action: { type: "play", p, inst, targets, mode } });
      }
    }
    const work = workableCells(game, p).length, avail = availableMinions(game, p);
    if (pl.minions < minionCap(game, p) && sumRes(pl.res) >= cfg("recruitCost") + 2 && work > avail && game.turn < 30)
      opts.push({ score: 3.5, action: { type: "recruit", p } });
    if (pl.hand.length >= 5 && work > avail && game.turn < 50) {
      const cheap = pl.hand.slice().sort((a, b) => this.keepValue(game, p, a) - this.keepValue(game, p, b)).slice(0, cfg("burnCards"));
      opts.push({ score: 2.2, action: { type: "burn", p, insts: cheap } });
    }
    const nonX = pl.res.E + pl.res.O + pl.res.M + pl.res.S;
    if (deviceNeed(game, p).X > 0 && pl.exchangedTurn !== game.turn && nonX >= cfg("exchangeCost"))
      opts.push({ score: 2 + game.turn / 10, action: { type: "exchange", p } });
    opts.sort((a, b) => b.score - a.score);
    return opts.find((o) => o.score > 1.2) || null;
  },

  bestPlacement(game, p) {
    if (availableMinions(game, p) <= 0) return null;
    const w = this.weights(game, p);
    const worked = new Set(game.board.map((c, i) => (c && c.worker === p ? i : -1)).filter((i) => i >= 0));
    let best = null;
    for (const i of workableCells(game, p)) {
      worked.add(i);
      let v = this.val(cellOutput(game, i, worked).out, w);
      worked.delete(i);
      if (game.board[i].owner !== p) v -= 0.6;
      if (!best || v > best.v) best = { v, i };
    }
    const need = deviceNeed(game, p);
    const idleVal = Math.max(...RES.filter((x) => x !== "X").map((k) => (need[k] > 0 ? w[k] : 1)));
    return best && best.v >= idleVal ? { type: "place", p, cell: best.i } : null;
  },

  // One resource per unused minion: favor what the device still needs most.
  idlePicks(game, p) {
    const need = deviceNeed(game, p), w = this.weights(game, p), pick = {};
    for (let n = availableMinions(game, p); n > 0; n--) {
      const k = RES.filter((x) => x !== "X").sort((a, b) => (need[b] > 0) * w[b] - (need[a] > 0) * w[a] || need[b] - need[a])[0];
      pick[k] = (pick[k] || 0) + 1;
      need[k] = Math.max(0, need[k] - 1);
    }
    return pick;
  },

  keepValue(game, p, inst) {
    const c = cardOf(game, inst);
    if (c.type === "doomsday") return 0;
    if (c.type === "worker") return game.players[p].minions < minionCap(game, p) ? 4 : 0.5;
    if (c.type === "distraction") return 2.5;
    return sumRes(c.produces) + (c.produces.X ? 2 : 0);
  },

  // The next action for p this turn, or null when the turn is over.
  next(game, p, difficulty) {
    if (game.phase === "main") {
      let m = this.bestMain(game, p);
      if (m && difficulty === "easy" && Math.random() < 0.3) m = null;
      if (m) return m.action;
      return this.bestPlacement(game, p) || { type: "collect", p, idle: this.idlePicks(game, p) };
    }
    if (game.phase === "charge") {
      const need = deviceNeed(game, p), pl = game.players[p];
      const reserve = game.turn < 14 ? 3 : 0;
      for (const k of RES) {
        const amt = Math.min(need[k], pl.res[k] - (k === "X" ? 0 : reserve));
        if (amt > 0) return { type: "charge", p, res: k, amount: amt };
      }
      const over = pl.hand.length - cfg("handLimit");
      const discards = over > 0 ? pl.hand.slice().sort((a, b) => this.keepValue(game, p, a) - this.keepValue(game, p, b)).slice(0, over) : [];
      return { type: "endTurn", p, discards };
    }
    return null;
  },
};
