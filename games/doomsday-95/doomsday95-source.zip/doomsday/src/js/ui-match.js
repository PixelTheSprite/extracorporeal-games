// Match screen rendering. Reads appState.game + appState.ui; input lives in controller.js.
const Match = {
  YOU: 0, FOE: 1,
  myTurn() { const g = appState.game; return g && g.active === 0 && !appState.ui.busy && (g.phase === "main" || g.phase === "charge"); },

  render() {
    const g = appState.game;
    if (!g) return;
    appState.screen = "match";
    const title = `Doomsday.exe: ${g.players[0].short} vs. ${g.players[1].short}`;
    const round = Math.max(1, Math.ceil(g.turn / 2));
    $("#screen").innerHTML = `<div class="match"><div class="win">
      <div class="titlebar">${Sprites.img("icon_skull")}<span class="ttl">${esc(title)}</span><span style="font-weight:normal;font-size:11px;padding-right:4px">Round ${round}</span></div>
      <div class="match-body">
        <div class="side">${this.pbox(1)}${this.pbox(0)}</div>
        <div class="board-wrap sunken"><div class="board" role="grid" aria-label="Board">${[3, 2, 1, 0].map((r) => [0, 1, 2].map((c) => this.cell(r * COLS + c)).join("")).join("")}</div></div>
        <div class="rpanel">${this.inspector()}${this.hand()}</div>
      </div></div></div>`;
    this.taskbar();
  },

  pbox(p) {
    const g = appState.game, pl = g.players[p], dev = deviceCard(g, p), ui = appState.ui;
    const chargeable = p === 0 && g.phase === "charge" && this.myTurn();
    const need = deviceNeed(g, p);
    const meters = dev ? RES.filter((k) => dev.cost[k]).map((k) => {
      const have = pl.device.charge[k], tot = dev.cost[k], can = chargeable && need[k] > 0 && pl.res[k] > 0;
      const inner = `${resIcon(k)}<span class="bar sunken"><i style="width:${(have / tot) * 100}%;--c:${RES_COLOR[k]}"></i></span><span class="num">${have}/${tot}</span>`;
      return can ? `<button class="meter tap${have >= tot ? " done" : ""}" data-act="charge" data-res="${k}" aria-label="Charge ${RES_NAME[k]}" data-meter="${p}${k}">${inner}</button>`
        : `<div class="meter${have >= tot ? " done" : ""}" data-meter="${p}${k}">${inner}</div>`;
    }).join("") : `<div class="meter">Choosing a device</div>`;
    const active = g.active === p && g.phase !== "setup" && g.phase !== "over";
    const minions = active ? `${availableMinions(g, p)} free of ${pl.minions + pl.tempMinions}` : `${pl.minions}`;
    return `<section class="pbox raised${active ? " active" : ""}" data-pbox="${p}" aria-label="${esc(pl.villain)}">
      <header>${Sprites.img(DATA.decks[pl.deck].icon)}<span class="who">${p === 0 ? "You" : "Rival"}: ${esc(pl.short)}</span>
        ${pl.shield ? `<span class="badge shield" title="Blocks the next sabotage">Shield</span>` : ""}
        ${active && p === 1 ? `<span class="badge">Thinking</span>` : ""}</header>
      ${dev ? `<button class="dev" data-act="inspectDev" data-p="${p}">${Sprites.img(dev.sprite)}<span class="dname">${esc(dev.name)}<br><span style="font-weight:normal">${Math.round(chargePct(g, p) * 100)}% charged</span></span></button>` : ""}
      <div class="meters">${meters}</div>
      <div class="resrow" title="Resources">${resChips(pl.res, true)}</div>
      <div class="stats"><span title="Minions">${Sprites.img("minion")} ${minions}</span><span>Hand ${pl.hand.length}</span><span>Deck ${pl.library.length}</span></div>
    </section>`;
  },

  cell(i) {
    const g = appState.game, ui = appState.ui, cell = g.board[i], r = rowOf(i);
    const zone = r === 3 ? "zone-rival" : r === 0 ? "zone-you" : "zone-public";
    const cls = ["cell", zone];
    const mine = this.myTurn() && g.phase === "main";
    if (mine && ui.mode === "build" && canBuildAt(g, 0, i)) cls.push("can-build");
    if (mine && ui.mode === "target" && cell && cell.owner === 1) cls.push(ui.picks.includes(i) ? "picked" : "can-target");
    if (mine && ui.mode === "scrap" && cell && cell.owner === 0) cls.push("can-scrap");
    if (mine && !ui.mode && canWork(g, 0, i) && availableMinions(g, 0) > 0) cls.push("can-work");
    if (!cell) {
      const label = r === 3 ? "Rival lab" : r === 0 ? "Your lab" : "Public Works";
      return `<button class="${cls.join(" ")}" data-cell="${i}" aria-label="${label}, empty"><span class="zlabel">${label}</span></button>`;
    }
    cls.push("filled");
    if (cell.playedTurn === g.turn) cls.push("fresh");
    const card = cardOf(g, cell.inst), own = DATA.decks[g.players[cell.owner].deck].accent;
    const jammed = cell.jamTurn >= g.turn;
    return `<button class="${cls.join(" ")}" data-cell="${i}" aria-label="${esc(card.name)}, ${cell.owner === 0 ? "yours" : "rival's"}${cell.worker !== null ? ", worked" : ""}">
      <div class="plane">${cardHtml(card, "plane")}</div>
      <span class="owner" style="--own:${own}" title="${esc(g.players[cell.owner].short)}"></span>
      <div class="popup" data-pop="${i}">${Sprites.img(card.sprite)}<span class="pname">${esc(card.name)}</span></div>
      <div class="out">${resChips(card.produces)}</div>
      ${cell.worker !== null ? `<img class="px minion" src="${Sprites.url("minion")}" alt="minion">` : ""}
      ${cell.playedTurn === g.turn ? `<span class="fresh-tag">New</span>` : ""}
      ${jammed ? `<span class="stamp">Jammed</span>` : ""}
    </button>`;
  },

  inspector() {
    const g = appState.game, ui = appState.ui, pl = g.players[0];
    let card = null, msg = "", acts = "";
    if (ui.inspect) card = ui.inspect.kind === "hand" || ui.inspect.kind === "card" ? Registry.card(ui.inspect.id) : null;
    if (!card) card = deviceCard(g, 0);
    if (g.phase === "over") msg = `<b>${g.winner === 0 ? "The world is yours." : "The world ended without you."}</b>`;
    else if (g.active !== 0 || ui.busy) msg = `<b>Rival's turn</b><br>${esc(g.players[1].short)} is scheming. Watch the board.`;
    else if (ui.mode === "burn") {
      msg = `<b>Burn cards</b><br>Pick ${cfg("burnCards")} cards to burn for one extra minion this turn.`;
      acts = `<button class="btn primary" data-act="confirmBurn" ${ui.picks.length === cfg("burnCards") ? "" : "disabled"}>Burn ${ui.picks.length}/${cfg("burnCards")}</button><button class="btn" data-act="cancel">Cancel</button>`;
    } else if (ui.mode === "scrap") {
      msg = `<b>Scrap</b><br>Tap one of your machines to scrap it and free the slot.`;
      acts = `<button class="btn" data-act="cancel">Cancel</button>`;
    } else if (ui.mode === "discard") {
      const over = pl.hand.length - cfg("handLimit");
      msg = `<b>Too many cards</b><br>Pick ${over} to discard. Your hand limit is ${cfg("handLimit")}.`;
      acts = `<button class="btn primary" data-act="confirmDiscard" ${ui.picks.length === over ? "" : "disabled"}>Discard and end turn</button><button class="btn" data-act="cancel">Cancel</button>`;
    } else if (ui.selected) {
      const c = cardOf(g, ui.selected), afford = c.type === "doomsday" || canAfford(pl, c.cost);
      msg = `<b>${esc(c.name)}</b><br>${afford || c.type === "doomsday" ? "" : `You can't afford this yet (costs ${costText(c.cost)}). `}`;
      if (afford) {
        if (c.type === "contraption") msg += "Tap a glowing slot in your lab or Public Works.";
        else if (c.modes && !ui.cardMode) { msg += "Choose one:"; acts = `<button class="btn" data-act="cardMode" data-mode="steal">Steal MacGuffin</button><button class="btn" data-act="cardMode" data-mode="bounce">Bounce a machine</button>`; }
        else if (ui.mode === "target") {
          const n = c.target.count, legal = rivalCells(g, 0).length;
          msg += legal ? `Tap ${n === 2 ? "two rival machines" : "a rival machine"} (${ui.picks.length}/${n}).` : "Your rival has no machines to target.";
          if (c.target.optional && !legal) acts = `<button class="btn primary" data-act="playSelected">Play anyway</button>`;
        } else if (c.type === "doomsday") { msg += "Swap this in as your device? It keeps half your current charge."; acts = `<button class="btn primary" data-act="playSelected">Swap device</button>`; }
        else acts = `<button class="btn primary" data-act="playSelected">Play ${esc(c.name)}</button>`;
      }
      acts += `<button class="btn" data-act="cancel">Cancel</button>`;
    } else if (ui.inspect && ui.inspect.kind === "card") {
      msg = `<b>${esc(card.name)}</b><br>${esc(card.rulesText || "")}<br><span class="flavor">${esc(card.flavor || "")}</span>`;
    } else if (g.phase === "main") {
      msg = `<b>Build and place</b><br>Tap a card to play it. Tap a glowing machine to send a minion (${availableMinions(g, 0)} free). Minions you leave unused each gather 1 resource of your choice (not MacGuffin) at Collect.`;
    } else if (g.phase === "charge") {
      msg = `<b>Charge your device</b><br>Move resources into your device, then End turn. Anything over ${cfg("carryCap")} of a kind is lost at end of turn.`;
      const need = deviceNeed(g, 0);
      acts = RES.filter((k) => need[k] > 0 && pl.res[k] > 0).map((k) => `<button class="btn small" data-act="charge" data-res="${k}">${resIcon(k)} Charge ${Math.min(need[k], pl.res[k])}</button>`).join("") || `<span>Nothing you hold fits the device right now.</span>`;
    }
    const log = g.log.slice(-6).reverse().map((l) => `<p>${esc(l.msg)}</p>`).join("");
    return `<section class="inspector raised"><div class="bigcard" data-tilt>${card ? cardHtml(card, "full") : ""}</div>
      <div class="info"><div class="msg" aria-live="polite">${msg}</div><div class="acts">${acts}</div><div class="log sunken" aria-label="Event log">${log}</div></div></section>`;
  },

  hand() {
    const g = appState.game, ui = appState.ui, pl = g.players[0];
    const cards = pl.hand.map((inst) => {
      const c = cardOf(g, inst), cls = ["hcard"];
      if (ui.selected === inst) cls.push("sel");
      if (ui.picks.includes(inst)) cls.push("picked");
      if (c.type !== "doomsday" && !canAfford(pl, c.cost)) cls.push("cant");
      return `<button class="${cls.join(" ")}" data-hand="${inst}" aria-label="${esc(c.name)}">${cardHtml(c, "mini")}</button>`;
    }).join("");
    return `<section class="handbox raised"><span class="legend">Your hand (${pl.hand.length})</span><div class="hand sunken">${cards || `<span class="empty">No cards in hand.</span>`}</div></section>`;
  },

  taskbar() {
    const g = appState.game, mine = this.myTurn(), pl = g.players[0], ui = appState.ui;
    const main = mine && g.phase === "main", charge = mine && g.phase === "charge";
    const label = g.phase === "over" ? "Game over" : !mine ? "Rival's turn" : main ? "Build and place" : "Charge";
    const btns = g.phase === "over" ? `<button class="btn primary" data-act="newGame">New game</button>` : `
      <button class="btn" data-act="recruit" ${main && pl.minions < minionCap(g, 0) && sumRes(pl.res) >= cfg("recruitCost") ? "" : "disabled"}>${Sprites.img("minion")}Recruit (${cfg("recruitCost")})</button>
      <button class="btn" data-act="exchange" title="Trade ${cfg("exchangeCost")} resources for 1 MacGuffin, once per turn" ${main && pl.exchangedTurn !== g.turn && pl.res.E + pl.res.O + pl.res.M + pl.res.S >= cfg("exchangeCost") ? "" : "disabled"}>${resIcon("X")}Exchange (${cfg("exchangeCost")})</button>
      <button class="btn${ui.mode === "burn" ? " on" : ""}" data-act="burnMode" ${main && pl.hand.length >= cfg("burnCards") ? "" : "disabled"}>Burn ${cfg("burnCards")}</button>
      <button class="btn${ui.mode === "scrap" ? " on" : ""}" data-act="scrapMode" ${main && g.board.some((c) => c && c.owner === 0) ? "" : "disabled"}>Scrap</button>
      ${charge ? `<button class="btn" data-act="chargeAll">Charge all</button><button class="btn primary" data-act="endTurn">End turn</button>`
        : `<button class="btn primary" data-act="collect" ${main ? "" : "disabled"}>Collect</button>`}`;
    Desktop.taskbar(`<span class="phase-label">${label}</span>${btns}`);
  },
};
