// Rasterize primitive-shape sprites (src/data/sprites.json) into crisp pixel images, cached as data URLs.
const Sprites = {
  cache: {},
  raster(def) {
    const n = def.size, px = Array.from({ length: n }, () => Array(n).fill(-1));
    const set = (x, y, c) => { x = Math.round(x); y = Math.round(y); if (x >= 0 && y >= 0 && x < n && y < n) px[y][x] = c; };
    const line = (x0, y0, x1, y1, c) => {
      const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
      let err = dx + dy;
      for (;;) { set(x0, y0, c); if (x0 === x1 && y0 === y1) break; const e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
    };
    for (const op of def.ops) {
      const [t, ...a] = op;
      if (t === "r") { for (let y = a[1]; y < a[1] + a[3]; y++) for (let x = a[0]; x < a[0] + a[2]; x++) set(x, y, a[4]); }
      else if (t === "p") set(a[0], a[1], a[2]);
      else if (t === "l") line(a[0], a[1], a[2], a[3], a[4]);
      else if (t === "c" || t === "o") {
        const [cx, cy, r, c] = a;
        for (let y = cy - r - 1; y <= cy + r + 1; y++) for (let x = cx - r - 1; x <= cx + r + 1; x++) {
          const d = (x - cx) ** 2 + (y - cy) ** 2;
          if (t === "c" ? d <= r * r + r * 0.6 : d <= r * r + r * 0.6 && d >= (r - 1) * (r - 1) + (r - 1) * 0.6) set(x, y, c);
        }
      } else if (t === "e") {
        const [cx, cy, rx, ry, c] = a;
        for (let y = cy - ry; y <= cy + ry; y++) for (let x = cx - rx; x <= cx + rx; x++)
          if (((x - cx) / (rx + 0.4)) ** 2 + ((y - cy) / (ry + 0.4)) ** 2 <= 1) set(x, y, c);
      } else if (t === "t") {
        const [x1, y1, x2, y2, x3, y3, c] = a;
        const minX = Math.min(x1, x2, x3), maxX = Math.max(x1, x2, x3), minY = Math.min(y1, y2, y3), maxY = Math.max(y1, y2, y3);
        const area = (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1);
        for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
          const w1 = ((x2 - x) * (y3 - y) - (x3 - x) * (y2 - y)) / area, w2 = ((x3 - x) * (y1 - y) - (x1 - x) * (y3 - y)) / area;
          if (w1 >= -0.02 && w2 >= -0.02 && 1 - w1 - w2 >= -0.02) set(x, y, c);
        }
      }
    }
    // Auto-outline in palette color 0 so every sprite reads at small sizes.
    const out = px.map((r) => r.slice());
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      if (px[y][x] !== -1) continue;
      if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => { const v = (px[y + dy] || [])[x + dx]; return v !== undefined && v > 0; })) out[y][x] = 0;
    }
    return out;
  },
  url(name) {
    if (this.cache[name]) return this.cache[name];
    const def = DATA.sprites.sprites[name];
    if (!def) return "";
    const pal = DATA.sprites.palettes[def.pal], px = this.raster(def), n = def.size;
    const cv = document.createElement("canvas");
    cv.width = n; cv.height = n;
    const ctx = cv.getContext("2d");
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (px[y][x] >= 0) { ctx.fillStyle = pal[px[y][x]]; ctx.fillRect(x, y, 1, 1); }
    return (this.cache[name] = cv.toDataURL());
  },
  img(name, cls = "", alt = "") { return `<img class="px ${cls}" src="${this.url(name)}" alt="${alt}" draggable="false">`; },
};
