// Boot screen, desktop, Scheme menu, and the menu windows (villain select, how to play, settings).
const Desktop = {
  boot() {
    appState.screen = "boot";
    $("#screen").innerHTML = `<div class="boot" data-act="skipBoot"><div><h1>DOOMSDAY 95</h1><div>Starting your evil empire</div>
      <div class="bar"><i></i></div><div style="font-size:12px;opacity:.7">Tap to skip</div></div></div>`;
    $("#taskbar").innerHTML = "";
    this.bootTimer = setTimeout(() => this.show(), appState.settings.reducedMotion ? 200 : 1600);
  },
  show() {
    clearTimeout(this.bootTimer);
    appState.screen = "desktop";
    const cont = Store.hasGame();
    $("#screen").innerHTML = `<div class="desktop"><div class="icons">
      <button class="dicon" data-act="newGame">${Sprites.img("icon_new")}<span>New Game</span></button>
      ${cont ? `<button class="dicon" data-act="continue">${Sprites.img("icon_continue")}<span>Continue</span></button>` : ""}
      <button class="dicon" data-act="howto">${Sprites.img("icon_howto")}<span>How to Play</span></button>
      <button class="dicon" data-act="settings">${Sprites.img("icon_settings")}<span>Settings</span></button>
    </div><div class="desk-title"><b>Doomsday 95</b><span>Two villains. One world to end.</span></div></div>`;
    this.taskbar();
  },
  taskbar(extra = "") {
    $("#taskbar").innerHTML = `<button class="btn scheme" data-act="menu" aria-haspopup="menu">${Sprites.img("icon_skull")}Scheme</button>${extra}
      <div class="tray sunken">${appState.settings.sound ? "♪" : ""}<span id="clock"></span></div>`;
    this.tick();
  },
  tick() {
    const c = $("#clock");
    if (c) c.textContent = new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  },
  menu() {
    if ($(".menu")) { $(".menu").remove(); return; }
    const inMatch = appState.screen === "match";
    const m = document.createElement("div");
    m.className = "menu win";
    m.setAttribute("role", "menu");
    m.innerHTML = `<div class="stripe">Doomsday 95</div><ul>
      <li><button data-act="newGame" role="menuitem">${Sprites.img("icon_new")}New Game</button></li>
      <li><button data-act="howto" role="menuitem">${Sprites.img("icon_howto")}How to Play</button></li>
      <li><button data-act="settings" role="menuitem">${Sprites.img("icon_settings")}Settings</button></li>
      ${inMatch ? `<li><button data-act="toDesktop" role="menuitem">${Sprites.img("icon_continue")}Back to desktop</button></li>` : ""}
    </ul>`;
    document.body.appendChild(m);
  },
  closeMenu() { const m = $(".menu"); if (m) m.remove(); },
  villainSelect() {
    const dossier = (deck) => {
      const d = DATA.decks[deck];
      return `<section class="dossier sunken" style="background:var(--face)"><header>${Sprites.img(d.icon)}<div><h3>${esc(d.villain)}</h3><div>${esc(d.style)}</div></div></header>
        <p>Heroes in this deck: ${esc(d.heroes)}.</p>
        <button class="btn primary" data-act="pickDeck" data-deck="${deck}">Play as ${esc(d.short)}</button></section>`;
    };
    showDialog("Choose your villain", `<div class="villains">${dossier("tesla")}${dossier("edison")}</div>`, [], { wide: true });
  },
  howto() {
    showDialog("How to Play.txt", `<div class="howto sunken" style="padding:10px;max-height:60vh;overflow:auto">
      <h3>Goal</h3><p>Fill every meter on your doomsday device. A full device fires at the start of your next turn and you win. Your rival gets one turn to stop it.</p>
      <h3>The board</h3><p>Your back row is your private lab. The two middle rows are Public Works: either villain may build there, and either may send a minion to work any machine there. When a rival works your machine, you get 1 of its output.</p>
      <h3>Your turn</h3><p>You draw a card, then build and place in any order. Tap a card to select it, then tap a highlighted slot. Tap one of your machines to put a minion on it, and tap again to take it back. New machines can't be worked the turn they're built.</p>
      <p>When you're done, tap Collect. Then tap a meter to charge it, or Charge all, and End turn.</p>
      <h3>Minions</h3><p>Recruit costs 4 resources of any kind. Burn 2 cards for one extra minion this turn only. Worker cards recruit cheaply. Any minion you don't place gathers 1 resource of your choice when you Collect, except MacGuffin.</p>
      <h3>Combos</h3><p>Two worked machines next to each other that make the same resource each make +1 more (Resonance). Some cards boost their neighbors. Combos count across owners.</p>
      <h3>Heroes</h3><p>Distraction cards send heroes at your rival: Jam a machine for a turn, steal resources, swap machines, or sabotage their device. A Shield blocks the next sabotage.</p>
      <h3>MacGuffin</h3><p>Every device needs 4 MacGuffin and few machines make it. Fight over them. Once per turn you can also use Exchange: trade 5 other resources for 1 MacGuffin (it takes from your biggest piles).</p></div>`, [{ label: "OK", primary: true }], { icon: "icon_howto" });
  },
  settings() {
    const s = appState.settings;
    showDialog("Settings", `<div class="field-row"><input type="checkbox" id="set-sound" ${s.sound ? "checked" : ""}><label for="set-sound">Sound effects</label></div>
      <div class="field-row"><input type="checkbox" id="set-motion" ${s.reducedMotion ? "checked" : ""}><label for="set-motion">Reduce motion</label></div>
      <div class="field-row"><label for="set-diff">Opponent</label><select id="set-diff" style="min-height:32px"><option value="normal" ${s.difficulty === "normal" ? "selected" : ""}>Normal</option><option value="easy" ${s.difficulty === "easy" ? "selected" : ""}>Easy</option></select></div>`,
      [{ label: "Save settings", primary: true, onClick: () => {
        s.sound = $("#set-sound").checked; s.reducedMotion = $("#set-motion").checked; s.difficulty = $("#set-diff").value;
        Store.saveSettings(); document.documentElement.classList.toggle("reduced", s.reducedMotion);
        if (appState.screen === "match") Match.render(); else this.taskbar();
        toast("Settings saved.");
      } }, { label: "Cancel" }], { icon: "icon_settings" });
  },
};
