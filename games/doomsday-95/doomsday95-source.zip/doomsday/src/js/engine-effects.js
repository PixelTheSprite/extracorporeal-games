// Effects: production (with combos) and on-play card effects. Mutates the game, returns events.

// Output of one contraption at cell i, given the set of cells worked this turn.
function cellOutput(game, i, worked) {
  const cell = game.board[i], card = cardOf(game, cell.inst), owner = cell.owner;
  const out = Object.assign(emptyRes(), card.produces);
  const combos = [];
  const nbrs = neighborsOf(i).filter((n) => game.board[n]);
  const tagsOf = (n) => cellCard(game, n).tags || [];

  for (const e of card.effects) {
    if (e.trigger !== "onWork") continue;
    if (e.action === "gain") {
      const tag = e.condition && e.condition.adjacentTag;
      const partner = tag ? nbrs.find((n) => tagsOf(n).includes(tag)) : null;
      if (!tag || partner !== undefined) {
        RES.forEach((k) => { out[k] += e.params[k] || 0; });
        if (tag) combos.push([i, partner]);
      }
    }
    if (e.action === "gainPerAdjacentOwned") {
      const owned = nbrs.filter((n) => game.board[n].owner === owner).slice(0, e.params.max);
      out[e.params.res] += owned.length;
      owned.forEach((n) => combos.push([i, n]));
    }
  }
  // Auras from neighbors (Wireless Pylon, Pearl Street Station).
  for (const n of nbrs) {
    for (const e of cellCard(game, n).effects) {
      if (e.trigger !== "aura" || e.action !== "boostAdjacent") continue;
      if (e.params.tag && !(card.tags || []).includes(e.params.tag)) continue;
      if (e.params.owned && game.board[n].owner !== owner) continue;
      out[e.params.res || firstRes(card)] += e.params.amount || 1;
      combos.push([n, i]);
    }
  }
  // Device passives that boost the owner's tagged cards.
  for (const e of passives(game, owner)) {
    if (e.action === "boostTag" && (card.tags || []).includes(e.params.tag)) out[e.params.res] += e.params.amount;
  }
  // Resonance: adjacent worked contraptions sharing an output resource.
  const own = card.effects.find((e) => e.action === "resonanceBonus");
  const dev = passive(game, owner, "resonanceBonus");
  const bonus = own ? own.params.amount : dev ? dev.params.amount : 1;
  for (const n of nbrs) {
    if (!worked.has(n)) continue;
    const nc = cellCard(game, n);
    for (const k of RES) if (card.produces[k] && nc.produces[k]) { out[k] += bonus; combos.push([i, n]); }
  }
  return { out, combos };
}

function resolveCollect(game, p, events) {
  const worked = new Set(game.board.map((c, i) => (c && c.worker === p ? i : -1)).filter((i) => i >= 0));
  const seen = new Set();
  for (const i of worked) {
    const cell = game.board[i], card = cardOf(game, cell.inst);
    const { out, combos } = cellOutput(game, i, worked);
    addRes(game.players[p], out);
    events.push({ type: "produce", cell: i, p, res: out });
    for (const [a, b] of combos) {
      const key = a < b ? a + "-" + b : b + "-" + a;
      if (!seen.has(key)) { seen.add(key); events.push({ type: "combo", a, b }); }
    }
    if (cell.owner !== p) {
      const tax = passive(game, cell.owner, "rivalTax");
      const amt = tax ? tax.params.amount : 1, k = firstRes(card);
      game.players[cell.owner].res[k] += amt;
      events.push({ type: "tax", cell: i, p: cell.owner, res: { [k]: amt } });
    }
    if (card.effects.some((e) => e.trigger === "onWork" && e.action === "shield")) {
      game.players[cell.owner].shield = true;
      events.push({ type: "shield", p: cell.owner });
    }
  }
  const total = events.filter((e) => e.type === "produce").reduce((a, e) => a + sumRes(e.res), 0);
  gameLog(game, `${pname(game, p)} collects ${total} resource${total === 1 ? "" : "s"}.`);
}

function drawCards(game, p, n, events) {
  const pl = game.players[p];
  for (let i = 0; i < n; i++) {
    if (!pl.library.length) {
      if (!pl.discard.length) break;
      pl.library = rngShuffle(game, pl.discard);
      pl.discard = [];
      pl.minions = Math.max(1, pl.minions - 1);
      gameLog(game, `${pname(game, p)} ran out of cards: discard reshuffled, 1 minion lost.`);
      events.push({ type: "deckout", p });
    }
    pl.hand.push(pl.library.pop());
    events.push({ type: "draw", p });
  }
}

function jamCell(game, i, events) {
  game.board[i].jamTurn = game.turn + 1;
  game.board[i].worker = null;
  events.push({ type: "jam", cell: i });
}

function sabotage(game, target, amount, events) {
  const pl = game.players[target];
  if (pl.shield) {
    pl.shield = false;
    events.push({ type: "blocked", p: target });
    gameLog(game, `${pname(game, target)}'s Shield blocks the sabotage.`);
    return;
  }
  const ch = pl.device.charge;
  let left = amount, removed = 0;
  while (left > 0) {
    const k = RES.slice().sort((a, b) => (ch[b] || 0) - (ch[a] || 0))[0];
    if (!ch[k]) break;
    ch[k]--; left--; removed++;
  }
  events.push({ type: "sabotage", p: target, amount: removed });
  gameLog(game, `Sabotage! ${pname(game, target)}'s device loses ${removed} charge.`);
}

// Resolve a played distraction or worker. targets: board indices; mode: chosen mode.
function resolveOnPlay(game, p, card, targets, mode, events) {
  const pl = game.players[p], foe = rival(p), fp = game.players[foe];
  for (const e of card.effects) {
    if (e.trigger !== "onPlay") continue;
    if (e.mode && e.mode !== mode) continue;
    const prm = e.params || {};
    switch (e.action) {
      case "gain": addRes(pl, prm); events.push({ type: "gain", p, res: prm }); break;
      case "recruit": pl.minions = Math.min(minionCap(game, p), pl.minions + (prm.amount || 1)); events.push({ type: "recruit", p }); break;
      case "draw": drawCards(game, p, prm.amount || 1, events); break;
      case "shield": pl.shield = true; events.push({ type: "shield", p }); break;
      case "jam": {
        if (targets[0] === undefined) break;
        jamCell(game, targets[0], events);
        if (prm.adjacent) {
          const n = neighborsOf(targets[0]).find((x) => game.board[x] && game.board[x].owner === foe);
          if (n !== undefined) jamCell(game, n, events);
        }
        break;
      }
      case "sabotage": sabotage(game, foe, prm.amount || 3, events); break;
      case "steal": {
        const k = prm.res || RES.slice().sort((a, b) => fp.res[b] - fp.res[a])[0];
        const amt = Math.min(prm.amount || 2, fp.res[k]);
        fp.res[k] -= amt; pl.res[k] += amt;
        events.push({ type: "steal", from: foe, to: p, res: { [k]: amt } });
        gameLog(game, `${pname(game, p)} steals ${amt} ${RES_NAME[k]}.`);
        break;
      }
      case "swap": {
        const [a, b] = targets;
        [game.board[a], game.board[b]] = [game.board[b], game.board[a]];
        game.board[a].worker = null; game.board[b].worker = null;
        events.push({ type: "swap", a, b });
        if (passive(game, p, "swapAlsoJams")) jamCell(game, a, events);
        break;
      }
      case "bounce": {
        const i = targets[0], cell = game.board[i];
        game.players[cell.owner].hand.push(cell.inst);
        game.board[i] = null;
        events.push({ type: "bounce", cell: i });
        break;
      }
    }
  }
}
