// Engine core: constants and pure helpers over a game object. No DOM.
const RES = ["E", "O", "M", "S", "X"];
const RES_NAME = { E: "Electricity", O: "Organic matter", M: "Magic", S: "Spirit essence", X: "MacGuffin" };
const COLS = 3, ROWS = 4;

function cfg(k) { return DATA.config[k]; }
function emptyRes() { return { E: 0, O: 0, M: 0, S: 0, X: 0 }; }
function rowOf(i) { return Math.floor(i / COLS); }
function colOf(i) { return i % COLS; }
function backRow(p) { return p === 0 ? 0 : ROWS - 1; }
function isPublicRow(r) { return r > 0 && r < ROWS - 1; }
function neighborsOf(i) {
  const r = rowOf(i), c = colOf(i), out = [];
  if (r > 0) out.push(i - COLS);
  if (r < ROWS - 1) out.push(i + COLS);
  if (c > 0) out.push(i - 1);
  if (c < COLS - 1) out.push(i + 1);
  return out;
}
function sumRes(r) { return RES.reduce((a, k) => a + (r[k] || 0), 0); }
function cardOf(game, inst) { return Registry.card(game.insts[inst].cardId); }
function cellCard(game, i) { const cell = game.board[i]; return cell ? cardOf(game, cell.inst) : null; }
function firstRes(card) { return RES.find((k) => card.produces[k]) || "E"; }
function canAfford(pl, cost) { return RES.every((k) => (pl.res[k] || 0) >= (cost[k] || 0)); }
function payCost(pl, cost) { RES.forEach((k) => { pl.res[k] -= cost[k] || 0; }); }
function addRes(pl, r) { RES.forEach((k) => { if (r[k]) pl.res[k] += r[k]; }); }
function rival(p) { return 1 - p; }

function deviceCard(game, p) { const d = game.players[p].device; return d ? cardOf(game, d.inst) : null; }
function deviceNeed(game, p) {
  const n = emptyRes(), c = deviceCard(game, p);
  if (!c) return n;
  const ch = game.players[p].device.charge;
  RES.forEach((k) => { n[k] = Math.max(0, (c.cost[k] || 0) - (ch[k] || 0)); });
  return n;
}
function chargePct(game, p) {
  const c = deviceCard(game, p);
  if (!c) return 0;
  const total = sumRes(c.cost);
  return total ? (total - sumRes(deviceNeed(game, p))) / total : 0;
}
function deviceFull(game, p) { return !!deviceCard(game, p) && sumRes(deviceNeed(game, p)) === 0; }
function passives(game, p) {
  const c = deviceCard(game, p);
  return c ? c.effects.filter((e) => e.trigger === "passive") : [];
}
function passive(game, p, action) { return passives(game, p).find((e) => e.action === action); }
function minionCap(game, p) { const m = passive(game, p, "minionCap"); return m ? m.params.amount : cfg("minionCap"); }
function placedCount(game, p) { return game.board.filter((c) => c && c.worker === p).length; }
function availableMinions(game, p) {
  const pl = game.players[p];
  return pl.minions + pl.tempMinions - placedCount(game, p);
}
function canBuildAt(game, p, i) {
  if (game.board[i]) return false;
  const r = rowOf(i);
  return r === backRow(p) || isPublicRow(r);
}
function isJammed(game, i) { const c = game.board[i]; return !!c && c.jamTurn === game.turn; }
function canWork(game, p, i) {
  const cell = game.board[i];
  if (!cell || cell.worker !== null) return false;
  if (cell.playedTurn === game.turn || cell.jamTurn === game.turn) return false;
  const r = rowOf(i);
  if (isPublicRow(r)) return true;
  return r === backRow(p) && cell.owner === p;
}
function workableCells(game, p) { return game.board.map((_, i) => i).filter((i) => canWork(game, p, i)); }
function rivalCells(game, p) { return game.board.map((c, i) => (c && c.owner === rival(p) ? i : -1)).filter((i) => i >= 0); }
function gameLog(game, msg) {
  game.log.push({ t: game.turn, msg });
  if (game.log.length > 150) game.log.shift();
}
function pname(game, p) { return game.players[p].short; }
