#!/usr/bin/env node
// Build the single-file deliverable from modular source.
//
//   node build.mjs                 -> dist/<name>.html
//   node build.mjs --out app.html  -> custom output path
//
// Inputs (all paths relative to this file):
//   src/index.template.html   page shell with three markers: <!-- @css -->, <!-- @data -->, <!-- @js -->
//   src/manifest.json         { "name": "...", "css": [...], "js": [...] }  (order matters)
//   src/data/*.json           inlined as  const DATA = { "<filename-without-ext>": ... };
//
// JS files are concatenated in manifest order into ONE <script> (plain vanilla JS, no import/export),
// each under a banner comment so stack traces and diffs stay readable. List a file in the manifest
// to include it; unlisted files are ignored on purpose, and the build warns about them.

import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync } from "node:fs";
import { dirname, join, basename } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const src = (...p) => join(root, "src", ...p);
const read = (p) => readFileSync(p, "utf8");

const manifest = JSON.parse(read(src("manifest.json")));
const outArg = process.argv.indexOf("--out");
const outPath = outArg > -1 ? process.argv[outArg + 1] : join(root, "dist", `${manifest.name || "app"}.html`);

function bundle(dir, files, label) {
  return files
    .map((f) => {
      const p = src(dir, f);
      if (!existsSync(p)) throw new Error(`manifest lists ${dir}/${f} but the file does not exist`);
      return `/* ===== ${label}: ${f} ===== */\n${read(p).trimEnd()}\n`;
    })
    .join("\n");
}

// Data: every src/data/*.json becomes a key on one DATA object. Invalid JSON fails the build loudly.
const dataDir = src("data");
const data = {};
if (existsSync(dataDir)) {
  for (const f of readdirSync(dataDir).filter((n) => n.endsWith(".json")).sort()) {
    try {
      data[basename(f, ".json")] = JSON.parse(read(join(dataDir, f)));
    } catch (e) {
      throw new Error(`src/data/${f} is not valid JSON: ${e.message}`);
    }
  }
}

// Warn about source files the manifest forgot, since a missing file is a confusing runtime bug.
for (const [dir, key] of [["css", "css"], ["js", "js"]]) {
  const listed = new Set(manifest[key] || []);
  const dirPath = src(dir);
  if (!existsSync(dirPath)) continue;
  for (const f of readdirSync(dirPath)) {
    if (!listed.has(f)) console.warn(`warning: src/${dir}/${f} is not in manifest.json and was not included`);
  }
}

let html = read(src("index.template.html"));
const markers = { "<!-- @css -->": `<style>\n${bundle("css", manifest.css || [], "css")}</style>`,
  "<!-- @data -->": `<script>\nconst DATA = ${JSON.stringify(data)};\n</script>`,
  "<!-- @js -->": `<script>\n${bundle("js", manifest.js || [], "js")}</script>` };
for (const [marker, content] of Object.entries(markers)) {
  if (!html.includes(marker)) throw new Error(`index.template.html is missing the ${marker} marker`);
  html = html.replace(marker, () => content);
}

mkdirSync(dirname(outPath), { recursive: true });
writeFileSync(outPath, html);
const kb = (Buffer.byteLength(html) / 1024).toFixed(1);
console.log(`Built ${outPath} (${kb} KB, ${manifest.js?.length || 0} js, ${manifest.css?.length || 0} css, ${Object.keys(data).length} data files)`);
