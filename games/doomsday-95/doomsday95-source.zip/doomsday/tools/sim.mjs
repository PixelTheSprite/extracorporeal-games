// Headless AI-vs-AI simulation: node tools/sim.mjs [games]
import { readFileSync, readdirSync } from "node:fs";
const root = new URL("..", import.meta.url).pathname;
const DATA = {};
for (const f of readdirSync(root + "src/data")) DATA[f.replace(".json", "")] = JSON.parse(readFileSync(root + "src/data/" + f, "utf8"));
const files = ["registry.js", "rng.js", "engine-core.js", "engine-effects.js", "engine-actions.js", "ai.js"];
const code = files.map((f) => readFileSync(root + "src/js/" + f, "utf8")).join("\n");
const api = new Function("DATA", code + "\nreturn { Registry, newGame, applyAction, AI, chargePct };")(DATA);
const { Registry, newGame, applyAction, AI, chargePct } = api;
if (!Registry.init()) { console.error(Registry.errors); process.exit(1); }
const N = +(process.argv[2] || 300);
const wins = { tesla: 0, edison: 0 }, turns = [], errors = []; let timeouts = 0, firstWins = 0;
for (let g = 0; g < N; g++) {
  const game = newGame(1000 + g, g % 2 ? "tesla" : "edison");
  game.players[0].ai = true;
  let guard = 0;
  while (game.phase !== "over" && guard++ < 5000) {
    let a;
    if (game.phase === "setup") a = AI.setupAction(game, game.players[0].setup !== "ready" ? 0 : 1);
    else if (game.phase === "bonus") a = { type: "bonus", p: 1 - game.first, res: "E" };
    else a = AI.next(game, game.active, "normal");
    const r = applyAction(game, a);
    if (!r.ok) { errors.push(`${g}: ${a.type} ${r.error}`); break; }
  }
  if (game.phase !== "over") { errors.push(`${g}: did not finish`); continue; }
  if (game.turn > 80) timeouts++;
  wins[game.players[game.winner].deck]++;
  if (game.winner === game.first) firstWins++;
  turns.push(Math.ceil(game.turn / 2));
}
turns.sort((a, b) => a - b);
const avg = turns.reduce((a, b) => a + b, 0) / turns.length;
console.log({ games: N, wins, firstPlayerWinPct: +(firstWins / turns.length * 100).toFixed(1), avgRounds: +avg.toFixed(1),
  medianRounds: turns[turns.length >> 1], p10: turns[Math.floor(turns.length * 0.1)], p90: turns[Math.floor(turns.length * 0.9)], timeouts, errors: errors.slice(0, 5), errorCount: errors.length });
