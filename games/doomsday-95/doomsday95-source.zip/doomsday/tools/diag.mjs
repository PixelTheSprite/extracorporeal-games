import { readFileSync, readdirSync } from "node:fs";
const root = new URL("..", import.meta.url).pathname;
const DATA = {};
for (const f of readdirSync(root + "src/data")) DATA[f.replace(".json", "")] = JSON.parse(readFileSync(root + "src/data/" + f, "utf8"));
const files = ["registry.js", "rng.js", "engine-core.js", "engine-effects.js", "engine-actions.js", "ai.js"];
const code = files.map((f) => readFileSync(root + "src/js/" + f, "utf8")).join("\n");
const api = new Function("DATA", code + "\nreturn { Registry, newGame, applyAction, AI, chargePct, deviceNeed, deviceCard, sumRes };")(DATA);
const { Registry, newGame, applyAction, AI, deviceNeed, deviceCard, sumRes } = api;
Registry.init();
const needAt = {}; const snap = []; const income={tesla:[],edison:[]};
for (let g = 0; g < 100; g++) {
  const game = newGame(5000 + g, g % 2 ? "tesla" : "edison"); game.players[0].ai = true;
  let guard = 0;
  while (game.phase !== "over" && guard++ < 5000) {
    let a;
    if (game.phase === "setup") a = AI.setupAction(game, game.players[0].setup !== "ready" ? 0 : 1);
    else if (game.phase === "bonus") a = { type: "bonus", p: 1 - game.first, res: "X" };
    else a = AI.next(game, game.active, "normal");
    const r = applyAction(game, a);
    if (a.type==="collect" && Math.ceil(game.turn/2)===10){ const s=r.events.filter(e=>e.type==="produce").reduce((x,e)=>x+sumRes(e.res),0); income[game.players[a.p].deck].push(s);}
    if (Math.ceil(game.turn / 2) === 20 && a.type === "endTurn") {
      for (const p of [0, 1]) { const n = deviceNeed(game, p); for (const k in n) needAt[k] = (needAt[k] || 0) + n[k]; }
      snap.push(game.board.filter(Boolean).length);
    }
  }
}
console.log("avg remaining need at round 20 (sum over players / games):", needAt, "board fill:", snap.reduce((a,b)=>a+b,0)/snap.length);
for (const d in income) console.log(d, "income round 10 avg", (income[d].reduce((a,b)=>a+b,0)/income[d].length).toFixed(1));
