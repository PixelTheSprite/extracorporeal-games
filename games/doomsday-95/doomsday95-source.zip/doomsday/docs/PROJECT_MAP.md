# Project map

Generated 2026-11-03 by repo_map.py from `src/`. 27 files, ~31,743 tokens of source in total.
Names are `name:line`. `()` = function, `*` = ALL_CAPS constant (usually a data table). Read only the line ranges you need. Regenerate after structural changes.

- `css/base.css` (67 lines, ~1,315 tok)
- `css/cards.css` (43 lines, ~1,105 tok)
- `css/desktop.css` (43 lines, ~932 tok)
- `css/fx.css` (14 lines, ~284 tok)
- `css/match.css` (105 lines, ~2,182 tok)
- `data/cards.json` (101 lines, ~3,167 tok)
- `data/config.json` (17 lines, ~64 tok)
- `data/decks.json` (4 lines, ~122 tok)
- `data/sprites.json` (57 lines, ~2,133 tok)
- `index.template.html` (27 lines, ~304 tok)
- `js/ai.js` (158 lines, ~2,039 tok)
  - AI*:2
- `js/audio.js` (21 lines, ~288 tok)
  - Sound:2
- `js/controller.js` (228 lines, ~3,042 tok)
  - Game:2
- `js/engine-actions.js` (222 lines, ~2,868 tok)
  - newGame():4 startTurn():26 endGame():41 Actions:48 applyAction():213
- `js/engine-core.js` (75 lines, ~889 tok)
  - RES*:2 RES_NAME*:3 COLS*:4 cfg():6 emptyRes():7 rowOf():8 colOf():9 backRow():10 isPublicRow():11 neighborsOf():12 sumRes():20 cardOf():21 cellCard():22 firstRes():23 canAfford():24 payCost():25 addRes():26 rival():27 deviceCard():29 deviceNeed():30 chargePct():37 deviceFull():43 passives():44 passive():48 minionCap():49 placedCount():50 availableMinions():51 canBuildAt():55 isJammed():60 canWork():61 workableCells():69 rivalCells():70 gameLog():71 pname():75
- `js/engine-effects.js` (168 lines, ~1,760 tok)
  - cellOutput():4 resolveCollect():53 drawCards():80 jamCell():96 sabotage():102 resolveOnPlay():122
- `js/fx.js` (89 lines, ~1,299 tok)
  - Fx:2
- `js/main.js` (52 lines, ~667 tok)
  - startApp():2
- `js/registry.js` (32 lines, ~326 tok)
  - Registry:2
- `js/rng.js` (15 lines, ~133 tok)
  - rngNext():2 rngInt():8 rngShuffle():9
- `js/sprites.js` (57 lines, ~818 tok)
  - Sprites:2
- `js/state.js` (10 lines, ~114 tok)
  - appState:2 resetUi():8
- `js/storage.js` (10 lines, ~229 tok)
  - Store:2
- `js/ui-common.js` (79 lines, ~1,102 tok)
  - $:2 esc:3 RES_COLOR*:4 TYPE_NAME*:5 RARITY_NAME*:6 resIcon():8 resChips():9 costPips():12 costText():17 cardHtml():23 winHtml():36 showDialog():44 closeDialogs():63 toastTimer:65 toast():66 errorFeedback():73 wait:79
- `js/ui-desktop.js` (78 lines, ~1,535 tok)
  - Desktop:2
- `js/ui-match.js` (143 lines, ~2,926 tok)
  - Match:2
- `manifest.json` (6 lines, ~87 tok)
