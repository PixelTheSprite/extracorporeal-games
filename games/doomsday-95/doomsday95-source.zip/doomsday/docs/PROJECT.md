# Doomsday 95 (Tesla vs. Edison)

Euro-style worker-placement card game, single player vs. AI. Browser prototype tuned for iPhone landscape; one self-contained HTML file.
Spec: the "Doomsday Race — TCG Prototype Spec" Claude Doc (rules, decisions, card lists, palettes).

## Build and test
- `node build.mjs` → `dist/doomsday95.html` (inlines src/css, src/js in manifest order, and src/data/*.json as `DATA`).
- `node tools/sim.mjs 400` → AI-vs-AI headless balance run (wins per deck, rounds, errors). Run after any card or rules change.

## Architecture
- **Engine (no DOM):** `engine-core.js` (helpers), `engine-effects.js` (production, combos, card effects), `engine-actions.js` (`newGame`, `applyAction(game, action) → {ok, error, events}`). Validate-then-mutate; every action is logged in `game.actions`. Seeded RNG in `rng.js` (`game.rng`).
- **AI:** `ai.js`, greedy scorer that emits the same actions as the player. `AI.next(game, p)` returns one action at a time.
- **UI:** `ui-match.js` renders from state; `controller.js` maps taps to actions, runs setup dialogs and AI turns; `fx.js` animates the engine's events; `ui-desktop.js` handles boot, desktop, menu and windows.
- **Data:** `data/cards.json` (both decks), `config.json` (all tuning numbers), `decks.json`, `sprites.json` (pixel art as shape primitives, auto-outlined).
- Registry (`registry.js`) is the only path from logic to card data; it validates deck size, copy limit and sprite names at startup.
- Board: 12 cells, index `row*3+col`; row 0 = your lab, row 3 = rival lab, rows 1–2 = Public Works. Player 0 = human.

## Extension points
- New card: add an entry to `cards.json` using existing effect actions (gain, recruit, draw, shield, jam, sabotage, steal, swap, bounce; onWork gain/gainPerAdjacentOwned/shield; aura boostAdjacent; passives resonanceBonus, boostTag, rivalTax, minionCap, swapAlsoJams). New effect = one case in `engine-effects.js`.
- New sprite: add primitives to `sprites.json` (`r` rect, `c` circle, `o` ring, `e` ellipse, `l` line, `t` triangle, `p` pixel; colors index the deck palette).
- New villain deck: add to `decks.json` + cards with that `deck` + a palette.
- Tuning: `config.json` (hand limit, carry cap, recruit cost, minion cap, AI delay, turn limit).

## Key decisions
- Engine is DOM-free so the sim harness can test balance headlessly.
- Sprites are 24x24 primitives, not hand-painted 32x32 bitmaps, to keep art as small editable data.
- Idle minions: at Collect, each unused minion (including burn minions) gathers 1 resource of the player's choice, never MacGuffin (keeps MacGuffin scarce). Passed as `collect.idle`; the engine checks the count. The AI idles a minion when no placement beats a free resource.
- MacGuffin Exchange: once per turn, trade `exchangeCost` (5) non-MacGuffin resources for 1 MacGuffin; pays from the largest piles like Recruit. Ends the MacGuffin drought (29% of games had none by round 13).
- Going-second bonus: 1 resource of choice, never MacGuffin. Free resource picks never give MacGuffin.
- Shield lasts until it absorbs one Sabotage (the spec left duration open).
- Overtime: after 40 rounds the higher charge % wins (safety net; about 2% of AI games).
- Balance changes from the spec draft: Induction Motor makes 1 E + 2 Magic (was 1 + 1). Ether Lens was raised to 3 Magic, then returned to 2 once the MacGuffin Exchange made Tesla too strong (53.5%).

## Current phase
v1 prototype complete (phases 1–6 of the spec roadmap in one pass). Next: Phase 7, optimization and debug pass, plus playtesting.
