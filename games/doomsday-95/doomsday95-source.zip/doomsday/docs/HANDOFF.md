# Handoff: after the MacGuffin Exchange and Ether Lens revert

Date: 2026-11-03
Next: Phase 7 (optimization, debug, balance). First step: playtest on a real iPhone.

## What changed (this session, after v1)
- Idle minions: each unused minion gathers 1 resource of choice at Collect, never MacGuffin.
- Going-second bonus: 1 resource of choice, never MacGuffin.
- Ether Lens back to 2 Magic (Tesla was 53.5% with the Exchange).
- MacGuffin Exchange: once per turn, trade 5 non-MacGuffin resources for 1 MacGuffin (taskbar button; pays from the largest piles). `config.exchangeCost`.

## Balance now (3,000 AI games)
- Tesla 49.5% / Edison 50.5%, first player 51%, median 13 rounds (p90 18), 0 errors.
- Before the Exchange, 29% of games had no MacGuffin for either player by round 13; now 0%.

## Decisions made (and why)
- Exchange at 5-for-1 rather than 4-for-1: it still ends the drought, while a real producer stays clearly better.
- Cheaper or extra producer cards were tested and rejected: the board fills before they get built (22% drought even with both).
- A neutral MacGuffin Mine was rejected: both players worked it every turn from round 1, which removed scarcity entirely.
- Earlier: Induction Motor 1 E + 2 Magic (Tesla Magic starvation); AI scraps when the board is full.

## Open items
- The UI test bot occasionally stalls at the discard confirm step. Six instrumented runs passed, so it's likely bot timing, but check the discard flow on device.
- Run balance checks with 3,000+ games; 400 games swings about ±2.5 points.
- Spec items not yet built: scripted tutorial, smarter AI (bluffing, holding cards), deck editor, native iOS port.

## Read first next time
- docs/PROJECT.md, then `src/js/engine-actions.js` and `src/js/ai.js` for rules or balance work, or `ui-match.js` and `controller.js` for UI.
